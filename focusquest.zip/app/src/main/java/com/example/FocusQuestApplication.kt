package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.backup.BackupManager
import com.example.data.local.AppDatabase
import com.example.data.repository.DayRepository
import com.example.data.repository.FPRepository
import com.example.data.repository.ScheduleRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TrackedAppRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FocusQuestApplication : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var dayRepository: DayRepository
        private set
    lateinit var scheduleRepository: ScheduleRepository
        private set
    lateinit var trackedAppRepository: TrackedAppRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var fpRepository: FPRepository
        private set
    lateinit var backupManager: BackupManager
        private set

    private val applicationScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        dayRepository = DayRepository(database.dayRecordDao(), database.appUsageEventDao())
        scheduleRepository = ScheduleRepository(database.scheduleBlockDao())
        trackedAppRepository = TrackedAppRepository(database.trackedAppDao())
        settingsRepository = SettingsRepository(this)
        backupManager = BackupManager(this, database)

        fpRepository = FPRepository(
            dayRepository = dayRepository,
            scheduleRepository = scheduleRepository,
            trackedAppRepository = trackedAppRepository,
            settingsRepository = settingsRepository
        )

        createNotificationChannels()

        applicationScope.launch {
            scheduleRepository.ensureDefaultSchedule()
            trackedAppRepository.seedDefaultsIfEmpty()
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val fgsChannel = NotificationChannel(
                CHANNEL_ID_FGS,
                getString(R.string.foreground_service_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.foreground_service_channel_desc)
                setShowBadge(false)
            }

            val soundUri = android.net.Uri.parse(
                "${android.content.ContentResolver.SCHEME_ANDROID_RESOURCE}://${packageName}/${R.raw.focus_notification_sound}"
            )
            val audioAttributes = android.media.AudioAttributes.Builder()
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .build()

            val alertChannel = NotificationChannel(
                CHANNEL_ID_ALERTS,
                "Focus Reminders & Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies for block reminders and background service status"
                setSound(soundUri, audioAttributes)
                enableVibration(true)
            }

            manager.createNotificationChannel(fgsChannel)
            manager.createNotificationChannel(alertChannel)
        }
    }

    companion object {
        const val CHANNEL_ID_FGS = "focusquest_fgs_channel"
        const val CHANNEL_ID_ALERTS = "focusquest_alerts_v2"

        lateinit var instance: FocusQuestApplication
            private set
    }
}
