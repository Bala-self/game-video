package com.example.service.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.FocusQuestApplication
import com.example.MainActivity
import com.example.R
import com.example.service.foreground.FocusForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val scope = CoroutineScope(Dispatchers.Default)

        when (action) {
            ACTION_RESTART_SERVICE -> {
                startForegroundServiceCompat(context)
            }
            ACTION_DAY_BOUNDARY -> {
                scope.launch {
                    FocusQuestApplication.instance.fpRepository.triggerDayBoundary()
                }
            }
            ACTION_HEARTBEAT -> {
                scope.launch {
                    val lastHeartbeat = FocusQuestApplication.instance.settingsRepository.heartbeatTimestamp.first()
                    val diff = System.currentTimeMillis() - lastHeartbeat
                    // If stale beyond 30 minutes, notify user gracefully (Part 5.6 HeartbeatWorker)
                    if (diff > 30 * 60 * 1000L) {
                        notifyServiceKilled(context)
                    }
                }
            }
            ACTION_SCHEDULE_REMINDER -> {
                val label = intent.getStringExtra("block_label") ?: "Focus Block"
                notifyBlockReminder(context, label)
            }
        }
    }

    private fun startForegroundServiceCompat(context: Context) {
        val fgsIntent = Intent(context, FocusForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(fgsIntent)
        } else {
            context.startService(fgsIntent)
        }
    }

    private fun notifyServiceKilled(context: Context) {
        val tapIntent = Intent(context, MainActivity::class.java).apply {
            putExtra("navigate_to", "permissions")
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            201,
            tapIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, FocusQuestApplication.CHANNEL_ID_ALERTS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(context.getString(R.string.heartbeat_notification_title))
            .setContentText(context.getString(R.string.heartbeat_notification_text))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(2001, notification)
    }

    private fun notifyBlockReminder(context: Context, blockLabel: String) {
        val tapIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            202,
            tapIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val soundUri = android.net.Uri.parse(
            "${android.content.ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.focus_notification_sound}"
        )

        val notification = NotificationCompat.Builder(context, FocusQuestApplication.CHANNEL_ID_ALERTS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Schedule Transition")
            .setContentText("Starting soon: $blockLabel")
            .setContentIntent(pendingIntent)
            .setSound(soundUri)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(2002, notification)
    }

    companion object {
        const val ACTION_RESTART_SERVICE = "com.focusquest.app.ACTION_RESTART_SERVICE"
        const val ACTION_DAY_BOUNDARY = "com.focusquest.app.ACTION_DAY_BOUNDARY"
        const val ACTION_HEARTBEAT = "com.focusquest.app.ACTION_HEARTBEAT"
        const val ACTION_SCHEDULE_REMINDER = "com.focusquest.app.ACTION_SCHEDULE_REMINDER"
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val fgsIntent = Intent(context, FocusForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(fgsIntent)
        } else {
            context.startService(fgsIntent)
        }
    }
}
