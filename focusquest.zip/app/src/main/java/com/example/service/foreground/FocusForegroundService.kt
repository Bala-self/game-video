package com.example.service.foreground

import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.example.FocusQuestApplication
import com.example.MainActivity
import com.example.R
import com.example.overlay.OverlayWindowManager
import com.example.service.receiver.AlarmReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class FocusForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var overlayManager: OverlayWindowManager? = null
    private var stateObserverJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        overlayManager = OverlayWindowManager(this)
        FocusQuestApplication.instance.fpRepository.setServiceRunningState(true)

        startAsForeground()
        observeFpState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        serviceScope.launch {
            FocusQuestApplication.instance.settingsRepository.updateHeartbeat()
            val overlayEnabled = FocusQuestApplication.instance.settingsRepository.isOverlayEnabled.first()
            if (overlayEnabled) {
                overlayManager?.showOverlay()
            } else {
                overlayManager?.hideOverlay()
            }
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val notification = buildNotification(100, "Focused")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun observeFpState() {
        stateObserverJob?.cancel()
        stateObserverJob = serviceScope.launch {
            var lastFp = -1
            FocusQuestApplication.instance.fpRepository.fpState.collect { state ->
                if (state.currentFp != lastFp) {
                    lastFp = state.currentFp
                    overlayManager?.notifyFpChanged()
                    val notification = buildNotification(state.currentFp, state.tier.label)
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    manager.notify(NOTIFICATION_ID, notification)
                }
            }
        }
    }

    private fun buildNotification(fp: Int, tierLabel: String): Notification {
        val tapIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            tapIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, FocusQuestApplication.CHANNEL_ID_FGS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Focus Companion")
            .setContentText("$tierLabel · $fp FP")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Part 5.6: Restart via PendingIntent + AlarmManager.setAndAllowWhileIdle()
        val restartIntent = Intent(applicationContext, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_RESTART_SERVICE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            applicationContext,
            101,
            restartIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_ONE_SHOT
        )
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 2000L,
            pendingIntent
        )
    }

    override fun onDestroy() {
        FocusQuestApplication.instance.fpRepository.setServiceRunningState(false)
        stateObserverJob?.cancel()
        overlayManager?.hideOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}
