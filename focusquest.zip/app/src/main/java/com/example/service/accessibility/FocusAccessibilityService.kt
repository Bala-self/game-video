package com.example.service.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.example.FocusQuestApplication
import com.example.service.foreground.FocusForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FocusAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var lastObservedPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return

        // Ignore internal same-package events to reduce noise per Part 5.6
        if (packageName == lastObservedPackage) return
        lastObservedPackage = packageName

        // Ignore system UI or launcher transitions if appropriate
        if (packageName == "com.android.systemui" || packageName == applicationContext.packageName) {
            // Internal app navigation
            return
        }

        serviceScope.launch {
            FocusQuestApplication.instance.fpRepository.onForegroundAppChanged(packageName)
        }
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Ensure foreground service is running
        val fgsIntent = Intent(this, FocusForegroundService::class.java)
        try {
            startService(fgsIntent)
        } catch (e: Exception) {
            // Android 8+ may require startForegroundService
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(fgsIntent)
            }
        }
    }
}
