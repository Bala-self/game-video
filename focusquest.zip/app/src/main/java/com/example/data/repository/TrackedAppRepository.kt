package com.example.data.repository

import com.example.data.local.dao.TrackedAppDao
import com.example.data.local.entity.TrackedAppEntity
import com.example.domain.model.AppCategory
import com.example.domain.model.TrackedAppModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class TrackedAppRepository(private val trackedAppDao: TrackedAppDao) {

    fun getAllTrackedApps(): Flow<List<TrackedAppModel>> {
        return trackedAppDao.getAllTrackedApps().map { list ->
            list.map { it.toModel() }
        }
    }

    suspend fun getAppCategory(packageName: String): AppCategory {
        val app = trackedAppDao.getByPackage(packageName)
        if (app != null) {
            return try { AppCategory.valueOf(app.category) } catch (e: Exception) { AppCategory.NEUTRAL }
        }
        // Known package heuristic if not explicitly saved
        return when {
            isCommonDistractingPackage(packageName) -> AppCategory.DISTRACTING
            isCommonFocusPackage(packageName) -> AppCategory.FOCUS
            else -> AppCategory.NEUTRAL
        }
    }

    suspend fun insertOrUpdate(model: TrackedAppModel) {
        trackedAppDao.insert(
            TrackedAppEntity(
                packageName = model.packageName,
                displayName = model.displayName,
                category = model.category.name,
                isGlobal = model.isGlobal
            )
        )
    }

    suspend fun delete(packageName: String) {
        trackedAppDao.delete(packageName)
    }

    suspend fun seedDefaultsIfEmpty() {
        val existing = trackedAppDao.getAllTrackedApps().first()
        if (existing.isEmpty()) {
            val defaults = listOf(
                TrackedAppModel("com.google.android.youtube", "YouTube", AppCategory.DISTRACTING),
                TrackedAppModel("com.instagram.android", "Instagram", AppCategory.DISTRACTING),
                TrackedAppModel("com.twitter.android", "X / Twitter", AppCategory.DISTRACTING),
                TrackedAppModel("com.reddit.frontpage", "Reddit", AppCategory.DISTRACTING),
                TrackedAppModel("com.zhiliaoapp.musically", "TikTok", AppCategory.DISTRACTING),
                TrackedAppModel("com.netflix.mediaclient", "Netflix", AppCategory.DISTRACTING),
                TrackedAppModel("tv.twitch.android.app", "Twitch", AppCategory.DISTRACTING),
                TrackedAppModel("com.facebook.katana", "Facebook", AppCategory.DISTRACTING),
                TrackedAppModel("com.google.android.apps.docs", "Google Docs", AppCategory.FOCUS),
                TrackedAppModel("notion.id", "Notion", AppCategory.FOCUS),
                TrackedAppModel("com.slack", "Slack", AppCategory.FOCUS),
                TrackedAppModel("com.google.android.apps.books", "Play Books", AppCategory.FOCUS)
            )
            defaults.forEach { insertOrUpdate(it) }
        }
    }

    suspend fun clearAll() {
        trackedAppDao.clearAll()
    }

    private fun isCommonDistractingPackage(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.contains("youtube") || lower.contains("instagram") ||
                lower.contains("twitter") || lower.contains("reddit") ||
                lower.contains("tiktok") || lower.contains("netflix") ||
                lower.contains("twitch") || lower.contains("facebook") ||
                lower.contains("game")
    }

    private fun isCommonFocusPackage(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.contains("notion") || lower.contains("docs") ||
                lower.contains("slack") || lower.contains("reader") ||
                lower.contains("books") || lower.contains("learn")
    }

    private fun TrackedAppEntity.toModel(): TrackedAppModel {
        val cat = try { AppCategory.valueOf(category) } catch (e: Exception) { AppCategory.NEUTRAL }
        return TrackedAppModel(
            packageName = packageName,
            displayName = displayName,
            category = cat,
            isGlobal = isGlobal
        )
    }
}
