package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.AppUsageEventDao
import com.example.data.local.dao.DayRecordDao
import com.example.data.local.dao.ScheduleBlockDao
import com.example.data.local.dao.TrackedAppDao
import com.example.data.local.entity.AppUsageEventEntity
import com.example.data.local.entity.DayRecordEntity
import com.example.data.local.entity.ScheduleBlockEntity
import com.example.data.local.entity.TrackedAppEntity
import java.util.concurrent.Executors

@Database(
    entities = [
        DayRecordEntity::class,
        AppUsageEventEntity::class,
        ScheduleBlockEntity::class,
        TrackedAppEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dayRecordDao(): DayRecordDao
    abstract fun appUsageEventDao(): AppUsageEventDao
    abstract fun scheduleBlockDao(): ScheduleBlockDao
    abstract fun trackedAppDao(): TrackedAppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val queryExecutor = Executors.newFixedThreadPool(4)
                val transactionExecutor = Executors.newSingleThreadExecutor()

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "focusquest.db"
                )
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                    .setQueryExecutor(queryExecutor)
                    .setTransactionExecutor(transactionExecutor)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
