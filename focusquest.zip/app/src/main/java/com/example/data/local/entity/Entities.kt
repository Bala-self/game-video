package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "day_records")
data class DayRecordEntity(
    @PrimaryKey val date: String,          // ISO-8601 "yyyy-MM-dd"
    val finalFp: Int,
    val endingTier: String,                // GOOD / NEUTRAL / ROUGH / DEFEATED
    val intentionText: String?,
    val forgivenessTokenUsed: Boolean,
    val dayStartTimestamp: Long,
    val dayEndTimestamp: Long?
)

@Entity(
    tableName = "app_usage_events",
    indices = [Index(value = ["timestamp"]), Index(value = ["packageName"])]
)
data class AppUsageEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,                      // FK-style link to DayRecordEntity.date
    val packageName: String,
    val timestamp: Long,
    val durationSeconds: Int,
    val category: String                   // DISTRACTING / FOCUS / NEUTRAL
)

@Entity(tableName = "schedule_blocks")
data class ScheduleBlockEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val type: String,                      // FOCUS / BREAK
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val sortOrder: Int,
    val reminderEnabled: Boolean,
    val reminderLeadMinutes: Int,
    val distractingAppsCsv: String = ""    // package names separated by comma
)

@Entity(tableName = "tracked_apps")
data class TrackedAppEntity(
    @PrimaryKey val packageName: String,
    val displayName: String,
    val category: String,                  // DISTRACTING / FOCUS / NEUTRAL
    val isGlobal: Boolean = true,          // applies to all blocks unless block overrides
    val scheduleBlockIdOverride: Long? = null
)
