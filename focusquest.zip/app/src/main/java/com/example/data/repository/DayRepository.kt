package com.example.data.repository

import com.example.data.local.dao.AppUsageEventDao
import com.example.data.local.dao.DayRecordDao
import com.example.data.local.entity.AppUsageEventEntity
import com.example.data.local.entity.DayRecordEntity
import com.example.domain.model.AppCategory
import com.example.domain.model.AppUsageSummary
import com.example.domain.model.EndingType
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DayRepository(
    private val dayRecordDao: DayRecordDao,
    private val appUsageEventDao: AppUsageEventDao
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun getTodayDateString(): String = dateFormat.format(Date())

    fun getAllDays(): Flow<List<DayRecordEntity>> = dayRecordDao.getAllDays()

    suspend fun getDayByDate(date: String): DayRecordEntity? = dayRecordDao.getDayByDate(date)

    fun observeDayByDate(date: String): Flow<DayRecordEntity?> = dayRecordDao.observeDayByDate(date)

    suspend fun saveDay(day: DayRecordEntity) {
        dayRecordDao.insertOrUpdate(day)
    }

    suspend fun recordUsage(date: String, packageName: String, durationSeconds: Int, category: AppCategory) {
        if (durationSeconds <= 0) return
        appUsageEventDao.insertEvent(
            AppUsageEventEntity(
                date = date,
                packageName = packageName,
                timestamp = System.currentTimeMillis(),
                durationSeconds = durationSeconds,
                category = category.name
            )
        )
    }

    suspend fun getAggregatedUsageForDate(date: String): List<AppUsageSummary> {
        val list = appUsageEventDao.getAggregatedUsageForDate(date)
        return list.map {
            val cat = try { AppCategory.valueOf(it.category) } catch (e: Exception) { AppCategory.NEUTRAL }
            val cleanName = it.packageName.substringAfterLast(".").replaceFirstChar { char -> char.uppercase() }
            AppUsageSummary(
                packageName = it.packageName,
                displayName = cleanName,
                durationSeconds = it.totalDuration,
                category = cat
            )
        }
    }

    suspend fun initializeDayIfAbsent(date: String = getTodayDateString()): DayRecordEntity {
        val existing = dayRecordDao.getDayByDate(date)
        if (existing != null) return existing
        val newDay = DayRecordEntity(
            date = date,
            finalFp = 100,
            endingTier = EndingType.GOOD.name,
            intentionText = null,
            forgivenessTokenUsed = false,
            dayStartTimestamp = System.currentTimeMillis(),
            dayEndTimestamp = null
        )
        dayRecordDao.insertOrUpdate(newDay)
        return newDay
    }

    suspend fun clearAll() {
        dayRecordDao.clearAll()
        appUsageEventDao.clearAll()
    }
}
