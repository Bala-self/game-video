package com.example.data.repository

import com.example.data.local.dao.ScheduleBlockDao
import com.example.data.local.entity.ScheduleBlockEntity
import com.example.domain.model.BlockType
import com.example.domain.model.ScheduleBlockModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.Calendar

class ScheduleRepository(private val scheduleBlockDao: ScheduleBlockDao) {

    fun getAllBlocks(): Flow<List<ScheduleBlockModel>> {
        return scheduleBlockDao.getAllBlocks().map { list ->
            list.map { it.toModel() }
        }
    }

    suspend fun getActiveBlockForMinute(minuteOfDay: Int): ScheduleBlockModel? {
        val all = scheduleBlockDao.getAllBlocks().first()
        return all.firstOrNull { entity ->
            if (entity.startMinuteOfDay <= entity.endMinuteOfDay) {
                minuteOfDay in entity.startMinuteOfDay until entity.endMinuteOfDay
            } else {
                // Overnight block
                minuteOfDay >= entity.startMinuteOfDay || minuteOfDay < entity.endMinuteOfDay
            }
        }?.toModel()
    }

    suspend fun getCurrentBlock(): ScheduleBlockModel? {
        val calendar = Calendar.getInstance()
        val currentMinute = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        return getActiveBlockForMinute(currentMinute)
    }

    suspend fun insertBlock(model: ScheduleBlockModel): Long {
        return scheduleBlockDao.insert(model.toEntity())
    }

    suspend fun updateBlock(model: ScheduleBlockModel) {
        scheduleBlockDao.update(model.toEntity())
    }

    suspend fun deleteBlock(id: Long) {
        scheduleBlockDao.deleteById(id)
    }

    suspend fun ensureDefaultSchedule() {
        val existing = scheduleBlockDao.getAllBlocks().first()
        if (existing.isEmpty()) {
            val defaults = listOf(
                ScheduleBlockEntity(
                    label = "Morning Deep Work",
                    type = BlockType.FOCUS.name,
                    startMinuteOfDay = 9 * 60, // 09:00
                    endMinuteOfDay = 12 * 60,  // 12:00
                    sortOrder = 1,
                    reminderEnabled = true,
                    reminderLeadMinutes = 5
                ),
                ScheduleBlockEntity(
                    label = "Midday Recharge",
                    type = BlockType.BREAK.name,
                    startMinuteOfDay = 12 * 60, // 12:00
                    endMinuteOfDay = 13 * 60,  // 13:00
                    sortOrder = 2,
                    reminderEnabled = true,
                    reminderLeadMinutes = 5
                ),
                ScheduleBlockEntity(
                    label = "Afternoon Flow",
                    type = BlockType.FOCUS.name,
                    startMinuteOfDay = 13 * 60, // 13:00
                    endMinuteOfDay = 17 * 60,  // 17:00
                    sortOrder = 3,
                    reminderEnabled = true,
                    reminderLeadMinutes = 5
                ),
                ScheduleBlockEntity(
                    label = "Evening Wind Down",
                    type = BlockType.BREAK.name,
                    startMinuteOfDay = 20 * 60, // 20:00
                    endMinuteOfDay = 22 * 60,  // 22:00
                    sortOrder = 4,
                    reminderEnabled = false,
                    reminderLeadMinutes = 5
                )
            )
            defaults.forEach { scheduleBlockDao.insert(it) }
        }
    }

    suspend fun clearAll() {
        scheduleBlockDao.clearAll()
    }

    private fun ScheduleBlockEntity.toModel(): ScheduleBlockModel {
        val blockType = try { BlockType.valueOf(type) } catch (e: Exception) { BlockType.FOCUS }
        val overrides = if (distractingAppsCsv.isBlank()) emptyList() else distractingAppsCsv.split(",")
        return ScheduleBlockModel(
            id = id,
            label = label,
            type = blockType,
            startMinuteOfDay = startMinuteOfDay,
            endMinuteOfDay = endMinuteOfDay,
            sortOrder = sortOrder,
            reminderEnabled = reminderEnabled,
            reminderLeadMinutes = reminderLeadMinutes,
            distractingAppsOverride = overrides
        )
    }

    private fun ScheduleBlockModel.toEntity(): ScheduleBlockEntity {
        return ScheduleBlockEntity(
            id = id,
            label = label,
            type = type.name,
            startMinuteOfDay = startMinuteOfDay,
            endMinuteOfDay = endMinuteOfDay,
            sortOrder = sortOrder,
            reminderEnabled = reminderEnabled,
            reminderLeadMinutes = reminderLeadMinutes,
            distractingAppsCsv = distractingAppsOverride.joinToString(",")
        )
    }
}
