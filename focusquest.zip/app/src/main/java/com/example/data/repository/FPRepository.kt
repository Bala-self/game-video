package com.example.data.repository

import com.example.data.local.entity.DayRecordEntity
import com.example.domain.model.AppCategory
import com.example.domain.model.EndingType
import com.example.domain.model.FPTier
import com.example.domain.model.FPState
import com.example.domain.model.ScheduleBlockModel
import com.example.domain.usecase.CalculateFPUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class FPRepository(
    private val dayRepository: DayRepository,
    private val scheduleRepository: ScheduleRepository,
    private val trackedAppRepository: TrackedAppRepository,
    private val settingsRepository: SettingsRepository
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val calculateFPUseCase = CalculateFPUseCase()

    private var exactFpFloat = 100f
    private var continuousAppSeconds = 0
    private var currentPackageName: String? = null
    private var lastRecordedPackage: String? = null
    private var lastSwitchTimestamp: Long = 0L

    private var forgivenessShieldEndTimestamp: Long = 0L
    private var tickerJob: Job? = null

    private val _fpState = MutableStateFlow(FPState())
    val fpState: StateFlow<FPState> = _fpState.asStateFlow()

    init {
        scope.launch {
            loadInitialState()
            startEngineLoop()
        }
    }

    private suspend fun loadInitialState() {
        val today = dayRepository.initializeDayIfAbsent()
        exactFpFloat = today.finalFp.toFloat().coerceIn(0f, 100f)
        val tier = FPTier.fromFp(exactFpFloat.roundToInt())
        val currentBlock = scheduleRepository.getCurrentBlock()

        _fpState.update {
            it.copy(
                currentFp = exactFpFloat.roundToInt(),
                tier = tier,
                currentBlock = currentBlock
            )
        }
    }

    private fun startEngineLoop() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            var lastSaveCounter = 0
            while (true) {
                delay(1000L) // 1 second tick
                tickOneSecond()

                lastSaveCounter++
                if (lastSaveCounter >= 10) { // save to db every 10 seconds
                    lastSaveCounter = 0
                    saveCurrentFpToDb()
                }
            }
        }
    }

    private suspend fun tickOneSecond() {
        val now = System.currentTimeMillis()
        val isShieldActive = now < forgivenessShieldEndTimestamp
        val shieldRemainingSeconds = if (isShieldActive) {
            ((forgivenessShieldEndTimestamp - now) / 1000).toInt().coerceAtLeast(0)
        } else {
            0
        }

        val activeBlock = scheduleRepository.getCurrentBlock()
        val category = _fpState.value.activeAppCategory

        if (currentPackageName != null) {
            continuousAppSeconds++
        }

        val delta = calculateFPUseCase.calculateDelta(
            intervalSeconds = 1,
            category = category,
            continuousSeconds = continuousAppSeconds,
            activeBlock = activeBlock,
            isShieldActive = isShieldActive
        )

        exactFpFloat = (exactFpFloat + delta).coerceIn(0f, 100f)
        val roundedFp = exactFpFloat.roundToInt()
        val newTier = FPTier.fromFp(roundedFp)

        _fpState.update {
            it.copy(
                currentFp = roundedFp,
                tier = newTier,
                isForgivenessShieldActive = isShieldActive,
                shieldRemainingSeconds = shieldRemainingSeconds,
                currentBlock = activeBlock
            )
        }
    }

    suspend fun onForegroundAppChanged(packageName: String, label: String? = null) {
        val now = System.currentTimeMillis()

        // Debounce / Grace window protection per Part 2.4 (15 seconds)
        if (packageName == currentPackageName) return

        // Flush recorded duration for previous app to Room if stayed >= 15 seconds
        if (currentPackageName != null && continuousAppSeconds >= CalculateFPUseCase.GRACE_WINDOW_SECONDS) {
            dayRepository.recordUsage(
                date = dayRepository.getTodayDateString(),
                packageName = currentPackageName!!,
                durationSeconds = continuousAppSeconds,
                category = _fpState.value.activeAppCategory
            )
        }

        currentPackageName = packageName
        continuousAppSeconds = 0
        lastSwitchTimestamp = now

        val category = trackedAppRepository.getAppCategory(packageName)
        val displayName = label ?: packageName.substringAfterLast(".").replaceFirstChar { it.uppercase() }

        _fpState.update {
            it.copy(
                activePackageName = packageName,
                activeAppDisplayName = displayName,
                activeAppCategory = category
            )
        }
    }

    suspend fun activateForgivenessShield(): Boolean {
        if (_fpState.value.isForgivenessShieldActive) return false
        val tokenUsed = settingsRepository.useForgivenessToken()
        if (tokenUsed) {
            val now = System.currentTimeMillis()
            forgivenessShieldEndTimestamp = now + (CalculateFPUseCase.FORGIVENESS_DURATION_SECONDS * 1000L)
            _fpState.update {
                it.copy(
                    isForgivenessShieldActive = true,
                    shieldRemainingSeconds = CalculateFPUseCase.FORGIVENESS_DURATION_SECONDS
                )
            }
            // Record token used in today's record
            val todayStr = dayRepository.getTodayDateString()
            val existing = dayRepository.getDayByDate(todayStr)
            if (existing != null) {
                dayRepository.saveDay(existing.copy(forgivenessTokenUsed = true))
            }
            return true
        }
        return false
    }

    suspend fun resetFpTo100(intention: String? = null) {
        exactFpFloat = 100f
        continuousAppSeconds = 0
        val roundedFp = 100
        val todayStr = dayRepository.getTodayDateString()

        val dayRecord = DayRecordEntity(
            date = todayStr,
            finalFp = 100,
            endingTier = EndingType.GOOD.name,
            intentionText = intention,
            forgivenessTokenUsed = false,
            dayStartTimestamp = System.currentTimeMillis(),
            dayEndTimestamp = null
        )
        dayRepository.saveDay(dayRecord)

        if (!intention.isNullOrBlank()) {
            settingsRepository.setTodayIntention(intention)
        }
        settingsRepository.setMorningRoutineCompleted(todayStr)

        _fpState.update {
            it.copy(
                currentFp = roundedFp,
                tier = FPTier.FOCUSED
            )
        }
    }

    suspend fun triggerDayBoundary() {
        val todayStr = dayRepository.getTodayDateString()
        val currentFp = _fpState.value.currentFp
        val ending = EndingType.fromFp(currentFp)
        val existing = dayRepository.getDayByDate(todayStr) ?: dayRepository.initializeDayIfAbsent(todayStr)

        val completedDay = existing.copy(
            finalFp = currentFp,
            endingTier = ending.name,
            dayEndTimestamp = System.currentTimeMillis()
        )
        dayRepository.saveDay(completedDay)
        settingsRepository.setLastEndingAcknowledged(todayStr)
    }

    private suspend fun saveCurrentFpToDb() {
        val todayStr = dayRepository.getTodayDateString()
        val existing = dayRepository.getDayByDate(todayStr)
        if (existing != null) {
            val currentFp = _fpState.value.currentFp
            dayRepository.saveDay(
                existing.copy(
                    finalFp = currentFp,
                    endingTier = EndingType.fromFp(currentFp).name
                )
            )
        }
    }

    fun setServiceRunningState(isRunning: Boolean) {
        _fpState.update { it.copy(isServiceRunning = isRunning) }
    }

    // Testing helper for simulating app change in developer / emulator mode
    fun simulateAppSwitch(packageName: String, label: String, category: AppCategory) {
        scope.launch {
            trackedAppRepository.insertOrUpdate(
                com.example.domain.model.TrackedAppModel(
                    packageName = packageName,
                    displayName = label,
                    category = category
                )
            )
            onForegroundAppChanged(packageName, label)
        }
    }
}
