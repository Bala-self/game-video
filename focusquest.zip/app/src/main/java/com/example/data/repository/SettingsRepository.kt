package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.PersonalityTone
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "focusquest_settings")

class SettingsRepository(private val context: Context) {

    private object PreferencesKeys {
        val IS_FIRST_RUN = booleanPreferencesKey("is_first_run")
        val PERSONALITY_TONE = stringPreferencesKey("personality_tone")
        val DAY_BOUNDARY_HOUR = intPreferencesKey("day_boundary_hour")
        val DAY_BOUNDARY_MINUTE = intPreferencesKey("day_boundary_minute")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val FORGIVENESS_TOKENS = intPreferencesKey("forgiveness_tokens")
        val FORGIVENESS_CADENCE = stringPreferencesKey("forgiveness_cadence")
        val IS_OVERLAY_ENABLED = booleanPreferencesKey("is_overlay_enabled")
        val LAST_BACKUP_TIMESTAMP = longPreferencesKey("last_backup_timestamp")
        val TODAY_INTENTION = stringPreferencesKey("today_intention")
        val MORNING_ROUTINE_DATE = stringPreferencesKey("morning_routine_date")
        val LAST_ENDING_ACKNOWLEDGED_DATE = stringPreferencesKey("last_ending_acknowledged_date")
        val HEARTBEAT_TIMESTAMP = longPreferencesKey("heartbeat_timestamp")
    }

    val isFirstRun: Flow<Boolean> = context.dataStore.data.map { it[PreferencesKeys.IS_FIRST_RUN] ?: true }

    val personalityTone: Flow<PersonalityTone> = context.dataStore.data.map {
        val name = it[PreferencesKeys.PERSONALITY_TONE] ?: PersonalityTone.GENTLE.name
        try { PersonalityTone.valueOf(name) } catch (e: Exception) { PersonalityTone.GENTLE }
    }

    val dayBoundaryHour: Flow<Int> = context.dataStore.data.map { it[PreferencesKeys.DAY_BOUNDARY_HOUR] ?: 0 }
    val dayBoundaryMinute: Flow<Int> = context.dataStore.data.map { it[PreferencesKeys.DAY_BOUNDARY_MINUTE] ?: 0 }
    val themeMode: Flow<String> = context.dataStore.data.map { it[PreferencesKeys.THEME_MODE] ?: "dark" }
    val forgivenessTokens: Flow<Int> = context.dataStore.data.map { it[PreferencesKeys.FORGIVENESS_TOKENS] ?: 2 }
    val forgivenessCadence: Flow<String> = context.dataStore.data.map { it[PreferencesKeys.FORGIVENESS_CADENCE] ?: "weekly" }
    val isOverlayEnabled: Flow<Boolean> = context.dataStore.data.map { it[PreferencesKeys.IS_OVERLAY_ENABLED] ?: true }
    val lastBackupTimestamp: Flow<Long> = context.dataStore.data.map { it[PreferencesKeys.LAST_BACKUP_TIMESTAMP] ?: 0L }
    val todayIntention: Flow<String> = context.dataStore.data.map { it[PreferencesKeys.TODAY_INTENTION] ?: "" }
    val morningRoutineDate: Flow<String> = context.dataStore.data.map { it[PreferencesKeys.MORNING_ROUTINE_DATE] ?: "" }
    val lastEndingDate: Flow<String> = context.dataStore.data.map { it[PreferencesKeys.LAST_ENDING_ACKNOWLEDGED_DATE] ?: "" }
    val heartbeatTimestamp: Flow<Long> = context.dataStore.data.map { it[PreferencesKeys.HEARTBEAT_TIMESTAMP] ?: 0L }

    suspend fun setFirstRunCompleted() {
        context.dataStore.edit { it[PreferencesKeys.IS_FIRST_RUN] = false }
    }

    suspend fun setPersonalityTone(tone: PersonalityTone) {
        context.dataStore.edit { it[PreferencesKeys.PERSONALITY_TONE] = tone.name }
    }

    suspend fun setDayBoundaryTime(hour: Int, minute: Int) {
        context.dataStore.edit {
            it[PreferencesKeys.DAY_BOUNDARY_HOUR] = hour
            it[PreferencesKeys.DAY_BOUNDARY_MINUTE] = minute
        }
    }

    suspend fun setThemeMode(theme: String) {
        context.dataStore.edit { it[PreferencesKeys.THEME_MODE] = theme }
    }

    suspend fun setForgivenessTokens(count: Int) {
        context.dataStore.edit { it[PreferencesKeys.FORGIVENESS_TOKENS] = count.coerceAtLeast(0) }
    }

    suspend fun useForgivenessToken(): Boolean {
        var used = false
        context.dataStore.edit {
            val current = it[PreferencesKeys.FORGIVENESS_TOKENS] ?: 2
            if (current > 0) {
                it[PreferencesKeys.FORGIVENESS_TOKENS] = current - 1
                used = true
            }
        }
        return used
    }

    suspend fun setForgivenessCadence(cadence: String) {
        context.dataStore.edit { it[PreferencesKeys.FORGIVENESS_CADENCE] = cadence }
    }

    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.IS_OVERLAY_ENABLED] = enabled }
    }

    suspend fun setLastBackupTimestamp(timestamp: Long) {
        context.dataStore.edit { it[PreferencesKeys.LAST_BACKUP_TIMESTAMP] = timestamp }
    }

    suspend fun setTodayIntention(intention: String) {
        context.dataStore.edit { it[PreferencesKeys.TODAY_INTENTION] = intention }
    }

    suspend fun setMorningRoutineCompleted(date: String) {
        context.dataStore.edit { it[PreferencesKeys.MORNING_ROUTINE_DATE] = date }
    }

    suspend fun setLastEndingAcknowledged(date: String) {
        context.dataStore.edit { it[PreferencesKeys.LAST_ENDING_ACKNOWLEDGED_DATE] = date }
    }

    suspend fun updateHeartbeat(timestamp: Long = System.currentTimeMillis()) {
        context.dataStore.edit { it[PreferencesKeys.HEARTBEAT_TIMESTAMP] = timestamp }
    }

    suspend fun clearAll() {
        context.dataStore.edit { it.clear() }
    }
}
