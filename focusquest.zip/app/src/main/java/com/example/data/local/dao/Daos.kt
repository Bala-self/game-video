package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AppUsageEventEntity
import com.example.data.local.entity.DayRecordEntity
import com.example.data.local.entity.ScheduleBlockEntity
import com.example.data.local.entity.TrackedAppEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DayRecordDao {
    @Query("SELECT * FROM day_records ORDER BY date DESC")
    fun getAllDays(): Flow<List<DayRecordEntity>>

    @Query("SELECT * FROM day_records WHERE date = :date LIMIT 1")
    suspend fun getDayByDate(date: String): DayRecordEntity?

    @Query("SELECT * FROM day_records WHERE date = :date LIMIT 1")
    fun observeDayByDate(date: String): Flow<DayRecordEntity?>

    @Query("SELECT finalFp FROM day_records WHERE date = :date LIMIT 1")
    fun observeFpForDate(date: String): Flow<Int?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(day: DayRecordEntity)

    @Query("DELETE FROM day_records")
    suspend fun clearAll()
}

@Dao
interface AppUsageEventDao {
    @Query("SELECT * FROM app_usage_events WHERE date = :date ORDER BY durationSeconds DESC")
    fun getEventsForDate(date: String): Flow<List<AppUsageEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: AppUsageEventEntity)

    @Query("SELECT packageName, category, SUM(durationSeconds) as totalDuration FROM app_usage_events WHERE date = :date GROUP BY packageName ORDER BY totalDuration DESC")
    suspend fun getAggregatedUsageForDate(date: String): List<AppUsageSummaryDb>

    @Query("DELETE FROM app_usage_events")
    suspend fun clearAll()
}

data class AppUsageSummaryDb(
    val packageName: String,
    val category: String,
    val totalDuration: Int
)

@Dao
interface ScheduleBlockDao {
    @Query("SELECT * FROM schedule_blocks ORDER BY sortOrder ASC, startMinuteOfDay ASC")
    fun getAllBlocks(): Flow<List<ScheduleBlockEntity>>

    @Query("SELECT * FROM schedule_blocks WHERE id = :id LIMIT 1")
    suspend fun getBlockById(id: Long): ScheduleBlockEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(block: ScheduleBlockEntity): Long

    @Update
    suspend fun update(block: ScheduleBlockEntity)

    @Query("DELETE FROM schedule_blocks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM schedule_blocks")
    suspend fun clearAll()
}

@Dao
interface TrackedAppDao {
    @Query("SELECT * FROM tracked_apps ORDER BY displayName ASC")
    fun getAllTrackedApps(): Flow<List<TrackedAppEntity>>

    @Query("SELECT * FROM tracked_apps WHERE packageName = :packageName LIMIT 1")
    suspend fun getByPackage(packageName: String): TrackedAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(apps: List<TrackedAppEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(app: TrackedAppEntity)

    @Query("DELETE FROM tracked_apps WHERE packageName = :packageName")
    suspend fun delete(packageName: String)

    @Query("DELETE FROM tracked_apps")
    suspend fun clearAll()
}
