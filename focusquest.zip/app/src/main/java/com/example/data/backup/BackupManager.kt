package com.example.data.backup

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.entity.DayRecordEntity
import com.example.data.local.entity.ScheduleBlockEntity
import com.example.data.local.entity.TrackedAppEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class BackupSummary(
    val dayRecordsCount: Int,
    val scheduleBlocksCount: Int,
    val trackedAppsCount: Int,
    val exportedAt: Long
)

class BackupManager(
    private val context: Context,
    private val appDatabase: AppDatabase
) {
    private val secretKey: SecretKeySpec by lazy {
        // Derive stable AES-256 key from app signature/package seed (Local-First privacy)
        val seed = "FocusQuest-LocalOnly-EncryptedBackup-${context.packageName}"
        val sha256 = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        SecretKeySpec(sha256, "AES")
    }

    suspend fun createEncryptedBackup(outputStream: OutputStream): BackupSummary = withContext(Dispatchers.IO) {
        val days = appDatabase.dayRecordDao().getAllDays().first()
        val blocks = appDatabase.scheduleBlockDao().getAllBlocks().first()
        val apps = appDatabase.trackedAppDao().getAllTrackedApps().first()
        val timestamp = System.currentTimeMillis()

        val rootJson = JSONObject().apply {
            put("version", 1)
            put("timestamp", timestamp)
            put("days", JSONArray().apply {
                days.forEach { d ->
                    put(JSONObject().apply {
                        put("date", d.date)
                        put("finalFp", d.finalFp)
                        put("endingTier", d.endingTier)
                        put("intentionText", d.intentionText ?: "")
                        put("forgivenessTokenUsed", d.forgivenessTokenUsed)
                        put("dayStartTimestamp", d.dayStartTimestamp)
                        put("dayEndTimestamp", d.dayEndTimestamp ?: 0L)
                    })
                }
            })
            put("blocks", JSONArray().apply {
                blocks.forEach { b ->
                    put(JSONObject().apply {
                        put("label", b.label)
                        put("type", b.type)
                        put("startMinuteOfDay", b.startMinuteOfDay)
                        put("endMinuteOfDay", b.endMinuteOfDay)
                        put("sortOrder", b.sortOrder)
                        put("reminderEnabled", b.reminderEnabled)
                        put("reminderLeadMinutes", b.reminderLeadMinutes)
                        put("distractingAppsCsv", b.distractingAppsCsv)
                    })
                }
            })
            put("apps", JSONArray().apply {
                apps.forEach { a ->
                    put(JSONObject().apply {
                        put("packageName", a.packageName)
                        put("displayName", a.displayName)
                        put("category", a.category)
                        put("isGlobal", a.isGlobal)
                    })
                }
            })
        }

        val jsonBytes = rootJson.toString().toByteArray(Charsets.UTF_8)

        // AES-256-GCM cipher setup with 12-byte IV
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        val iv = cipher.iv

        // Write 12-byte IV prefix
        outputStream.write(iv)

        // Encrypt and stream
        CipherOutputStream(outputStream, cipher).use { cos ->
            cos.write(jsonBytes)
            cos.flush()
        }

        BackupSummary(
            dayRecordsCount = days.size,
            scheduleBlocksCount = blocks.size,
            trackedAppsCount = apps.size,
            exportedAt = timestamp
        )
    }

    suspend fun restoreEncryptedBackup(inputStream: InputStream): BackupSummary = withContext(Dispatchers.IO) {
        // Read 12-byte IV
        val iv = ByteArray(12)
        val ivRead = inputStream.read(iv)
        if (ivRead != 12) throw IllegalArgumentException("Invalid backup file: header corrupt.")

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))

        val decryptedBytes = CipherInputStream(inputStream, cipher).use { cis ->
            cis.readBytes()
        }
        val jsonString = String(decryptedBytes, Charsets.UTF_8)
        val root = JSONObject(jsonString)

        val daysArray = root.getJSONArray("days")
        val blocksArray = root.getJSONArray("blocks")
        val appsArray = root.getJSONArray("apps")
        val timestamp = root.optLong("timestamp", System.currentTimeMillis())

        // Insert restored records
        for (i in 0 until daysArray.length()) {
            val d = daysArray.getJSONObject(i)
            appDatabase.dayRecordDao().insertOrUpdate(
                DayRecordEntity(
                    date = d.getString("date"),
                    finalFp = d.getInt("finalFp"),
                    endingTier = d.getString("endingTier"),
                    intentionText = d.optString("intentionText").ifBlank { null },
                    forgivenessTokenUsed = d.optBoolean("forgivenessTokenUsed", false),
                    dayStartTimestamp = d.optLong("dayStartTimestamp", System.currentTimeMillis()),
                    dayEndTimestamp = d.optLong("dayEndTimestamp", 0L).let { if (it == 0L) null else it }
                )
            )
        }

        for (i in 0 until blocksArray.length()) {
            val b = blocksArray.getJSONObject(i)
            appDatabase.scheduleBlockDao().insert(
                ScheduleBlockEntity(
                    label = b.getString("label"),
                    type = b.getString("type"),
                    startMinuteOfDay = b.getInt("startMinuteOfDay"),
                    endMinuteOfDay = b.getInt("endMinuteOfDay"),
                    sortOrder = b.optInt("sortOrder", i),
                    reminderEnabled = b.optBoolean("reminderEnabled", true),
                    reminderLeadMinutes = b.optInt("reminderLeadMinutes", 5),
                    distractingAppsCsv = b.optString("distractingAppsCsv", "")
                )
            )
        }

        for (i in 0 until appsArray.length()) {
            val a = appsArray.getJSONObject(i)
            appDatabase.trackedAppDao().insert(
                TrackedAppEntity(
                    packageName = a.getString("packageName"),
                    displayName = a.getString("displayName"),
                    category = a.getString("category"),
                    isGlobal = a.optBoolean("isGlobal", true)
                )
            )
        }

        BackupSummary(
            dayRecordsCount = daysArray.length(),
            scheduleBlocksCount = blocksArray.length(),
            trackedAppsCount = appsArray.length(),
            exportedAt = timestamp
        )
    }
}
