package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.DayRecordEntity
import com.example.data.repository.DayRepository
import com.example.data.repository.FPRepository
import com.example.data.repository.ScheduleRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TrackedAppRepository
import com.example.domain.model.AppCategory
import com.example.domain.model.AppUsageSummary
import com.example.domain.model.EndingType
import com.example.domain.model.FPState
import com.example.domain.model.PersonalityTone
import com.example.domain.model.ScheduleBlockModel
import com.example.domain.model.TrackedAppModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class ScreenDestination {
    object Splash : ScreenDestination()
    object Onboarding : ScreenDestination()
    object Home : ScreenDestination()
    object History : ScreenDestination()
    data class DayDetail(val date: String) : ScreenDestination()
    object Reputation : ScreenDestination()
    object Settings : ScreenDestination()
    object Schedule : ScreenDestination()
    object PermissionHealth : ScreenDestination()
    object ExportImport : ScreenDestination()
    object MorningModal : ScreenDestination()
    data class EndingModal(val finalFp: Int, val endingType: EndingType) : ScreenDestination()
}

class MainViewModel(
    private val fpRepository: FPRepository,
    private val dayRepository: DayRepository,
    private val scheduleRepository: ScheduleRepository,
    private val trackedAppRepository: TrackedAppRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Splash)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    val fpState: StateFlow<FPState> = fpRepository.fpState

    val scheduleBlocks: StateFlow<List<ScheduleBlockModel>> = scheduleRepository.getAllBlocks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDays: StateFlow<List<DayRecordEntity>> = dayRepository.getAllDays()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isFirstRun: StateFlow<Boolean> = settingsRepository.isFirstRun
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val personalityTone: StateFlow<PersonalityTone> = settingsRepository.personalityTone
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PersonalityTone.GENTLE)

    val themeMode: StateFlow<String> = settingsRepository.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "dark")

    val forgivenessTokens: StateFlow<Int> = settingsRepository.forgivenessTokens
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2)

    val forgivenessCadence: StateFlow<String> = settingsRepository.forgivenessCadence
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "weekly")

    val isOverlayEnabled: StateFlow<Boolean> = settingsRepository.isOverlayEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val lastBackupTimestamp: StateFlow<Long> = settingsRepository.lastBackupTimestamp
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val dayBoundaryHour: StateFlow<Int> = settingsRepository.dayBoundaryHour
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val dayBoundaryMinute: StateFlow<Int> = settingsRepository.dayBoundaryMinute
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _selectedDayUsage = MutableStateFlow<List<AppUsageSummary>>(emptyList())
    val selectedDayUsage: StateFlow<List<AppUsageSummary>> = _selectedDayUsage.asStateFlow()

    private val _selectedDayRecord = MutableStateFlow<DayRecordEntity?>(null)
    val selectedDayRecord: StateFlow<DayRecordEntity?> = _selectedDayRecord.asStateFlow()

    fun navigateTo(destination: ScreenDestination) {
        _currentScreen.value = destination
    }

    fun onSplashFinished() {
        viewModelScope.launch {
            val firstRun = settingsRepository.isFirstRun.first()
            if (firstRun) {
                _currentScreen.value = ScreenDestination.Onboarding
            } else {
                checkMorningOrEndingRitual()
            }
        }
    }

    private suspend fun checkMorningOrEndingRitual() {
        val todayStr = dayRepository.getTodayDateString()
        val morningCompletedDate = settingsRepository.morningRoutineDate.first()
        val lastEndingDate = settingsRepository.lastEndingDate.first()

        // If yesterday ended but ending was not viewed yet
        val existingToday = dayRepository.getDayByDate(todayStr)
        if (existingToday != null && existingToday.dayEndTimestamp != null && lastEndingDate != todayStr) {
            val endingType = EndingType.fromFp(existingToday.finalFp)
            _currentScreen.value = ScreenDestination.EndingModal(existingToday.finalFp, endingType)
            return
        }

        // If today's morning routine is not yet completed (Part 0.2 Law of Clean Slate)
        if (morningCompletedDate != todayStr) {
            _currentScreen.value = ScreenDestination.MorningModal
        } else {
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun completeOnboarding(selectedApps: List<TrackedAppModel>, tone: PersonalityTone) {
        viewModelScope.launch {
            selectedApps.forEach { trackedAppRepository.insertOrUpdate(it) }
            settingsRepository.setPersonalityTone(tone)
            settingsRepository.setFirstRunCompleted()
            fpRepository.resetFpTo100()
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun completeMorningRoutine(intention: String?) {
        viewModelScope.launch {
            fpRepository.resetFpTo100(intention)
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun dismissEndingModal() {
        viewModelScope.launch {
            val todayStr = dayRepository.getTodayDateString()
            settingsRepository.setLastEndingAcknowledged(todayStr)
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun activateForgivenessToken() {
        viewModelScope.launch {
            fpRepository.activateForgivenessShield()
        }
    }

    fun simulateAppSwitch(packageName: String, label: String, category: AppCategory) {
        fpRepository.simulateAppSwitch(packageName, label, category)
    }

    fun loadDayDetail(date: String) {
        viewModelScope.launch {
            _selectedDayRecord.value = dayRepository.getDayByDate(date)
            _selectedDayUsage.value = dayRepository.getAggregatedUsageForDate(date)
            _currentScreen.value = ScreenDestination.DayDetail(date)
        }
    }

    fun saveScheduleBlock(block: ScheduleBlockModel) {
        viewModelScope.launch {
            if (block.id == 0L) {
                scheduleRepository.insertBlock(block)
            } else {
                scheduleRepository.updateBlock(block)
            }
        }
    }

    fun deleteScheduleBlock(id: Long) {
        viewModelScope.launch {
            scheduleRepository.deleteBlock(id)
        }
    }

    fun setPersonalityTone(tone: PersonalityTone) {
        viewModelScope.launch { settingsRepository.setPersonalityTone(tone) }
    }

    fun setThemeMode(theme: String) {
        viewModelScope.launch { settingsRepository.setThemeMode(theme) }
    }

    fun setOverlayEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setOverlayEnabled(enabled) }
    }

    fun setForgivenessCadence(cadence: String) {
        viewModelScope.launch { settingsRepository.setForgivenessCadence(cadence) }
    }

    fun setDayBoundaryTime(hour: Int, minute: Int) {
        viewModelScope.launch { settingsRepository.setDayBoundaryTime(hour, minute) }
    }

    fun clearAllData() {
        viewModelScope.launch {
            dayRepository.clearAll()
            scheduleRepository.clearAll()
            trackedAppRepository.clearAll()
            settingsRepository.clearAll()
            scheduleRepository.ensureDefaultSchedule()
            trackedAppRepository.seedDefaultsIfEmpty()
            fpRepository.resetFpTo100()
            _currentScreen.value = ScreenDestination.Home
        }
    }

    companion object {
        fun provideFactory(app: FocusQuestApplication): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainViewModel(
                        fpRepository = app.fpRepository,
                        dayRepository = app.dayRepository,
                        scheduleRepository = app.scheduleRepository,
                        trackedAppRepository = app.trackedAppRepository,
                        settingsRepository = app.settingsRepository
                    ) as T
                }
            }
    }
}
