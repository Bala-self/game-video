package com.example.util

import com.example.domain.model.EndingType
import com.example.domain.model.PersonalityTone

data class EndingCopy(
    val headline: String,
    val subtext: String,
    val actionableHint: String
)

object EndingCopyProvider {

    fun getCopy(tier: EndingType, tone: PersonalityTone): EndingCopy {
        return when (tone) {
            PersonalityTone.GENTLE -> when (tier) {
                EndingType.GOOD -> EndingCopy(
                    headline = "Great focus today.",
                    subtext = "You held steady — nice work.",
                    actionableHint = "Take a restful evening to celebrate your momentum."
                )
                EndingType.NEUTRAL -> EndingCopy(
                    headline = "A mixed day.",
                    subtext = "Some focus, some drift. That's most days.",
                    actionableHint = "A balanced rhythm is natural. Tomorrow is another fresh start."
                )
                EndingType.ROUGH -> EndingCopy(
                    headline = "Today was tough.",
                    subtext = "Want to see what pulled your focus?",
                    actionableHint = "Curiosity teaches us more than self-criticism. We can adjust your blocks anytime."
                )
                EndingType.DEFEATED -> EndingCopy(
                    headline = "Zero today.",
                    subtext = "That's not a verdict — just today. Fresh start tomorrow.",
                    actionableHint = "Focus Points reset cleanly to 100 tomorrow morning with no leftover residue."
                )
            }
            PersonalityTone.NEUTRAL -> when (tier) {
                EndingType.GOOD -> EndingCopy(
                    headline = "Strong focus maintained.",
                    subtext = "Consistent energy recorded across your focus blocks.",
                    actionableHint = "Day completed within upper tier."
                )
                EndingType.NEUTRAL -> EndingCopy(
                    headline = "Moderate day recorded.",
                    subtext = "Active time balanced between focus and secondary apps.",
                    actionableHint = "Review your app usage breakdown below."
                )
                EndingType.ROUGH -> EndingCopy(
                    headline = "Lower focus recorded.",
                    subtext = "Sustained time detected in categorized distraction apps.",
                    actionableHint = "Consider adding a forgiveness token or shortening focus intervals."
                )
                EndingType.DEFEATED -> EndingCopy(
                    headline = "Points reached zero.",
                    subtext = "Active usage exhausted all daily FP reserves.",
                    actionableHint = "Day closed. Clean slate of 100 FP activates at next morning check-in."
                )
            }
            PersonalityTone.BLUNT -> when (tier) {
                EndingType.GOOD -> EndingCopy(
                    headline = "Solid day.",
                    subtext = "Steady discipline throughout. Well done.",
                    actionableHint = "Keep this cadence tomorrow."
                )
                EndingType.NEUTRAL -> EndingCopy(
                    headline = "Even split.",
                    subtext = "Half focused, half off-track. Common reality.",
                    actionableHint = "Decide where you want the needle tomorrow."
                )
                EndingType.ROUGH -> EndingCopy(
                    headline = "Rough one.",
                    subtext = "Focus slipped into rabbit holes early.",
                    actionableHint = "Inspect what pulled you in. Reset tomorrow."
                )
                EndingType.DEFEATED -> EndingCopy(
                    headline = "Zeroed out.",
                    subtext = "Not the end of the world. Reset tomorrow.",
                    actionableHint = "Full 100 FP slate in the morning. Let it go."
                )
            }
        }
    }
}
