package com.example.util

import android.os.SystemClock

/**
 * Part 5.2 & Part 6 #9: Clock manipulation defense.
 * Cross-checks elapsedRealtime() with wall clock to avoid false day boundary triggers.
 */
class ClockIntegrityChecker {
    private var lastWallClockMs: Long = System.currentTimeMillis()
    private var lastElapsedRealtimeMs: Long = SystemClock.elapsedRealtime()

    fun checkIntegrity(): Boolean {
        val currentWallMs = System.currentTimeMillis()
        val currentElapsedMs = SystemClock.elapsedRealtime()

        val deltaWall = currentWallMs - lastWallClockMs
        val deltaElapsed = currentElapsedMs - lastElapsedRealtimeMs

        // If wall clock jumped by more than 10 minutes compared to elapsedRealtime, clock was shifted
        val isManipulated = Math.abs(deltaWall - deltaElapsed) > (10 * 60 * 1000L)

        lastWallClockMs = currentWallMs
        lastElapsedRealtimeMs = currentElapsedMs

        return !isManipulated
    }
}
