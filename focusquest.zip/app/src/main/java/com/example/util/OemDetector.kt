package com.example.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Part 5.2, 5.8 & Part 6 #14: OEM layer detection and routing.
 * Detects Samsung, Xiaomi, Oppo, Vivo, OnePlus, Huawei and provides tailored instructions.
 */
object OemDetector {

    val manufacturer: String = Build.MANUFACTURER.lowercase()

    fun getOemDisplayName(): String {
        return Build.MANUFACTURER.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }

    fun getOemAutostartAdvice(): String {
        return when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco") ->
                "Xiaomi MIUI/HyperOS: Go to Settings > Apps > Manage Apps > FocusQuest > enable 'Autostart' and set Battery Saver to 'No restrictions'."
            manufacturer.contains("samsung") ->
                "Samsung One UI: Go to Settings > Battery > Background usage limits > add FocusQuest to 'Never sleeping apps'."
            manufacturer.contains("oppo") || manufacturer.contains("realme") ->
                "Oppo/Realme ColorOS: Go to Settings > Battery > App Battery Management > FocusQuest > allow background activity and autostart."
            manufacturer.contains("vivo") || manufacturer.contains("iqoo") ->
                "Vivo Funtouch OS: Go to Settings > Battery > High background power consumption > enable for FocusQuest."
            manufacturer.contains("huawei") || manufacturer.contains("honor") ->
                "Huawei/Honor: Go to Settings > Battery > App launch > FocusQuest > turn off 'Manage automatically' and enable all manual toggles."
            else ->
                "Android: Ensure background battery restrictions are disabled so the companion service stays alive throughout your focus hours."
        }
    }

    fun createOemSettingsIntent(): Intent? {
        val intents = listOf(
            // Xiaomi
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            // Huawei
            Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
            // Oppo
            Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
            // Vivo
            Intent().setComponent(ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
            // Samsung
            Intent().setComponent(ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"))
        )

        for (intent in intents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return intent
        }
        return null
    }
}
