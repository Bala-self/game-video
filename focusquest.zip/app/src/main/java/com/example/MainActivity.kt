package com.example

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.AppCategory
import com.example.service.foreground.FocusForegroundService
import com.example.ui.screens.DayDetailScreen
import com.example.ui.screens.EndingScreen
import com.example.ui.screens.ExportImportScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MorningRoutineModal
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PermissionHealthScreen
import com.example.ui.screens.ReputationScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.FocusQuestTheme
import com.example.util.PermissionStatusProvider

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.provideFactory(application as FocusQuestApplication)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Start foreground service if overlay is enabled
        try {
            val fgsIntent = Intent(this, FocusForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(fgsIntent)
            } else {
                startService(fgsIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isDark = when (themeMode) {
                "light" -> false
                "system" -> isSystemInDarkTheme()
                else -> true
            }

            FocusQuestTheme(darkTheme = isDark) {
                MainContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainContent(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val fpState by viewModel.fpState.collectAsState()
    val scheduleBlocks by viewModel.scheduleBlocks.collectAsState()
    val allDays by viewModel.allDays.collectAsState()
    val personalityTone by viewModel.personalityTone.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val forgivenessTokens by viewModel.forgivenessTokens.collectAsState()
    val forgivenessCadence by viewModel.forgivenessCadence.collectAsState()
    val isOverlayEnabled by viewModel.isOverlayEnabled.collectAsState()
    val lastBackupTimestamp by viewModel.lastBackupTimestamp.collectAsState()
    val dayBoundaryHour by viewModel.dayBoundaryHour.collectAsState()
    val dayBoundaryMinute by viewModel.dayBoundaryMinute.collectAsState()

    val selectedDayRecord by viewModel.selectedDayRecord.collectAsState()
    val selectedDayUsage by viewModel.selectedDayUsage.collectAsState()

    // Determine permission health status
    val hasPermissionIssue = !PermissionStatusProvider.hasOverlayPermission(context) ||
            !PermissionStatusProvider.hasAccessibilityPermission(context)

    // Window size class / tablet check per Part 3.6.3 (Bottom Nav on phone, Navigation Rail on sw600dp)
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    when (val screen = currentScreen) {
        is ScreenDestination.Splash -> {
            SplashScreen(onSplashFinished = { viewModel.onSplashFinished() })
        }
        is ScreenDestination.Onboarding -> {
            OnboardingScreen(onFinish = { apps, tone ->
                viewModel.completeOnboarding(apps, tone)
            })
        }
        is ScreenDestination.MorningModal -> {
            MorningRoutineModal(onStartDay = { intention ->
                viewModel.completeMorningRoutine(intention)
            })
        }
        is ScreenDestination.EndingModal -> {
            EndingScreen(
                finalFp = screen.finalFp,
                endingTier = screen.endingType,
                personalityTone = personalityTone,
                forgivenessTokenUsedToday = fpState.isForgivenessShieldActive,
                onViewDayDetail = {
                    val todayStr = (context.applicationContext as FocusQuestApplication).dayRepository.getTodayDateString()
                    viewModel.loadDayDetail(todayStr)
                },
                onContinue = { viewModel.dismissEndingModal() }
            )
        }
        is ScreenDestination.Schedule -> {
            ScheduleScreen(
                blocks = scheduleBlocks,
                onSaveBlock = { viewModel.saveScheduleBlock(it) },
                onDeleteBlock = { viewModel.deleteScheduleBlock(it) },
                onNavigateBack = { viewModel.navigateTo(ScreenDestination.Home) }
            )
        }
        is ScreenDestination.PermissionHealth -> {
            PermissionHealthScreen(
                onNavigateBack = { viewModel.navigateTo(ScreenDestination.Home) }
            )
        }
        is ScreenDestination.ExportImport -> {
            ExportImportScreen(
                lastBackupTimestamp = lastBackupTimestamp,
                onNavigateBack = { viewModel.navigateTo(ScreenDestination.Settings) }
            )
        }
        is ScreenDestination.DayDetail -> {
            DayDetailScreen(
                date = screen.date,
                record = selectedDayRecord,
                usageList = selectedDayUsage,
                onNavigateBack = { viewModel.navigateTo(ScreenDestination.History) }
            )
        }
        // Main tabs with bottom nav / rail
        is ScreenDestination.Home,
        is ScreenDestination.History,
        is ScreenDestination.Reputation,
        is ScreenDestination.Settings -> {
            val currentTab = screen

            if (isTablet) {
                // Tablet layout: Side Navigation Rail (Adaptive & Responsive design)
                Row(modifier = Modifier.fillMaxSize()) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight().testTag("tablet_nav_rail")
                    ) {
                        NavigationRailItem(
                            selected = currentTab is ScreenDestination.Home,
                            onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                            label = { Text("Home") },
                            modifier = Modifier.testTag("nav_home")
                        )
                        NavigationRailItem(
                            selected = currentTab is ScreenDestination.History,
                            onClick = { viewModel.navigateTo(ScreenDestination.History) },
                            icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "History") },
                            label = { Text("History") },
                            modifier = Modifier.testTag("nav_history")
                        )
                        NavigationRailItem(
                            selected = currentTab is ScreenDestination.Reputation,
                            onClick = { viewModel.navigateTo(ScreenDestination.Reputation) },
                            icon = { Icon(Icons.Default.TrendingUp, contentDescription = "Reputation") },
                            label = { Text("Reputation") },
                            modifier = Modifier.testTag("nav_reputation")
                        )
                        NavigationRailItem(
                            selected = currentTab is ScreenDestination.Settings,
                            onClick = { viewModel.navigateTo(ScreenDestination.Settings) },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                            label = { Text("Settings") },
                            modifier = Modifier.testTag("nav_settings")
                        )
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        TabScreenContent(
                            currentTab = currentTab,
                            viewModel = viewModel,
                            fpState = fpState,
                            scheduleBlocks = scheduleBlocks,
                            allDays = allDays,
                            personalityTone = personalityTone,
                            themeMode = themeMode,
                            forgivenessTokens = forgivenessTokens,
                            forgivenessCadence = forgivenessCadence,
                            isOverlayEnabled = isOverlayEnabled,
                            dayBoundaryHour = dayBoundaryHour,
                            dayBoundaryMinute = dayBoundaryMinute,
                            hasPermissionIssue = hasPermissionIssue
                        )
                    }
                }
            } else {
                // Phone layout: Bottom Navigation Bar
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
                            NavigationBarItem(
                                selected = currentTab is ScreenDestination.Home,
                                onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home") },
                                modifier = Modifier.testTag("nav_home")
                            )
                            NavigationBarItem(
                                selected = currentTab is ScreenDestination.History,
                                onClick = { viewModel.navigateTo(ScreenDestination.History) },
                                icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "History") },
                                label = { Text("History") },
                                modifier = Modifier.testTag("nav_history")
                            )
                            NavigationBarItem(
                                selected = currentTab is ScreenDestination.Reputation,
                                onClick = { viewModel.navigateTo(ScreenDestination.Reputation) },
                                icon = { Icon(Icons.Default.TrendingUp, contentDescription = "Reputation") },
                                label = { Text("Reputation") },
                                modifier = Modifier.testTag("nav_reputation")
                            )
                            NavigationBarItem(
                                selected = currentTab is ScreenDestination.Settings,
                                onClick = { viewModel.navigateTo(ScreenDestination.Settings) },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") },
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                        TabScreenContent(
                            currentTab = currentTab,
                            viewModel = viewModel,
                            fpState = fpState,
                            scheduleBlocks = scheduleBlocks,
                            allDays = allDays,
                            personalityTone = personalityTone,
                            themeMode = themeMode,
                            forgivenessTokens = forgivenessTokens,
                            forgivenessCadence = forgivenessCadence,
                            isOverlayEnabled = isOverlayEnabled,
                            dayBoundaryHour = dayBoundaryHour,
                            dayBoundaryMinute = dayBoundaryMinute,
                            hasPermissionIssue = hasPermissionIssue
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabScreenContent(
    currentTab: ScreenDestination,
    viewModel: MainViewModel,
    fpState: com.example.domain.model.FPState,
    scheduleBlocks: List<com.example.domain.model.ScheduleBlockModel>,
    allDays: List<com.example.data.local.entity.DayRecordEntity>,
    personalityTone: com.example.domain.model.PersonalityTone,
    themeMode: String,
    forgivenessTokens: Int,
    forgivenessCadence: String,
    isOverlayEnabled: Boolean,
    dayBoundaryHour: Int,
    dayBoundaryMinute: Int,
    hasPermissionIssue: Boolean
) {
    if (currentTab !is ScreenDestination.Home) {
        BackHandler {
            viewModel.navigateTo(ScreenDestination.Home)
        }
    }

    when (currentTab) {
        is ScreenDestination.Home -> {
            HomeScreen(
                fpState = fpState,
                scheduleBlocks = scheduleBlocks,
                forgivenessTokensCount = forgivenessTokens,
                hasPermissionIssue = hasPermissionIssue,
                onActivateToken = { viewModel.activateForgivenessToken() },
                onNavigateSchedule = { viewModel.navigateTo(ScreenDestination.Schedule) },
                onNavigateHistory = { viewModel.navigateTo(ScreenDestination.History) },
                onNavigatePermissions = { viewModel.navigateTo(ScreenDestination.PermissionHealth) },
                onOpenMorningModal = { viewModel.navigateTo(ScreenDestination.MorningModal) },
                onSimulateAppSwitch = { pkg, label, cat ->
                    viewModel.simulateAppSwitch(pkg, label, cat)
                }
            )
        }
        is ScreenDestination.History -> {
            HistoryScreen(
                days = allDays,
                onSelectDay = { date -> viewModel.loadDayDetail(date) },
                onNavigateBack = { viewModel.navigateTo(ScreenDestination.Home) }
            )
        }
        is ScreenDestination.Reputation -> {
            ReputationScreen(
                days = allDays,
                onNavigateBack = { viewModel.navigateTo(ScreenDestination.Home) }
            )
        }
        is ScreenDestination.Settings -> {
            SettingsScreen(
                personalityTone = personalityTone,
                themeMode = themeMode,
                forgivenessTokens = forgivenessTokens,
                forgivenessCadence = forgivenessCadence,
                isOverlayEnabled = isOverlayEnabled,
                dayBoundaryHour = dayBoundaryHour,
                dayBoundaryMinute = dayBoundaryMinute,
                onToneChanged = { viewModel.setPersonalityTone(it) },
                onThemeChanged = { viewModel.setThemeMode(it) },
                onOverlayToggled = { viewModel.setOverlayEnabled(it) },
                onCadenceChanged = { viewModel.setForgivenessCadence(it) },
                onDayBoundaryChanged = { h, m -> viewModel.setDayBoundaryTime(h, m) },
                onNavigateExportImport = { viewModel.navigateTo(ScreenDestination.ExportImport) },
                onClearAllData = { viewModel.clearAllData() },
                onNavigateBack = { viewModel.navigateTo(ScreenDestination.Home) }
            )
        }
        else -> {}
    }
}
