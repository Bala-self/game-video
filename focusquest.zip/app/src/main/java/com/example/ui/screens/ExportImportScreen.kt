package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.FocusQuestApplication
import com.example.data.backup.BackupSummary
import com.example.ui.components.GentleDialog
import com.example.ui.components.SoftButton
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.ShapeMedium
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportImportScreen(
    lastBackupTimestamp: Long,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var backupResultSummary by remember { mutableStateOf<BackupSummary?>(null) }
    var restorePreviewSummary by remember { mutableStateOf<BackupSummary?>(null) }
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }

    // SAF file pickers
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { os ->
                        val summary = FocusQuestApplication.instance.backupManager.createEncryptedBackup(os)
                        FocusQuestApplication.instance.settingsRepository.setLastBackupTimestamp(summary.exportedAt)
                        backupResultSummary = summary
                        Toast.makeText(context, "Encrypted backup created successfully", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Backup failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            pendingRestoreUri = uri
            scope.launch {
                try {
                    context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        val summary = FocusQuestApplication.instance.backupManager.restoreEncryptedBackup(inputStream)
                        restorePreviewSummary = summary
                        Toast.makeText(context, "Backup restored successfully!", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Failed to restore: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val lastBackupStr = if (lastBackupTimestamp > 0L) {
        SimpleDateFormat("MMM d, yyyy · h:mm a", Locale.US).format(Date(lastBackupTimestamp))
    } else {
        "Never backed up"
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("export_import_screen"),
        topBar = {
            TopAppBar(
                title = { Text("Encrypted Backup", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("export_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Local-First encryption guarantee badge
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AES-256-GCM On-Device Encryption",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "FocusQuest is 100% offline. Backups are encrypted locally with hardware-backed keys and never leave your phone unless you manually share the exported file.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Export Section
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().testTag("export_section")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Export Focus History",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Last backup: $lastBackupStr",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SoftButton(
                        text = "Back Up Now",
                        onClick = {
                            val defaultFileName = "focusquest_backup_${System.currentTimeMillis()}.fqb"
                            exportLauncher.launch(defaultFileName)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "backup_now_button"
                    )
                }
            }

            // Restore Section
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().testTag("restore_section")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Restore from File",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Restores your recorded days, schedule blocks, custom apps, and preferences from an encrypted .fqb file.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SoftButton(
                        text = "Restore from Backup",
                        onClick = {
                            importLauncher.launch(arrayOf("application/octet-stream", "*/*"))
                        },
                        isPrimary = false,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "restore_backup_button"
                    )
                }
            }

            // Summary card after export
            if (backupResultSummary != null) {
                val s = backupResultSummary!!
                Card(
                    shape = ShapeMedium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Backup Export Summary",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("• ${s.dayRecordsCount} days of focus history saved", style = MaterialTheme.typography.bodyMedium)
                        Text("• ${s.scheduleBlocksCount} schedule blocks saved", style = MaterialTheme.typography.bodyMedium)
                        Text("• ${s.trackedAppsCount} tracked apps saved", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
