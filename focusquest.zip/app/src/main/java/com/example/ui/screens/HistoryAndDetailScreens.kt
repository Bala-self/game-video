package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.DayRecordEntity
import com.example.domain.model.AppUsageSummary
import com.example.domain.model.FPTier
import com.example.ui.components.FPRing
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.ShapeMedium
import com.example.ui.theme.fpToColor
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    days: List<DayRecordEntity>,
    onSelectDay: (String) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)

    val calendar = remember { Calendar.getInstance() }
    var displayedMonthOffset by remember { mutableIntStateOf(0) } // 0 = current month, -1 = last month, etc.

    val currentMonthCalendar = remember(displayedMonthOffset) {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, displayedMonthOffset)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal
    }

    val monthYearStr = remember(currentMonthCalendar) {
        SimpleDateFormat("MMMM yyyy", Locale.US).format(currentMonthCalendar.time)
    }

    val daysInMonth = currentMonthCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = currentMonthCalendar.get(Calendar.DAY_OF_WEEK) // 1 = Sunday, 2 = Monday

    // Map date string -> DayRecordEntity
    val dayRecordMap = remember(days) { days.associateBy { it.date } }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("history_screen"),
        topBar = {
            TopAppBar(
                title = { Text("History", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("history_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Month navigation header (Part 3.6.8)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { displayedMonthOffset-- }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Month")
                }
                Text(
                    text = monthYearStr,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                IconButton(onClick = { displayedMonthOffset++ }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Month")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Day of week labels (7 columns)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("S", "M", "T", "W", "T", "F", "S").forEach { dayLabel ->
                    Text(
                        text = dayLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.width(36.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 7-column calendar month grid per Part 3.6.8
            val totalCells = ((firstDayOfWeek - 1) + daysInMonth + 6) / 7 * 7

            Column(modifier = Modifier.fillMaxWidth()) {
                var cellIndex = 0
                val rows = totalCells / 7
                val year = currentMonthCalendar.get(Calendar.YEAR)
                val month = currentMonthCalendar.get(Calendar.MONTH) + 1

                for (r in 0 until rows) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        for (c in 0 until 7) {
                            val dayNumber = cellIndex - (firstDayOfWeek - 1) + 1
                            if (dayNumber in 1..daysInMonth) {
                                val dateKey = String.format("%04d-%02d-%02d", year, month, dayNumber)
                                val record = dayRecordMap[dateKey]

                                CalendarDayCell(
                                    dayNumber = dayNumber,
                                    record = record,
                                    onClick = { onSelectDay(dateKey) }
                                )
                            } else {
                                Spacer(modifier = Modifier.size(38.dp))
                            }
                            cellIndex++
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Recent Days Summary List
            Text(
                text = "Recorded Days",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(days) { day ->
                    Card(
                        shape = ShapeMedium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectDay(day.date) }
                            .testTag("day_item_${day.date}")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val dotColor = fpToColor(day.finalFp)
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(dotColor)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = day.date,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${day.endingTier.lowercase().replaceFirstChar { it.uppercase() }} · ${day.finalFp} FP",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (day.forgivenessTokenUsed) {
                                Text(
                                    text = "Shielded",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    dayNumber: Int,
    record: DayRecordEntity?,
    onClick: () -> Unit
) {
    val tierColor = if (record != null) fpToColor(record.finalFp) else Color.Transparent

    Column(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "$dayNumber",
            style = MaterialTheme.typography.bodySmall,
            color = if (record != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )
        Spacer(modifier = Modifier.height(2.dp))
        // Colored dot or hollow outline per Part 3.6.8
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(tierColor)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayDetailScreen(
    date: String,
    record: DayRecordEntity?,
    usageList: List<AppUsageSummary>,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)

    val finalFp = record?.finalFp ?: 100
    val tier = FPTier.fromFp(finalFp)

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("day_detail_screen"),
        topBar = {
            TopAppBar(
                title = { Text(date, fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Mini FPRing static (Part 3.6.9)
                FPRing(
                    fp = finalFp,
                    tier = tier,
                    size = 140.dp,
                    strokeWidth = 10.dp,
                    showLabel = true
                )
            }

            // Morning Intention Quote Block (Part 3.6.9)
            if (!record?.intentionText.isNullOrBlank()) {
                item {
                    Card(
                        shape = ShapeMedium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth().testTag("intention_quote_block")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Morning Intention",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "“${record?.intentionText}”",
                                style = MaterialTheme.typography.bodyMedium,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "App Usage Breakdown",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }

            if (usageList.isEmpty()) {
                item {
                    Text(
                        text = "No recorded external app switches on this date.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                val maxDuration = usageList.maxOfOrNull { it.durationSeconds }?.coerceAtLeast(1) ?: 1
                items(usageList) { app ->
                    val progress = (app.durationSeconds.toFloat() / maxDuration).coerceIn(0f, 1f)
                    val minutes = app.durationSeconds / 60
                    val seconds = app.durationSeconds % 60
                    val timeStr = if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"

                    Card(
                        shape = ShapeMedium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = app.displayName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = timeStr,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                strokeCap = StrokeCap.Round,
                                color = fpToColor(finalFp),
                                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth().height(6.dp)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
