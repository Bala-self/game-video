package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BlockType
import com.example.domain.model.ScheduleBlockModel
import com.example.ui.components.SoftButton
import com.example.ui.theme.FpFocusedStartDark
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.ShapeMedium
import com.example.ui.theme.ShapePill
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(
    blocks: List<ScheduleBlockModel>,
    onSaveBlock: (ScheduleBlockModel) -> Unit,
    onDeleteBlock: (Long) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)

    var editingBlock by remember { mutableStateOf<ScheduleBlockModel?>(null) }
    var showSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("schedule_screen"),
        topBar = {
            TopAppBar(
                title = { Text("Daily Schedule", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("schedule_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingBlock = ScheduleBlockModel(
                        label = "Focus Session",
                        type = BlockType.FOCUS,
                        startMinuteOfDay = 9 * 60,
                        endMinuteOfDay = 11 * 60
                    )
                    showSheet = true
                },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_block_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Block")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Defined Focus & Break Blocks",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            items(blocks, key = { it.id }) { block ->
                val startHour = block.startMinuteOfDay / 60
                val startMin = block.startMinuteOfDay % 60
                val endHour = block.endMinuteOfDay / 60
                val endMin = block.endMinuteOfDay % 60
                val timeStr = String.format("%02d:%02d – %02d:%02d", startHour, startMin, endHour, endMin)

                Card(
                    shape = ShapeMedium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().testTag("schedule_card_${block.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = block.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = block.type.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (block.type == BlockType.FOCUS) FpFocusedStartDark else MaterialTheme.colorScheme.tertiary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = timeStr,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(onClick = {
                            editingBlock = block
                            showSheet = true
                        }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        IconButton(onClick = { onDeleteBlock(block.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    if (showSheet && editingBlock != null) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            BlockEditBottomSheet(
                initialBlock = editingBlock!!,
                existingBlocks = blocks,
                onSave = { updated ->
                    onSaveBlock(updated)
                    scope.launch { sheetState.hide() }.invokeOnCompletion { showSheet = false }
                },
                onCancel = {
                    scope.launch { sheetState.hide() }.invokeOnCompletion { showSheet = false }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlockEditBottomSheet(
    initialBlock: ScheduleBlockModel,
    existingBlocks: List<ScheduleBlockModel>,
    onSave: (ScheduleBlockModel) -> Unit,
    onCancel: () -> Unit
) {
    var label by remember { mutableStateOf(initialBlock.label) }
    var blockType by remember { mutableStateOf(initialBlock.type) }
    var startHour by remember { mutableIntStateOf(initialBlock.startMinuteOfDay / 60) }
    var startMinute by remember { mutableIntStateOf(initialBlock.startMinuteOfDay % 60) }
    var endHour by remember { mutableIntStateOf(initialBlock.endMinuteOfDay / 60) }
    var endMinute by remember { mutableIntStateOf(initialBlock.endMinuteOfDay % 60) }

    val startTotal = startHour * 60 + startMinute
    val endTotal = endHour * 60 + endMinute

    // Overlap validation per Part 3.6.6
    val hasOverlap = existingBlocks.any { other ->
        if (other.id == initialBlock.id) false
        else !(endTotal <= other.startMinuteOfDay || startTotal >= other.endMinuteOfDay)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
            .testTag("block_edit_sheet")
    ) {
        Text(
            text = if (initialBlock.id == 0L) "Add Schedule Block" else "Edit Schedule Block",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = label,
            onValueChange = { label = it },
            label = { Text("Label") },
            shape = ShapeMedium,
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Type Segmented Control (Focus / Break per Part 3.6.6)
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            SegmentedButton(
                selected = blockType == BlockType.FOCUS,
                onClick = { blockType = BlockType.FOCUS },
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
            ) {
                Text("Focus")
            }
            SegmentedButton(
                selected = blockType == BlockType.BREAK,
                onClick = { blockType = BlockType.BREAK },
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
            ) {
                Text("Break")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Time Range Pickers
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            OutlinedTextField(
                value = String.format("%02d:%02d", startHour, startMinute),
                onValueChange = { str ->
                    val parts = str.split(":")
                    if (parts.size == 2) {
                        parts[0].toIntOrNull()?.let { if (it in 0..23) startHour = it }
                        parts[1].toIntOrNull()?.let { if (it in 0..59) startMinute = it }
                    }
                },
                label = { Text("Start (HH:MM)") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = String.format("%02d:%02d", endHour, endMinute),
                onValueChange = { str ->
                    val parts = str.split(":")
                    if (parts.size == 2) {
                        parts[0].toIntOrNull()?.let { if (it in 0..23) endHour = it }
                        parts[1].toIntOrNull()?.let { if (it in 0..59) endMinute = it }
                    }
                },
                label = { Text("End (HH:MM)") },
                modifier = Modifier.weight(1f)
            )
        }

        if (hasOverlap) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Note: This time range overlaps with another block.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFF59E0B)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            SoftButton(
                text = "Cancel",
                onClick = onCancel,
                isPrimary = false,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(16.dp))
            SoftButton(
                text = "Save Block",
                onClick = {
                    onSave(
                        initialBlock.copy(
                            label = label.trim().ifEmpty { "Focus Session" },
                            type = blockType,
                            startMinuteOfDay = startTotal,
                            endMinuteOfDay = endTotal
                        )
                    )
                },
                isPrimary = true,
                modifier = Modifier.weight(1f),
                testTag = "save_block_button"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
