package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.PersonalityTone
import com.example.ui.components.GentleDialog
import com.example.ui.components.SoftButton
import com.example.ui.theme.FpWarningEndDark
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.ShapeMedium

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    personalityTone: PersonalityTone,
    themeMode: String,
    forgivenessTokens: Int,
    forgivenessCadence: String,
    isOverlayEnabled: Boolean,
    dayBoundaryHour: Int,
    dayBoundaryMinute: Int,
    onToneChanged: (PersonalityTone) -> Unit,
    onThemeChanged: (String) -> Unit,
    onOverlayToggled: (Boolean) -> Unit,
    onCadenceChanged: (String) -> Unit,
    onDayBoundaryChanged: (Int, Int) -> Unit,
    onNavigateExportImport: () -> Unit,
    onClearAllData: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)

    var showClearDataDialog by remember { mutableStateOf(false) }
    var deleteConfirmInput by remember { mutableStateOf("") }

    var editingBoundaryHour by remember { mutableIntStateOf(dayBoundaryHour) }
    var editingBoundaryMin by remember { mutableIntStateOf(dayBoundaryMinute) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("settings_screen"),
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Theme Mode
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Appearance Theme",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = themeMode == "dark",
                            onClick = { onThemeChanged("dark") },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 3)
                        ) {
                            Text("Dark")
                        }
                        SegmentedButton(
                            selected = themeMode == "light",
                            onClick = { onThemeChanged("light") },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 3)
                        ) {
                            Text("Light")
                        }
                        SegmentedButton(
                            selected = themeMode == "system",
                            onClick = { onThemeChanged("system") },
                            shape = SegmentedButtonDefaults.itemShape(index = 2, count = 3)
                        ) {
                            Text("System")
                        }
                    }
                }
            }

            // Personality Tone
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Companion Tone",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Adjust the feedback phrasing used during evening endings and check-ins.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        PersonalityTone.entries.forEachIndexed { index, tone ->
                            SegmentedButton(
                                selected = personalityTone == tone,
                                onClick = { onToneChanged(tone) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = PersonalityTone.entries.size)
                            ) {
                                Text(tone.displayName)
                            }
                        }
                    }
                }
            }

            // Floating Overlay Toggle
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Persistent Floating Overlay",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Always-on-top draggable bubble showing live FP",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isOverlayEnabled,
                        onCheckedChange = onOverlayToggled,
                        modifier = Modifier.testTag("overlay_toggle_switch")
                    )
                }
            }

            // Default Notification Sound & Chime Preview
            val context = androidx.compose.ui.platform.LocalContext.current
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().testTag("notification_sound_card")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Default Notification Sound",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Focus Chime (Custom Alert Sound)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    SoftButton(
                        text = "Play",
                        onClick = {
                            try {
                                val mp = android.media.MediaPlayer.create(context, com.example.R.raw.focus_notification_sound)
                                mp?.setOnCompletionListener { it.release() }
                                mp?.start()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        },
                        isPrimary = false,
                        modifier = Modifier.height(40.dp),
                        testTag = "test_sound_button"
                    )
                }
            }

            // Forgiveness Tokens & Cadence
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Forgiveness Shield Tokens",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Currently available: $forgivenessTokens tokens",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Replenishment Cadence:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = forgivenessCadence == "weekly",
                            onClick = { onCadenceChanged("weekly") },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) {
                            Text("Weekly (Mondays)")
                        }
                        SegmentedButton(
                            selected = forgivenessCadence == "biweekly",
                            onClick = { onCadenceChanged("biweekly") },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) {
                            Text("Biweekly")
                        }
                    }
                }
            }

            // Day Boundary Time
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Day Boundary Trigger",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Time of day when today's FP snapshots to History and triggers the ending evaluation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = String.format("%02d:%02d", editingBoundaryHour, editingBoundaryMin),
                            onValueChange = { str ->
                                val parts = str.split(":")
                                if (parts.size == 2) {
                                    val h = parts[0].toIntOrNull()
                                    val m = parts[1].toIntOrNull()
                                    if (h != null && h in 0..23 && m != null && m in 0..59) {
                                        editingBoundaryHour = h
                                        editingBoundaryMin = m
                                        onDayBoundaryChanged(h, m)
                                    }
                                }
                            },
                            label = { Text("Boundary (HH:MM)") },
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "Default: 00:00 (Midnight)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Backup & Restore Navigation Card
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onNavigateExportImport)
                    .testTag("nav_export_import_card")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Encrypted Export & Import",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Manage on-device AES-256 backup archives",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Privacy Guarantee Notice (Part 5.10)
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Law of Local-First",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "This app cannot connect to the internet. android.permission.INTERNET is completely absent from the manifest. Zero analytics, zero servers, zero trackers.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Danger Zone (Part 3.6.13)
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, FpWarningEndDark.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth().testTag("danger_zone_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Danger Zone",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FpWarningEndDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Permanently clears all recorded focus history, schedule blocks, custom apps, and preferences from this device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SoftButton(
                        text = "Clear All Data",
                        onClick = { showClearDataDialog = true },
                        isPrimary = false,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "clear_all_data_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // High friction double-confirmation dialog requiring typing "DELETE" (Part 3.6.13)
    if (showClearDataDialog) {
        GentleDialog(
            title = "Erase All Focus Data?",
            message = "This will wipe all historical day logs and reset your schedule. To confirm this irreversible action, type DELETE below:",
            confirmText = "Erase Everything",
            dismissText = "Keep My Data",
            onConfirm = {
                if (deleteConfirmInput.trim() == "DELETE") {
                    showClearDataDialog = false
                    deleteConfirmInput = ""
                    onClearAllData()
                }
            },
            onDismiss = {
                showClearDataDialog = false
                deleteConfirmInput = ""
            }
        ) {
            OutlinedTextField(
                value = deleteConfirmInput,
                onValueChange = { deleteConfirmInput = it },
                label = { Text("Type DELETE") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
