package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = FpFocusedStartDark,
    onPrimary = BgPrimaryDark,
    primaryContainer = BgSurfaceVariantDark,
    onPrimaryContainer = TextPrimaryDark,
    secondary = FpFocusedEndDark,
    onSecondary = BgPrimaryDark,
    background = BgPrimaryDark,
    onBackground = TextPrimaryDark,
    surface = BgSurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = BgSurfaceVariantDark,
    onSurfaceVariant = TextMutedDark,
    error = FpWarningEndDark,
    tertiary = AccentForgivenessDark
)

private val LightColorScheme = lightColorScheme(
    primary = FpFocusedStartLight,
    onPrimary = BgSurfaceLight,
    primaryContainer = BgSurfaceVariantLight,
    onPrimaryContainer = TextPrimaryLight,
    secondary = FpFocusedEndLight,
    onSecondary = BgSurfaceLight,
    background = BgPrimaryLight,
    onBackground = TextPrimaryLight,
    surface = BgSurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = BgSurfaceVariantLight,
    onSurfaceVariant = TextMutedLight,
    error = FpWarningEndLight,
    tertiary = AccentForgivenessLight
)

@Composable
fun FocusQuestTheme(
    darkTheme: Boolean = true, // Default to deep serene dark companion theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FocusQuestTypography,
        shapes = FocusQuestShapes,
        content = content
    )
}

// Backward-compatibility alias if referenced
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    FocusQuestTheme(darkTheme = darkTheme, content = content)
}
