package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.PermissionRow
import com.example.ui.components.SoftButton
import com.example.ui.theme.QuicksandFontFamily
import com.example.util.OemDetector
import com.example.util.PermissionStatusProvider

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionHealthScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)
    val context = LocalContext.current
    var refreshTrigger by remember { mutableIntStateOf(0) }

    // Re-evaluated on refresh
    val hasOverlay = remember(refreshTrigger) { PermissionStatusProvider.hasOverlayPermission(context) }
    val hasAccessibility = remember(refreshTrigger) { PermissionStatusProvider.hasAccessibilityPermission(context) }
    val hasUsageStats = remember(refreshTrigger) { PermissionStatusProvider.hasUsageStatsPermission(context) }
    val isBatteryOptimized = remember(refreshTrigger) { PermissionStatusProvider.isIgnoringBatteryOptimizations(context) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("permission_health_screen"),
        topBar = {
            TopAppBar(
                title = { Text("Permission Health", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("health_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { refreshTrigger++ }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Recheck permissions")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "System Capability Status",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // 1. Overlay Permission
            PermissionRow(
                title = "Floating Overlay",
                statusText = if (hasOverlay) "Active · Companion can float over apps" else "Disabled · Tap Fix to allow display over other apps",
                isGranted = hasOverlay,
                onFixClick = {
                    val intent = PermissionStatusProvider.createOverlaySettingsIntent(context)
                    try { context.startActivity(intent) } catch (e: Exception) { e.printStackTrace() }
                }
            )

            // 2. Accessibility Service
            PermissionRow(
                title = "Accessibility Detection",
                statusText = if (hasAccessibility) "Active · Real-time app window listener running" else "Disabled · Tap Fix to enable in Accessibility menu",
                isGranted = hasAccessibility,
                onFixClick = {
                    val intent = PermissionStatusProvider.createAccessibilitySettingsIntent()
                    try { context.startActivity(intent) } catch (e: Exception) { e.printStackTrace() }
                }
            )

            // 3. Usage Access (fallback)
            PermissionRow(
                title = "Usage Access (Fallback)",
                statusText = if (hasUsageStats) "Granted · Standby tracking available" else "Optional · Standby fallback if accessibility stops",
                isGranted = hasUsageStats,
                isWarning = !hasUsageStats,
                onFixClick = {
                    val intent = PermissionStatusProvider.createUsageStatsSettingsIntent()
                    try { context.startActivity(intent) } catch (e: Exception) { e.printStackTrace() }
                }
            )

            // 4. Battery Optimization - Stock Android
            PermissionRow(
                title = "Stock Battery Exemption",
                statusText = if (isBatteryOptimized) "Exempted · OS will not pause background ticks" else "Restricted · Android may kill service when screen sleeps",
                isGranted = isBatteryOptimized,
                onFixClick = {
                    val intent = PermissionStatusProvider.createBatteryOptimizationIntent(context)
                    try { context.startActivity(intent) } catch (e: Exception) { e.printStackTrace() }
                }
            )

            // 5. Battery/Autostart Manager — OEM Layer (Part 3.6.11)
            val oemName = OemDetector.getOemDisplayName()
            PermissionRow(
                title = "$oemName Autostart & Power Management",
                statusText = OemDetector.getOemAutostartAdvice(),
                isGranted = false, // OEM proprietary, indirect detection
                isWarning = true,
                disclaimer = "Can silently reset after system updates — we'll flag it again if it does.",
                onFixClick = {
                    val oemIntent = OemDetector.createOemSettingsIntent()
                    if (oemIntent != null) {
                        try { context.startActivity(oemIntent) } catch (e: Exception) {
                            // Fallback to stock battery
                            context.startActivity(PermissionStatusProvider.createBatteryOptimizationIntent(context))
                        }
                    } else {
                        context.startActivity(PermissionStatusProvider.createBatteryOptimizationIntent(context))
                    }
                }
            )

            // 6. Alarm Scheduling & Background Watchdog
            PermissionRow(
                title = "Alarm & Schedule Watchdog",
                statusText = "Active · setAndAllowWhileIdle enabled for morning & ending boundaries",
                isGranted = true,
                onFixClick = {}
            )

            Spacer(modifier = Modifier.height(16.dp))

            SoftButton(
                text = "Re-check All Permissions",
                onClick = { refreshTrigger++ },
                isPrimary = false,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
