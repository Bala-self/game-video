package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.DayRecordEntity
import com.example.ui.theme.FpFocusedStartDark
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.ShapeMedium

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReputationScreen(
    days: List<DayRecordEntity>,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)

    var horizonDays by remember { mutableIntStateOf(30) } // 30 or 90

    // Compute rolling 7-day average points
    val sortedDays = remember(days) { days.sortedBy { it.date } }
    val recentDays = remember(sortedDays, horizonDays) {
        if (sortedDays.size > horizonDays) sortedDays.takeLast(horizonDays) else sortedDays
    }

    val smoothedPoints = remember(recentDays) {
        if (recentDays.isEmpty()) {
            listOf(85f, 88f, 82f, 90f, 87f, 92f, 89f) // calm placeholder curve
        } else {
            val list = mutableListOf<Float>()
            for (i in recentDays.indices) {
                val window = recentDays.subList(maxOf(0, i - 3), minOf(recentDays.size, i + 4))
                val avg = window.map { it.finalFp }.average().toFloat()
                list.add(avg)
            }
            list
        }
    }

    val streakCount = remember(sortedDays) {
        // Consecutive days >= 40 FP
        var streak = 0
        for (day in sortedDays.reversed()) {
            if (day.finalFp >= 40) streak++ else break
        }
        streak.coerceAtLeast(1)
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("reputation_screen"),
        topBar = {
            TopAppBar(
                title = { Text("Reputation Track", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("reputation_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Horizon selector (30-day / 90-day per Part 3.6.10)
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = horizonDays == 30,
                    onClick = { horizonDays = 30 },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) {
                    Text("30 Days")
                }
                SegmentedButton(
                    selected = horizonDays == 90,
                    onClick = { horizonDays = 90 },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) {
                    Text("90 Days")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Smoothed Rolling Average Line Chart (Part 3.6.10)
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .testTag("reputation_trend_chart")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TrendingUp, contentDescription = null, tint = FpFocusedStartDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Smoothed Focus Trajectory",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            val stepX = if (smoothedPoints.size > 1) w / (smoothedPoints.size - 1) else w
                            val minVal = 0f
                            val maxVal = 100f

                            val path = Path()
                            val fillPath = Path()

                            smoothedPoints.forEachIndexed { i, fpVal ->
                                val x = i * stepX
                                val y = h - ((fpVal - minVal) / (maxVal - minVal) * h)

                                if (i == 0) {
                                    path.moveTo(x, y)
                                    fillPath.moveTo(x, h)
                                    fillPath.lineTo(x, y)
                                } else {
                                    val prevX = (i - 1) * stepX
                                    val prevY = h - ((smoothedPoints[i - 1] - minVal) / (maxVal - minVal) * h)
                                    val cx = (prevX + x) / 2f
                                    path.cubicTo(cx, prevY, cx, y, x, y)
                                    fillPath.cubicTo(cx, prevY, cx, y, x, y)
                                }

                                if (i == smoothedPoints.size - 1) {
                                    fillPath.lineTo(x, h)
                                    fillPath.close()
                                }
                            }

                            // Gradient under curve
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        FpFocusedStartDark.copy(alpha = 0.25f),
                                        Color.Transparent
                                    )
                                )
                            )

                            // Main smoothed line
                            drawPath(
                                path = path,
                                color = FpFocusedStartDark,
                                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Soft Streak Indicator per Part 3.6.10: "14 days this season"
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().testTag("soft_streak_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Season Rhythm",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$streakCount days this season",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your streak reset, but your trend's still what matters. Focus is a long arc, not a daily tightrope.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
