package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FPTier
import com.example.ui.theme.Baloo2FontFamily
import com.example.ui.theme.FpDefeatedDark
import com.example.ui.theme.FpFocusedEndDark
import com.example.ui.theme.FpFocusedStartDark
import com.example.ui.theme.FpNeutralDark
import com.example.ui.theme.FpWarningEndDark
import com.example.ui.theme.FpWarningStartDark
import com.example.ui.theme.fpToColor
import java.util.Calendar

@Composable
fun FPRing(
    fp: Int,
    tier: FPTier,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    strokeWidth: Dp = 14.dp,
    showLabel: Boolean = true
) {
    // Arc sweep animation with spring overshoot (dampingRatio=0.6f per Part 3.4)
    val animatedProgress by animateFloatAsState(
        targetValue = (fp / 100f).coerceIn(0f, 1f),
        animationSpec = spring(
            dampingRatio = 0.6f,
            stiffness = Spring.StiffnessLow
        ),
        label = "fpProgress"
    )

    // Tier crossfade color transition (500ms linear interpolation per Part 3.4)
    val targetColor = fpToColor(fp)
    val animatedColor by animateColorAsState(
        targetValue = targetColor,
        animationSpec = tween(durationMillis = 500),
        label = "fpColor"
    )

    val trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .testTag("fp_ring_container"),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val strokePx = strokeWidth.toPx()
                val diameter = this.size.minDimension - strokePx
                val topLeft = Offset(strokePx / 2f, strokePx / 2f)
                val arcSize = Size(diameter, diameter)

                // Background track full circle
                drawArc(
                    color = trackColor,
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )

                // Active animated progress arc
                val sweep = 270f * animatedProgress
                if (sweep > 0f) {
                    drawArc(
                        color = animatedColor,
                        startAngle = 135f,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )
                }
            }

            // Big Centered FP Number (Part 3.2 display_fp: 64sp, Baloo 2, Bold)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "$fp",
                    fontFamily = Baloo2FontFamily,
                    fontSize = if (size < 120.dp) (size.value * 0.35f).sp else 64.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("fp_display_number")
                )
                if (size >= 160.dp) {
                    Text(
                        text = "FOCUS POINTS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        letterSpacing = 1.5.sp
                    )
                }
            }
        }

        if (showLabel) {
            Spacer(modifier = Modifier.height(14.dp))
            val phrase = remember(tier, fp) { getCalmPhraseForTier(tier) }
            Text(
                text = phrase,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("fp_state_phrase")
            )
        }
    }
}

/**
 * Rotates between calm phrases per tier, seeded by day-of-month to stay consistent within a day (Part 3.6.3)
 */
fun getCalmPhraseForTier(tier: FPTier): String {
    val dayOfMonth = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
    return when (tier) {
        FPTier.FOCUSED -> {
            val phrases = listOf("Locked in.", "Good rhythm today.", "Steady.", "Flowing smoothly.")
            phrases[dayOfMonth % phrases.size]
        }
        FPTier.NEUTRAL -> {
            val phrases = listOf("Cruising steadily.", "Balanced pace.", "Holding the center.", "Even rhythm.")
            phrases[dayOfMonth % phrases.size]
        }
        FPTier.WARNING -> {
            val phrases = listOf("Focus running low.", "Attention shifting.", "Gentle breath.", "Time to regroup.")
            phrases[dayOfMonth % phrases.size]
        }
        FPTier.DEFEATED -> {
            val phrases = listOf("Settled for the day.", "Quiet resting point.", "Fresh start ahead.", "Rest now.")
            phrases[dayOfMonth % phrases.size]
        }
    }
}
