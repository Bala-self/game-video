package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.CompanionPose
import com.example.ui.theme.fpToColor

@Composable
fun CompanionMascot(
    pose: CompanionPose,
    fp: Int = 100,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp
) {
    // Breathing idle animation per Part 3.4
    val infiniteTransition = rememberInfiniteTransition(label = "CompanionBreathe")
    val breatheDuration = when (pose) {
        CompanionPose.FOCUSED, CompanionPose.NEUTRAL -> 3000
        CompanionPose.TIRED -> 4500
        CompanionPose.RESTING -> 0 // settle
    }

    val breatheScale by if (breatheDuration > 0) {
        infiniteTransition.animateFloat(
            initialValue = 1.0f,
            targetValue = if (pose == CompanionPose.FOCUSED) 1.05f else 1.03f,
            animationSpec = infiniteRepeatable(
                animation = tween(breatheDuration / 2, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "breatheScale"
        )
    } else {
        infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = 0.95f,
            animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing)),
            label = "settleScale"
        )
    }

    val auraColor = fpToColor(fp)

    // Select the authentic user character face:
    val faceDrawableRes = when (pose) {
        CompanionPose.FOCUSED -> R.drawable.face_angel
        CompanionPose.NEUTRAL -> R.drawable.app_logo_split
        CompanionPose.TIRED -> R.drawable.face_devil
        CompanionPose.RESTING -> R.drawable.face_devil
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        // Soft glowing radial aura behind the character
        Canvas(modifier = Modifier.size(size * 1.25f)) {
            val centerX = this.size.width / 2f
            val centerY = this.size.height / 2f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(auraColor.copy(alpha = 0.38f), Color.Transparent),
                    center = Offset(centerX, centerY),
                    radius = (size.toPx() * 0.55f)
                ),
                radius = (size.toPx() * 0.55f),
                center = Offset(centerX, centerY)
            )
        }

        // Authentic Character Face with breathing scale
        Image(
            painter = painterResource(id = faceDrawableRes),
            contentDescription = "Companion mascot in ${pose.name} state",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(size)
                .scale(breatheScale)
        )
    }
}

@Composable
fun AppLogoCharacter(
    modifier: Modifier = Modifier,
    size: Dp = 140.dp
) {
    Image(
        painter = painterResource(id = R.drawable.app_logo_split),
        contentDescription = "FocusQuest Two-Face Logo",
        contentScale = ContentScale.Fit,
        modifier = modifier.size(size)
    )
}
