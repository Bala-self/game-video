package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AppCategory
import com.example.domain.model.CompanionPose
import com.example.domain.model.PersonalityTone
import com.example.domain.model.TrackedAppModel
import com.example.ui.components.CompanionMascot
import com.example.ui.components.SoftButton
import com.example.ui.theme.Baloo2FontFamily
import com.example.ui.theme.FpFocusedStartDark
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.ShapeMedium
import com.example.util.PermissionStatusProvider

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    onFinish: (selectedApps: List<TrackedAppModel>, tone: PersonalityTone) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentStep by remember { mutableIntStateOf(1) } // 1 to 5
    var selectedTone by remember { mutableStateOf(PersonalityTone.GENTLE) }

    // Pre-populated common distracting apps per Part 3.6.2
    val trackedApps = remember {
        mutableStateListOf(
            TrackedAppModel("com.google.android.youtube", "YouTube", AppCategory.DISTRACTING),
            TrackedAppModel("com.instagram.android", "Instagram", AppCategory.DISTRACTING),
            TrackedAppModel("com.twitter.android", "X / Twitter", AppCategory.DISTRACTING),
            TrackedAppModel("com.reddit.frontpage", "Reddit", AppCategory.DISTRACTING),
            TrackedAppModel("com.zhiliaoapp.musically", "TikTok", AppCategory.DISTRACTING),
            TrackedAppModel("com.netflix.mediaclient", "Netflix", AppCategory.DISTRACTING)
        )
    }
    val selectedPackages = remember { mutableStateListOf("com.google.android.youtube", "com.instagram.android") }
    var customAppInput by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("onboarding_screen"),
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStep > 1) {
                    IconButton(
                        onClick = { currentStep-- },
                        modifier = Modifier.testTag("onboarding_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(48.dp))
                }
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Step $currentStep of 5",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "onboarding_step_transition"
            ) { step ->
                when (step) {
                    1 -> StepConcept(onNext = { currentStep = 2 })
                    2 -> StepOverlayPermission(context, onNext = { currentStep = 3 })
                    3 -> StepAccessibilityPermission(context, onNext = { currentStep = 4 })
                    4 -> StepScheduleSetup(
                        apps = trackedApps,
                        selected = selectedPackages,
                        customInput = customAppInput,
                        onCustomInputChange = { customAppInput = it },
                        onAddCustom = {
                            if (customAppInput.isNotBlank()) {
                                val pkg = "custom.${customAppInput.lowercase().replace(" ", "")}"
                                trackedApps.add(TrackedAppModel(pkg, customAppInput.trim(), AppCategory.DISTRACTING))
                                selectedPackages.add(pkg)
                                customAppInput = ""
                            }
                        },
                        onToggle = { pkg ->
                            if (selectedPackages.contains(pkg)) {
                                if (selectedPackages.size > 1) selectedPackages.remove(pkg)
                            } else {
                                selectedPackages.add(pkg)
                            }
                        },
                        onNext = { currentStep = 5 }
                    )
                    5 -> StepToneSelection(
                        selectedTone = selectedTone,
                        onSelectTone = { selectedTone = it },
                        onFinish = {
                            val finalList = trackedApps.filter { selectedPackages.contains(it.packageName) }
                            onFinish(finalList, selectedTone)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun StepConcept(onNext: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
    ) {
        CompanionMascot(pose = CompanionPose.FOCUSED, fp = 100, size = 160.dp)
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Meet your focus companion.",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "An offline, local-first companion that turns your device habits into a calm Focus Points economy. No guilt, no leaderboards — honest observations and a daily clean slate.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(32.dp))
        SoftButton(
            text = "Continue",
            onClick = onNext,
            modifier = Modifier.fillMaxWidth(),
            testTag = "onboarding_continue_1"
        )
    }
}

@Composable
private fun StepOverlayPermission(context: Context, onNext: () -> Unit) {
    val hasPermission = PermissionStatusProvider.hasOverlayPermission(context)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
    ) {
        CompanionMascot(pose = CompanionPose.FOCUSED, fp = 85, size = 140.dp)
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Glanceable Overlay",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "I need permission to float over your screen so I can show your live focus energy anywhere in under 300ms without opening the app.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(32.dp))
        if (!hasPermission) {
            SoftButton(
                text = "Grant Overlay Permission",
                onClick = {
                    val intent = PermissionStatusProvider.createOverlaySettingsIntent(context)
                    try { context.startActivity(intent) } catch (e: Exception) { e.printStackTrace() }
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "grant_overlay_button"
            )
            Spacer(modifier = Modifier.height(16.dp))
            SoftButton(
                text = "Continue Anyway",
                onClick = onNext,
                isPrimary = false,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            SoftButton(
                text = "Permission Granted — Continue",
                onClick = onNext,
                modifier = Modifier.fillMaxWidth(),
                testTag = "continue_overlay_granted"
            )
        }
    }
}

@Composable
private fun StepAccessibilityPermission(context: Context, onNext: () -> Unit) {
    val hasPermission = PermissionStatusProvider.hasAccessibilityPermission(context)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
    ) {
        CompanionMascot(pose = CompanionPose.NEUTRAL, fp = 65, size = 140.dp)
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Foreground Detection",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "I need accessibility to detect which app is open — just the app package name. FocusQuest never touches what you type, read, or view on screen.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(32.dp))
        if (!hasPermission) {
            SoftButton(
                text = "Open Accessibility Settings",
                onClick = {
                    val intent = PermissionStatusProvider.createAccessibilitySettingsIntent()
                    try { context.startActivity(intent) } catch (e: Exception) { e.printStackTrace() }
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "grant_accessibility_button"
            )
            Spacer(modifier = Modifier.height(16.dp))
            SoftButton(
                text = "Continue Anyway",
                onClick = onNext,
                isPrimary = false,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            SoftButton(
                text = "Accessibility Active — Continue",
                onClick = onNext,
                modifier = Modifier.fillMaxWidth(),
                testTag = "continue_accessibility_granted"
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StepScheduleSetup(
    apps: List<TrackedAppModel>,
    selected: List<String>,
    customInput: String,
    onCustomInputChange: (String) -> Unit,
    onAddCustom: () -> Unit,
    onToggle: (String) -> Unit,
    onNext: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "What pulls your focus?",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Select apps that tend to pull your attention into rabbit holes. You can change these anytime.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(24.dp))

        FlowRow(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            apps.forEach { app ->
                val isSelected = selected.contains(app.packageName)
                FilterChip(
                    selected = isSelected,
                    onClick = { onToggle(app.packageName) },
                    label = { Text(app.displayName) },
                    leadingIcon = if (isSelected) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    modifier = Modifier.padding(4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = customInput,
                onValueChange = onCustomInputChange,
                placeholder = { Text("Add custom app (e.g. Chess)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            SoftButton(
                text = "Add",
                onClick = onAddCustom,
                enabled = customInput.isNotBlank(),
                modifier = Modifier.height(56.dp)
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
        SoftButton(
            text = "Continue (${selected.size} selected)",
            onClick = onNext,
            enabled = selected.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            testTag = "onboarding_schedule_next"
        )
    }
}

@Composable
private fun StepToneSelection(
    selectedTone: PersonalityTone,
    onSelectTone: (PersonalityTone) -> Unit,
    onFinish: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Choose your tone",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "How should your companion speak to you when a day runs low on Focus Points?",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(24.dp))

        PersonalityTone.entries.forEach { tone ->
            val isSelected = tone == selectedTone
            val sampleEnding = when (tone) {
                PersonalityTone.GENTLE -> "\"Today was tough. Want to see what pulled your focus?\""
                PersonalityTone.NEUTRAL -> "\"Lower focus recorded. Sustained time in distraction apps.\""
                PersonalityTone.BLUNT -> "\"Rough one. Inspect what pulled you in. Reset tomorrow.\""
            }

            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                ),
                border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { onSelectTone(tone) }
                    .testTag("tone_option_${tone.name.lowercase()}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = tone.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = FpFocusedStartDark)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = tone.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Rough day example: $sampleEnding",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        SoftButton(
            text = "You're All Set — Enter FocusQuest",
            onClick = onFinish,
            modifier = Modifier.fillMaxWidth(),
            testTag = "onboarding_finish_button"
        )
    }
}
