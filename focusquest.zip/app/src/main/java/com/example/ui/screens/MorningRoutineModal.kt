package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CompanionPose
import com.example.ui.components.CompanionMascot
import com.example.ui.components.SoftButton
import com.example.ui.theme.Baloo2FontFamily
import com.example.ui.theme.FpFocusedEndDark
import com.example.ui.theme.FpFocusedStartDark
import com.example.ui.theme.ShapeMedium

@Composable
fun MorningRoutineModal(
    onStartDay: (intention: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    // Non-dismissable via back button per Part 3.6.5
    BackHandler(enabled = true) { /* Intentional ritual completion required */ }

    var intentionInput by remember { mutableStateOf("") }

    // Calm gradient background (fp_focused_start -> fp_focused_end per Part 3.6.5)
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            FpFocusedStartDark.copy(alpha = 0.35f),
            FpFocusedEndDark.copy(alpha = 0.25f),
            Color(0xFF121212)
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .padding(24.dp)
            .testTag("morning_routine_modal"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            CompanionMascot(
                pose = CompanionPose.FOCUSED,
                fp = 100,
                size = 150.dp
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "New day.",
                fontFamily = Baloo2FontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Focus Points reset to 100.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Optional intention input per Part 3.6.5
            OutlinedTextField(
                value = intentionInput,
                onValueChange = { intentionInput = it },
                label = { Text("Today I want to focus on... (optional)") },
                placeholder = { Text("e.g. Finish quarterly project proposal") },
                shape = ShapeMedium,
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("morning_intention_input")
            )

            Spacer(modifier = Modifier.height(32.dp))

            SoftButton(
                text = "Start the Day",
                onClick = { onStartDay(intentionInput.trim().ifEmpty { null }) },
                modifier = Modifier.fillMaxWidth(),
                testTag = "start_day_button"
            )
        }
    }
}
