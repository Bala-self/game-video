package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AppCategory
import com.example.domain.model.FPState
import com.example.domain.model.ScheduleBlockModel
import com.example.ui.components.BlockChip
import com.example.ui.components.FPRing
import com.example.ui.components.GentleDialog
import com.example.ui.components.SoftButton
import com.example.ui.theme.AccentForgivenessDark
import com.example.ui.theme.Baloo2FontFamily
import com.example.ui.theme.FpFocusedStartDark
import com.example.ui.theme.FpWarningEndDark
import com.example.ui.theme.ShapeMedium
import com.example.ui.theme.fpToColor

@Composable
fun HomeScreen(
    fpState: FPState,
    scheduleBlocks: List<ScheduleBlockModel>,
    forgivenessTokensCount: Int,
    hasPermissionIssue: Boolean,
    onActivateToken: () -> Unit,
    onNavigateSchedule: () -> Unit,
    onNavigateHistory: () -> Unit,
    onNavigatePermissions: () -> Unit,
    onOpenMorningModal: () -> Unit,
    onSimulateAppSwitch: (packageName: String, label: String, category: AppCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    var showTokenConfirmDialog by remember { mutableStateOf(false) }
    var selectedBlockForDetail by remember { mutableStateOf<ScheduleBlockModel?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("home_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top App Bar per Part 3.6.3 with Two-Face Logo
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            com.example.ui.components.AppLogoCharacter(size = 32.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "FocusQuest",
                fontFamily = Baloo2FontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.weight(1f))

            // Permission Health icon: only badged red/amber if issue exists, otherwise invisible/clean
            IconButton(
                onClick = onNavigatePermissions,
                modifier = Modifier.testTag("health_icon_button")
            ) {
                if (hasPermissionIssue) {
                    BadgedBox(
                        badge = {
                            Badge(containerColor = FpWarningEndDark) {
                                Text("!")
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Permission Health Attention Needed",
                            tint = Color(0xFFF59E0B)
                        )
                    }
                } else {
                    // Subtle shield icon confirming green health
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Permission Health Good",
                        tint = FpFocusedStartDark.copy(alpha = 0.7f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Hero Companion Mascot (Angel / Devil / Two-Face according to live FP tier)
        val companionPose = when (fpState.tier) {
            com.example.domain.model.FPTier.FOCUSED -> com.example.domain.model.CompanionPose.FOCUSED
            com.example.domain.model.FPTier.NEUTRAL -> com.example.domain.model.CompanionPose.NEUTRAL
            com.example.domain.model.FPTier.WARNING -> com.example.domain.model.CompanionPose.TIRED
            com.example.domain.model.FPTier.DEFEATED -> com.example.domain.model.CompanionPose.RESTING
        }
        com.example.ui.components.CompanionMascot(
            pose = companionPose,
            fp = fpState.currentFp,
            size = 110.dp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Hero Zone: FPRing 220dp with display_fp centered
        FPRing(
            fp = fpState.currentFp,
            tier = fpState.tier,
            size = 220.dp,
            strokeWidth = 14.dp,
            showLabel = true
        )

        // Forgiveness Shield Active Banner
        if (fpState.isForgivenessShieldActive) {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                shape = ShapeMedium,
                colors = CardDefaults.cardColors(containerColor = AccentForgivenessDark.copy(alpha = 0.15f)),
                border = BorderStroke(1.dp, AccentForgivenessDark),
                modifier = Modifier.testTag("shield_active_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = AccentForgivenessDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Forgiveness Shield Active (${fpState.shieldRemainingSeconds / 60}m remaining)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = AccentForgivenessDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Real-Time Active Foreground App Status Bar
        Card(
            shape = ShapeMedium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().testTag("active_status_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val catColor = when (fpState.activeAppCategory) {
                    AppCategory.DISTRACTING -> FpWarningEndDark
                    AppCategory.FOCUS -> FpFocusedStartDark
                    AppCategory.NEUTRAL -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(catColor)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = fpState.activeAppDisplayName ?: "FocusQuest Companion",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    val rateText = when (fpState.activeAppCategory) {
                        AppCategory.DISTRACTING -> if (fpState.isForgivenessShieldActive) "Shielded · 0 FP/min" else "Active · Escalating drain (-2 to -4 FP/min)"
                        AppCategory.FOCUS -> "Active · Restoring (+0.5 FP/min)"
                        AppCategory.NEUTRAL -> "Neutral app · Steady (0 FP/min)"
                    }
                    Text(
                        text = rateText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Timeline Strip per Part 3.6.3
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Rhythm",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Schedule",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .testTag("timeline_strip")
            ) {
                scheduleBlocks.forEach { block ->
                    val isCurrent = fpState.currentBlock?.id == block.id
                    BlockChip(
                        block = block,
                        isCurrent = isCurrent,
                        onClick = { selectedBlockForDetail = block },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Actions Row (Part 3.6.3: Forgiveness Token, Edit Schedule, History)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SoftButton(
                text = "Shield ($forgivenessTokensCount left)",
                onClick = { showTokenConfirmDialog = true },
                enabled = forgivenessTokensCount > 0 && !fpState.isForgivenessShieldActive,
                icon = Icons.Default.Shield,
                modifier = Modifier.weight(1.2f),
                testTag = "forgiveness_token_button"
            )
            SoftButton(
                text = "Schedule",
                onClick = onNavigateSchedule,
                icon = Icons.Default.EditCalendar,
                isPrimary = false,
                modifier = Modifier.weight(1f),
                testTag = "edit_schedule_quick_button"
            )
            SoftButton(
                text = "History",
                onClick = onNavigateHistory,
                icon = Icons.Default.CalendarMonth,
                isPrimary = false,
                modifier = Modifier.weight(1f),
                testTag = "history_quick_button"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Testing & Sideload Companion Quick Switcher
        Card(
            shape = ShapeMedium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth().testTag("app_simulation_panel")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Companion Real-Time Telemetry",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Tap below to test foreground app transitions and watch the FP curve react live:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SoftButton(
                        text = "Social (-Drain)",
                        onClick = {
                            onSimulateAppSwitch("com.instagram.android", "Instagram", AppCategory.DISTRACTING)
                        },
                        isPrimary = false,
                        modifier = Modifier.weight(1f)
                    )
                    SoftButton(
                        text = "Docs (+Regen)",
                        onClick = {
                            onSimulateAppSwitch("com.google.android.apps.docs", "Google Docs", AppCategory.FOCUS)
                        },
                        isPrimary = false,
                        modifier = Modifier.weight(1f)
                    )
                    SoftButton(
                        text = "Camera (0)",
                        onClick = {
                            onSimulateAppSwitch("com.android.camera", "Camera", AppCategory.NEUTRAL)
                        },
                        isPrimary = false,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }

    // Block Popover Modal
    if (selectedBlockForDetail != null) {
        val b = selectedBlockForDetail!!
        GentleDialog(
            title = b.label,
            message = "Type: ${b.type.name}\nTime: ${String.format("%02d:%02d to %02d:%02d", b.startMinuteOfDay / 60, b.startMinuteOfDay % 60, b.endMinuteOfDay / 60, b.endMinuteOfDay % 60)}\nReminder: ${if (b.reminderEnabled) "${b.reminderLeadMinutes} min lead" else "Off"}",
            confirmText = "Done",
            onConfirm = { selectedBlockForDetail = null },
            onDismiss = { selectedBlockForDetail = null }
        )
    }

    // Forgiveness Token Activation Dialog
    if (showTokenConfirmDialog) {
        GentleDialog(
            title = "Activate Forgiveness Shield",
            message = "This pauses all Focus Point drain for the next 30 minutes, allowing you to handle interruptions without losing points. It does not add points, but protects your current level.",
            confirmText = "Activate Shield",
            dismissText = "Cancel",
            onConfirm = {
                showTokenConfirmDialog = false
                onActivateToken()
            },
            onDismiss = { showTokenConfirmDialog = false }
        )
    }
}
