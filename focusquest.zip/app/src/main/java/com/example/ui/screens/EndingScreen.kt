package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CompanionPose
import com.example.domain.model.EndingType
import com.example.domain.model.PersonalityTone
import com.example.ui.components.CompanionMascot
import com.example.ui.components.SoftButton
import com.example.ui.theme.AccentForgivenessDark
import com.example.ui.theme.Baloo2FontFamily
import com.example.ui.theme.ShapeMedium
import com.example.util.EndingCopyProvider

@Composable
fun EndingScreen(
    finalFp: Int,
    endingTier: EndingType,
    personalityTone: PersonalityTone,
    forgivenessTokenUsedToday: Boolean,
    onViewDayDetail: () -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val copy = EndingCopyProvider.getCopy(endingTier, personalityTone)
    val pose = when (endingTier) {
        EndingType.GOOD -> CompanionPose.FOCUSED
        EndingType.NEUTRAL -> CompanionPose.NEUTRAL
        EndingType.ROUGH -> CompanionPose.TIRED
        EndingType.DEFEATED -> CompanionPose.RESTING
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
            .testTag("ending_screen_${endingTier.name.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            // Pose illustration (top, 180dp per Part 3.6.7)
            CompanionMascot(
                pose = pose,
                fp = finalFp,
                size = 180.dp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Headline (centered, headline style)
            Text(
                text = copy.headline,
                fontFamily = Baloo2FontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Subtext (centered, body style, max 2 lines)
            Text(
                text = copy.subtext,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = copy.actionableHint,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
            )

            // If FP=0 and no token used today: extra inline card offering tomorrow's protection (Part 3.6.7)
            if (endingTier == EndingType.DEFEATED && !forgivenessTokenUsedToday) {
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    shape = ShapeMedium,
                    colors = CardDefaults.cardColors(containerColor = AccentForgivenessDark.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, AccentForgivenessDark),
                    modifier = Modifier.fillMaxWidth().testTag("tomorrow_protection_card")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = AccentForgivenessDark,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Tomorrow's Shield Available",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = AccentForgivenessDark
                            )
                            Text(
                                text = "You have an unused token. You can activate it tomorrow morning for an initial 30-minute shield.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Buttons per Part 3.6.7: Primary (View Day Detail - outlined), Secondary (Continue - filled)
            SoftButton(
                text = "Continue",
                onClick = onContinue,
                isPrimary = true,
                modifier = Modifier.fillMaxWidth(),
                testTag = "ending_continue_button"
            )

            Spacer(modifier = Modifier.height(16.dp))

            SoftButton(
                text = "View Day Detail",
                onClick = onViewDayDetail,
                isPrimary = false,
                modifier = Modifier.fillMaxWidth(),
                testTag = "ending_view_detail_button"
            )
        }
    }
}
