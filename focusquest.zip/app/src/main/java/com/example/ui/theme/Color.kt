package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import kotlin.math.roundToInt

// FocusQuest Color Palette — Part 3.1 Token Table
val FpFocusedStartDark = Color(0xFF34D399) // 100-70
val FpFocusedEndDark = Color(0xFF3B82F6)
val FpNeutralDark = Color(0xFFA8A29E)      // 69-40
val FpWarningStartDark = Color(0xFFF59E0B)  // 39-1
val FpWarningEndDark = Color(0xFFEF4444)
val FpDefeatedDark = Color(0xFF6B7280)      // 0

val FpFocusedStartLight = Color(0xFF10B981)
val FpFocusedEndLight = Color(0xFF2563EB)
val FpNeutralLight = Color(0xFF78716C)
val FpWarningStartLight = Color(0xFFD97706)
val FpWarningEndLight = Color(0xFFDC2626)
val FpDefeatedLight = Color(0xFF9CA3AF)

val BgPrimaryDark = Color(0xFF121212)
val BgSurfaceDark = Color(0xFF1E1E1E)
val BgSurfaceVariantDark = Color(0xFF292929)
val TextPrimaryDark = Color(0xFFF5F5F4)
val TextMutedDark = Color(0xFFA8A29E)

val BgPrimaryLight = Color(0xFFFAFAF9)
val BgSurfaceLight = Color(0xFFFFFFFF)
val BgSurfaceVariantLight = Color(0xFFF0F0EF)
val TextPrimaryLight = Color(0xFF1C1917)
val TextMutedLight = Color(0xFF78716C)

val AccentForgivenessDark = Color(0xFFA78BFA)
val AccentForgivenessLight = Color(0xFF7C3AED)

/**
 * Linear HSL interpolation across 4 anchor points (0, 39, 70, 100) per Part 3.1.
 * Never a hard if/else color switch.
 */
fun fpToColor(fp: Int, isDark: Boolean = true): Color {
    val clamped = fp.coerceIn(0, 100)
    val startFocus = if (isDark) FpFocusedStartDark else FpFocusedStartLight
    val neutral = if (isDark) FpNeutralDark else FpNeutralLight
    val warning = if (isDark) FpWarningEndDark else FpWarningEndLight
    val defeated = if (isDark) FpDefeatedDark else FpDefeatedLight

    return when {
        clamped >= 70 -> {
            val fraction = (clamped - 70) / 30f
            lerpColor(neutral, startFocus, fraction)
        }
        clamped >= 40 -> {
            val fraction = (clamped - 40) / 30f
            lerpColor(warning, neutral, fraction)
        }
        clamped > 0 -> {
            val fraction = clamped / 40f
            lerpColor(defeated, warning, fraction)
        }
        else -> defeated
    }
}

fun lerpColor(start: Color, end: Color, fraction: Float): Color {
    val f = fraction.coerceIn(0f, 1f)
    return Color(
        red = start.red + (end.red - start.red) * f,
        green = start.green + (end.green - start.green) * f,
        blue = start.blue + (end.blue - start.blue) * f,
        alpha = start.alpha + (end.alpha - start.alpha) * f
    )
}
