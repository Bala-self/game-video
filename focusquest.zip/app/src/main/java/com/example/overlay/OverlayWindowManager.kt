package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import com.example.FocusQuestApplication
import com.example.MainActivity
import com.example.overlay.composables.CollapsedBubble
import com.example.overlay.composables.ExpandedCard
import com.example.ui.theme.FocusQuestTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class OverlayWindowManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var composeView: ComposeView? = null
    private var lifecycleOwner: ComposeOverlayLifecycleOwner? = null

    private var isExpanded by mutableStateOf(false)
    private var isRecentlyChanged by mutableStateOf(false)
    private var isHalfHidden by mutableStateOf(false)

    private val scope = CoroutineScope(Dispatchers.Main)
    private var changeTimerJob: Job? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        },
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 60
        y = 300
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showOverlay() {
        if (!Settings.canDrawOverlays(context)) return
        if (composeView != null) return // already attached

        lifecycleOwner = ComposeOverlayLifecycleOwner()
        val view = ComposeView(context).apply {
            lifecycleOwner?.attachToComposeView(this)
            setContent {
                FocusQuestTheme(darkTheme = true) {
                    val fpState by FocusQuestApplication.instance.fpRepository.fpState.collectAsState()

                    if (isExpanded) {
                        ExpandedCard(
                            fp = fpState.currentFp,
                            tier = fpState.tier,
                            onCollapse = {
                                isExpanded = false
                                updateWindowSize()
                            },
                            onOpenApp = {
                                val intent = Intent(context, MainActivity::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                }
                                context.startActivity(intent)
                                isExpanded = false
                                updateWindowSize()
                            }
                        )
                    } else {
                        CollapsedBubble(
                            fp = fpState.currentFp,
                            tier = fpState.tier,
                            isRecentlyChanged = isRecentlyChanged,
                            onTap = {
                                if (isHalfHidden) {
                                    // First tap un-hides (Part 3.6.4)
                                    snapToEdge(fullyVisible = true)
                                    isHalfHidden = false
                                } else {
                                    // Second tap expands
                                    isExpanded = true
                                    updateWindowSize()
                                }
                            }
                        )
                    }
                }
            }
        }

        view.setOnTouchListener { _, event ->
            handleTouchEvent(event)
        }

        try {
            windowManager.addView(view, params)
            composeView = view
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = params.x
                initialY = params.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                isDragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY
                if (abs(dx) > 10 || abs(dy) > 10) {
                    isDragging = true
                    params.x = initialX + dx.toInt()
                    params.y = initialY + dy.toInt()
                    composeView?.let { windowManager.updateViewLayout(it, params) }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!isDragging) {
                    // Tap event handled
                    composeView?.performClick()
                } else if (!isExpanded) {
                    // Drag release: snap to nearest edge (Part 3.6.4)
                    snapToEdge(fullyVisible = false)
                }
                return true
            }
        }
        return false
    }

    private fun snapToEdge(fullyVisible: Boolean) {
        val displayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val snapToRight = params.x > (screenWidth / 2)

        val targetX = if (snapToRight) {
            if (fullyVisible) screenWidth - 140 else screenWidth - 70 // 24dp hidden
        } else {
            if (fullyVisible) 20 else -40 // half-hidden
        }
        params.x = targetX
        isHalfHidden = !fullyVisible
        composeView?.let { windowManager.updateViewLayout(it, params) }
    }

    private fun updateWindowSize() {
        composeView?.let {
            windowManager.updateViewLayout(it, params)
        }
    }

    fun notifyFpChanged() {
        isRecentlyChanged = true
        changeTimerJob?.cancel()
        changeTimerJob = scope.launch {
            delay(2000L) // fades back to 85% after 2s (Part 3.6.4)
            isRecentlyChanged = false
        }
    }

    fun hideOverlay() {
        composeView?.let { view ->
            try {
                windowManager.removeView(view)
                view.disposeComposition()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            composeView = null
        }
        lifecycleOwner?.destroy()
        lifecycleOwner = null
    }
}
