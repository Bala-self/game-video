package com.example.overlay.composables

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FPTier
import com.example.ui.components.FPRing
import com.example.ui.components.getCalmPhraseForTier
import com.example.ui.theme.Baloo2FontFamily
import com.example.ui.theme.BgPrimaryDark
import com.example.ui.theme.BgSurfaceDark
import com.example.ui.theme.ShapeLarge
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.fpToColor

@Composable
fun CollapsedBubble(
    fp: Int,
    tier: FPTier,
    isRecentlyChanged: Boolean,
    onTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 85% opacity idle, 100% on any FP change (Part 3.6.4)
    val alphaAnim by animateFloatAsState(
        targetValue = if (isRecentlyChanged) 1.0f else 0.85f,
        animationSpec = tween(durationMillis = 300),
        label = "bubbleAlpha"
    )

    val arcColor = fpToColor(fp)

    Box(
        modifier = modifier
            .size(48.dp)
            .alpha(alphaAnim)
            .clip(CircleShape)
            .background(BgPrimaryDark.copy(alpha = 0.92f))
            .clickable(onClick = onTap)
            .testTag("collapsed_overlay_bubble"),
        contentAlignment = Alignment.Center
    ) {
        // 4dp arc stroke showing FP progress around edge
        Canvas(modifier = Modifier.size(48.dp)) {
            val strokePx = 4.dp.toPx()
            val diameter = size.minDimension - strokePx
            val topLeft = Offset(strokePx / 2f, strokePx / 2f)
            val arcSize = Size(diameter, diameter)

            // Background subtle rim
            drawArc(
                color = Color(0x33FFFFFF),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx)
            )

            // FP Progress arc
            val sweep = 360f * (fp / 100f).coerceIn(0f, 1f)
            drawArc(
                color = arcColor,
                startAngle = -90f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }

        // Center companion face glyph (Angel / Devil / Two-Face per tier per Part 3.6.4)
        val glyphRes = when (tier) {
            FPTier.FOCUSED -> com.example.R.drawable.face_angel
            FPTier.NEUTRAL -> com.example.R.drawable.app_logo_split
            FPTier.WARNING -> com.example.R.drawable.face_devil
            FPTier.DEFEATED -> com.example.R.drawable.face_devil
        }
        Image(
            painter = painterResource(id = glyphRes),
            contentDescription = null,
            modifier = Modifier.size(28.dp)
        )
    }
}

@Composable
fun ExpandedCard(
    fp: Int,
    tier: FPTier,
    onCollapse: () -> Unit,
    onOpenApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = ShapeLarge,
        colors = CardDefaults.cardColors(containerColor = BgSurfaceDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier
            .width(220.dp)
            .height(120.dp)
            .clickable(onClick = onOpenApp)
            .testTag("expanded_overlay_card")
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mini FPRing (64dp per Part 3.6.4)
                FPRing(
                    fp = fp,
                    tier = tier,
                    size = 64.dp,
                    strokeWidth = 6.dp,
                    showLabel = false
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = tier.label,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = fpToColor(fp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = getCalmPhraseForTier(tier),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Small "X" collapse control (top-right, >= 24dp tap target per Part 3.6.4)
            IconButton(
                onClick = onCollapse,
                modifier = Modifier
                    .size(28.dp)
                    .align(Alignment.TopEnd)
                    .testTag("overlay_collapse_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Collapse overlay",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
