package com.example.domain.usecase

import com.example.domain.model.AppCategory
import com.example.domain.model.BlockType
import com.example.domain.model.EndingType
import com.example.domain.model.FPTier
import com.example.domain.model.ScheduleBlockModel

class CalculateFPUseCase {
    companion object {
        const val FP_MAX = 100f
        const val FP_MIN = 0f
        const val DRAIN_RATE_BASE = 2.0f // points per minute
        const val REGEN_RATE_BASE = 0.5f // points per minute
        const val GRACE_WINDOW_SECONDS = 15
        const val FORGIVENESS_DURATION_SECONDS = 30 * 60 // 30 minutes
    }

    /**
     * Calculates the delta FP for an active interval (e.g. 1 second or 1 minute).
     * @param intervalSeconds elapsed seconds in this tick
     * @param category category of the foreground app
     * @param continuousSeconds how many continuous seconds the user has been in this app
     * @param activeBlock the current schedule block if any
     * @param isShieldActive whether a forgiveness token is currently shielding drain
     */
    fun calculateDelta(
        intervalSeconds: Int,
        category: AppCategory,
        continuousSeconds: Int,
        activeBlock: ScheduleBlockModel?,
        isShieldActive: Boolean
    ): Float {
        if (intervalSeconds <= 0) return 0f

        val minutesFraction = intervalSeconds / 60f

        return when (category) {
            AppCategory.DISTRACTING -> {
                if (isShieldActive) {
                    0f // Shield active: drain paused completely
                } else {
                    // Escalating Drain Curve per Part 2.2
                    val continuousMinutes = continuousSeconds / 60f
                    val multiplier = when {
                        continuousMinutes < 5f -> 1.0f
                        continuousMinutes < 15f -> 1.5f
                        else -> 2.0f // capped at 2.0x
                    }
                    val drainRate = DRAIN_RATE_BASE * multiplier
                    -(drainRate * minutesFraction)
                }
            }
            AppCategory.FOCUS -> {
                // Regen only accrues during defined Focus Blocks in Schedule (Part 2.3)
                if (activeBlock != null && activeBlock.type == BlockType.FOCUS) {
                    REGEN_RATE_BASE * minutesFraction
                } else {
                    0f
                }
            }
            AppCategory.NEUTRAL -> 0f
        }
    }
}

class EvaluateEndingUseCase {
    fun execute(finalFp: Int): EndingType {
        return EndingType.fromFp(finalFp)
    }

    fun getTier(fp: Int): FPTier {
        return FPTier.fromFp(fp)
    }
}
