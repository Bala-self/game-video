package com.example.domain.model

enum class FPTier(val label: String, val minFp: Int, val maxFp: Int) {
    FOCUSED("Focused", 70, 100),
    NEUTRAL("Neutral", 40, 69),
    WARNING("Warning", 1, 39),
    DEFEATED("Zero", 0, 0);

    companion object {
        fun fromFp(fp: Int): FPTier = when {
            fp >= 70 -> FOCUSED
            fp >= 40 -> NEUTRAL
            fp >= 1 -> WARNING
            else -> DEFEATED
        }
    }
}

enum class EndingType {
    GOOD,
    NEUTRAL,
    ROUGH,
    DEFEATED;

    companion object {
        fun fromFp(fp: Int): EndingType = when {
            fp >= 70 -> GOOD
            fp >= 40 -> NEUTRAL
            fp >= 1 -> ROUGH
            else -> DEFEATED
        }
    }
}

enum class AppCategory(val title: String) {
    DISTRACTING("Distracting"),
    FOCUS("Focus"),
    NEUTRAL("Neutral")
}

enum class BlockType {
    FOCUS,
    BREAK
}

enum class CompanionPose {
    FOCUSED, // Upright, serene, glowing
    NEUTRAL, // Slouched, calm
    TIRED,   // Warning, sluggish posture
    RESTING  // Defeated / 0 FP, settled and resting peacefully
}

enum class PersonalityTone(val displayName: String, val description: String) {
    GENTLE("Gentle", "Warm, validating, and soft-spoken encouragement."),
    NEUTRAL("Neutral", "Balanced, matter-of-fact, and objective observation."),
    BLUNT("Blunt", "Concise, direct, and straight to the point.")
}

data class FPState(
    val currentFp: Int = 100,
    val tier: FPTier = FPTier.FOCUSED,
    val activePackageName: String? = null,
    val activeAppDisplayName: String? = null,
    val activeAppCategory: AppCategory = AppCategory.NEUTRAL,
    val isForgivenessShieldActive: Boolean = false,
    val shieldRemainingSeconds: Int = 0,
    val isServiceRunning: Boolean = false,
    val currentBlock: ScheduleBlockModel? = null
)

data class ScheduleBlockModel(
    val id: Long = 0,
    val label: String,
    val type: BlockType,
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val sortOrder: Int = 0,
    val reminderEnabled: Boolean = true,
    val reminderLeadMinutes: Int = 5,
    val distractingAppsOverride: List<String> = emptyList()
)

data class TrackedAppModel(
    val packageName: String,
    val displayName: String,
    val category: AppCategory,
    val isGlobal: Boolean = true
)

data class DaySummaryModel(
    val date: String,
    val finalFp: Int,
    val endingTier: EndingType,
    val intentionText: String?,
    val forgivenessTokenUsed: Boolean,
    val topApps: List<AppUsageSummary> = emptyList()
)

data class AppUsageSummary(
    val packageName: String,
    val displayName: String,
    val durationSeconds: Int,
    val category: AppCategory
)
