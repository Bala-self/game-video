package com.example

import com.example.domain.model.AppCategory
import com.example.domain.model.BlockType
import com.example.domain.model.ScheduleBlockModel
import com.example.domain.usecase.CalculateFPUseCase
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testFpEscalatingDrainCurve() {
    val useCase = CalculateFPUseCase()

    // First 5 minutes: base drain (2.0 FP / min -> -2.0 for 60s)
    val deltaEarly = useCase.calculateDelta(
      intervalSeconds = 60,
      category = AppCategory.DISTRACTING,
      continuousSeconds = 120, // 2 minutes in
      activeBlock = null,
      isShieldActive = false
    )
    assertEquals(-2.0f, deltaEarly, 0.01f)

    // Minutes 5-15: 1.5x escalation (3.0 FP / min -> -3.0 for 60s)
    val deltaEscalated = useCase.calculateDelta(
      intervalSeconds = 60,
      category = AppCategory.DISTRACTING,
      continuousSeconds = 480, // 8 minutes in
      activeBlock = null,
      isShieldActive = false
    )
    assertEquals(-3.0f, deltaEscalated, 0.01f)

    // Minutes 15+: 2.0x escalation capped (4.0 FP / min -> -4.0 for 60s)
    val deltaCapped = useCase.calculateDelta(
      intervalSeconds = 60,
      category = AppCategory.DISTRACTING,
      continuousSeconds = 1200, // 20 minutes in
      activeBlock = null,
      isShieldActive = false
    )
    assertEquals(-4.0f, deltaCapped, 0.01f)

    // Shield active: drain should be paused at 0.0
    val deltaShielded = useCase.calculateDelta(
      intervalSeconds = 60,
      category = AppCategory.DISTRACTING,
      continuousSeconds = 480,
      activeBlock = null,
      isShieldActive = true
    )
    assertEquals(0.0f, deltaShielded, 0.01f)

    // Focus app during focus block: +0.5 FP/min
    val focusBlock = ScheduleBlockModel(
      label = "Focus Session",
      type = BlockType.FOCUS,
      startMinuteOfDay = 540,
      endMinuteOfDay = 660
    )
    val deltaRegen = useCase.calculateDelta(
      intervalSeconds = 60,
      category = AppCategory.FOCUS,
      continuousSeconds = 120,
      activeBlock = focusBlock,
      isShieldActive = false
    )
    assertEquals(0.5f, deltaRegen, 0.01f)
  }
}
