# SPACE — the deep-space edition

Black-only rebuild of the single-page portfolio. Ivory / Forest is retired from
this version; the original blue project in `/home/user/portfolio/` is untouched.

```
Hallmark · macrostructure: Orbital Ledger
Hallmark · pre-emit critique: P5 H5 E4 S5 R4 V5
```

---

## 1. What was asked for

| Request | Where it landed |
|---|---|
| GSAP — collect smooth animation and motion effects | `js/scroll-fx.js`, `js/space.js`: scrubbed parallax, one hero dissolve, word-mask reveals, magnetic controls, pointer halos. GSAP ScrollTrigger drives scroll timing **when it can be fetched**; the same effects fall back to a vanilla rAF path when it cannot. |
| Aura gradients — “nice colour gradient for my background — I like black” | `css/space.css` §2: two fixed aurora hues (ion teal, nebula indigo) blended with `screen` over a near-black field, plus SVG turbulence grain at 0.045 and a vignette. Base is `#05070d`, never `#000`. |
| Hallmark — clear the AI pattern | `hallmark` (nutlope) audit rules applied to the real page: no purple ramp, no gradient text, no side-stripe cards, no three-column feature grid, no centred full-viewport hero, no floating orbs, no invented metrics. Copy was rewritten in a specific, human voice (below). |
| CodePen “Shooting Star” — cursor effect | `js/cursor-trail.js`: particles born from pointer travel, each drawing a tapered tail with a bright head. Written from scratch — no code, geometry or constants taken from the pen. The real pointer is never hidden. |
| Space theme, new features, smooth | Everything below. |

---

## 2. Palette

Both skies are black; `eclipse` is the calm variant for long reading, low
battery, or anyone who wants a quieter sky. The toggle lives where the old
light/dark switch was.

| Token | Nebula (default) | Eclipse |
|---|---|---|
| `--void` / page | `#05070d` | `#05070d` |
| `--void-2` / band | `#080c16` | `#080c16` |
| `--card` / panel | `#0b1120` | `#0b1120` |
| `--ink` | `#e9eefb` | `#e9eefb` |
| `--ink-2` | `#b0bdd9` | `#b0bdd9` |
| `--ink-3` muted | `#8d9ab9` | `#8d9ab9` |
| `--accent` ion | `#5ce6c9` | `#7f9dff` |
| `--accent-2` nebula | `#7f9dff` | `#7f9dff` |
| `--starlight` | `#ffd9a8` | `#ffd9a8` |
| aurora opacity | `0.78` | `0.22` |

Contrast at the brightest bloom (measured top-left of the hero, `#0a2d2c`):
body ink 12.3:1, muted ink 5.0:1. Both skies pass full-page axe WCAG 2.2 AA.
The bloom was lowered from 0.95 to 0.78 in the focus pass below, and every
content band now carries a scrim, so type is never read straight on a bloom.

---

## 3. What is new on the page

1. **Aurora sky** — three layered radial blooms, fixed-attached, two hues.
   One layer drifts on a 120 s transform; reduced motion and Motion off stop it.
2. **Starfield** — `js/sky.js`. One canvas, one rAF loop, DPR capped at 2,
   occasional meteors, stars drift with the scroll. Reduced motion or Motion off
   paints a single static frame; hidden tabs cost zero frames.
3. **Shooting-star cursor** — `js/cursor-trail.js`. Fine pointers only, capped at
   90 particles, the loop stops the moment nothing is alive. A pointer-down
   throws a small burst. The native cursor stays exactly as it is.
4. **Section rail** — a seven-stop rail on wide screens (≥ 1360 px) with a comet
   that tracks reading progress; a 2 px hairline bar plays the same role below
   that. The current stop is the last one whose top has passed the reading line,
   and the close always wins at the bottom of the page.
5. **Word-mask reveals** — headings unmask word by word (620 ms, staggered,
   finite). Masks are built only when motion is allowed and the heading keeps
   its exact text, spaces and emphasis.
6. **Magnetic controls and pointer halos** — buttons and social links lean 3 px
   toward the pointer; large cards carry a faint halo that follows it. Desktop
   fine pointers only.
7. **Scroll-linked parallax** — `[data-speed]` on the portrait, the four project
   screenshots and the two certificate images.
8. **Live Chennai clock** in the hero (`Asia/Kolkata`), falling back to the
   static “Chennai · IST” text without `Intl`; asserted against the browser's
   own `Intl` output in `tests/space.cjs`.
9. **Case study** (`/work/billpro/`) carries the same palette; its closing band
   became a deep panel so its large type keeps its contrast.

---

## 3b. The focus pass (same day, after review)

A full re-check of the page against the notes: *alignment, cursor, two pause
options, sharp boxes, unnecessary text, the logo, the navbar, and focus on the
content.* All eight are addressed; the corrections are listed here because most
of them were real bugs, not preferences.

| Note | What changed | Where |
|---|---|---|
| Navbar | The masthead is gone: no `<header>`, no `.desktop-nav`, no mobile menu dialog, on the main page **and** on the BillPro case study (which now opens with a single “Back to the portfolio” link). The seven-stop rail is the only in-page navigation, and it only appears on wide screens. The skip link was moved to be the first element in `<body>` so it is the first tab stop instead of sitting behind seven rail links. | `index.html`, `work/billpro/index.html`, `js/nav.js` deleted, `js/main.js` |
| Logo, top and bottom | The monogram mark and both brand wordmarks are removed — the header one with the header, the footer one and the giant signature name with the footer rebuild. | `index.html` |
| Two pause options | **Pause orbits** and **Pause journey** are gone. The guards that mattered stay: rings and the road still stop offscreen, on a hidden tab, when a planet is hovered or focused, and under Motion off. Selecting a skill no longer freezes the rings for good — with the manual resume removed, that would have stranded them. | `index.html`, `js/solar.js`, `js/life-road.js` |
| Sharp boxes | One three-step radius scale (`--radius-s 10`, `--radius-m 16`, `--radius-l 22`). Project cards, credentials, life cards, timeline cards, the about panel and the contact intro became rounded panels with air inside the edge; media, inputs, the proof strip and the portrait backplate take the middle step; buttons, tags, chips and the small controls are pills. The contact field wrapper lost its panel background so the input is not a card inside a card. | `css/space.css` §13.2 |
| Text alignment | Headings balance, body copy wraps prettily, and the short blocks (hero description, about copy, the desk note, card text, the form note) balance so no paragraph ends on a single word. Inputs had their text flush against the left wall of a filled box; they now have padding. Two real orphans (`“mindset to the web.”`, `“everything that ships.”`) are gone. | `css/space.css` §13.3 |
| Cursor | The trail's halo used to keep repainting forever once the pointer had moved, leaving a frozen ring on an idle page; it now fades out and the loop stops, so an idle page schedules nothing. The contextual follower no longer blinks away on every click or scroll — it hides only when it is not allowed (a dialog is open, motion off, non-mouse pointer). | `js/cursor-trail.js`, `js/signature.js` |
| Unnecessary text | Removed: the hero's three-part caption strip, its asterisk and stack line, the small-caps “ROBOTICS GRADUATE / MERN DEVELOPER” label, the portrait caption, the decorative education route label, the “ALONG THE WAY” index, the repeated “USED IN …” lines inside the toolkit rows, and a duplicated AI-usage sentence that appeared both in the toolkit and in the desk panel. The skills intro went from two lines to one; the form note is one short sentence. | `index.html` |
| Focus on the content | Every band except the hero now carries a scrim behind the column (`§13.4`), the nebula bloom was lowered to 0.78, and two palette leaks were fixed — see below. | `css/space.css` |

**Two palette leaks found and fixed.** Black-only was not true everywhere:

1. *The Work band was cream with near-black type.* `atelier.css` sets the
   retired ivory tokens on `.reference-page .ref-work .ref-project`, and in a
   browser that reports a light system preference (`data-theme="light"`) those
   rules outranked the space tokens. Measured: `--card #fbfaf5`, `--ink
   #202c25` — a bright block in the middle of a black page.
2. *The Experience band was forest green.* `--card #2c5141` gave every timeline
   card a green panel.

Both bands now take the void palette at a specificity that beats the atelier
`[data-theme]` rules, in both skies.

**One dead control fixed.** The sky switch toggled `dark` ↔ `light`, and since
both resolve to the same black field, it did nothing visible. It now toggles
nebula ↔ eclipse, which is what its label always promised.

---

## 4. Copy: the AI pattern, cleared

The writing was audited against the `hallmark` anti-pattern list and rewritten
where it read like a template. Every fact is unchanged.

- “Thoughtful interfaces. Solid foundations.” → **“I build the software small
  businesses run on.”**
- “ENGINEERING MIND. DEVELOPER CRAFT.” → **“ROBOTICS GRADUATE. MERN DEVELOPER.”**
- “One system for the numbers that matter.” → **“Invoices, purchases, stock and
  reports for a GST-registered business, kept in one place.”**
- Four identical “The hard part:” lines → four different, concrete sentences
  (“the GST maths started out in three places…”, “the admin routes are guarded on
  the server…”, “eight dense sections that still have to read on a 320px
  phone”, “no framework, so I split the interface, the data layer and the
  rules myself…”).
- “Learning doesn’t stop. Neither does the journey.” → **“Still adding stops to
  it. The next one is a full-time role.”**
- “An engineer’s approach to building software.” → **“Systems thinking, applied
  to the web.”** · “Software for the way business really works.” → **“Software
  for businesses that count things.”**
- Slogans removed: “BUILT WITH INTENTION.” → “CHENNAI · TAMIL NADU”,
  “FRONTEND · BACKEND · EVERYTHING BETWEEN” → “REACT · NODE · MONGODB”.
- Em dashes cut from the hero and every project blurb. No invented metrics,
  testimonials or logos were added anywhere.

---

## 5. Motion and honesty rules kept

- Native scrolling only: no wheel capture, no smooth-scroll hijack, no pinning.
- Nothing is hidden by CSS while waiting for JavaScript; word masks are created
  by script and only when motion is allowed.
- Every effect answers to `prefers-reduced-motion`, the footer **Motion** switch
  (`html.motion-off`), tab visibility and the opening sequence lock.
- Without JavaScript the aurora, grain and vignette still render, plus all
  content, the four projects, the certificates and native navigation.
- Accessibility: `aria-current` on the rail, `aria-hidden` on decorative layers,
  visible focus rings that appear instantly, pointer-events off every overlay.

## 6. Known limits (measured, not estimated)

- **JavaScript budget is over.** Local scripts: 20 files, **108,588 bytes raw**,
  **38,456 bytes gzipped** (target was 15 KB gzipped). With GSAP loaded:
  **≈ 225 KB raw / ≈ 85 KB gzipped** (target was 70 KB). GSAP is fetched with
  SRI only after the page is idle and only when motion is allowed, so it never
  blocks first paint, and the site is fully functional without it — but the
  budget is missed and I am not claiming otherwise.
- **No Lighthouse run.** No Safari, Firefox, physical-device or screen-reader
  session has been recorded for this edition.
- GSAP is loaded from `cdnjs` with pinned integrity hashes; offline, the built-in
  rAF scroll layer takes over (covered by a test).

---

## 7. Tests

`NODE_PATH=/home/user/node_modules node tests/<suite>.cjs`

| Suite | Checks | Covers |
|---|---|---|
| `regression.cjs` | 24 | opening, lightbox, solar keyboard, contact draft, both skies, no showcase, mobile, no-JS |
| `signature.cjs` | 16 | single-page structure, cursor, certificates, solar interaction, no navbar, full-page axe |
| `life-road.cjs` | 16 | four milestones, measured route, offscreen and auto-resume, no-JS |
| `solar-system.cjs` | 18 | 28 icons, four rings, hover/focus hold, auto-resume, sequential experience stops |
| `edge-checks.cjs` | 10 | first frame, repeated Enter, mobile sections, mail draft |
| `opening-refresh.cjs` | 6 | greeting on every refresh, deep links, reduced motion |
| `palette.cjs` | 1 | black-only in both skies, ion accent, untouched imagery, case study |
| `atelier.cjs` | 14 | structure, alternating projects, contact split, responsive bounds, no-JS |
| `space.cjs` | **27** | aurora, starfield, cursor trail, rail, progress, word masks, resize-while-scrolled, axe on both skies, reduced motion, Motion off, touch, no-JS, **plus the focus pass**: no navbar, no logo, no pause controls, rounded panels, unclipped word masks, idle cursor, real sky switch, black-only bands, skip-link order |
| **Total** | **132** | all passing |

`scripts/verify_local.py`: **151 local references, 0 broken**.

`tests/screens-space.cjs` writes the review screenshots to `tests/artifacts/`.
