> Historical implementation record. See `IVORY-FOREST.md` and `QA.md` for the current separate redesign and its validation.

# QA record

Test date: **14 October 2026**.

## Local mobile Lighthouse

Lighthouse CLI against the local Python static server using Chromium, default mobile simulation and simulated throttling. These are **local laboratory results**, not deployed PageSpeed Insights or real-user measurements. Repeated runs varied slightly. The motion edition was re-measured after the animation pass. The final recorded runs were:

| Page | Performance | Accessibility | Best practices | SEO | LCP | CLS (rounded) |
|---|---:|---:|---:|---:|---:|---:|
| / | 95 | 100 | 100 | 100 | 2.7 s | 0.001 |
| /work/billpro/ | 96 | 100 | 100 | 100 | 2.6 s | 0 |

Both pages meet the plan's 95-point category threshold **in these runs**. The stricter **under-2.0-second LCP target is not yet met**, and the home page has a very small nonzero measured layout shift. A rounded zero for the case-study page is not a guarantee of mathematical zero on every load. No claim of full budget compliance is made.

Remaining performance work: finalize font fallback metrics, tune critical CSS/font discovery, and retest with production compression/caching and a real mobile connection. The preview server does not implement the production `_headers` rules.

## Interaction and accessibility checks

- No horizontal overflow at 320, 360, 640, 768, 960 and 1440 CSS pixels.
- 360×780: hero availability and both buttons above fold; menu opens and Escape closes.
- Dark theme persists after reload; project screenshot modal opens and closes.
- Skill disclosures open on keyboard focus, linked projects are tabbable, Escape dismisses.
- Email copied using Clipboard API with accessible status feedback.
- CV PDF and vCard available.
- / light: 0 axe violations.
- / dark: 0 axe violations.
- /work/billpro/ light: 0 axe violations.
- /work/billpro/ dark: 0 axe violations.
- JavaScript disabled: headline, project content and mobile navigation remain available.
- Reduced motion: no hero introduction; skill controls still work.
- JavaScript scroll-spine fallback updates when CSS timeline support is unavailable.
- No JavaScript page errors recorded.

Automated axe checks are not a complete accessibility certification. Manual NVDA/VoiceOver, real-device touch behavior and every-browser validation remain outstanding.

## Static references and payload

- 104 local HTML asset/link/anchor references checked: no broken references.
- Four self-hosted WOFF2 files: 112,584 bytes total.
- Motion-edition JavaScript: 29,464 bytes uncompressed; 8,119 bytes in a concatenated gzip estimate. No framework or runtime dependency.
- Portrait optimized below 60 KB; screenshots have 400/800-pixel responsive derivatives with explicit dimensions.
- Original uploaded PDF retained; no claim that its content/layout was corrected.
- New vCard uses CRLF line endings; import into actual Android/iOS contact apps still needs a device check.

## Public source checks

- Pizza Palace and TripAdvisor homepages returned HTTP 200 and rendered in Chromium.
- This confirms homepage availability, not authenticated ordering, admin permissions or backend responsiveness after idle.
- BillPro's old portfolio explicitly says it is not publicly deployed.
- KADAI's old portfolio explicitly says setup is required; source documentation records limitations. No public demo was invented.
- Real BillPro and KADAI screenshots and original certificate images were recovered from the owner's supplied portfolio URL.
- No SMTP delivery, phone call, WhatsApp message, calendar booking or external account change was made.

## Deliberate deviations from the master plan

1. **Four projects**, explicitly selected by the owner after KADAI was found.
2. **No blocking preloader or GSAP dependency.** A short in-place hero introduction favors immediate access and fails open.
3. **No video playback yet.** Authentic recordings were not provided; there are real screenshots and an accessible enlargement dialog.
4. **No fabricated demo credentials, uptime monitors, API URLs, analytics identifiers or calendar link.** Corresponding setup is documented.
5. **Mobile hero omits the portrait** to keep the headline, availability and both actions above the fold; the portrait remains in About.
6. **No continuous reading-text parallax.** The spine carries continuous scroll feedback; other reveals play once.
7. **Certificate links use the original PNG evidence**, not fabricated PDFs or claims of third-party verification.
8. **Canonical URLs and sitemap wait for a real domain.** Run the included domain script before public deployment.

## Launch checks still required

- Correct the supplied CV and align it with the internship/certificates/one domain.
- Get the Prompt Engineering certificate date fixed by the issuer.
- Choose and deploy the canonical domain; run the configuration script.
- Validate share cards on WhatsApp and LinkedIn after deployment.
- Test on real Android and iOS devices, and Firefox/Safari.
- Re-run Lighthouse on the deployed CDN; meet LCP and CLS targets rather than treating current scores as the finish line.
- Test screen-reader navigation and actual contact-card import.
- Add/verify backend health routes, waking states and monitoring in the demo apps.
- Obtain real recordings and verifiable performance/test artifacts before publishing numerical claims.

## Motion-edition regression checks

- All scene families exercised through actual browser scrolling.
- Four-part shutters and frame traces clean up after completion.
- OS reduced-motion change during an active shutter removes all cover layers.
- Motion pause persists across reload; explicit replay returns to the top and re-arms the story.
- No horizontal overflow at 320 / 360 / 640 / 768 / 960 / 1440px.
- Both pages and both themes: zero settled-state axe violations.
- No page-script errors recorded.
- Local mobile Lighthouse re-run after the animation pass: home 95 / 100 / 100 / 100; case study 96 / 100 / 100 / 100 (Performance / Accessibility / Best Practices / SEO). LCP remains 2.7s / 2.6s; original stricter launch targets still apply.
- A walkthrough of the real running page is provided separately from the deployed assets.
