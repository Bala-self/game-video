> Historical implementation record. The separate Ivory / Forest redesign supersedes its visual descriptions. See `IVORY-FOREST.md` and `QA.md` for the current version.

# Solar skills & viewport experience update

15 October 2026. A scoped update to the existing single-page portfolio; no framework or overall redesign.

## What changed

- Removed the visible Technical Skills heading, connected-toolkit description, “Explore the toolkit” and selection instructions. A visually hidden section heading preserves accessible navigation.
- Replaced the ten abstract category nodes with **28 actual skill-icon buttons on four circular orbits**, surrounding a stationary **FSD** centre. The existing 20-item complete-toolkit disclosure remains available.
- Kept the owner’s blue **#1E4E98**, white/black palette, dark theme, section order, four projects, education/certificates, opening, About and contact integrations.
- Experience markers now trace open with their associated card/note, one entry at a time when the card reaches the viewport. Cards wait for their turn instead of appearing fully visible beforehand. Each entrance plays once per page load.

## Complete icon inventory

| Ring | Period / direction | Icons |
|---|---|---|
| 1 | 110 seconds / clockwise | React, Node.js, Express, MongoDB |
| 2 | 150 seconds / counter-clockwise | HTML5, CSS3, JavaScript, Tailwind CSS, Next.js, Redux Toolkit |
| 3 | 195 seconds / clockwise | Mongoose, JWT, bcrypt, REST APIs, MySQL, Firebase, PDFKit, TypeScript |
| 4 | 240 seconds / counter-clockwise | Git, GitHub, Jest, Supertest, Vercel, Postman, App Router, Docker, Claude, GitHub Copilot |

Paired items in the old toolkit now have individual icons. Existing learning/practice distinctions and project evidence are preserved; the AI tools are described as workflow assistance, not independent development experience. No proficiency was invented for unused hosting tools.

Images are self-hosted. Most are brand marks; bcrypt, REST APIs, Supertest and PDFKit use original neutral pictograms, not claimed official logos. App Router uses the Next.js mark. See `assets/icons/ICONS.md` and the included licences. The inventory mapping is in `tests/fixtures/skill-inventory.json`.

## Motion & interaction

- Four track rotations plus 28 counter-rotations keep icons and labels upright. No continuous JavaScript animation loop is used for the orbits.
- Hovering or focusing a **skill** pauses the rings; the empty centre does not. Selecting a skill shows its evidence and keeps motion paused until Resume orbits is used.
- Arrow keys and Home/End navigate the native buttons. Small screens hide the floating labels, but retain accessible names and tap-to-read details.
- Offscreen/document-hidden orbits stop. The local pause control, global Motion switch and OS reduced-motion preference are respected. The existing static embed mode stays static.
- Experience uses a viewport observer, a sequential queue and approximately 700 ms entrances. Nothing activates before reaching the viewport. Keyboard focus exposes its card immediately; Motion off and no-JS content remain readable. Printing exposes all cards.
- Removed competing old timeline/orbit animation handlers. Reset inherited list-item margins to prevent icons drifting away from their rings and overlapping during mobile rotations.

## Changed implementation files

- `index.html`: solar markup, icon buttons/evidence templates, accessible heading, timeline SVG rings.
- `css/solar.css`: circular geometry, responsive controls, marker and card states; loaded after the existing palette.
- `js/solar.js`: orbital controls and sequential experience entrances.
- `js/main.js`, `js/reference.js`, `js/signature.js`: initialize the new handlers and remove competing old skills/timeline behavior.
- `assets/icons/`: eleven new SVG assets plus attribution/licences.
- `tests/solar-system.cjs`: dedicated verification; existing regression/signature checks updated to the new interface rather than the removed ten-node graph.

## Verification

**74 named Chromium browser checks passed**: 18 solar/experience, 24 regression, 16 signature, 10 opening-edge and 6 refresh checks. The separate palette probe also passed. **194 local HTML asset/link/anchor references** were checked with no missing targets or duplicate IDs.

The focused suite checks all 28 decoded icons, all 32 slow rotation effects, pause/resume, evidence, keyboard behavior, no-JS, reduced motion, light/dark axe checks, and responsive bounds. At 320 px it samples six orbital phases and checks icon separation. Experience tests confirm no activation offscreen, sequential circle/card appearances during mobile scrolling, timing/order when several entries are visible, immediate keyboard access and no replay on return.

Full-site regression checks cover the opening/refresh behavior, project and certificate viewers, offline guide, mobile navigation, contact drafts, theme persistence, the case-study route and axe A/AA audits. Local reference checks cover CV and asset targets. No console warnings/errors occurred in normal exercised flows. Tested widths include 320, 390, 768, 1024, 1280 and 1440 px. Light/dark solar, mobile and completed timeline screenshots were reviewed.

### Reproduce

Serve the folder on port 3000. Test-only dependencies are Playwright, its Chromium browser and `@axe-core/playwright`; none is required by the website runtime.

```sh
node tests/solar-system.cjs
node tests/regression.cjs
node tests/signature.cjs
node tests/edge-checks.cjs
node tests/opening-refresh.cjs
node tests/palette.cjs
```

Machine-readable results are included in `tests/results/`; screenshots are generated under `tests/artifacts/` when the suites run.

### Remaining limits

These are local Chromium tests, not Safari/Firefox, real-device or screen-reader certification. No fresh Lighthouse run or production performance claim is made. The original 15 KB raw-JavaScript target remains exceeded; see `QA.md` for measured source size. External authenticated project workflows and actual email delivery are not verified. Existing CV/certificate limitations are unchanged. No external repository or live hosting account was modified.
