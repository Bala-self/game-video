# Space — validation (current)

Tested 16 October 2026 against the deep-space edition on port 3001. The
Ivory / Forest record follows below and is historical.

## Focus pass (second run the same day): 132 / 132 checks passed

Re-checked the whole page after a review that called out text alignment, the
cursor, the two pause options, sharp-cornered boxes, unnecessary text, the logo
at the top and bottom, the navbar, and focus on the content. Everything the
review asked for is done; four real bugs surfaced while checking.

| Suite | Passed | Scope |
|---|---:|---|
| `regression.cjs` | 24 | opening, replay, guide, lightboxes, forms, sections, both skies, accessibility, mobile, no JS, failure recovery |
| `signature.cjs` | 16 | cursor, credentials, solar interaction, motion controls, no navbar, responsive and full-page axe |
| `life-road.cjs` | 16 | exact facts, measured route, progress reversal, offscreen + auto-resume, certificates, mobile, no JS, axe |
| `solar-system.cjs` | 18 | all 28 icons, 32 rotating effects, hover/focus hold, auto-resume, responsive bounds, sequential Experience, axe |
| `edge-checks.cjs` | 10 | night-sky greeting, repeated input, lazy images, disclosures, guide, real draft, failure/deep-link/skip behaviour |
| `opening-refresh.cjs` | 6 | consecutive refreshes, anchored refresh, fresh deep links, skip and reduced motion |
| `palette.cjs` | 1 | black-only in both skies, ion accent, unaltered imagery, BillPro palette |
| `atelier.cjs` | 14 | structure, alternating project studies, contact split, 320–1440px bounds, axe, no JS, browser errors |
| `space.cjs` | **27** | the space suite plus: no navbar, no logo, no pause controls, every panel rounded, word masks unclipped, idle cursor clears, the sky switch really switches, black-only Work and Experience bands, skip-link order |

New checks written for this pass: no header/desktop nav/menu dialog anywhere;
no monogram or brand wordmark; both pause controls gone while the motion guards
still hold; every painted panel ≥ 8 px radius; `.space-word` masks never clip
(`scrollHeight ≤ clientHeight`); the trail canvas is empty again once the
pointer rests; the sky switch moves `data-theme` between `dark` and `eclipse`
with the matching `--brand`; the Work and Experience bands resolve to
black-only `--card`/`--paper`; the skip link is the first focusable element and
hands focus to `main`, and the first Tab from the top of the document lands on
it.

### Bugs found and fixed in this pass

1. **The Work band was cream on a black page.** `atelier.css` sets the retired
   ivory tokens (`.reference-page .ref-work .ref-project`, `--card #fbfaf5`,
   `--ink #202c25`) at a specificity that beats the space tokens whenever the
   browser reports a light system preference. Measured mean luminance of the
   band was 86 against 8 for the rest of the page. Fixed at the token level for
   both skies.
2. **The Experience band was forest green** (`--card #2c5141`) — the retired
   palette showing through every timeline card. Fixed at the token level.
3. **Word masks clipped descenders.** `scrollHeight 184` against
   `clientHeight 165` on the hero heading: the mask cut the tails of `g`, `y`
   and the accent on `é`. The mask now carries `padding-bottom: .18em` with a
   matching negative margin, and the reveal travels 120 % instead of 105 %.
4. **The sky switch did nothing.** It toggled `dark` ↔ `light`, and both
   resolve to the same black field, so the control changed nothing on screen
   (the tests set `eclipse` by hand, which is why they passed). It now toggles
   nebula ↔ eclipse.
5. **Skip link was not the first tab stop.** With the masthead gone, the
   section rail (seven links) came first in the DOM. The skip link is now the
   first element in `<body>`.
6. **The cursor trail never idled.** After the first pointer movement the loop
   redrew its halo every frame forever, leaving a frozen ring on screen. It now
   fades out and stops; the canvas is empty again once the pointer rests.
7. **The contextual follower blinked away on every click and on scroll**
   (hide handlers removed in an earlier pass). It now hides only when the
   follower is not allowed — dialog open, motion off, non-mouse pointer.
8. **Selecting a skill froze the orbit rings for good**, because `select()`
   set the internal paused flag and only the (now removed) resume button could
   clear it. Selection no longer pauses; hover and focus still hold the rings.

Also removed: the two pause controls, the header logo and the footer logo plus
the giant signature name, the navbar and mobile menu dialog on both pages, the
hero's caption strip / asterisk / stack line / small-caps label, the portrait
caption, the decorative education route label, the repeated “USED IN …” lines
in the toolkit, and one duplicated AI-usage sentence.

### Honest limits for this pass

- Same as before: no Lighthouse run, no Safari/Firefox, no physical devices, no
  screen-reader session.
- The layout audit (`tests/audit-layout.cjs`, report-only) still lists four
  categories I checked by hand and judged intentional or false: the 8 px
  “overflow” on `.ref-timeline-card` is the card's decorative arrow; the
  `.space-word` “overlaps” are transparent masks overlapping by the new 7 px of
  descender padding; the `.life-milestone` “orphans” are a separated `<strong>`
  inside a one-line result; and the full-bleed sections are bands, not boxes.
- JavaScript is over budget: 20 files, 108,588 bytes raw, 38,456 bytes gzipped
  (target 15 KB). With GSAP: ≈ 225 KB raw, ≈ 85 KB gzipped (target 70 KB).

## Automated results: 122 / 122 checks passed

| Suite | Passed | Scope |
|---|---:|---|
| `regression.cjs` | 24 | Opening, replay, guide, lightboxes, forms, sections, both skies, accessibility, mobile, no JS, failure recovery |
| `signature.cjs` | 16 | Cursor, credentials, solar interaction, motion controls, navigation, responsive and full-page axe |
| `life-road.cjs` | 16 | Exact facts, measured route, progress reversal, pause, certificates, mobile, no JS and axe |
| `solar-system.cjs` | 18 | All 28 icons, 32 rotating effects, pause/focus, offscreen behavior, responsive bounds, sequential Experience, axe |
| `edge-checks.cjs` | 10 | Night-sky greeting, repeated input, lazy images, disclosures, guide, real draft, failure/deep-link/skip behavior |
| `opening-refresh.cjs` | 6 | Consecutive refreshes, anchored refresh, fresh deep links, skip and reduced motion |
| `palette.cjs` | 1 | Black-only in both skies, ion accent, unaltered imagery, BillPro palette |
| `atelier.cjs` | 14 | Structure, alternating project studies, contact split, 320–1440px bounds, axe, no JS, browser errors |
| `space.cjs` | **17** | Aurora, starfield, cursor trail, rail, progress, word masks, resize-while-scrolled, axe on both skies, reduced motion, Motion off, touch, no-JS |

### Space edition: what was exercised

- Aurora: two fixed hues, no purple or magenta bloom, grain at 0.045 with `overlay` blending.
- Starfield: canvas paints (pixel readback), stops when hidden, paints a static frame under reduced motion.
- Cursor trail: canvas starts empty, paints only after pointer travel, native cursor untouched, hidden on touch and under reduced motion or Motion off.
- Rail: seven stops, `aria-current` follows the scroll, comet tracks progress, hidden below 1360 px where the hairline bar takes over.
- Word masks: reveal without changing heading text, spaces or emphasis.
- Resizing while scrolled to the bottom: re-measured from a known origin, the hero is no longer stranded at its faded end state (a real bug found and fixed in this pass).
- Axe WCAG 2.2 AA on the whole homepage in both skies.

### Corrections made during this pass

1. **Eclipse sky did nothing.** The token block sets its values on
   `html body.reference-page`, which is nearer in the inheritance chain than a
   bare `html[data-theme]` rule, so descendants kept the Nebula values. The
   calm sky now also targets the body.
2. **Resize while scrolled corrupted every scroll timeline** (GSAP measured
   against a smooth-scroll animation still in flight). Refresh now runs with
   instant scrolling from a known origin, and GSAP's own auto-refresh on resize
   is switched off in favour of our debounced one.
3. **Contrast on accent-filled chips.** White-on-forest became white-on-ion
   (1.54:1); the education stops and the BillPro closing band now use dark ink
   or a deep panel.
4. **Theme-colour metadata** still carried the forest value during the opening;
   both the opening stage and its restore use the space values.

### Honest limits

- No Lighthouse run, no Safari/Firefox, no physical devices, no screen-reader session.
- JavaScript is over budget: 21 local files, 111,405 bytes raw, 39,310 bytes
  gzipped (target 15 KB). With GSAP: ≈ 228 KB raw, ≈ 85 KB gzipped (target 70 KB).
  GSAP is deferred to idle and skipped entirely when motion is off or reduced.
- `tests/atelier.cjs` skips its original-file comparison because the preserved
  copy and its manifest were removed from the workspace at the owner's request.

---

# Ivory / Forest — validation (historical)

Tested 15 October 2026 against the separate redesign on port 3001. Earlier blue-edition results are historical and are not the evidence for this release.

## Automated results: 106 / 106 checks passed

| Suite | Passed | Scope |
|---|---:|---|
| `regression.cjs` | 24 | Opening, replay, guide, lightboxes, forms, sections, themes, accessibility, mobile, no JS, failure recovery |
| `signature.cjs` | 16 | Cursor, credentials, solar interaction, motion controls, navigation, responsive and accessibility checks |
| `life-road.cjs` | 16 | Exact facts, measured route, progress reversal, pause, certificates, mobile, no JS and axe |
| `solar-system.cjs` | 18 | All 28 icons, 32 rotating effects, pause/focus, offscreen behavior, responsive bounds, sequential Experience, axe |
| `edge-checks.cjs` | 10 | Forest greeting, repeated input, lazy images, disclosures, guide, real draft, failure/deep-link/skip behavior |
| `opening-refresh.cjs` | 6 | Consecutive refreshes, anchored refresh, fresh deep links, skip and reduced motion |
| `palette.cjs` | 1 | Opening, ivory/forest surfaces, both themes, original imagery and BillPro palette assertions |
| `atelier.cjs` | 15 | Original preservation, new composition, short hero motion, 320–1440px bounds, dark axe, no JS and browser errors |

These are grouped automated checks, not a claim of exhaustive certification. The original-file check is filesystem-based; the interaction/layout checks use Chromium through Playwright. Current JSON evidence is in `tests/results/`. Old reports and the obsolete mood test are under `tests/history/`.

### Accessibility and responsiveness

- Axe scans passed on the homepage and BillPro case study in light and dark modes, plus focused opening, guide, solar and road scans.
- Tested viewport widths include 320, 390, 768, 1024, 1280 and 1440 pixels.
- New heading bounds and section overflow were checked at 320, 390, 768, 1024 and 1440 pixels.
- Keyboard navigation, modal focus/Escape, reduced motion, OS motion changes and no-JS content were exercised.
- No browser warnings or exceptions were recorded in the exercised flows.
- Desktop and mobile screenshots were visually reviewed, including the new masthead, alternating work rows, forest Experience, education road and contact layout.

### Corrections made during this pass

- Removed an inherited block style that incorrectly detached the hero initial onto another line.
- Corrected the portrait alignment and replaced the footer's inherited local blue variables.
- Darkened secondary text after light-mode axe reported 4.43:1 against sage; the final full-page scans pass.
- Changed the solar test to await the actual paused state, avoiding an immediate animation-frame race. It still requires every infinite orbit/counter-rotation effect to pause.

## Static and preservation checks

- **158 local references checked; zero broken local references.** Includes HTML src/href/srcset, CSS URLs and relative module imports. Run `python3 scripts/verify_local.py` to repeat.
- **209 / 209 original files** still match the saved SHA-256 manifest.
- The preserved directory also contains the same 209 matching files.
- The frozen 24,039,532-byte ZIP passed integrity testing; all 209 entries match the manifest.
- The original blue release ZIP was not overwritten. The redesigned release has a separate filename.

## Performance: measured size, not a Lighthouse claim

- Native JavaScript: **17 files; 83,633 bytes raw**.
- Sum of individual gzip sizes: **29,305 bytes**. Actual transfer depends on server compression and caching.
- No GSAP, runtime framework, bundler, external font CDN or scroll-smoothing library was added.
- **The 15 KB JavaScript target is not met.** The retained interactive opening, guide, solar controls and road account for functionality beyond that budget.
- Lighthouse mobile 95+, LCP <2s and CLS 0 remain unverified targets. No fresh field metrics or Lighthouse certification is claimed.

## Remaining limits

- This pass does not certify Safari, Firefox, physical devices or real screen-reader sessions.
- Email draft creation/copying is tested; actual mail-client delivery is not.
- External demos and authenticated project workflows are not newly certified. No BillPro deployment or KADAI live demo was invented.
- The original CV PDF remains unchanged and may not include the latest internship/project information.
- Configure canonical/share URLs for the actual hosting domain before public release. Hosting at a subpath requires adapting the root-relative URLs.
- The reference website supplied mood only; its particular layout, assets, text and effects were deliberately not reproduced.
