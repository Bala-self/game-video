> Historical implementation record. See `IVORY-FOREST.md` and `QA.md` for the current separate redesign and its validation.

# Current QA record

Revision: **15 October 2026 — supplied opening + monochrome integration**.

Chromium 156, Playwright and axe, local HTTP server. **34/34 checks passed.** No console errors/warnings were captured across normal tested routes. Deliberately aborted module requests belong to failure-path testing.

Six axe audits passed with no WCAG A/AA violations: homepage light/dark, BillPro light/dark, mobile opening and offline guide. This is automated coverage, not full accessibility certification.

Source and repeatable commands: [OPENING-IMPLEMENTATION.md](OPENING-IMPLEMENTATION.md). The JSON results are in `tests/results/`. Screenshots are regenerated under `tests/artifacts/` when running the tests.

## Regression

| Check | Result |
|---|---|
| Escape releases preload, page lock and focus | PASS |
| Replay / keyboard trap / immediate repeated replay | PASS |
| Session reload bypasses opening | PASS |
| Offline guide, truthful answers, escaping input, Escape focus | PASS |
| Project lightbox / Escape | PASS |
| Ten native skill controls / keyboard navigation | PASS |
| Contact draft copy retains actual destination | PASS |
| No removed showcase; About directly precedes Contact | PASS |
| Light / dark theme switch and persistence | PASS |
| Homepage axe WCAG 2.2 AA light | PASS |
| Homepage axe WCAG 2.2 AA dark | PASS |
| Motion toggle persists and bypasses replay | PASS |
| Reduced-motion 320px: no loader, no overflow, readable content | PASS |
| Reduced-motion 390px: no loader, no overflow, readable content | PASS |
| Mobile navigation opens, link navigates, dialog closes | PASS |
| Mobile chat fits and does not obscure mobile action bar | PASS |
| Reduced-motion 768px: no loader, no overflow, readable content | PASS |
| Reduced-motion 1280px: no loader, no overflow, readable content | PASS |
| Changing OS reduced motion immediately releases active opening | PASS |
| Hung font readiness cannot trap opening | PASS |
| No JavaScript: content and native navigation remain accessible | PASS |
| BillPro case axe / monochrome light | PASS |
| BillPro case axe / monochrome dark | PASS |
| No browser console warnings/errors across exercised routes | PASS |

## Opening / edge cases

| Check | Result |
|---|---|
| Mobile first frame: pure black, 72vw loader, no overflow | PASS |
| Mobile intro axe WCAG AA and all local fonts loaded | PASS |
| Repeated Enter cannot create competing portal or leave inert content | PASS |
| Every mobile section scrolls normally; lazy images decode when reached | PASS |
| Project disclosures and preserved skill popovers work | PASS |
| Offline guide axe WCAG AA | PASS |
| Mail composer prepares correct encoded draft without sending | PASS |
| Missing main module independently releases initial black stage | PASS |
| Fresh deep link never shows opening | PASS |
| Skip intro activates reveal, not a second sequence | PASS |

## Additional inspection

The complete desktop counter → English → Tamil → Hindi → English → robot → portal sequence was captured and visually reviewed. Mobile greeting screenshots, full-page light/dark layouts, mobile skills and lazy-loaded portrait behavior were also inspected. Local references exist and native JS modules pass syntax checks.

## Performance and coverage limits

No Lighthouse measurement was made for this revision. The previous 95/96 scores are **historical**, archived in `QA-PAPER-SIGNAL.md`; they do not validate the present homepage. The original <2s LCP / zero CLS / 15KB raw JS goals are not certified and the raw JavaScript target is exceeded (approximately 67KB of native module source; no runtime framework).

Safari, Firefox, real devices, screen readers, production deployment, email delivery and authenticated demo/back-end operations remain unverified. CV/certificate content limitations remain as recorded in README. No external account or repository was modified.
