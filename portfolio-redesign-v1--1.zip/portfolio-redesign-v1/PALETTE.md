> Historical implementation record. The separate Ivory / Forest redesign supersedes its visual descriptions. See `IVORY-FOREST.md` and `QA.md` for the current version.

# Reference palette update

> **Current visual direction — Daylight / Blue Studio:** The owner selected a whole-portfolio, light-first redesign using the supplied site for mood only, with no reused assets, code or distinctive components. See [MOOD-DIRECTION.md](MOOD-DIRECTION.md) for scope, preservation, tests and limits.


The owner supplied an image with a white/black masthead and a deep blue project field. Sampling a flat area of that image produced RGB **30, 78, 152**, or **#1E4E98**.

## Applied throughout the site

- White surfaces and black typography remain the light-theme foundation.
- Project section, opening background and footer use the sampled blue.
- Primary actions, experience progress, selected skills, connection paths, education accents, field-focus lines and the cursor use coordinated blue accents.
- The existing dark theme uses navy surfaces and lighter blue accents for readable contrast, while retaining the sampled blue project/footer fields.
- Project screenshots and certificate previews display their original colors. Owner portraits remain monochrome. Original downloaded documents are unchanged.
- The BillPro case study uses the same shared palette. Browser/app icons, manifest theme color and opening browser chrome were updated.

`css/palette.css` is the final color layer on both routes. Earlier monochrome CSS remains as a structural/base fallback; older black-and-white design notes describe the preceding edition.

The single-page layout, content, section animations, native-pointer follower, original robot/portal sequence and every-refresh opening behavior are preserved. The removed 000–100 loading screen stays removed.

## Verification

The 24 regression checks, 16 signature checks, 10 opening-edge checks and six refresh checks were rerun successfully. A separate palette probe verified the exact blue in the opening, project section and footer; both theme variants; screenshot/portrait filters; and the BillPro palette.

Full-page light/dark screenshots were regenerated and the light-theme composition was visually reviewed. The audited homepage, case-study and overlay states reported no axe WCAG A/AA violations. No console exceptions or responsive overflow were reported in the exercised flows.

Run `node tests/palette.cjs` for palette assertions. Other test commands are in `SIGNATURE-DESIGN.md`. This is Chromium-based local verification, not Safari/Firefox, screen-reader, real-device or production Lighthouse certification.
