> Historical implementation record. The separate Ivory / Forest redesign supersedes its visual descriptions. See `IVORY-FOREST.md` and `QA.md` for the current version.

# Current motion system

> **Current visual direction — Daylight / Blue Studio:** The owner selected a whole-portfolio, light-first redesign using the supplied site for mood only, with no reused assets, code or distinctive components. See [MOOD-DIRECTION.md](MOOD-DIRECTION.md) for scope, preservation, tests and limits.


> **Latest update — animated life road:** Education now follows the four supplied milestones from Class X (2019) to the ongoing paid internship. Both certificates remain below the route. See [LIFE-ROAD.md](LIFE-ROAD.md) for design, animation, changed files, tests and limits.


> **Latest update — solar skills and experience:** 28 actual icon planets orbit a stationary FSD centre; experience circles and cards open sequentially on viewport arrival. The requested Skills intro copy is removed. See [SOLAR-UPDATE.md](SOLAR-UPDATE.md) for the complete inventory, changed files, controls, verification and remaining limits.


> **Current color theme:** the owner’s image now supplies the blue/white/black palette, with sampled blue **#1E4E98**. See `PALETTE.md` for scope and fresh verification. Earlier monochrome descriptions below are historical.


> **Opening update:** The initial 000–100 counter screen has been removed. The greeting → robot → portal sequence now starts directly and repeats on every refresh, including refreshed anchor URLs. Fresh deep links still go directly to their section. Reduced-motion, Motion off, Escape and fail-open safeguards remain. Previous counter/once-per-session descriptions below are historical. Focused verification: `node tests/opening-refresh.cjs` (six checks passed).


**Current single-page choreography:** see `SIGNATURE-DESIGN.md` for the complete section plan and implementation. `js/solar.js` now owns the skill orbits and viewport-sequential experience stops. `js/signature.js` supplies distinct hero, project, education, About, contact and footer motion, plus the owner-approved subtle desktop follower. `css/signature.css` contains its presentation.

The follower preserves the system pointer, cannot intercept clicks, and is disabled on touch/reduced-motion/manual-off states. Generic duplicated entrance handlers were removed from `reference.js`; all existing controls remain; timeline progress now ends at the actual opened marker, including after responsive layout changes. Hero choreography is prepared during the portal to avoid replaying already-revealed text.


The homepage now uses the owner's supplied opening, ported natively without React or Framer Motion. See [OPENING-IMPLEMENTATION.md](OPENING-IMPLEMENTATION.md) for source provenance, timings, easing, safeguards and deliberate integration differences.

## Homepage

`js/reference.js` retains section entrance tracking and the contact composer. Skills and experience are independently initialized from `js/solar.js`. It initializes `js/opening.js` and binds the footer Replay intro control. The superseded monogram loader has been removed.

Opening state machine:

```text
preload → intro → activating → portal → done
```

`opening-easing.js` retains the supplied cubic-bezier calculations. Word masks preserve complete Tamil/Devanagari shaped words. The robot uses the source SVG and native animation; the portal is a feathered radial mask expanding from its feet.

## Access and lifecycle

- OS reduced motion and the persisted Motion off preference bypass the opening and pause ambient motion.
- Once per tab session; explicit replay; direct links bypass the opening.
- Escape releases page locks and focus. The preload skip is keyboard-accessible.
- Font, bootstrap and activation failure deadlines prevent trapping the page.
- Animations and sequence timers are cancelled on exit. Activation is guarded against repeated clicks.
- Pointer-eye animation runs only while converging; idle animations stop under reduced/manual-off motion.
- The real document exists before enhancement and remains readable without JavaScript.
- Native scrolling, anchors and dialogs are retained. There is no scroll hijacking or pointer replacement. The approved contextual follower is decorative and optional through the Motion control.

## Case study / history

The case-study route retains the earlier shared WAAPI scene director in `js/motion.js`, now using neutral color tokens. The prior edition's design rationale is archived in `MOTION-PAPER-SIGNAL.md`; its vermilion/paper descriptions no longer describe the current palette or homepage opening.

Current validation is in `QA.md`. Historical Lighthouse values are not current performance claims.
