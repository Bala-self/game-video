# Balakrishnan M — content research and reconciliation

Inspected: **14 October 2026**. This is a factual inventory for the portfolio rebuild, not an independent verification of employment, certificates, production security or project performance.

## Sources inspected

1. [Existing published portfolio](https://bala-self.github.io/perfectional-portfolio-/) — rendered content, links, HTML metadata, JavaScript and public assets.
2. [Existing portfolio repository](https://github.com/Bala-self/perfectional-portfolio-) — file tree, README, certificate assets and linked résumé.
3. User-uploaded `balakrishnan_FSD_CV.pdf` and the [résumé linked from the existing site](https://bala-self.github.io/perfectional-portfolio-/assets/files/Balakrishnan_M_Resume.pdf). Extracted text matches, including the Database layout problem.
4. [BillPro repository](https://github.com/Bala-self/billing-software) — README, billing helper, billing calculation tests, invoice model and stock-movement model.
5. [Pizza Palace repository](https://github.com/Bala-self/pizza-palace) and [live application](https://pizza-palace-lake.vercel.app/). The landing page loaded and was captured; the authenticated workflow was not exercised.
6. [TripAdvisor repository](https://github.com/Bala-self/tripadvisor.com) and [live website](https://bala-self.github.io/tripadvisor.com/). The homepage loaded and was captured.
7. [KADAI repository](https://github.com/Bala-self/ecommeres-website-using-firebase) — README, Firebase setup material and `docs/test-report.md`, including its later corrections. Reported test outcomes were not re-run during this portfolio build.
8. [Earlier portfolio portrait source](https://github.com/Bala-self/bala-portfolio/blob/main/frontend/src/assets/myimg.png).

## Owner decisions confirmed in this conversation

- Use `balakrishnan.code@email.com`. This was explicitly confirmed after the master plan questioned the domain. Mailbox delivery has not been tested.
- Use **the CV's LinkedIn profile**, `https://www.linkedin.com/in/balakrishnan-m-509aa8423/`.
- The **Shanthi IT Solutions internship is current**, and **immediate joining remains possible**.
- Include **all four projects**. This explicitly revises v2's three-project limit.

## 1. Identity, location and contact

| Field | Collected information | Handling |
|---|---|---|
| Name | Balakrishnan M | Consistent across CV, site and certificate images |
| Role | MERN Stack Developer | Used in title, navigation and contact card |
| Location | Chennai, Tamil Nadu, India | Consistent across supplied material |
| Phone | +91 9384590539 | Present in CV and site's WhatsApp destination |
| Email | balakrishnan.code@email.com | Confirmed by owner; not delivery-tested |
| GitHub | https://github.com/Bala-self | Public repositories inspected |
| LinkedIn, CV | https://www.linkedin.com/in/balakrishnan-m-509aa8423/ | **Selected by owner** |
| LinkedIn, old site | https://www.linkedin.com/in/balakrishnan-mariyappan-b43813294 | Conflicting alternative; not used in rebuild |
| Languages | Tamil — native; English — professional | From CV |
| Availability | Immediate joiner; on-site across Tamil Nadu | Reconfirmed despite ongoing internship |
| Booking link | Not supplied | No invented cal.com account; direct phone call is offered instead |
| Production domain | Not chosen | No invented canonical domain; run `scripts/configure_domain.py` at launch |

### Existing portfolio URLs encountered

- https://bala-self.github.io/perfectional-portfolio-/ — additional source supplied in this conversation.
- https://bala-self.github.io/portfolio_me — CV portfolio URL.
- https://bala-portfolio-psi.vercel.app — another public portfolio repo's homepage.
- https://balainfo.vercel.app — `new_portfolio` repo's homepage.

These are an inventory, not confirmation that every old deployment is current or should be preserved. Choose one destination and update/redirect the others using your hosting accounts. No redirects on those external hosts were changed here.

## 2. Project evidence

### BillPro — flagship

**Public source:** https://github.com/Bala-self/billing-software

**Deployment:** The existing portfolio explicitly states **“Not deployed publicly — repo has setup instructions.”** This is stronger evidence than merely failing to discover a demo URL. Do not publish `billpro.yourdomain.in`, `demo@billpro.app`, or `demo1234` as real access details.

**Collected scope:**

- GST invoices; products, stock and stock movements; purchases; quotations; customers; employees and attendance; user permissions; reporting; audit logs; business settings.
- React frontend, Express/Node backend, MongoDB/Mongoose data layer.
- JWT authentication, bcrypt password hashing, Helmet and API rate limiting appear in the project documentation.
- PDFKit document generation.
- Shared tax calculation helper in `backend/utils/billing.js`.
- Intrastate CGST/SGST split versus interstate IGST, with pre-tax discounts and total calculations.
- Invoice lines retain their item-level tax and price values.
- Stock movements store business/product references, signed quantity, previous/new stock and transaction reference.
- Jest/Supertest test sources and an in-memory MongoDB test setup.

**Assets newly recovered:**

- [Actual dashboard screenshot](https://bala-self.github.io/perfectional-portfolio-/assets/images/billpro/01.webp).
- [Connection-flow illustration](https://bala-self.github.io/perfectional-portfolio-/assets/images/billpro/billpro-connection-flow.webp).
- [Overview illustration](https://bala-self.github.io/perfectional-portfolio-/assets/images/billpro/billpro-overview.webp).

The real dashboard screenshot now replaces the temporary illustration in the rebuild. Its displayed balances and sales are application data visible in the screenshot, **not impact metrics or evidence of paying customers**. The new case study uses its own concise SVG architecture diagram; existing infographic labels are not treated as proof of implementation.

**Important qualifications:**

- “16+ modules” comes from the CV/project material; an endpoint count is not substituted for a module count.
- The billing helper accepts an interstate flag. Do not claim that the helper independently validates a GSTIN or determines the state relationship.
- The repository README itself calls out development/demo authentication and CORS behavior for production review.
- Stock tracking exists; fully atomic multi-document updates under concurrent workloads have not been established by this review.
- No passing test count, Lighthouse score, load benchmark or production-security certification is published in the new case study.

### Pizza Palace

**Demo:** https://pizza-palace-lake.vercel.app/  
**Source:** https://github.com/Bala-self/pizza-palace

**Collected scope:** customer menu, cart and checkout; admin order dashboard; Preparing → Out for Delivery → Delivered workflow; JWT/bcrypt and role-based admin routing. MERN application.

The live homepage returned HTTP 200 and loaded in Chromium. A screenshot was captured directly from the deployment.

**Not established:** test-account credentials; current API health URL; warm-up monitoring; authenticated checkout/admin behavior; the CV's “60% faster”, “100+ concurrent users”, “<2s” and “95+ Lighthouse” claims. These figures are omitted from portfolio copy pending reproducible evidence.

### TripAdvisor UI

**Demo:** https://bala-self.github.io/tripadvisor.com/  
**Source:** https://github.com/Bala-self/tripadvisor.com

The old project's description explicitly calls this a **UI practice project / clone**, not a company product. The CV and old experience section call the role “Freelance”; that does not establish a paying client. The rebuild uses the neutral role title “Frontend UI Developer” and labels the project self-directed practice.

Collected scope: HTML, CSS and JavaScript; responsive multi-section homepage; hero search interface and category navigation; Flexbox and custom CSS. The old copy mentions 470+ CSS lines, but line count is not used as a quality metric.

The homepage loaded and was captured. No claim that it is an operational travel booking service is made. Claims of “100% browser compatibility”, “40% faster” and zero layout shift are omitted without test evidence.

### KADAI

**Source:** https://github.com/Bala-self/ecommeres-website-using-firebase  
**Public deployment:** none supplied; the existing portfolio says Firebase configuration/setup is required.

**Collected scope:**

- HTML, CSS, Tailwind and modular vanilla JavaScript.
- Firebase Authentication, Cloud Firestore and Firebase Storage integration paths.
- Catalog browsing, search, cart, wishlist, customer accounts and order history.
- **Cash-on-delivery order requests, not online payment processing.**
- Product/order administration, coupons and review moderation.
- Firestore/Storage rules and local setup documentation.

**Screenshot:** [existing portfolio asset](https://bala-self.github.io/perfectional-portfolio-/assets/images/kadai/kadai.png), optimized locally as `assets/img/kadai.webp`.

**Deeper documentation findings:**

`docs/test-report.md` contains a sequence of testing and correction notes, not just a single “everything works” declaration. It reports static and service-layer checks and a 142-scenario sweep, but earlier sections explicitly leave live Firebase queries and browser/screen-reader verification pending. Later addenda discuss real setup diagnostics and an authentication-readiness barrier defect that service-layer tests did not catch. Those later notes must be read alongside the early report, rather than quoting only the green totals.

The report also documents client-computed order totals as a backend-validation gap for online payments. The portfolio therefore does not describe KADAI as production-payment-ready. Razorpay is not attributed to it.

The README describes demo mode, while a later test-report addendum says the runtime demo catalog was removed in favor of Firebase-backed catalog data. Until a current local/live run confirms behavior, do not promise a populated offline demo.

## 3. Experience

| Period | Role/context | Source and decision |
|---|---|---|
| Aug 2026–present | Full Stack Development Intern — Shanthi IT Solutions; paid internship | Newly found on old site; owner confirmed current |
| Jun 2026–present | Independent MERN Developer | CV and old site; overlaps internship and is presented as independent work |
| Feb–Mar 2026 | Frontend UI Developer; TripAdvisor UI practice | Dates from CV/site; client relationship not established |

No invented internship responsibilities, client names, team size or business outcomes have been added. A useful next input would be two factual internship bullets: a feature you owned and the technologies you used.

The supplied CV does **not** yet contain the internship. It remains unchanged in the build because the selected deliverable was the website, not a CV rewrite. Reconcile it before a hiring launch.

## 4. Education and certificates

### Degree

- B.E., Robotics and Automation, **2021–2025**.
- Dhanalakshmi Srinivasan Engineering College, Perambalur, Tamil Nadu.
- **CGPA 7.4 · First Class**.

### Earlier schooling, collected but deliberately not placed on the new site

- Class X: Dalmia Higher Secondary School, completed 2019, 60%.
- Class XII: Vettri Vedyalaya Higher Secondary School, Computer Science group, completed 2021, 70%.

These are self-reported on the existing site; spelling and marks were not checked against marksheets. They are excluded in accordance with v2's degree-only rule.

### MERN certificate — documentary detail

[Certificate image](https://bala-self.github.io/perfectional-portfolio-/assets/images/certificates/cert-mern-bootcamp.png) visibly states:

- Recipient: **BALAKRISHNAN M**.
- Issuer branding: **EMC / error makes clever**.
- Award: **4-Month Full Stack MERN Development Bootcamp**.
- Date: **23 June 2026**.
- Signatories shown: Agnel John, Founder & CEO; Arjun VS, Mentor.

The CV instead lists **“The Complete MERN Stack Developer Masterclass.”** The plan suggests Udemy. Neither proves this is the same course. The rebuild uses the specific title supported by the recovered certificate; if the masterclass is a second credential, supply its certificate separately.

### Prompt Engineering certificate — unresolved document defect

[Certificate image](https://bala-self.github.io/perfectional-portfolio-/assets/images/certificates/cert-prompt-engineering.png) visibly states:

- Recipient: BALAKRISHNAN M.
- Issuer: EMC.
- Award: **Prompt Engineering Course**.
- Date field: **“Invalid Date”**.

The CV/site say 2025, but the certificate image does not substantiate a valid award date. The new page names the course and issuer without displaying a year and links to the **unchanged original certificate**. Request a corrected certificate from EMC; do not edit the award date yourself. “View certificate” is used instead of implying independent issuer verification.

## 5. CV and profile issues still requiring action

1. **Database layout defect:** its values appear after Additional Information rather than following “Database:”. Found in both uploaded and linked PDFs.
2. **LinkedIn mismatch:** resolved for the new site by the owner's explicit choice; update the old site's links if the CV profile is canonical.
3. **Experience mismatch:** current internship missing from CV.
4. **Certificate naming mismatch:** masterclass versus EMC bootcamp; establish whether one or two credentials exist.
5. **Prompt certificate date:** original image has a rendering/data defect.
6. **Razorpay:** listed in the CV, but KADAI explicitly excludes online payment integration. A separate learning repository is not proof of a shipped payment flow.
7. **Impact/performance numbers:** unsupported claims in the CV have not been repeated on the site.
8. **Old portfolio README:** still contains placeholder LinkedIn/Twitter/email/portfolio links and generic Python/Figma claims; do not reuse it as factual content.
9. **One domain:** still a launch decision, not something inferred from an old URL.

## 6. Applied to the new build

- Four projects, exact source links and two verified public homepage URLs.
- Real BillPro screenshot and local certificate images.
- Confirmed internship, correct ordering and immediate-joiner availability.
- CV-selected LinkedIn link in page markup, Person schema and vCard.
- Firebase grounded in KADAI instead of an unexplained skill-list entry.
- No fake BillPro login, public endpoint, payment integration, test-run screenshot or performance number.
- No external account changes, resume rewriting, hosting configuration or uptime monitor creation performed.

## 7. Remaining owner inputs

**Before public hiring launch:** corrected CV, final canonical domain, internship responsibilities, corrected Prompt Engineering certificate and confirmation of the masterclass/bootcamp distinction.

**For richer project demos:** BillPro public deployment and safe seeded credentials; tested backend health URLs; short authentic video recordings; reproducible test/performance evidence; optional working booking-calendar URL.
