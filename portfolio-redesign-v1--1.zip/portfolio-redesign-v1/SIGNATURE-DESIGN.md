> Historical implementation record. See `IVORY-FOREST.md` and `QA.md` for the current separate redesign and its validation.

# Single-page motion design — implementation record

> **Latest update — solar skills and experience:** 28 actual icon planets orbit a stationary FSD centre; experience circles and cards open sequentially on viewport arrival. The requested Skills intro copy is removed. See [SOLAR-UPDATE.md](SOLAR-UPDATE.md) for the complete inventory, changed files, controls, verification and remaining limits.

Skills graph/timeline descriptions below document the preceding design and are superseded by the solar update. The other section designs and cursor safeguards remain in place.


> **Current color theme:** the owner’s image now supplies the blue/white/black palette, with sampled blue **#1E4E98**. See `PALETTE.md` for scope and fresh verification. Earlier monochrome descriptions below are historical.


> **Opening update:** The initial 000–100 counter screen has been removed. The greeting → robot → portal sequence now starts directly and repeats on every refresh, including refreshed anchor URLs. Fresh deep links still go directly to their section. Reduced-motion, Motion off, Escape and fail-open safeguards remain. Previous counter/once-per-session descriptions below are historical. Focused verification: `node tests/opening-refresh.cjs` (six checks passed).


15 October 2026. Owner decisions: **single-page portfolio** and **subtle contextual desktop cursor**, keeping the native pointer. This explicitly revises the earlier no-custom-cursor direction; it does not introduce pointer replacement, scroll hijacking or 3D tilt.

## Design approach

Keep the existing black-and-white identity, real photographs, real project screenshots, supplied opening and accurate content. Give each section a different motion treatment tied to its subject, rather than applying the same fade to every block. Repeated floating geometric ornaments were removed. The main sections remain on one document; the previously implemented BillPro case-study URL is retained as supporting project content.

### Section-by-section plan, now implemented

| Area | Motion and interaction | Visual restraint |
|---|---|---|
| Home | Three headline lines reveal in 95ms offsets; portrait reveals with a vertical crop and small scale correction; description and actions follow. | 0.95–1.3s entrances, once per visit or explicit opening replay. No pointer tilt or scroll-controlled reading. |
| Projects | Screenshot crops open vertically; project copy/indexes stagger underneath. Hover/focus pans the real screenshot slightly. Native details and screenshot dialogs remain functional. | Original screenshots, not invented hover videos; no whole-card tilt or magnetic click targets. |
| Practical Experience | Cards arrive from alternating sides while timeline nodes settle into place. Existing native-scroll progress traces the line and updates the `01 / 03` indicator. | The role dates/content never change or count up. No invented statistics. |
| Technical Skills | SVG orbit paths draw progressively and skill medallions enter in sequence. Selecting a skill draws a connecting curve from its description to the selected node. Arrow keys select neighboring skills. | Static resting state; redundant perpetual icon floating removed. The connection is supplemental, with text/buttons carrying the accessible information. |
| Education & Certifications | Dedicated top-level section. Credential numbers, text and document previews reveal in reading order; an engineering-cap line drawing traces for the degree row. | Three real records, original certificate previews, actual CV link. The Prompt Engineering issue date remains omitted rather than invented. |
| About | Portrait backplate extends horizontally before the photograph wipes into view; the existing career narrative follows. | Real owner portrait and existing copy retained. About still directly precedes Contact. |
| Contact | Fields enter in a short sequence; focus draws a baseline. Actual clipboard success triggers a brief Copied label/icon response; status text remains available. | No fake send operation. The form copies a draft or opens the visitor’s mail app. |
| Footer | The owner’s name rises into its baseline; a horizontal rule draws and navigation groups follow. | One closing signature, not an endless text marquee. All footer links remain native. |

### Contextual cursor

A small damped follower sits beside the **unchanged system pointer**. It expands into a compact View, Go or Email label only on marked targets. The animation stops requesting frames when it converges, rather than running an idle render loop.

- Fine-pointer/hover devices at least 960px wide only.
- Hidden over form fields, in the supplied opening and native dialogs, during keyboard interaction, on window blur, and while scrolling.
- Disabled by OS reduced motion or the existing Motion off control.
- Decorative, `aria-hidden`, and `pointer-events:none`; it cannot intercept clicks or become a keyboard stop.
- Native cursor styles remain in place, including the screenshot zoom cursor.

## Structure and content

Top-level main sections: `#home`, `#work`, `#experience`, `#skills`, `#education`, `#about`, `#contact`, followed by the footer. Education was moved out of About, not duplicated. Desktop navigation now includes Experience and Education; mobile navigation includes every section. The removed device showcase was not reintroduced.

Degree: B.E. Robotics and Automation, 2021–2025, Dhanalakshmi Srinivasan Engineering College, Perambalur, CGPA 7.4 / First Class. Bootcamp: original EMC MERN certificate, 23 June 2026. Prompt Engineering: original credential, no fabricated date. Certificate thumbnails are derived from the supplied original files; links still resolve to those originals.

## Architecture / changed files

- `index.html`: dedicated education section, project indexes, navigation updates, signature footer, removal of repeated ornaments, stylesheet inclusion and wrapping no-JS navigation.
- `css/signature.css`: section-specific styling, responsive education/navigation, interaction states and cursor appearance. No default hidden content.
- `js/signature.js`: independent native WAAPI choreography, SVG path tracing, skill connector, contact feedback and contextual follower.
- `js/reference.js`: retained page controls/timeline progress; removed the superseded generic entrance observer to avoid competing animation handlers.
- `js/main.js`: initializes the new enhancement independently after the existing reference initializer.
- `js/gallery.js`: supports original certificate captions through the same accessible native-dialog viewer.
- `assets/img/cert-*.webp`: optimized derivatives of existing certificate images.
- `tests/signature.cjs`: new motion/cursor/layout/accessibility regression coverage.

The supplied opening files are unchanged by this upgrade. Website runtime remains HTML, CSS, native ES modules and browser APIs: no React, Next, Tailwind, Vite, Framer Motion or external animation dependency.

## Accessibility and lifecycle

Every content section is readable before JavaScript runs. No class hides it while waiting for an observer. Effects run once when a section enters view; they are cancelled when motion is disabled. Focus cancels any active reveal on a containing element so the focused control is immediately visible. The opening’s independent fail-open safeguards remain intact.

Scrolling, links, form validation, native dialogs and native details remain browser-controlled. The custom cursor adds information but never replaces a visible label or interaction. Ordinary image/certificate links still work without JavaScript.

## Actual validation

Current automated runs passed **50 named checks**:

- 24 existing regression checks, rerun after this upgrade.
- 10 opening/failure-path edge checks, rerun after this upgrade.
- 16 new signature-edition checks covering the single-page structure, certificate viewer, cursor behavior, skill connection, form/keyboard suppression, animation pause, responsive overflow, mobile navigation, no-JS reading, console errors and full-page light/dark axe audits.

A separate runtime probe found active animations in all eight content areas: hero, projects, experience, skills, education, About, contact and footer. Its element/property records are included in `tests/results/scene-motion-evidence.json`. This verifies that the choreography actually executes, not that every device produces identical frame timing.

Tested using Chromium 156 via Playwright against the local static server. Exercised widths include 320, 390, 768, 1024, 1280 and 1440px. Light/dark page screenshots and the mobile education layout were visually inspected. No horizontal overflow or console exceptions/warnings were reported in the tested normal flows. Six current page/overlay states passed axe WCAG A/AA checks; the new full-page checks also passed after adding education.

### Reproduce

From the site directory, start the static server on port 3000. In another terminal:

```sh
npm install --no-save playwright @axe-core/playwright
npx playwright install chromium
# Minimal Linux systems may also require: npx playwright install-deps chromium
node tests/regression.cjs
node tests/edge-checks.cjs
node tests/signature.cjs
```

These are test-only dependencies. Test screenshots/reports are written to `tests/artifacts/`; recorded JSON summaries are in `tests/results/`. Do not deploy node_modules or test artifacts.

## Remaining limits

No new Lighthouse score or universal animation-performance claim is made. The original strict LCP, CLS and raw-JavaScript budgets are not certified as met. Native module source exceeds the earlier 15KB raw target. Production compression, payload splitting and device-level performance measurement remain follow-up work.

Safari, Firefox, actual touch hardware and screen-reader sessions have not been certified. Automated accessibility checks do not establish complete accessibility. External demos/authenticated workflows were not retested; no mail was sent and no external repository or deployment account was changed. The existing CV and certificate limitations remain documented in README.
