> Historical implementation record. The separate Ivory / Forest redesign supersedes its visual descriptions. See `IVORY-FOREST.md` and `QA.md` for the current version.

# Daylight / Blue Studio — whole-portfolio visual direction

## The approved brief

The owner supplied https://nidheesh23.github.io/Portfolio/ strictly as a **mood reference**, explicitly prohibiting copying. After visual inspection, the owner chose **the entire portfolio** and **the existing light, white-and-blue direction**, rather than a dark-first redesign.

The qualities carried forward are atmospheric depth, confident typography, visual hierarchy and coordinated motion. No reference-site images, wording, source code, components or distinctive effects were reused. In particular, this portfolio does not reproduce its portrait/laptop composition, circular portrait frame, code card, rotating panels, gold palette, fabric opening or review widgets. The reference captures remain research files outside the app; none is shipped as a site asset.

## Original treatment

- **Hero:** a new “Built for the real world.” headline, solid royal-blue typography, original planar lighting, an offset folio frame and the owner's existing real grayscale portrait. Location/current-internship metadata and the existing availability fact are presented without invented metrics.
- **Navigation:** a restrained white surface with blue active states and a compact mobile/tablet menu. No-JS navigation wraps naturally; nonfunctional menu/theme buttons are hidden in that fallback.
- **Projects:** retain all four real projects, original screenshots, links, disclosures and viewers. Larger images and typography sit in raised white cards against a softly lit blue gallery.
- **Experience:** clearer type and dimensional cards, retaining the existing sequential viewport-driven circle/card reveals.
- **Skills:** all 28 actual icons still orbit FSD. The solar system sits in a softly lit white panel; the removed Skills introduction remains removed.
- **Education:** the owner's four-stop life road retains its geometry, travelling marker, exact details and animations. Certificates remain independently viewable below it.
- **About:** the owner's existing image and writing are retained, with a coordinated blue backplate and a quieter career panel.
- **Contact:** a spacious, clearly labelled form surface and stronger action hierarchy. Copy message is secondary; Open email draft remains the real primary action. Nothing sends email automatically.
- **Footer and case study:** typography, surfaces and palette are coordinated with the main page. The optional dark theme remains available and respects existing preferences.

The owner’s blue remains **#1E4E98**. White and pale-blue surfaces lead the light design; the original project/certificate images retain their own colours. Existing self-hosted fonts and assets are used. No new runtime assets or external libraries were introduced.

## Implementation

- `css/mood.css`: the new, scoped art-direction layer, loaded after previous styles. Earlier stylesheet names/design descriptions are historical; this layer does not originate from the supplied mood-reference site.
- `index.html`: original hero composition and typography, metadata, lighting layers, stylesheet, contact-button hierarchy and no-JS navigation fallback.
- `js/signature.js`: integrates the new eyebrow, metadata and lighting entrances into the existing motion controller. New light-panel effects finish in approximately 2.3 and 3.1 seconds; they are not infinite animations. Existing reduced-motion/global-off cancellation remains in force.
- `work/billpro/index.html`: loads the shared visual layer, without rewriting case-study facts or workflows.
- `tests/mood.cjs`: 15 focused checks for original content/assets, the selected palette, typography/imagery, retained components, finite effects, responsive layouts, tablet navigation, dark-theme axe and no-JS behavior.
- Existing test adjustments: the all-visible experience timing fixture uses a taller viewport to accommodate larger, more readable cards. The separate mobile test still verifies that offscreen entries do not activate early. The refresh test waits for the reduced-motion release condition instead of relying on a fixed 150 ms scheduling assumption.

The supplied multilingual greeting → robot → portal opening, refresh behavior, Skip/Escape/replay, offline guide, subtle cursor follower, native scrolling, project/certificate viewers, contact drafts and supporting CV route are preserved. No rejected device showcase, scroll replacement or 3D tilt was introduced.

## Verification

**105 named Chromium checks passed:** 15 mood, 16 life-road, 18 solar/experience, 24 regression, 16 signature, 10 opening-edge and 6 refresh checks. The separate palette probe also passed. Reports are included in `tests/results/`.

The new responsive checks examine section and heading bounds at 320, 390, 768, 1024 and 1440 px, including tablet menu navigation and 16 px mobile form fields. Existing suites additionally cover 1280 px, normal and reduced motion, keyboard controls, no-JS, contact drafts, overlays, opening failure paths and fresh/refresh anchor behavior. Light/dark and mobile screenshots were inspected. Automated axe A/AA checks found no violations in the exercised scopes/states; this is not accessibility certification.

Run the suites against the static server on port 3000:

```sh
node tests/mood.cjs
node tests/regression.cjs
node tests/signature.cjs
node tests/life-road.cjs
node tests/solar-system.cjs
node tests/edge-checks.cjs
node tests/opening-refresh.cjs
node tests/palette.cjs
```

Playwright, Chromium and `@axe-core/playwright` are test-only dependencies. The app itself remains HTML, CSS and native JavaScript with no bundler or framework.

## Limits and unchanged facts

No fresh Lighthouse or production performance result is claimed. The original 15 KB raw-JavaScript target remains exceeded; see `QA.md` for current source sizes. Safari/Firefox, real devices and assistive-technology sessions remain unverified. The original CV and certificate-date limitations, external authenticated project workflows and actual email delivery remain outside this UI update. No external hosting account or repository was modified.
