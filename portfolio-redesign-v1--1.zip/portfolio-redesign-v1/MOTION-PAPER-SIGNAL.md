> Historical implementation record. See `IVORY-FOREST.md` and `QA.md` for the current separate redesign and its validation.

# Paper / Signal — the motion edition

A full-page, hand-written animation system added at the owner's request. No animation library, smooth-scroll replacement or custom cursor.

## Concept

The page feels like a document being uncovered and annotated as you read it. Paper shutters reveal the work; the vermilion spine acts as a moving pen; typography arrives in reading order. Each section has its own treatment, but all share three easing curves and the existing palette.

## The sequence

| Moment | Treatment | Trigger |
|---|---|---|
| Opening | Monogram wipe, a vertical signal drawn down the spine, three masked headline lines | Page entry, or explicit replay |
| Hero portrait | Four vertical paper shutters with alternating top/bottom hinges; image settles from 1.06 scale | Opening, 180ms offset |
| Hero details | Short stagger through subline, availability, actions and shipping note | Opening, finished within 1.2s |
| Section titles | Individual visual words rise behind masks with a subtle rotational settle | First intersection |
| BillPro | Horizontal paper shutters, browser-window lift, a tracing border, coordinated copy | First intersection |
| Other projects | Same vocabulary with an 80ms desktop card offset, followed by title and detail stagger | First intersection |
| Skills | Labels reveal first, then chips settle with a restrained spring | First intersection per tier |
| Experience / education | Date arrives, a short vermilion rule draws, role unfolds, then context and outcomes | First intersection per entry |
| Pivot sentences | Softer word-level fade/rise instead of another image effect | First intersection |
| About portrait | Horizontal alternating shutters | First intersection |
| About text | Paragraph-by-paragraph reading rhythm | First intersection |
| Now card | Brief outline trace, title, then paired label/value rows | First intersection |
| Contact | Heading mask, email left-to-right wipe, then staggered contact actions | First intersection |
| Spine | Progress fill, moving pen-tip and one-time chapter branch lines | Native scroll progress |
| Buttons | Restrained light sweep and arrow response | Hover or keyboard focus |

## Controls

- **Motion on / Motion off** is in the footer, next to Replay the story. Its state persists locally.
- **Replay the story** uses an ordinary top anchor, then replays the opening and re-arms below-the-fold scenes. Normal upward scrolling does not replay entrances.
- Device **prefers-reduced-motion** wins over the optional site setting. In that mode the footer explains that reduced motion is active.
- Changing the preference during an animation finishes/cancels active effects and immediately removes temporary cover layers.

## Engineering

- `js/motion.js` is the scene director. IntersectionObserver triggers the effects, and the Web Animations API plays them.
- Only transform, opacity and clip-path are animated by the director.
- Text masks operate on visual copies; each heading keeps one complete accessible name. Emphasis and normal responsive wrapping are preserved.
- Off-screen content is not hidden in the base stylesheet. Without JavaScript it remains readable.
- Shutter layers are created only when needed, are aria-hidden and pointer-transparent, and are removed after their animations settle. A 1.5-second fail-open cleanup guard protects against interrupted effects.
- Compositor hints are temporary and removed after completion.
- Existing CSS scroll timelines retain their JavaScript fallback.
- The sticky navigation, native scrolling, project links, CV and contact controls remain real HTML interactions, not simulated animation elements.

## Timing rules

Main entrances: 600ms. Headline and image work: 900ms. Longest settling/trace effect: 1200ms. Word/chip increments: 40ms, capped so a long heading or row cannot create a long wait. No content-blocking preloader is used.

## Validation

The motion edition was checked in Chromium at 320, 360, 640, 768, 960 and 1440px widths. Checks cover layer cleanup, pause persistence, replay, reduced-motion interruption, keyboard access and both colour themes. Both main pages returned zero axe violations once entrance animations settled.

A recorded walkthrough, `portfolio-motion-preview.webm`, accompanies the source ZIP outside the deployed site. It is a recording of the implemented page, not a mockup or extra runtime asset.
