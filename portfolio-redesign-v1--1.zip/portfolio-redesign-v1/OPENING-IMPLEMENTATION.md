> Historical implementation record. See `IVORY-FOREST.md` and `QA.md` for the current separate redesign and its validation.

# Supplied opening + monochrome integration

> **Current color theme:** the owner’s image now supplies the blue/white/black palette, with sampled blue **#1E4E98**. See `PALETTE.md` for scope and fresh verification. Earlier monochrome descriptions below are historical.


> **Opening update:** The initial 000–100 counter screen has been removed. The greeting → robot → portal sequence now starts directly and repeats on every refresh, including refreshed anchor URLs. Fresh deep links still go directly to their section. Reduced-motion, Motion off, Escape and fail-open safeguards remain. Previous counter/once-per-session descriptions below are historical. Focused verification: `node tests/opening-refresh.cjs` (six checks passed).


> Earlier integration record. The opening is retained in the current single-page motion edition; see `SIGNATURE-DESIGN.md` and `QA.md` for the latest additions, tests and payload figures.

Revision: 15 October 2026. Source: https://github.com/Bala-self/game-file/blob/main/interactive-portfolio-opening-experience.zip

## What changed

The supplied React/Framer Motion experience was read and ported to native DOM, CSS, requestAnimationFrame and the Web Animations API. **The delivered website does not use React, Framer Motion, Vite, Tailwind, a bundler, a runtime CDN, or a chatbot service.** The ZIP’s sample homepage was not substituted for the existing portfolio.

### Opening reproduced from the supplied files

- Pure-black stage; centered `min(320px, 72vw)` preloader; three-digit `000–100` counter, 1px progress track, Balakrishnan / Full Stack Developer labels and Latin/Tamil/Devanagari glyphs.
- Local font readiness, a 1,900ms minimum counter phase, the source’s 0.085 progress-follow factor and 86% cap while fonts are pending; converging track and outward-moving text on completion.
- English → Tamil → Hindi → English greetings at 0 / 2,400 / 4,900 / 7,400ms relative to the intro. PORTFOLIO appears at 8,300ms. Word-level masks preserve Tamil and Devanagari shaping; source font sizes, word stagger and easing values are retained.
- Source robot SVG geometry, breathing, antenna sway, blinking, pointer-following eyes, idle glances, anticipation, jump, landing squash and spring recovery.
- Landing-origin ellipse: 420ms emergence, 1,700ms expansion, 46px seed radius, 0.22 initial flattening, source cubic-bezier calculations and 1.25px mask-edge feather.
- Source-style robot guide after entry. It is explicitly **offline, preset-answer help**, not a live AI or support service. The sample ZIP’s unsupported stack/availability claims were replaced with confirmed portfolio facts. No visitor messages are transmitted or stored; the visible conversation is bounded to 30 message elements.

### Entire website made monochrome

Both light and dark themes now use neutral black, white and gray. Blue skill halos, colored skill icons, the gold timeline node, green status badge, warm paper, tinted shadows and footer colors were neutralized. Project imagery and portraits render in grayscale; browser/app icons and the sharing image were also neutralized. Original project screenshot files, certificates and the owner’s CV were not rewritten.

All four projects, BillPro case study, CV/certificates, education, internship, skills, social links and contact-draft controls remain. The previously rejected device-showcase section remains removed; About directly precedes Contact.

## Deliberate integration differences

This is a faithful native port, not a claim of pixel-identical Framer runtime output. Native spring sampling and browser font rasterization can differ slightly in frame pacing/subpixels.

- Existing real portfolio retained instead of the ZIP’s generic sample homepage.
- Opening runs once per tab session. Footer **Replay intro** plays it again. Deep links go directly to their destinations.
- Reduced-motion or manually paused motion bypasses the sequence rather than requiring the source’s full greeting wait. Replay is visibly disabled while motion is off.
- Escape exits immediately. The preload phase has a keyboard-accessible skip control. Focus is contained while the opening owns the screen and returned to the main content on exit.
- A 2.5s independent bootstrap deadline reveals the document if enhancement modules do not arrive; a 6s preloader deadline and 6.5s activation deadline release page locks on failure. Fonts have the source’s 3.5s readiness timeout. Normal intro readiness waits for the visitor’s PORTFOLIO/Skip action, rather than navigating automatically.
- Page content stays readable without JavaScript. Only a successful enhancement locks it. Duplicate activation is guarded.
- On small screens, Bit moves above the existing fixed action bar after entry. The temporary greeting bubble dismisses on scrolling or pointer interaction so it does not cover the work while browsing.
- Tamil and Devanagari fonts are self-hosted, phrase-subset Noto fonts with OFL licenses; existing local Inter and JetBrains Mono are retained. Adding new scripts/phrases may require expanding the subsets.

## Files

| File/group | Purpose |
|---|---|
| `js/opening.js` | Native opening state machine, loading, greetings, robot, reveal, accessibility safeguards and offline guide |
| `js/opening-easing.js` | Supplied cubic-bezier, interpolation and progress helpers |
| `css/opening.css` | Scoped port of the supplied component styling, mobile integration and accessibility rules |
| `css/monochrome.css` | Shared neutral theme for homepage, case study and interactive states |
| `index.html` | CSS wiring, first-frame fail-open bootstrap, minor mobile heading whitespace fix |
| `js/reference.js`, `css/reference.css` | Removed superseded monogram loader; wired opening/replay and motion state; preserved page interactions |
| `js/theme.js` | Neutral browser theme-color values |
| `css/*.css` | Neutralized remaining legacy literal colors, including hover states |
| `work/billpro/index.html`, `cv/index.html` | Monochrome styling/metadata on secondary routes |
| `assets/fonts/noto-*` | Local Tamil/Devanagari font subsets and licenses |
| `assets/favicon.svg`, `assets/icon-*.png`, `assets/og.png` | Monochrome browser/app/sharing assets |
| `tests/*.cjs` | Repeatable Chromium interaction, accessibility and opening-flow checks |

## Verification of this revision

Chromium 156 via Playwright, local Python HTTP server. **24 regression checks and 10 additional edge checks passed**. A separate desktop flow capture exercised every greeting and the full portal reveal. No browser console warnings/errors were captured across the normal exercised routes. The missing-module test intentionally aborts a request.

- Widths: 320, 390, 768, 1280 and 1440px across layout/flow checks. No horizontal document overflow in the tested layouts.
- Full desktop and mobile opening, local font readiness, repeated activation, Skip, Escape, keyboard focus, replay and once-per-session behavior.
- Native scrolling through every mobile section; lazy portrait/project images decode when reached.
- Mobile navigation, native project details, screenshot lightbox and Escape, ten orbit skill buttons/arrow keys, retained skill popovers, theme persistence and motion preferences.
- Clipboard draft copying and correctly encoded mailto drafting. Tests prevented launching mail software; **no email was sent**.
- Offline guide input is rendered as text, not HTML. Known answers, mobile dimensions, Escape/focus return and disclosure are tested.
- JavaScript-disabled reading/navigation; hung font readiness; missing entry module; reduced-motion changes while the intro is active; fresh deep links.
- **Zero axe WCAG A/AA violations in the six audited states:** homepage light/dark, BillPro light/dark, mobile intro, and offline guide. Automated axe checks are not a substitute for screen-reader or real-device testing.
- Native-module syntax checks and local HTML asset/link existence checks passed.

### Reproduce

Serve the site from its root:

```sh
python3 -m http.server 3000 --bind 0.0.0.0
```

In a separate terminal, from the same directory, install **test-only** tooling and run:

```sh
npm install --no-save playwright @axe-core/playwright
npx playwright install chromium
# On a minimal Linux machine, browser system libraries may also be needed:
# npx playwright install-deps chromium
node tests/opening-flow.cjs
node tests/regression.cjs
node tests/edge-checks.cjs
```

Reports/screenshots are written to `tests/artifacts/`. These tools are not used by the website and need not be deployed. A first visit triggers the complete sequence; a return visit can use Replay intro. This static site uses root-relative URLs and must be hosted at a domain root unless its asset paths are adjusted.

## Limits / not claimed

Safari, Firefox, actual mobile devices, assistive-technology sessions and production-host behavior have not been certified in this revision. No new Lighthouse run was made. The old 95/96 performance scores in historical QA do **not** validate this reconstruction.

The source intentionally adds an opening wait. The original <2s LCP / 0 CLS / 15KB raw-JavaScript goals are **not claimed as met**. Native JS files total approximately 67KB raw, approximately 23KB with per-file gzip (excluding inline boot code; gzip is a size estimate, not the Python server’s transfer encoding). There are no runtime third-party framework dependencies. Further payload splitting and production measurement remain possible follow-up work.

External demos, authenticated workflows, Firebase writes/checkouts, email delivery and deployment to the owner’s GitHub account were not performed or revalidated in this pass. The CV remains the original document, with its previously noted content/layout limitations.
