> Historical implementation record. The separate Ivory / Forest redesign supersedes its visual descriptions. See `IVORY-FOREST.md` and `QA.md` for the current version.

# Education & Certifications — the life road

## Design and content

The existing Education section is now a winding, native-scrolling road through four owner-supplied milestones:

1. **Class X — 2019:** Dalmia Higher Secondary School. Year of completion: 2019 · Percentage: 60%.
2. **Class XII — Computer Science group — 2021:** Vettri Vedyalaya Higher Secondary School. Year of completion: 2021 · Percentage: 70%.
3. **B.E., Robotics and Automation — 2021–2025:** Dhanalakshmi Srinivasan Engineering College, Perambalur, Tamil Nadu. CGPA: 7.4 · First Class.
4. **Paid Internship — Full Stack Development — Aug 2026–present:** Shanthi IT Solutions. Ongoing · Paid internship.

School names are retained as supplied, not silently corrected. The degree moved from its former credential row into this road; the two actual EMC certificate viewers remain underneath. The CV file has not been rewritten.

## Animation

- A measured SVG road winds between alternating desktop cards. On mobile it becomes a narrow, gently curved roadside rail alongside the cards.
- A travelling direction marker follows the road as the visitor scrolls forward or backward. Its blue progress line follows the same geometry, passing through the actual marker centres rather than guessed offsets.
- Dashed lane markings move subtly, with a soft animated halo around the traveller.
- Cards slide/fade in, years wipe into view, icons turn into place, and factual text reveals in staggered stages. Marker rings pulse as the traveller passes them. Card entrances run once per page visit.
- Native scrolling is untouched. No pinning, scroll hijacking, smooth-scroll library, 3D tilt, framework or external animation dependency was added.
- Local Pause journey / Resume journey controls, the existing global Motion switch and OS reduced-motion preferences are supported. With motion disabled the route is presented as a completed static illustration, not as a claim that the internship has finished.
- Continuous effects stop offscreen and when the document is hidden. The animation frame loop settles when the traveller reaches its current target; it does not run continuously while idle. The road adapts when its container resizes.
- All factual content and certificate links remain readable without JavaScript. Decorative graphics are hidden from assistive technology. No controls were added to non-interactive milestone cards.

## Changed files

- `index.html`: replaced the old education introduction/degree row with four milestones and the route; retained both certificate articles.
- `css/life-road.css`: responsive road, checkpoint years, cards, blue/white/black and dark-theme treatment, animated lanes/halo and motion/print fallbacks.
- `js/life-road.js`: measured SVG geometry, scroll-following traveller, viewport entrances and motion controls.
- `js/main.js`: initializes the independent enhancement.
- `tests/life-road.cjs`: new focused browser checks.
- `tests/signature.cjs`: now expects two certificate rows plus four road milestones, rather than treating the degree as a third certificate row.

## Actual verification

**90 named Chromium checks passed:** 16 life-road, 18 solar/experience, 24 regression, 16 signature, 10 opening-edge and 6 refresh checks. The separate palette probe also passed.

Focused checks cover exact content, both certificates, staggered effects, forward/reverse native scrolling, path alignment to all four markers, local/global pause, offscreen suspension, light/dark and mobile axe A/AA audits, 320/390/768 px layouts, reduced motion, no-JS access and browser errors/warnings. The broad suites also exercise widths up to 1440 px, the opening, project/certificate overlays, contact drafts, navigation, the existing skill solar system and experience sequence. Desktop, dark and mobile captures were inspected.

Run `node tests/life-road.cjs` against the existing static server on port 3000. Tests use Playwright/Chromium and `@axe-core/playwright` as test-only dependencies. Website runtime remains plain HTML, CSS and JavaScript. Results are saved in `tests/results/`; test-generated screenshots are in `tests/artifacts/`.

## Limits

These are local automated Chromium checks, not Safari/Firefox, real-hardware or screen-reader certification. No new Lighthouse or production performance score is claimed. Total native JavaScript source remains above the original 15 KB target; current raw/gzip sizes are recorded in `QA.md`. Existing CV/certificate limitations and external project/email-delivery verification limits remain unchanged. No external host or repository was modified.
