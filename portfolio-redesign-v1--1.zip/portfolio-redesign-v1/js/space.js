/*
 * SPACE — the orchestrator for the deep-space edition.
 * Adds the section rail, the Chennai clock and the word-mask reveals, then
 * hands the sky, the cursor trail and the scroll layer to their modules.
 * Every piece is optional: if one fails the page stays exactly as it was.
 */
import { motionAllowed } from "./motion.js";
import { initSky } from "./sky.js";
import { initCursorTrail } from "./cursor-trail.js";
import { initScrollFx } from "./scroll-fx.js";

const RAIL_SECTIONS = [
  ["home", "Home"],
  ["work", "Work"],
  ["experience", "Experience"],
  ["skills", "Skills"],
  ["education", "Education"],
  ["about", "About"],
  ["contact", "Contact"],
];

function initRail() {
  const rail = document.querySelector(".space-rail");
  if (!rail || !("IntersectionObserver" in window)) return;
  const list = rail.querySelector("ol");
  if (!list) return;
  list.innerHTML = RAIL_SECTIONS.map(
    ([id, label]) =>
      `<li><a href="#${id}"><span aria-hidden="true"></span><span>${label}</span></a></li>`,
  ).join("");
  rail.classList.add("is-ready");

  const links = [...list.querySelectorAll("a")];
  const stops = RAIL_SECTIONS.map(([id]) => id)
    .map((id) => ({ id, el: document.getElementById(id) }))
    .filter((stop) => stop.el);

  // The current stop is the last one whose top has passed the reading line,
  // except at the very bottom of the page where the close always wins.
  let marked = "";
  let queued = false;
  const sync = () => {
    const line = window.innerHeight * 0.35;
    let id = stops[0] ? stops[0].id : "";
    for (const stop of stops) if (stop.el.getBoundingClientRect().top <= line) id = stop.id;
    const max = document.documentElement.scrollHeight - window.innerHeight;
    if (max > 0 && window.scrollY >= max - 4) id = "contact";
    if (id === marked) return;
    marked = id;
    links.forEach((a) =>
      a.setAttribute("aria-current", a.getAttribute("href") === `#${id}` ? "true" : "false"),
    );
  };
  const onScroll = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      sync();
    });
  };
  sync();
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onScroll);
}

function initClock() {
  const clock = document.querySelector("[data-clock]");
  if (!clock) return;
  let formatter;
  try {
    formatter = new Intl.DateTimeFormat("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      timeZone: "Asia/Kolkata",
    });
  } catch {
    return; // No Intl: leave the static "Chennai · IST" text in place.
  }
  const render = () => {
    clock.textContent = `Chennai · ${formatter.format(new Date())} IST`;
  };
  render();
  const align = () => {
    const now = new Date();
    const delay = 60000 - (now.getSeconds() * 1000 + now.getMilliseconds());
    setTimeout(() => {
      render();
      align();
    }, delay + 200);
  };
  align();
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) render();
  });
}

/*
 * Word masks are built only when motion is allowed, and the heading keeps its
 * exact text content: spaces stay as real text nodes, emphasis stays inline.
 */
function initWordMasks() {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");
  const targets = [...document.querySelectorAll("[data-split]")];

  function split(el) {
    if (el.dataset.spaceSplit) return [...el.querySelectorAll(".space-word")];
    el.dataset.spaceSplit = "1";
    const created = [];
    const walk = (parent) => {
      [...parent.childNodes].forEach((node) => {
        if (node.nodeType === Node.TEXT_NODE) {
          const parts = node.textContent.split(/(\s+)/);
          const fragment = document.createDocumentFragment();
          for (const part of parts) {
            if (!part) continue;
            if (/^\s+$/.test(part)) {
              fragment.appendChild(document.createTextNode(part));
              continue;
            }
            const mask = document.createElement("span");
            mask.className = "space-word";
            const inner = document.createElement("span");
            inner.textContent = part;
            mask.appendChild(inner);
            fragment.appendChild(mask);
            created.push(mask);
          }
          parent.replaceChild(fragment, node);
        } else if (node.nodeType === Node.ELEMENT_NODE) {
          walk(node);
        }
      });
    };
    walk(el);
    return created;
  }

  function reveal(el) {
    if (el.dataset.spaceRevealed) return;
    el.dataset.spaceRevealed = "1";
    const words = split(el);
    words.forEach((word, index) => {
      word.style.setProperty("--word-delay", `${Math.min(index * 45, 420)}ms`);
      word.classList.add("is-in");
    });
  }

  function clear() {
    for (const el of targets) {
      el.querySelectorAll(".space-word").forEach((word) => {
        word.classList.remove("is-in");
      });
      delete el.dataset.spaceRevealed;
    }
  }

  if (!("IntersectionObserver" in window)) return;

  const blocked = () =>
    document.body.classList.contains("opening-locked") ||
    document.documentElement.classList.contains("opening-pending");

  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        if (blocked()) continue;
        reveal(entry.target);
        observer.unobserve(entry.target);
      }
    },
    { threshold: 0.2, rootMargin: "0px 0px -6% 0px" },
  );

  function arm() {
    if (!motionAllowed() || reduce.matches) {
      clear();
      return;
    }
    targets.forEach((el) => {
      if (!el.dataset.spaceRevealed) observer.observe(el);
    });
  }

  function replayAfterOpening() {
    // The hero masks wait for the greeting → robot → portal to finish.
    targets
      .filter((el) => el.closest("#home"))
      .forEach((el) => {
        if (!el.dataset.spaceRevealed) observer.observe(el);
      });
  }

  arm();
  document.addEventListener("portfolio:openingdone", replayAfterOpening);
  document.addEventListener("portfolio:motionchange", arm);
  reduce.addEventListener("change", arm);
}

export function initSpace() {
  // One shared class so CSS can switch the sky, trail and masks off together.
  const syncMotion = () =>
    document.documentElement.classList.toggle("motion-off", !motionAllowed());
  syncMotion();
  document.addEventListener("portfolio:motionchange", syncMotion);
  for (const init of [initRail, initClock, initWordMasks, initSky, initCursorTrail, initScrollFx]) {
    try {
      init();
    } catch (error) {
      console.warn(`Space enhancement unavailable: ${init.name}`, error);
    }
  }
}
