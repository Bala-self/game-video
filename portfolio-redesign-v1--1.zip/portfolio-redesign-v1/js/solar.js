import { motionAllowed } from './motion.js';
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
const OUT='cubic-bezier(.22,1,.36,1)';

export function initSolarSystem(){
  const stage=document.querySelector('.solar-stage');if(!stage||new URLSearchParams(location.search).has('embed'))return;
  const section=stage.closest('#skills'),buttons=[...stage.querySelectorAll('.solar-planet')],detail=section.querySelector('#solar-detail');
  let inView=false,hovered=false,focused=false,paused=false;
  const spins=[];
  if(stage.animate)stage.querySelectorAll('.solar-track').forEach(track=>{
    const duration=Number(track.dataset.period)*1000,direction=Number(track.dataset.direction);
    // The counter-rotation keeps every logo and label upright, not just the ring.
    for(const [el,angle] of [[track,360*direction],...[...track.querySelectorAll('.solar-planet')].map(el=>[el,-360*direction])]){
      const animation=el.animate([{transform:'rotate(0deg)'},{transform:`rotate(${angle}deg)`}],{duration,iterations:Infinity,easing:'linear'});
      animation.pause();animation.currentTime=0;spins.push(animation);
    }
  });
  function sync(){
    const enabled=motionAllowed(),running=enabled&&inView&&!hovered&&!focused&&!paused&&!document.hidden&&!document.body.classList.contains('opening-locked');
    for(const animation of spins){if(running)animation.play();else animation.pause();}
    stage.dataset.running=String(running);
  }
  function select(button){
    buttons.forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
    detail.replaceChildren();const title=document.createElement('strong');title.textContent=button.dataset.label;
    const level=document.createElement('span');level.className='skill-level';level.textContent=button.dataset.level;title.append(level);detail.append(title);
    const evidence=document.createElement('div');evidence.className='solar-evidence';const template=document.getElementById(button.dataset.info);
    if(template)evidence.append(template.content.cloneNode(true));detail.append(evidence);
    /* No manual pause control: hover and focus still hold the rings, and a
       tap holds them for touch. Selection itself no longer freezes them. */
    sync();
  }
  buttons.forEach((button,index)=>{
    button.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse'){hovered=true;sync();}});
    button.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'){hovered=false;sync();}});
    button.addEventListener('click',()=>select(button));
    button.addEventListener('keydown',event=>{
      const keys=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'];if(!keys.includes(event.key))return;
      event.preventDefault();const i=event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1)+buttons.length)%buttons.length;
      buttons[i].focus({preventScroll:true});select(buttons[i]);
    });
  });
  stage.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'){hovered=false;sync();}});
  stage.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse'){paused=true;sync();}});
  stage.addEventListener('focusin',()=>{focused=true;sync();});
  stage.addEventListener('focusout',()=>queueMicrotask(()=>{focused=stage.contains(document.activeElement);sync();}));
  if('IntersectionObserver' in window)new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;sync();},{threshold:.05}).observe(stage);
  else {inView=true;}
  document.addEventListener('visibilitychange',sync);document.addEventListener('portfolio:motionchange',sync);document.addEventListener('portfolio:openingdone',sync);reduce.addEventListener('change',sync);
  window.addEventListener('pagehide',()=>spins.forEach(a=>a.pause()));window.addEventListener('pageshow',sync);
  window.addEventListener('beforeprint',()=>spins.forEach(a=>a.pause()));window.addEventListener('afterprint',sync);
  sync();
}

export function initExperienceStops(){
  const timeline=document.querySelector('.ref-timeline');if(!timeline||new URLSearchParams(location.search).has('embed'))return;
  const entries=[...timeline.querySelectorAll('.ref-timeline-entry')],line=timeline.querySelector('.ref-timeline-line'),fill=line.querySelector('span'),count=document.querySelector('.experience-counter');
  const visible=new Set(),seen=new Set(),queued=new Set(),effects=new Set();let queue=[],busy=false,progress=0;
  function animate(el,frames,options={}){
    if(!motionAllowed()||!el?.animate)return Promise.resolve();
    const animation=el.animate(frames,{duration:700,easing:OUT,fill:'backwards',...options});effects.add(animation);
    return animation.finished.catch(()=>{}).finally(()=>effects.delete(animation));
  }
  function align(){
    const box=timeline.getBoundingClientRect(),first=entries[0].querySelector('.ref-timeline-node').getBoundingClientRect(),last=entries.at(-1).querySelector('.ref-timeline-node').getBoundingClientRect();
    line.style.top=`${first.top+first.height/2-box.top}px`;line.style.left=`${first.left+first.width/2-box.left}px`;
    const height=Math.max(0,last.top+last.height/2-first.top-first.height/2);
    line.style.bottom='auto';line.style.height=`${height}px`;
    const latest=entries.reduce((last,e)=>seen.has(e)?e:last,null);
    const marker=latest?.querySelector('.ref-timeline-node').getBoundingClientRect();
    progress=marker&&height?Math.max(0,Math.min(1,(marker.top+marker.height/2-first.top-first.height/2)/height)):0;
    timeline.style.setProperty('--timeline-progress',progress);
  }
  async function reveal(entry,instant=false){
    const index=entries.indexOf(entry),from=progress;
    // A direct jump past earlier roles completes their markers without offscreen animation.
    entries.slice(0,index).forEach(previous=>{if(instant||previous.getBoundingClientRect().bottom<0){seen.add(previous);previous.classList.add('is-revealed');}});
    seen.add(entry);entry.classList.add('is-revealed');entries.forEach(e=>e.classList.toggle('is-current',e===entry));
    if(count)count.textContent=`${String(index+1).padStart(2,'0')} / ${String(entries.length).padStart(2,'0')}`;
    align();
    await Promise.all(instant?[]:[
      animate(entry.querySelector('.stop-progress'),[{strokeDashoffset:100},{strokeDashoffset:0}],{duration:700}),
      animate(entry.querySelector('.stop-core'),[{opacity:.2,scale:.4},{opacity:1,scale:1}],{duration:450,delay:220}),
      animate(entry.querySelector('.ref-timeline-card'),[{opacity:0,transform:`translateX(${index%2?10:-10}px)`},{opacity:1,transform:'translateX(0)'}],{duration:700}),
      animate(entry.querySelector('.ref-timeline-note'),[{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],{duration:550,delay:120}),
      animate(fill,[{transform:`scaleY(${from})`},{transform:`scaleY(${progress})`}],{duration:700})
    ]);
  }
  const blocked=()=>document.body.classList.contains('opening-locked');
  async function drain(){
    if(busy||blocked())return;busy=true;
    try{while(queue.length){const entry=queue.shift();queued.delete(entry);if(!visible.has(entry)||seen.has(entry))continue;await reveal(entry);}}finally{busy=false;}
  }
  function enqueue(entry){if(!seen.has(entry)&&!queued.has(entry)){queue.push(entry);queued.add(entry);queue.sort((a,b)=>entries.indexOf(a)-entries.indexOf(b));}}
  if(!('IntersectionObserver' in window)){entries.forEach(e=>{seen.add(e);e.classList.add('is-revealed');});if(count)count.textContent=`${String(entries.length).padStart(2,'0')} / ${String(entries.length).padStart(2,'0')}`;align();return;}
  const observer=new IntersectionObserver(changes=>{
    for(const change of changes){const entry=change.target.closest('.ref-timeline-entry');if(change.isIntersecting&&change.intersectionRatio>=.25){visible.add(entry);enqueue(entry);}else visible.delete(entry);}
    drain();
  },{threshold:[0,.25],rootMargin:'0px 0px -8% 0px'});
  document.documentElement.classList.add('experience-ready');entries.forEach(entry=>observer.observe(entry.querySelector('.ref-timeline-card')));
  if('ResizeObserver' in window)new ResizeObserver(align).observe(timeline);else window.addEventListener('resize',align);
  function sync(){if(!motionAllowed())effects.forEach(a=>a.cancel());drain();}
  document.addEventListener('portfolio:motionchange',sync);reduce.addEventListener('change',sync);document.addEventListener('portfolio:openingdone',drain);
  document.addEventListener('focusin',event=>{
    const entry=event.target.closest('.ref-timeline-entry');
    // Keyboard navigation never waits for an entrance, or leaves focus invisible.
    if(entry&&entries.includes(entry)&&!seen.has(entry)){effects.forEach(a=>a.cancel());void reveal(entry,true);}
    else effects.forEach(a=>{if(a.effect?.target?.contains(event.target))a.cancel();});
  });
  align();
}
