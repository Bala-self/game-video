// Only add confirmed, owned health endpoints. Never guess deployment addresses.
export const healthEndpoints = [];
