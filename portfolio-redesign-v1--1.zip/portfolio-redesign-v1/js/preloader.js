import { healthEndpoints } from "./config.js";
import { playHero, motionAllowed } from "./motion.js";
export function initIntro() {
  // The opening is part of the page, not an overlay blocking the work.
  if (!navigator.connection?.saveData)
    healthEndpoints.forEach((url) => {
      fetch(url, {
        mode: "no-cors",
        cache: "no-store",
        signal: AbortSignal.timeout(1800),
      }).catch(() => {});
    });
  if (motionAllowed()) playHero();
}
