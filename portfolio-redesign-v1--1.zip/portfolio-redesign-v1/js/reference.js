import { initOpening, replayOpening } from "./opening.js";
import { motionAllowed, setMotionEnabled } from "./motion.js";

const reduced = matchMedia("(prefers-reduced-motion: reduce)");
const embedded = new URLSearchParams(location.search).has("embed");
function updateMotion() {
  const enabled = motionAllowed();
  document.documentElement.classList.toggle("motion-paused", !enabled || embedded);
  document.querySelectorAll("[data-motion-toggle]").forEach(button => {
    button.disabled = reduced.matches;
    button.setAttribute("aria-pressed", String(!enabled));
    const label = reduced.matches ? "Reduced motion" : enabled ? "Motion on" : "Motion off";
    button.querySelector("span").textContent = label;
    button.setAttribute("aria-label", label + (reduced.matches ? " — following your device preference" : enabled ? " — pause animations" : " — enable animations"));
  });
  const replay=document.querySelector("[data-reference-replay]");
  if(replay){replay.disabled=!enabled;replay.title=enabled?"Play the opening again":"Replay is disabled while motion is off";}
}

function reveals(){
  if(!("IntersectionObserver" in window)||embedded)return;
  const activity=new IntersectionObserver(entries=>entries.forEach(e=>e.target.classList.toggle("is-inview",e.isIntersecting)),{threshold:.1});
  document.querySelectorAll(".ref-section").forEach(el=>activity.observe(el));

}

function composer(){
  const form=document.querySelector("#contact-form"),status=document.querySelector("#form-status");
  function content(){
    const data=new FormData(form);const name=String(data.get("name")).trim(),company=String(data.get("company")).trim(),email=String(data.get("email")).trim(),message=String(data.get("message")).trim();
    return {subject:`MERN opportunity${company?" — "+company:""}`,body:`Hi Balakrishnan,\n\n${message}\n\n${name}${company?"\n"+company:""}\n${email}`};
  }
  form.addEventListener("submit",event=>{
    event.preventDefault();if(!form.reportValidity())return;
    const {subject,body}=content();const mailto=`mailto:balakrishnan.code@email.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    const link=document.createElement("a");link.href=mailto;link.click();
    status.textContent="Email draft prepared for your mail app. If it did not open, use Copy message. Nothing has been sent by this website.";
    document.dispatchEvent(new CustomEvent("portfolio:email-draft",{detail:{subject,body,mailto}}));
  });
  form.querySelector("[data-copy-message]").addEventListener("click",async()=>{
    if(!form.reportValidity())return;const {subject,body}=content();
    try{await navigator.clipboard.writeText(`Subject: ${subject}\n\n${body}`);status.textContent="Message copied. Paste it into an email to balakrishnan.code@email.com."}
    catch{status.replaceChildren();const note=document.createElement("p");note.textContent="Clipboard access is unavailable. Select and copy your message below:";const text=document.createElement("pre");text.textContent=`Subject: ${subject}\n\n${body}`;text.tabIndex=0;text.style.whiteSpace="pre-wrap";status.append(note,text)}
  });
}


export function initReference(){
  document.documentElement.classList.add("reference-ready");
  if(embedded){
    document.documentElement.classList.add("is-embedded","motion-paused");
    document.addEventListener("click",event=>{const a=event.target.closest("a");if(a&&!a.hasAttribute("download"))a.target="_top"},true);
  }
  composer();
  if(!embedded){
    updateMotion();reveals();
    reduced.addEventListener("change",updateMotion);document.addEventListener("portfolio:motionchange",updateMotion);
    document.querySelectorAll("[data-motion-toggle]").forEach(button=>button.addEventListener("click",()=>{if(!reduced.matches)setMotionEnabled(!motionAllowed())}));
    document.querySelector("[data-reference-replay]").addEventListener("click",()=>{
      if(!motionAllowed())return;
      // Explicit action; ordinary scrolling is never controlled by the page.
      window.scrollTo({top:0,behavior:"instant"});replayOpening();
    });
    initOpening();
  }
}
