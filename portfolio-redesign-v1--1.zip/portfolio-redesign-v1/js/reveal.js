import { initChoreography } from "./motion.js";
// Kept as the small entry point for the site's reveal enhancement.
export function initReveals() {
  initChoreography();
}
