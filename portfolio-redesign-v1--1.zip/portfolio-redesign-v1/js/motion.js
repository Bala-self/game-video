/*
 * PAPER / SIGNAL — a small, dependency-free choreography director.
 * The reading order is also the animation order. Never conceal content in CSS
 * while waiting for JavaScript; every mask exists only during a running effect.
 */
const OUT = "cubic-bezier(.16,1,.3,1)";
const QUART = "cubic-bezier(.76,0,.24,1)";
const SPRING = "cubic-bezier(.34,1.56,.64,1)";
const reduce = matchMedia("(prefers-reduced-motion: reduce)");
const active = new Set();
let paused = false;
let sceneObserver;
let scenes = [];
try {
  paused = localStorage.getItem("bm-motion") === "off";
} catch {}

export const motionAllowed = () => !reduce.matches && !paused;

function run(element, keyframes, options = {}) {
  if (!element?.animate) return Promise.resolve();
  if (!motionAllowed()) return Promise.resolve();
  // A temporary compositor hint, not hundreds of permanent GPU layers.
  element.style.willChange = "transform, opacity";
  const animation = element.animate(keyframes, {
    duration: 600,
    easing: OUT,
    fill: "backwards",
    ...options,
  });
  active.add(animation);
  return animation.finished
    .catch(() => {})
    .finally(() => {
      active.delete(animation);
      element.style.removeProperty("will-change");
    });
}

function rise(element, delay = 0, distance = 24, duration = 600) {
  return run(
    element,
    [
      { opacity: 0, transform: `translateY(${distance}px)` },
      { opacity: 1, transform: "translateY(0)" },
    ],
    { delay, duration },
  );
}

/* Split only the visual copy. The original heading's full accessible name
 * remains intact, including emphasis. Ordinary whitespace still wraps natively.
 */
function words(element) {
  if (!element) return [];
  if (element.dataset.motionWords)
    return [...element.querySelectorAll(".motion-word-inner")];
  const name = element.textContent.replace(/\s+/g, " ").trim();
  const visual = document.createElement("span");
  visual.className = "motion-heading";
  visual.setAttribute("aria-hidden", "true");
  while (element.firstChild) visual.append(element.firstChild);
  element.append(visual);
  element.setAttribute("aria-label", name);
  element.dataset.motionWords = "true";
  const walker = document.createTreeWalker(visual, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach((node) => {
    const fragment = document.createDocumentFragment();
    node.textContent.split(/(\s+)/).forEach((token) => {
      if (!token.trim()) {
        fragment.append(document.createTextNode(token));
        return;
      }
      const mask = document.createElement("span");
      mask.className = "motion-word";
      const inner = document.createElement("span");
      inner.className = "motion-word-inner";
      inner.textContent = token;
      mask.append(inner);
      fragment.append(mask);
    });
    node.replaceWith(fragment);
  });
  return [...element.querySelectorAll(".motion-word-inner")];
}

function heading(element, delay = 0, soft = false) {
  if (!motionAllowed() || !element) return;
  words(element).forEach((word, i) =>
    run(
      word,
      soft
        ? [
            { opacity: 0, transform: "translateY(12px)" },
            { opacity: 1, transform: "translateY(0)" },
          ]
        : [
            { opacity: 0, transform: "translateY(110%) rotate(3deg)" },
            { opacity: 1, transform: "translateY(0) rotate(0deg)" },
          ],
      { duration: soft ? 600 : 900, delay: delay + Math.min(i * 40, 240) },
    ),
  );
}

/* Four independent paper shutters: alternating hinge directions make the
 * photo feel uncovered, rather than sliding another rectangle up the page.
 * Absolutely positioned, aria-hidden, non-interactive, and always removed.
 */
function shutters(surface, direction = "vertical", delay = 0) {
  if (
    !motionAllowed() ||
    !surface ||
    surface.getBoundingClientRect().width === 0
  )
    return;
  surface.classList.add("motion-surface");
  const cover = document.createElement("span");
  cover.className = `paper-shutters paper-shutters--${direction}`;
  cover.setAttribute("aria-hidden", "true");
  const promises = [];
  for (let i = 0; i < 4; i++) {
    const blade = document.createElement("span");
    blade.className = "paper-blade";
    blade.style.transformOrigin =
      direction === "vertical"
        ? i % 2
          ? "bottom"
          : "top"
        : i % 2
          ? "right"
          : "left";
    cover.append(blade);
  }
  surface.append(cover);
  const remove = () => cover.remove();
  // The timeout is only a fail-open guard, never an animation scheduler.
  const ceiling = setTimeout(remove, 1500);
  cover.querySelectorAll(".paper-blade").forEach((blade, i) => {
    promises.push(
      run(
        blade,
        [
          {
            transform:
              direction === "vertical" ? "scaleY(1.01)" : "scaleX(1.01)",
          },
          { transform: direction === "vertical" ? "scaleY(0)" : "scaleX(0)" },
        ],
        { duration: 900, delay: delay + i * 40, easing: QUART },
      ),
    );
  });
  const image = surface.querySelector("img");
  if (image)
    run(image, [{ transform: "scale(1.06)" }, { transform: "scale(1)" }], {
      duration: 1200,
    });
  Promise.all(promises).finally(() => {
    clearTimeout(ceiling);
    remove();
  });
}

function trace(surface) {
  if (!surface || !motionAllowed()) return;
  surface.classList.add("motion-surface");
  const outline = document.createElement("span");
  outline.className = "motion-trace";
  outline.setAttribute("aria-hidden", "true");
  surface.append(outline);
  run(
    outline,
    [
      { clipPath: "inset(0 100% 100% 0)", opacity: 0.65, offset: 0 },
      { clipPath: "inset(0 0 0 0)", opacity: 0.65, offset: 0.65 },
      { clipPath: "inset(0 0 0 0)", opacity: 0, offset: 1 },
    ],
    { duration: 1200 },
  ).finally(() => outline.remove());
}

function media(figure, delay = 0) {
  const surface = figure.querySelector(".media-stage") || figure;
  shutters(surface, "horizontal", delay);
  const frame = surface.querySelector(".browser");
  if (frame) {
    trace(frame);
    run(
      frame,
      [
        { opacity: 0.5, transform: "translateY(24px) scale(.97)" },
        { opacity: 1, transform: "translateY(0) scale(1)" },
      ],
      { duration: 900, delay },
    );
  }
  rise(figure.querySelector("figcaption, .media-caption"), 240, 12);
}

function tell(element) {
  element.dataset.motionSeen = "true";
  if (!motionAllowed()) return;
  element.classList.add("is-telling");
  if (element.matches(".section-header, .footer-heading")) {
    rise(element.querySelector(".section-label"), 0, 12, 600);
    heading(element.querySelector("h2"), 80);
    rise(element.querySelector(".section-intro"), 240);
  } else if (element.matches(".project-copy")) {
    heading(element.querySelector("h3"));
    rise(element.querySelector(".flag-tag"), 120, 12, 300);
    [...element.children]
      .filter((e) => !e.matches(".project-heading"))
      .forEach((e, i) => {
        rise(e, Math.min(120 + i * 60, 420));
      });
  } else if (element.matches(".secondary-project")) {
    const index = [...element.parentElement.children].indexOf(element);
    const delay = matchMedia("(min-width:960px)").matches ? index * 80 : 0;
    media(element.querySelector("figure"), delay);
    heading(element.querySelector("h3"), delay + 120);
    element
      .querySelectorAll(
        ".project-description, li, .hard-line, .tags, .project-links, .feature-caption",
      )
      .forEach((e, i) => rise(e, delay + Math.min(160 + i * 40, 300)));
    rise(element.querySelector(".project-index"), delay + 160, 12);
  } else if (element.matches(".feature-media")) {
    media(element);
  } else if (element.matches(".skill-row")) {
    heading(element.querySelector("h3"));
    rise(element.querySelector(".skill-label p"), 120, 12);
    element.querySelectorAll(".skill-chip").forEach((chip, i) =>
      run(
        chip,
        [
          { opacity: 0, transform: "translateY(16px) scale(.92)" },
          { opacity: 1, transform: "translateY(0) scale(1)" },
        ],
        { duration: 600, delay: 120 + Math.min(i * 40, 360), easing: SPRING },
      ),
    );
  } else if (element.matches(".timeline-entry")) {
    rise(element.querySelector(".timeline-date"), 0, 12, 300);
    heading(element.querySelector("h3"), 80);
    element
      .querySelectorAll(
        ".context, .timeline-copy>p:not(.context), li, .timeline-copy>.link, .certifications",
      )
      .forEach((e, i) => rise(e, 160 + Math.min(i * 60, 360)));
  } else if (element.matches(".pivot, .bridge")) {
    heading(element, 0, true);
  } else if (element.matches(".about-photo")) {
    shutters(element, "horizontal");
    rise(element.querySelector("figcaption"), 300, 12);
  } else if (element.matches(".now-card")) {
    trace(element);
    rise(element, 0, 24);
    rise(element.querySelector(".now-title"), 120, 12);
    element
      .querySelectorAll("dt,dd")
      .forEach((e, i) => rise(e, 160 + Math.floor(i / 2) * 80, 12));
  } else if (element.matches(".footer-email")) {
    const link = element.querySelector(".email-link");
    run(
      link,
      [
        { clipPath: "inset(0 100% 0 0)", transform: "translateY(24px)" },
        { clipPath: "inset(0 0 0 0)", transform: "translateY(0)" },
      ],
      { duration: 900 },
    );
  } else if (element.matches(".contact-actions")) {
    [...element.children].forEach((e, i) => rise(e, i * 40, 16));
  } else if (element.matches(".case-block")) {
    heading(element.querySelector("h2"));
    element
      .querySelectorAll(
        ":scope>p, :scope>ul, .architecture, .gst-table, .code-block, .notice, .project-links",
      )
      .forEach((e, i) => rise(e, Math.min(120 + i * 60, 360)));
  } else if (element.matches(".ask")) {
    heading(element, 0, true);
  } else {
    const children = [...element.children];
    if (children.length > 1 && element.matches(".about-copy>.reveal"))
      children.forEach((e, i) => rise(e, i * 120));
    else rise(element);
  }
}

export function playHero() {
  if (!motionAllowed()) return;
  const hero = document.querySelector(".hero");
  if (!hero) {
    heading(document.querySelector(".case-hero h1"));
    rise(document.querySelector(".case-subtitle"), 160);
    return;
  }
  hero.classList.remove("hero-ready");
  document.documentElement.classList.add("motion-enabled");
  rise(hero.querySelector(".hero-kicker"), 0, 12);
  hero.querySelectorAll("h1 .line>span").forEach((line, i) =>
    run(
      line,
      [
        { transform: "translateY(110%) rotate(2deg)", opacity: 0 },
        { transform: "translateY(0) rotate(0deg)", opacity: 1 },
      ],
      { duration: 900, delay: i * 80 },
    ),
  );
  shutters(hero.querySelector(".hero-portrait picture"), "vertical", 180);
  rise(hero.querySelector(".photo-foot"), 400, 12);
  rise(hero.querySelector(".hero-subline"), 300);
  rise(hero.querySelector(".availability"), 380, 12);
  hero
    .querySelectorAll(".button-row>a")
    .forEach((button, i) => rise(button, 400 + i * 80));
  rise(hero.querySelector(".hero-bottom"), 500, 12);
  const brand = document.querySelector(".site-header .brand");
  run(
    brand,
    [
      { clipPath: "inset(0 100% 0 0)", transform: "translateY(12px)" },
      { clipPath: "inset(0 0 0 0)", transform: "translateY(0)" },
    ],
    { duration: 600 },
  );
  document.querySelector(".spine")?.classList.add("spine-intro");
  setTimeout(
    () => document.querySelector(".spine")?.classList.remove("spine-intro"),
    1200,
  );
}

function stop() {
  active.forEach((animation) => {
    try {
      animation.finish();
    } catch {
      animation.cancel();
    }
  });
  document
    .querySelectorAll(".paper-shutters, .motion-trace")
    .forEach((e) => e.remove());
}

function syncControls() {
  const enabled = motionAllowed();
  document.documentElement.classList.toggle("motion-paused", !enabled);
  document.querySelectorAll("[data-motion-toggle]").forEach((button) => {
    button.setAttribute("aria-pressed", String(!enabled));
    button.disabled = reduce.matches;
    button.setAttribute(
      "aria-label",
      reduce.matches
        ? "Reduced motion — following your device setting"
        : `${enabled ? "Motion on — pause" : "Motion off — enable"} animations`,
    );
    button.querySelector("span").textContent = reduce.matches
      ? "Reduced motion"
      : enabled
        ? "Motion on"
        : "Motion off";
  });
  if (!enabled) stop();
}

export function initChoreography() {
  if (!("IntersectionObserver" in window) || !Element.prototype.animate) return;
  document.documentElement.classList.add("motion-enabled");
  syncControls();
  scenes = [
    ...document.querySelectorAll(
      ".reveal, .reveal-image, .ai-note, .contact-meta, .footer-bottom",
    ),
  ];
  sceneObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        sceneObserver.unobserve(entry.target);
        tell(entry.target);
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -6% 0px" },
  );
  scenes.forEach((element) => {
    // Already-readable first-viewport content is never hidden after first paint.
    if (element.getBoundingClientRect().top < innerHeight * 0.92)
      element.dataset.motionSeen = "true";
    else sceneObserver.observe(element);
  });
  reduce.addEventListener("change", syncControls);
  document.querySelectorAll("[data-motion-toggle]").forEach((button) =>
    button.addEventListener("click", () => {
      if (reduce.matches) return;
      paused = !paused;
      try {
        localStorage.setItem("bm-motion", paused ? "off" : "on");
      } catch {}
      syncControls();
    }),
  );
  // Replay is explicit. Scrolling up normally never replays entrances.
  document.querySelectorAll("[data-motion-replay]").forEach((link) =>
    link.addEventListener("click", () => {
      if (!motionAllowed()) return;
      let done = false;
      const replay = () => {
        if (done || scrollY > 8) return;
        done = true;
        scenes.forEach((element) => {
          element.classList.remove("is-telling");
          if (element.getBoundingClientRect().top >= innerHeight * 0.92)
            sceneObserver.observe(element);
        });
        playHero();
        removeEventListener("scrollend", replay);
      };
      if (scrollY < 8) replay();
      else {
        addEventListener("scrollend", replay);
        setTimeout(replay, 1200);
        setTimeout(() => removeEventListener("scrollend", replay), 3000);
      }
    }),
  );
  // Ordinary keyboard focus receives the same arrow emphasis as pointer hover.
  document.querySelectorAll(".btn-primary").forEach((button) => {
    const pulse = () => {
      if (!motionAllowed()) return;
      const arrow = button.querySelector(".icon, [aria-hidden]");
      if (arrow)
        run(
          arrow,
          [
            { transform: "translateY(0)" },
            { transform: "translateY(-2px)", offset: 0.45 },
            { transform: "translateY(0)" },
          ],
          { duration: 300 },
        );
    };
    button.addEventListener("pointerenter", pulse);
    button.addEventListener("focus", pulse);
  });
}

// Shared with the reference homepage; micro-interactions use this same setting.
export function setMotionEnabled(enabled) {
  paused = !enabled;
  try { localStorage.setItem("bm-motion", enabled ? "on" : "off"); } catch {}
  syncControls();
  document.dispatchEvent(new CustomEvent("portfolio:motionchange"));
}
