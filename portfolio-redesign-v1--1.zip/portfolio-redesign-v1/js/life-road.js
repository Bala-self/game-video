import { motionAllowed } from './motion.js';
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
const OUT='cubic-bezier(.22,1,.36,1)';

export function initLifeRoad(){
  const road=document.querySelector('.life-road');if(!road)return;
  const section=road.closest('#education'),svg=road.querySelector('.life-map'),paths=[...svg.querySelectorAll(':scope > path')],route=svg.querySelector('.life-road-progress'),traveller=svg.querySelector('.life-traveller'),direction=svg.querySelector('.life-direction');
  const rows=[...road.querySelectorAll('.life-milestone')];
  const embedded=new URLSearchParams(location.search).has('embed');
  const seen=new Set(),effects=new Set();let printing=false,paused=false,inView=false,frame=0,position=0,target=0,length=0,points=[],stops=[],height=0,ready=false;
  const enabled=()=>motionAllowed()&&!paused&&!embedded;
  const active=()=>enabled()&&inView&&!printing&&!document.hidden&&!document.body.classList.contains('opening-locked');
  function run(el,frames,options={}){
    if(!enabled()||!el?.animate)return;
    const a=el.animate(frames,{duration:800,easing:OUT,fill:'backwards',...options});effects.add(a);a.finished.catch(()=>{}).finally(()=>effects.delete(a));
  }
  function paint(){
    if(!length)return;
    const p=route.getPointAtLength(position),next=route.getPointAtLength(Math.min(length,position+2));
    route.style.strokeDashoffset=String(length-position);
    traveller.setAttribute('transform',`translate(${p.x} ${p.y})`);
    direction.setAttribute('transform',`rotate(${Math.atan2(next.y-p.y,next.x-p.x)*180/Math.PI+90})`);
    rows.forEach((row,i)=>{
      const passed=!enabled()||p.y>=stops[i].y-2;
      if(passed&&!row.classList.contains('is-passed')&&active())run(row.querySelector('.life-stop'),[{scale:1},{scale:1.12,offset:.45},{scale:1}],{duration:700});
      row.classList.toggle('is-passed',passed);
    });
    road.dataset.progress=(position/length).toFixed(3);
  }
  function tick(){
    frame=0;if(!active())return;
    position+=(target-position)*.16;
    if(Math.abs(target-position)<.15)position=target;
    paint();if(position!==target)frame=requestAnimationFrame(tick);
  }
  function measureTarget(){
    if(!length)return;
    const y=Math.max(0,Math.min(height,innerHeight*.6-road.getBoundingClientRect().top));
    let low=0,high=points.length-1;
    while(high-low>1){const mid=(low+high)>>1;if(points[mid].y<y)low=mid;else high=mid;}
    const a=points[low],b=points[high],ratio=Math.max(0,Math.min(1,(y-a.y)/(b.y-a.y||1)));
    target=length*(low+ratio)/(points.length-1);
  }
  function update(){
    measureTarget();
    road.classList.toggle('life-running',active());
    if(!enabled()){cancelAnimationFrame(frame);frame=0;position=length;paint();return;}
    if(!active()){cancelAnimationFrame(frame);frame=0;return;}
    if(!frame)frame=requestAnimationFrame(tick);
  }
  function layout(){
    const box=road.getBoundingClientRect();height=box.height;
    stops=rows.map(row=>{const r=row.querySelector('.life-stop').getBoundingClientRect();return {x:r.left+r.width/2-box.left,y:r.top+r.height/2-box.top};});
    let d=`M ${stops[0].x} 4 L ${stops[0].x} ${stops[0].y}`;
    for(let i=1;i<stops.length;i++){const a=stops[i-1],b=stops[i],mid=(a.y+b.y)/2;d+=` C ${a.x} ${mid}, ${b.x} ${mid}, ${b.x} ${b.y}`;}
    d+=` L ${stops.at(-1).x} ${height-4}`;
    svg.setAttribute('viewBox',`0 0 ${box.width} ${height}`);paths.forEach(p=>p.setAttribute('d',d));
    length=route.getTotalLength();route.style.strokeDasharray=String(length);
    points=Array.from({length:161},(_,i)=>route.getPointAtLength(length*i/160));
    measureTarget();position=enabled()?target:length;paint();ready=true;update();
  }
  function reveal(row){
    if(!inView||seen.has(row)||document.body.classList.contains('opening-locked'))return;
    seen.add(row);row.classList.add('is-visited');if(!active())return;
    const reverse=rows.indexOf(row)%2===1;
    run(row.querySelector('.life-card'),[{opacity:0,transform:`translate(${reverse?10:-10}px,8px)`},{opacity:1,transform:'translate(0,0)'}],{duration:650});
    run(row.querySelector('.life-year'),[{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'translateY(0)'}],{duration:650,delay:90});
    row.querySelectorAll('.life-kicker,h3,.life-school,.life-result').forEach((el,i)=>run(el,[{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],{duration:650,delay:140+i*85}));
    run(row.querySelector('.life-symbol'),[{opacity:0,transform:'rotate(-4deg) scale(.95)'},{opacity:1,transform:'rotate(0) scale(1)'}],{duration:850,delay:130});
  }
  function visibleRows(){if(inView)rows.forEach(row=>{const r=row.getBoundingClientRect();if(r.top<innerHeight*.86&&r.bottom>0)reveal(row);});}
  function sync(){
    if(!enabled()||!inView||document.hidden){effects.forEach(a=>a.cancel());}
    update();visibleRows();
  }
  if('IntersectionObserver' in window){
    new IntersectionObserver(([entry])=>{inView=entry.isIntersecting;sync();},{threshold:0}).observe(road);
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){reveal(entry.target);if(seen.has(entry.target))observer.unobserve(entry.target);}}),{threshold:.2});rows.forEach(row=>observer.observe(row));
  }else{inView=true;rows.forEach(row=>row.classList.add('is-visited'));}
  if('ResizeObserver' in window)new ResizeObserver(layout).observe(road);
  else window.addEventListener('resize',layout,{passive:true});
  window.addEventListener('scroll',()=>{if(inView&&ready)update();},{passive:true});
  document.addEventListener('visibilitychange',sync);document.addEventListener('portfolio:motionchange',sync);document.addEventListener('portfolio:openingdone',sync);reduce.addEventListener('change',sync);
  document.addEventListener('focusin',event=>effects.forEach(a=>{if(a.effect?.target?.contains(event.target))a.cancel();}));
  window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);frame=0;road.classList.remove('life-running');effects.forEach(a=>a.cancel());});window.addEventListener('pageshow',sync);
  window.addEventListener('beforeprint',()=>{printing=true;cancelAnimationFrame(frame);frame=0;effects.forEach(a=>a.cancel());road.classList.remove('life-running');position=length;paint();});window.addEventListener('afterprint',()=>{printing=false;sync();});
  layout();sync();
}
