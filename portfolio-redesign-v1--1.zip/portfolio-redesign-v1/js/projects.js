export function initProjects() {
  // Videos are progressive enhancement. Add real recordings alongside posters;
  // never load video for reduced-motion or data-saving visitors.
  const reduced = matchMedia("(prefers-reduced-motion: reduce)");
  document.querySelectorAll("[data-project-video]").forEach((frame) => {
    if (reduced.matches || navigator.connection?.saveData) return;
    const video = frame.querySelector("video");
    if (!video) return;
    function play() {
      if (reduced.matches) return;
      video.querySelectorAll("source[data-src]").forEach((source) => {
        source.src = source.dataset.src;
        source.removeAttribute("data-src");
      });
      if (video.readyState === 0) video.load();
      video.currentTime = 0;
      video
        .play()
        .then(() => frame.classList.add("is-playing"))
        .catch(() => {});
    }
    const pause = () => {
      video.pause();
      frame.classList.remove("is-playing");
    };
    if (matchMedia("(hover:hover)").matches) {
      frame.addEventListener("pointerenter", play);
      frame.addEventListener("pointerleave", pause);
    } else if ("IntersectionObserver" in window) {
      let played = false;
      new IntersectionObserver(
        (entries) =>
          entries.forEach((e) => {
            if (e.isIntersecting && !played) {
              play();
              played = true;
            } else if (!e.isIntersecting) pause();
          }),
        { threshold: 0.6 },
      ).observe(frame);
    }
    reduced.addEventListener("change", (e) => {
      if (e.matches) pause();
    });
  });
  // Accessible click / keyboard / hover disclosures, not title attributes.
  const chips = [...document.querySelectorAll(".skill-chip")];
  const close = (chip) => {
    chip.querySelector("button").setAttribute("aria-expanded", "false");
    chip.querySelector(".skill-popover").hidden = true;
  };
  const open = (chip) => {
    chips.filter((other) => other !== chip).forEach(close);
    chip.querySelector("button").setAttribute("aria-expanded", "true");
    const pop = chip.querySelector(".skill-popover");
    pop.hidden = false;
    pop.style.left = "";
    pop.style.right = "";
    if (pop.getBoundingClientRect().right > innerWidth - 16) {
      pop.style.left = "auto";
      pop.style.right = "0";
    }
  };
  chips.forEach((chip) => {
    const button = chip.querySelector("button");
    button.addEventListener("click", () => open(chip));
    button.addEventListener("focus", () => open(chip));
    chip.addEventListener("pointerenter", (e) => {
      if (e.pointerType === "mouse") open(chip);
    });
    chip.addEventListener("pointerleave", () => {
      if (!chip.contains(document.activeElement)) close(chip);
    });
    chip.addEventListener("focusout", (e) => {
      if (!chip.contains(e.relatedTarget)) close(chip);
    });
    chip.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        button.focus();
        close(chip);
      }
    });
    chip
      .querySelectorAll("a")
      .forEach((a) => a.addEventListener("click", () => close(chip)));
  });
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".skill-chip")) chips.forEach(close);
  });
}
