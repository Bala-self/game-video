/*
 * SCROLL LAYER — GSAP ScrollTrigger does the scroll-linked work when it can
 * be fetched; everything degrades to the same effects in vanilla rAF when it
 * cannot (offline, blocked, SRI mismatch, slow network).
 *
 * What it does, and nothing more:
 *   1. normalised scroll progress → --space-progress (drives the top bar and
 *      the comet on the section rail)
 *   2. parallax on [data-speed] elements, scrubbed, never pinned
 *   3. one hero dissolve as the hero leaves the viewport
 *   4. magnetic pull and pointer halos on desktop controls
 * Native scrolling is untouched: no smooth-scroll hijack, no wheel capture.
 */
import { motionAllowed } from "./motion.js";

const CORE = "https://cdnjs.cloudflare.com/ajax/libs/gsap/3.13.0/gsap.min.js";
const TRIGGER =
  "https://cdnjs.cloudflare.com/ajax/libs/gsap/3.13.0/ScrollTrigger.min.js";
const CORE_SRI =
  "sha384-HOvlOYPIs/zjoIkWUGXkVmXsjr8GuZLV+Q+rcPwmJOVZVpvTSXQChiN4t9Euv9Vc";
const TRIGGER_SRI =
  "sha384-P8VzCVnT9NBUkMrpcIZrJbA7EBjJvh/fJS6PmP+4nLIM284DtsImIv8D0fFjIkeh";

function loadScript(src, integrity) {
  return new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = src;
    script.async = true;
    script.crossOrigin = "anonymous";
    script.integrity = integrity;
    script.referrerPolicy = "no-referrer";
    script.onload = () => resolve(true);
    script.onerror = () => reject(new Error("unable to load " + src));
    document.head.appendChild(script);
    setTimeout(() => reject(new Error("timeout " + src)), 6000);
  });
}

export function initScrollFx() {
  const root = document.documentElement;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");
  const fine = matchMedia("(hover: hover) and (pointer: fine)");
  const targets = [...document.querySelectorAll("[data-speed]")];
  const hero = document.querySelector(".atelier-hero-grid");
  let progress = 0;
  let queued = false;
  let idleTimer = 0;
  let gsapActive = false;
  let triggers = [];
  let resizeTimer = 0;
  let enhanceTried = false;

  const active = () => motionAllowed() && !reduce.matches;

  function setProgress(value) {
    progress = Math.min(1, Math.max(0, value));
    root.style.setProperty("--space-progress", progress.toFixed(4));
  }

  function measure() {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    setProgress(max > 0 ? window.scrollY / max : 0);
  }

  /* ---------- vanilla path ---------- */
  function vanillaParallax() {
    const vh = window.innerHeight;
    for (const el of targets) {
      const rect = el.getBoundingClientRect();
      if (rect.bottom < -200 || rect.top > vh + 200) continue;
      const span = vh + rect.height;
      const ratio = (vh - rect.top) / span; // 0 entering → 1 leaving
      const speed = Number(el.dataset.speed) || 0.3;
      el.style.transform = `translate3d(0, ${((ratio - 0.5) * speed * 90).toFixed(2)}px, 0)`;
    }
    if (hero) {
      const rect = hero.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, -rect.top / (rect.height || 1)));
      hero.style.transform = `translate3d(0, ${(-p * 46).toFixed(2)}px, 0)`;
      hero.style.opacity = (1 - p * 0.55).toFixed(3);
    }
  }

  function clearVanilla() {
    for (const el of targets) el.style.removeProperty("transform");
    if (hero) {
      hero.style.removeProperty("transform");
      hero.style.removeProperty("opacity");
    }
  }

  function onScroll() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      measure();
      root.classList.add("space-scrolling");
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => root.classList.remove("space-scrolling"), 700);
      if (active() && !gsapActive) vanillaParallax();
    });
  }

  /* ---------- GSAP path ---------- */
  async function enhance() {
    if (enhanceTried || gsapActive) return;
    enhanceTried = true;
    try {
      await loadScript(CORE, CORE_SRI);
      await loadScript(TRIGGER, TRIGGER_SRI);
    } catch (error) {
      // Offline or blocked: the vanilla path already covers every effect.
      console.info("GSAP unavailable, using the built-in scroll layer.");
      return;
    }
    const { gsap, ScrollTrigger } = window;
    if (!gsap || !ScrollTrigger) return;
    gsap.registerPlugin(ScrollTrigger);
    // Refresh timing is ours: a refresh fired while the document shrinks under
    // a scrolled viewport measures every start against the wrong offset.
    ScrollTrigger.config({ autoRefreshEvents: "visibilitychange,DOMContentLoaded,load" });
    /* The page scrolls smoothly by design, and a smooth scroll animation is
     * still in flight when a refresh measures: every start offset would be
     * taken against the old scroll position. Force instant scrolling for the
     * duration of any refresh, ours or GSAP's. */
    ScrollTrigger.addEventListener("refreshInit", () =>
      root.style.setProperty("scroll-behavior", "auto", "important"),
    );
    ScrollTrigger.addEventListener("refresh", () =>
      root.style.removeProperty("scroll-behavior"),
    );
    clearVanilla();
    gsapActive = true;
    root.classList.add("space-gsap");

    for (const el of targets) {
      const speed = Number(el.dataset.speed) || 0.3;
      const tween = gsap.fromTo(
        el,
        { y: -speed * 45 },
        {
          y: speed * 45,
          ease: "none",
          scrollTrigger: {
            trigger: el.closest("section") || el,
            start: "top bottom",
            end: "bottom top",
            scrub: 0.8,
            invalidateOnRefresh: true,
          },
        },
      );
      triggers.push(tween.scrollTrigger);
    }

    if (hero) {
      const tween = gsap.to(hero, {
        y: -46,
        opacity: 0.45,
        ease: "none",
        scrollTrigger: {
          trigger: "#home",
          start: "top top",
          end: "bottom top",
          scrub: 0.6,
        },
      });
      triggers.push(tween.scrollTrigger);
    }

    const progressTrigger = ScrollTrigger.create({
      start: 0,
      end: "max",
      onUpdate: (self) => setProgress(self.progress),
    });
    triggers.push(progressTrigger);
  }

  function teardown() {
    for (const trigger of triggers) trigger && trigger.kill && trigger.kill();
    triggers = [];
    gsapActive = false;
    root.classList.remove("space-gsap");
    clearVanilla();
  }

  /* ---------- magnetic controls + pointer halo ---------- */
  function initMagnetism() {
    if (!fine.matches) return;
    const magnets = [
      ...document.querySelectorAll(
        ".btn, .ref-card-button, .ref-social-row a, .ref-link",
      ),
    ];
    for (const el of magnets) {
      el.addEventListener("pointermove", (event) => {
        if (!active()) return;
        const rect = el.getBoundingClientRect();
        const dx = (event.clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
        const dy = (event.clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
        el.style.transition = "transform 220ms cubic-bezier(.16,1,.3,1)";
        el.style.transform = `translate3d(${(dx * 3.5).toFixed(2)}px, ${(dy * 2.5).toFixed(2)}px, 0)`;
      });
      el.addEventListener("pointerleave", () => {
        el.style.transform = "";
      });
    }
  }

  function initHalo() {
    if (!fine.matches) return;
    const surfaces = [
      ...document.querySelectorAll(
        ".ref-project, .credential, .ref-timeline-card, .life-card",
      ),
    ];
    for (const el of surfaces) {
      el.classList.add("space-glow");
      let queuedHalo = false;
      el.addEventListener(
        "pointermove",
        (event) => {
          if (queuedHalo) return;
          queuedHalo = true;
          requestAnimationFrame(() => {
            queuedHalo = false;
            const rect = el.getBoundingClientRect();
            el.style.setProperty(
              "--mx",
              `${(((event.clientX - rect.left) / rect.width) * 100).toFixed(2)}%`,
            );
            el.style.setProperty(
              "--my",
              `${(((event.clientY - rect.top) / rect.height) * 100).toFixed(2)}%`,
            );
          });
        },
        { passive: true },
      );
    }
  }

  /* ---------- wiring ---------- */
  measure();
  initMagnetism();
  initHalo();
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", () => {
    measure();
    if (active() && !gsapActive) vanillaParallax();
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      const { ScrollTrigger } = window;
      if (!gsapActive || !ScrollTrigger) return;
      try {
        /* Measure from a known origin: refreshing while the viewport is
         * scrolled and the document height has just changed makes every start
         * offset relative to the old scroll position, which strands the
         * scrubbed elements at their end state. */
        const y = window.scrollY;
        ScrollTrigger.clearScrollMemory();
        window.scrollTo({ top: 0, left: 0, behavior: "instant" });
        ScrollTrigger.refresh();
        window.scrollTo({ top: y, left: 0, behavior: "instant" });
        measure();
      } catch (error) {
        teardown(); // never leave the page on a half-measured timeline
      }
    }, 220);
  });
  document.addEventListener("portfolio:openingdone", () => {
    measure();
    if (active()) enhance();
  });
  document.addEventListener("portfolio:motionchange", () => {
    if (active()) {
      enhance();
      measure();
    } else {
      teardown();
      clearVanilla();
    }
  });
  reduce.addEventListener("change", () => {
    if (reduce.matches) teardown();
  });

  if (active()) {
    const idle = window.requestIdleCallback || ((fn) => setTimeout(fn, 1200));
    idle(() => {
      if (active()) enhance();
    });
  } else {
    clearVanilla();
  }

  window.__spaceScroll = { teardown, measure };
}
