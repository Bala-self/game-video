/* Content-led motion for the single-page portfolio. No scroll replacement.
 * Every element is visible by default; animations are optional enhancements.
 */
import { motionAllowed } from './motion.js';
const OUT='cubic-bezier(.22,1,.36,1)';
const active=new Set();
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
function run(el,frames,options={}){
  if(!el?.animate||!motionAllowed())return Promise.resolve();
  const a=el.animate(frames,{duration:550,easing:OUT,fill:'backwards',...options});active.add(a);
  return a.finished.catch(()=>{}).finally(()=>active.delete(a));
}
function rise(el,delay=0,distance=18){return run(el,[{opacity:0,transform:`translateY(${distance}px)`},{opacity:1,transform:'translateY(0)'}],{delay});}
function draw(el,delay=0,duration=1100){
  if(!el?.getTotalLength||!motionAllowed())return;
  const length=el.getTotalLength();el.style.strokeDasharray=length;
  run(el,[{strokeDashoffset:length},{strokeDashoffset:0}],{duration,delay}).finally(()=>el.style.removeProperty('stroke-dasharray'));
}
function heading(el){rise(el,0,8);}
function hero(){
  rise(document.querySelector('.atelier-intro-line'),0,6);
  rise(document.querySelector('.ref-hero h1'),60,12);
  rise(document.querySelector('.ref-portrait'),140,10);
  rise(document.querySelector('.atelier-hero-note'),210,8);
  rise(document.querySelector('.ref-hero-copy'),270,8);
  rise(document.querySelector('.atelier-hero-foot'),320,6);
}
function project(el){
  rise(el.querySelector('.ref-project-media'),0,10);
  rise(el.querySelector('.ref-project-body'),100,8);
}
function credential(el){rise(el,0,8);}
function about(){
  rise(document.querySelector('.ref-offset-portrait'),0,10);
  rise(document.querySelector('.ref-about-right'),100,8);
}
function contact(){
  heading(document.querySelector('#contact-title'));
  document.querySelectorAll('.ref-field').forEach((field,i)=>run(field,[{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],{duration:550,delay:i*80}));
  document.querySelectorAll('#contact-form>.btn').forEach((button,i)=>rise(button,340+i*80,10));
}
function footer(){
  rise(document.querySelector('.signature-name'),0,10);
  document.querySelectorAll('.ref-footer-grid>nav').forEach((nav,i)=>rise(nav,100+i*60,6));
}
function scenes(){
  if(!('IntersectionObserver' in window))return;
  const seen=new Set();const targets=new Map();
  const add=(selector,fn)=>document.querySelectorAll(selector).forEach(el=>targets.set(el,fn));
  add('.ref-hero',hero);add('.ref-project',project);add('.credential',credential);add('#about',about);add('#contact',contact);add('.ref-footer',footer);
  add('#work .ref-section-heading,#experience .ref-sans-title,.education-heading',heading);
  const blocked=()=>document.body.classList.contains('opening-locked')||document.documentElement.classList.contains('opening-pending');
  function play(el){if(seen.has(el)||blocked())return;seen.add(el);observer.unobserve(el);if(motionAllowed())targets.get(el)(el);}
  const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)play(e.target)}),{threshold:.12,rootMargin:'0px 0px -4% 0px'});
  targets.forEach((fn,el)=>observer.observe(el));
  const visible=()=>{if(blocked())return;targets.forEach((fn,el)=>{const r=el.getBoundingClientRect();if(r.top<innerHeight*.9&&r.bottom>0)play(el);});};
  // Prepare the hero during the portal, rather than hiding/replaying text
  // that the expanding mask has already revealed. No opening timing is changed.
  let heroPrepared=false;const opening=document.querySelector('.opening-experience');
  if(opening)new MutationObserver(()=>{
    if(['preload','intro'].includes(opening.dataset.phase))heroPrepared=false;
    if(opening.dataset.phase==='portal'&&!heroPrepared&&motionAllowed()){
      const el=document.querySelector('.ref-hero');heroPrepared=true;seen.add(el);observer.unobserve(el);hero();
    }
  }).observe(opening,{attributes:true,attributeFilter:['data-phase']});
  document.addEventListener('portfolio:openingdone',()=>{const el=document.querySelector('.ref-hero');if(!heroPrepared&&seen.has(el)&&el.getBoundingClientRect().bottom>0&&motionAllowed())hero();visible();});
  document.addEventListener('portfolio:motionchange',visible);requestAnimationFrame(visible);
}
function interactions(){
  document.querySelectorAll('.ref-project-details,.ref-toolkit,.ref-now').forEach(details=>details.addEventListener('toggle',()=>{if(details.open)[...details.children].filter(el=>el.tagName!=='SUMMARY').forEach((el,i)=>rise(el,i*35,8));}));
  const status=document.querySelector('#form-status'),copy=document.querySelector('[data-copy-message]'),text=[...copy.childNodes].find(n=>n.nodeType===Node.TEXT_NODE),label=text.textContent;
  let timeout;
  new MutationObserver(()=>{
    if(!status.textContent)return;rise(status,0,7);
    if(status.textContent.startsWith('Message copied.')){clearTimeout(timeout);text.textContent='Copied ';run(copy.querySelector('svg'),[{transform:'scale(.7)'},{transform:'scale(1.18)',offset:.6},{transform:'scale(1)'}],{duration:450});timeout=setTimeout(()=>text.textContent=label,1800);}
  }).observe(status,{childList:true,subtree:true,characterData:true});
  document.addEventListener('focusin',e=>active.forEach(a=>{if(a.effect?.target?.contains(e.target))a.cancel();}));
}
function cursor(){
  const desktop=matchMedia('(hover: hover) and (pointer: fine) and (min-width: 960px)');
  const el=document.createElement('div');el.className='context-cursor';el.setAttribute('aria-hidden','true');el.innerHTML='<div class="context-cursor-shape"><span class="cursor-label"></span></div>';document.body.append(el);
  const label=el.querySelector('.cursor-label');let x=0,y=0,tx=0,ty=0,raf=0,visible=false;
  const allowed=()=>desktop.matches&&motionAllowed()&&!document.hidden&&!document.body.classList.contains('opening-locked')&&!document.documentElement.classList.contains('opening-pending')&&!document.querySelector('dialog[open]');
  function hide(){visible=false;el.classList.remove('visible','pressed');cancelAnimationFrame(raf);raf=0;}
  function tick(){raf=0;if(!visible||!allowed()){hide();return;}x+=(tx-x)*.23;y+=(ty-y)*.23;el.style.transform=`translate3d(${x.toFixed(2)}px,${y.toFixed(2)}px,0)`;if(Math.abs(tx-x)+Math.abs(ty-y)>.15)raf=requestAnimationFrame(tick);}
  document.addEventListener('pointermove',e=>{
    if(e.pointerType!=='mouse'||!allowed()||e.target.closest('input,textarea,select,[contenteditable],.opening-experience')){hide();return;}
    const target=e.target.closest('[data-cursor]'),next=target?.dataset.cursor||'';
    if(label.textContent!==next){label.textContent=next;el.classList.toggle('has-label',!!next);}
    tx=Math.max(4,Math.min(e.clientX+18,innerWidth-(next?90:40)));ty=Math.max(4,Math.min(e.clientY+18,innerHeight-45));
    if(!visible){x=tx;y=ty;visible=true;el.classList.add('visible');}if(!raf)raf=requestAnimationFrame(tick);
  },{passive:true});
  document.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&visible)el.classList.add('pressed');else hide();},{passive:true});
  document.addEventListener('pointerup',()=>el.classList.remove('pressed'),{passive:true});
  document.documentElement.addEventListener('pointerleave',hide);document.addEventListener('keydown',hide);window.addEventListener('blur',hide);
  // A click that opens a dialog (or any state where the follower is not
  // allowed) must drop it at once; ordinary clicks leave it alone.
  document.addEventListener('click',()=>{if(!allowed())hide();});
  document.addEventListener('visibilitychange',hide);document.addEventListener('portfolio:motionchange',hide);reduce.addEventListener('change',hide);desktop.addEventListener('change',hide);
}
export function initSignature(){
  if(!document.body.classList.contains('reference-page')||new URLSearchParams(location.search).has('embed'))return;
  document.documentElement.classList.add('signature-ready');
  const sync=()=>{if(!motionAllowed())active.forEach(a=>a.cancel());};
  reduce.addEventListener('change',sync);document.addEventListener('portfolio:motionchange',sync);
  scenes();interactions();cursor();
}
