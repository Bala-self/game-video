export function initGallery() {
  const dialog = document.querySelector(".image-viewer");
  if (!dialog || !dialog.showModal) return;
  const image = dialog.querySelector("img");
  const caption = dialog.querySelector(".image-viewer-caption");
  document.querySelectorAll("[data-lightbox]").forEach((link) =>
    link.addEventListener("click", (event) => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey)
        return;
      event.preventDefault();
      const original = link.querySelector("img") || link.closest(".ref-project-media,.credential")?.querySelector("img");
      image.src = link.href;
      image.alt = original?.alt || "Project screenshot";
      caption.textContent = image.alt;
      dialog.showModal();
      document.body.style.overflow = "hidden";
    }),
  );
  dialog
    .querySelector(".image-close")
    .addEventListener("click", () => dialog.close());
  dialog.addEventListener("close", () => {
    document.body.style.overflow = "";
  });
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog) {
      const r = dialog.getBoundingClientRect();
      if (
        event.clientX < r.left ||
        event.clientX > r.right ||
        event.clientY < r.top ||
        event.clientY > r.bottom
      )
        dialog.close();
    }
  });
}
