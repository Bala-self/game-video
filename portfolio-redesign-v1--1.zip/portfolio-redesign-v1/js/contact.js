import { motionAllowed } from "./motion.js";
export function initContact() {
  const status = document.querySelector(".toast");
  let timer;
  function notify(message) {
    clearTimeout(timer);
    status.textContent = message;
    status.hidden = false;
    timer = setTimeout(() => {
      status.hidden = true;
    }, 3000);
  }
  document.querySelectorAll("[data-copy-email]").forEach((link) => {
    link.addEventListener("click", async (event) => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey)
        return;
      event.preventDefault();
      const email = link.href.split("mailto:")[1].split("?")[0];
      try {
        await navigator.clipboard.writeText(decodeURIComponent(email));
        notify("Email copied. Looking forward to hearing from you.");
        if (motionAllowed())
          link.animate(
            [
              { transform: "translateY(6px)", opacity: 0.5 },
              { transform: "translateY(0)", opacity: 1 },
            ],
            { duration: 300, easing: "cubic-bezier(.34,1.56,.64,1)" },
          );
      } catch {
        notify(
          "Copy unavailable here. Use “open in your mail app” or select the email.",
        );
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(link);
        selection.removeAllRanges();
        selection.addRange(range);
      }
    });
  });
  // Vendor-independent hook; no analytics requests or personal data collection.
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a");
    if (!a) return;
    let type = a.hasAttribute("download")
      ? "download"
      : a.hasAttribute("data-copy-email")
        ? "email-copy"
        : a.href.startsWith("mailto:")
          ? "email"
          : a.href.includes("wa.me/")
            ? "whatsapp"
            : a.host !== location.host
              ? "outbound"
              : null;
    if (type)
      document.dispatchEvent(
        new CustomEvent("portfolio:outbound", {
          detail: { type, label: a.textContent.trim(), href: a.href },
        }),
      );
  });
}
