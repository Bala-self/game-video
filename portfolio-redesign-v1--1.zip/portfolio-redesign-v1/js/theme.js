import { motionAllowed } from "./motion.js";
export function initTheme() {
  const root = document.documentElement;
  const button = document.querySelector(".theme-toggle");
  // Pages without a sky switch (the case study) simply keep the default sky.
  if (!button) return;
  const system = matchMedia("(prefers-color-scheme: dark)");
  const reduced = matchMedia("(prefers-reduced-motion: reduce)");
  const calm = () => root.dataset.theme === "eclipse";
  function updateLabel() {
    button.setAttribute(
      "aria-label",
      `Switch to the ${calm() ? "nebula" : "eclipse"} sky`,
    );
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = calm() ? "#04060b" : "#05070d";
  }
  updateLabel();
  button.addEventListener("click", () => {
    const apply = () => {
      root.dataset.theme = calm() ? "dark" : "eclipse";
      try {
        localStorage.setItem("bm-theme", root.dataset.theme);
      } catch {}
      updateLabel();
    };
    if (document.startViewTransition && motionAllowed())
      document.startViewTransition(apply);
    else apply();
    if (motionAllowed())
      button.animate(
        [{ transform: "rotate(-90deg)" }, { transform: "rotate(0)" }],
        { duration: 300, easing: "cubic-bezier(.16,1,.3,1)" },
      );
  });
  system.addEventListener("change", () => {
    let stored;
    try {
      stored = localStorage.getItem("bm-theme");
    } catch {}
    if (!stored) {
      root.dataset.theme = calm() ? "eclipse" : "dark";
      updateLabel();
    }
  });
}
