export function initSpine() {
  const spine = document.querySelector(".spine");
  const fill = spine.querySelector(".spine-fill");
  const tip = document.createElement("span");
  tip.className = "spine-tip";
  spine.append(tip);
  const nodes = [...document.querySelectorAll(".node-anchor")];
  const cssTimeline = CSS.supports("animation-timeline: scroll()");
  let scheduled = false,
    measurements = [];
  function measure() {
    const start = spine.getBoundingClientRect().top + scrollY;
    measurements = nodes.map((node) => ({
      node,
      y: node.getBoundingClientRect().top + scrollY - start,
    }));
    render();
  }
  function render() {
    const max = document.documentElement.scrollHeight - innerHeight;
    const fraction = max > 0 ? Math.min(1, Math.max(0, scrollY / max)) : 1;
    if (!cssTimeline) fill.style.transform = `scaleY(${fraction})`;
    const reached = spine.offsetHeight * fraction;
    tip.style.transform = `translateY(${reached}px)`;
    measurements.forEach(({ node, y }) => {
      if (y <= reached + 10) node.classList.add("is-reached");
    });
    scheduled = false;
  }
  addEventListener(
    "scroll",
    () => {
      if (!scheduled) {
        scheduled = true;
        requestAnimationFrame(render);
      }
    },
    { passive: true },
  );
  addEventListener("resize", measure);
  document.fonts.ready.then(measure);
  measure();
  // Node intersections also refresh geometry after images or content settle.
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) measure();
      },
      { threshold: 0.2 },
    );
    nodes.forEach((node) => observer.observe(node));
  }
}
