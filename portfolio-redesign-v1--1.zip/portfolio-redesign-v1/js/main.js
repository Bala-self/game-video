import { initLifeRoad } from './life-road.js';
import { initSolarSystem, initExperienceStops } from "./solar.js";
import { initSignature } from "./signature.js";
import { initReference } from "./reference.js";
import { initGallery } from "./gallery.js";
import { initTheme } from "./theme.js";
import { initSpine } from "./spine.js";
import { initReveals } from "./reveal.js";
import { initIntro } from "./preloader.js";
import { initProjects } from "./projects.js";
import { initContact } from "./contact.js";
import { initSpace } from "./space.js";
// Each enhancement is independent: one failed feature never hides the page.
const reference = document.body.classList.contains("reference-page");
for (const init of [
  initTheme,
  ...(reference ? [] : [initSpine, initReveals, initIntro]),
  initProjects,
  initContact,
  initGallery,
  ...(reference
    ? [initReference, initSignature, initSolarSystem, initExperienceStops, initLifeRoad, initSpace]
    : []),
]) {
  try {
    init();
  } catch (error) {
    console.warn(`Enhancement unavailable: ${init.name}`, error);
  }
}
