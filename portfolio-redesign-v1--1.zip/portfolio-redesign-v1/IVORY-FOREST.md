> **Historical.** Ivory / Forest was superseded by the deep-space edition on
> 16 October 2026. The design layer described here is no longer loaded
> (`css/atelier.css` still provides the structure; `css/space.css` owns the
> colour and atmosphere). Kept as the record of that pass — see `SPACE.md`
> for what ships now.

# Ivory / Forest — redesign record

## Direction

Warm, restrained editorial design: ivory `#f7f5ed`, forest `#234b3c`, ink `#202c25`, sage `#eceee2`. Secondary text was darkened to `#596653` after a real axe contrast failure on sage surfaces. Dark mode uses deep green and cream, not the former navy palette.

The supplied reference website was mood-only. Its assets, words, code, composition and distinctive effects are not used. The portrait, screenshots, certificates, skill icons and CV are the existing owner's assets. Project screenshots retain their genuine colors.

## Changed layout

1. **Header and hero:** flat serif wordmark, fine divider, giant name, small engineering note, central arched portrait, biography and stacked CTAs. The portrait has a CSS grayscale treatment; its source image is unchanged.
2. **Work:** four alternating horizontal image/text studies, generous spacing and thin rules. Genuine source/demo/case-study actions remain.
3. **Experience:** a full forest chapter with cream typography. The original once-per-load sequential circle/card behavior remains.
4. **Skills:** a quieter sage solar instrument with all 28 original icons and a stationary FSD center.
5. **Education:** ivory surface, lighter route treatment and serif headings. The exact four milestones, ongoing-internship distinction and two certificate previews remain.
6. **About:** portrait on the left and biography on the right.
7. **Contact:** a separate editorial invitation beside a real, labeled form. Fields are at least 16px on small screens.
8. **Footer:** sage surface and a large, quiet signature instead of the earlier blue finish.

## Motion

- Signature section entrances: roughly 550ms with 6–12px of travel, replacing the previous large masks and hero light planes.
- Road entrances: roughly 650ms, with smaller offsets and opacity-based years.
- Solar entry: reduced to 10px; existing slow rings retain hover/focus/pause/offscreen guards.
- Opening, sequential Experience and measured road retain their native-JS control architecture. Reduced motion, global/local pause and no-JS content remain available.
- Native pointer and native scrolling remain. No scroll hijacking, 3D tilt or framework animation dependency was introduced.

## Main changed files

- `index.html`: new hero, work/road headings, About and Contact composition.
- `css/atelier.css`: complete final responsive design layer, including dark mode, print and no-JS rules.
- Shared CSS token/palette/reference/signature/solar/road files: forest substitutions where needed.
- `js/signature.js`, `js/life-road.js`, `js/solar.js`: restrained animation changes.
- `js/opening.js`, `js/theme.js`: coordinated theme colors.
- `work/billpro/index.html`: shared final design layer and theme metadata.
- CV fallback HTML, favicon, app icons and web manifest: coordinated brand color; original PDF unchanged.
- `tests/atelier.cjs`, `tests/palette.cjs`: new design assertions. All active suites target port 3001.
- `tests/solar-system.cjs`: hover-pause assertion waits for animation state settlement rather than racing the next animation frame; all 32 infinite orbit/counter-rotation effects must still become paused.

The original project, full backup ZIP, original checksums and original blue release ZIP were not edited. Only this separate working edition was redesigned. Documentation headed “Historical implementation record” describes earlier work and is not current visual acceptance evidence.
