extends SceneTree
## Headless test runner (Prompt 01, §33–34). Runs unit + integration suites,
## prints TEST lines + TEST_SUMMARY, exits 1 on any failure, 0 when all pass.
## Usage: godot --headless --path . --script res://tests/godot/test_runner.gd

const SUITES: Array[String] = [
	"res://tests/godot/unit/test_seed_vectors.gd",
	"res://tests/godot/unit/test_coordinates.gd",
	"res://tests/godot/unit/test_sectors.gd",
	"res://tests/godot/unit/test_contract_loader.gd",
	"res://tests/godot/unit/test_checksum.gd",
	"res://tests/godot/unit/test_diag_bench.gd",
	"res://tests/godot/integration/test_bootstrap_integration.gd",
	"res://tests/godot/integration/test_cross_layer.gd",
]

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var total_pass := 0
	var total_fail := 0
	for sp in SUITES:
		var suite = load(sp).new()
		suite.run_suite(self)
		for r in suite.results:
			if r["pass"]:
				total_pass += 1
				print("TEST %s::%s PASS %s" % [r["suite"], r["name"], r["detail"]])
			else:
				total_fail += 1
				print("TEST %s::%s FAIL %s" % [r["suite"], r["name"], r["detail"]])
	print("TEST_SUMMARY passed=%d failed=%d suites=%d" % [total_pass, total_fail, SUITES.size()])
	if total_fail > 0:
		printerr("TEST_RUN FAILED: %d failing checks" % total_fail)
		quit(1)
	else:
		print("TEST_RUN OK: %d checks passed" % total_pass)
		quit(0)
	return true
