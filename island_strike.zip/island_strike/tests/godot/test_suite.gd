extends RefCounted
## Minimal in-engine test framework (Prompt 01, §33). No external deps by design.
## Suites extend this via path, implement run_suite(tree), use check*() helpers.
## The runner (tests/godot/test_runner.gd) aggregates results and sets exit code.

var suite_name: String = "unnamed"
var results: Array = []


func check(test_name: String, condition: bool, detail: String = "") -> void:
	results.append({"suite": suite_name, "name": test_name, "pass": bool(condition), "detail": str(detail)})


func check_approx(test_name: String, a: float, b: float, eps: float, detail: String = "") -> void:
	var ok: bool = absf(a - b) <= eps
	var d := detail
	if d == "":
		d = "a=%s b=%s eps=%s" % [str(a), str(b), str(eps)]
	check(test_name, ok, d)


func passed_count() -> int:
	var n := 0
	for r in results:
		if r["pass"]:
			n += 1
	return n


func failed_count() -> int:
	return results.size() - passed_count()
