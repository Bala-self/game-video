extends SceneTree
## Buildings lightweight verifier (Prompt 06): independently re-verifies
## the exported buildings + massing meshes (data/derived/buildings.json,
## data/derived/urban_mesh.json) inside the engine.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/buildings_check.gd
##     -- --verify <buildings.json> --mesh <urban_mesh.json>
## Output: BUILDINGS_METRICS <json> or BUILDINGS_FAIL. Scalar floats only.
## Exit: 0 = BUILDINGS_OK, 2 = BUILDINGS_FAIL.
##
## Semantic parity (P06-CONTINUE 68), explicit tolerances:
##   heights:      mesh mid-box height vs height_m, tol 0.05 m
##   footprint:    mesh base corners vs footprint, tol 0.01 m
##   sectors:      recomputed with GRID_MIN/SECTOR_SIZE, exact match
##   mesh_valid:   no NaN, no degenerate tri (area < 1e-6)
##   checksum:     fnv1a32 over sorted "id|class|h3|sector" lines, exact
##     (h3 = height_m rounded to 3 decimals; cross-language safe by design)

const GRID_MIN := -2048.0
const SECTOR_SIZE := 256.0
const TOL_H := 0.05
const TOL_FP := 0.01

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	if args.has("--verify") and args.has("--mesh"):
		_cmd_verify(_flag(args, "--verify", ""), _flag(args, "--mesh", ""))
	else:
		_fail("usage", ["want --verify <buildings.json> --mesh <urban_mesh.json>"])
	return true


func _flag(args: PackedStringArray, key: String, dflt: String) -> String:
	var i: int = args.find(key)
	if i < 0 or i + 1 >= args.size():
		return dflt
	return args[i + 1]


func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "missing " + path}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _fail(stage: String, notes: Array) -> void:
	print("BUILDINGS_FAIL " + JSON.stringify({"stage": stage, "notes": notes}))
	quit(2)


func _sector_of(x: float, z: float) -> String:
	var ix: int = floori((x - GRID_MIN) / SECTOR_SIZE)
	var iz: int = floori((z - GRID_MIN) / SECTOR_SIZE)
	return "SX%02dZ%02d" % [ix, iz]


func _fnv1a32(s: String) -> int:
	var h: int = 2166136261
	for i in range(s.length()):
		h = h ^ s.unicode_at(i)
		h = (h * 16777619) & 0xFFFFFFFF
	return h


func _tri_area(a: Array, b: Array, c: Array) -> float:
	var ux: float = b[0] - a[0]
	var uy: float = b[1] - a[1]
	var uz: float = b[2] - a[2]
	var vx: float = c[0] - a[0]
	var vy: float = c[1] - a[1]
	var vz: float = c[2] - a[2]
	var nx: float = uy * vz - uz * vy
	var ny: float = uz * vx - ux * vz
	var nz: float = ux * vy - uy * vx
	return sqrt(nx * nx + ny * ny + nz * nz) / 2.0


func _cmd_verify(buildings_path: String, mesh_path: String) -> void:
	if buildings_path == "" or mesh_path == "":
		_fail("verify", ["missing path"])
		return
	var bj: Dictionary = _load_json(buildings_path)
	var mj: Dictionary = _load_json(mesh_path)
	for e in [bj, mj]:
		if not e["ok"]:
			_fail("load", [str(e["error"])])
			return
	var buildings: Array = (bj["data"] as Dictionary)["buildings"]
	var meshes: Array = (mj["data"] as Dictionary)["meshes"]
	if buildings.size() != meshes.size():
		_fail("counts", ["buildings=%d meshes=%d" % [buildings.size(), meshes.size()]])
		return
	var by_id: Dictionary = {}
	for b in buildings:
		by_id[str(b["id"])] = b
	var lines: PackedStringArray = []
	var bad_h := 0
	var bad_fp := 0
	var bad_sec := 0
	var bad_tri := 0
	var bad_nan := 0
	for m in meshes:
		var bid: String = str(m["building"])
		if not by_id.has(bid):
			_fail("ids", ["mesh without building " + bid])
			return
		var b: Dictionary = by_id[bid]
		var h: float = float(b["height_m"])
		var fp: Array = (b["footprint"] as Array).slice(0, 4)
		# mid-box height check
		var mv: Array = m["mid"]["verts"]
		var ymin: float = 1e18
		var ymax: float = -1e18
		for v in mv:
			ymin = min(ymin, float(v[1]))
			ymax = max(ymax, float(v[1]))
		if abs((ymax - ymin) - h) > TOL_H:
			bad_h += 1
		# base corners vs footprint
		for i in range(4):
			var dx: float = float(mv[i][0]) - float(fp[i][0])
			var dz: float = float(mv[i][2]) - float(fp[i][1])
			if abs(dx) > TOL_FP or abs(dz) > TOL_FP:
				bad_fp += 1
				break
		# sector recompute
		var secs: Array = []
		for i in range(4):
			secs.append(_sector_of(float(fp[i][0]), float(fp[i][1])))
		secs.sort()
		if str(m["sector"]) != str(secs[0]):
			bad_sec += 1
		# near-mesh validity
		var nv: Array = m["near"]["verts"]
		for v in nv:
			for c in [v[0], v[1], v[2]]:
				var f: float = float(c)
				if is_nan(f) or is_inf(f):
					bad_nan += 1
		for t in m["near"]["tris"]:
			var a: Array = nv[int(t[0])]
			var bb: Array = nv[int(t[1])]
			var cc: Array = nv[int(t[2])]
			if _tri_area(a, bb, cc) < 0.000001:
				bad_tri += 1
		lines.append("%s|%s|%.3f|%s" % [bid, str(b["class"]), h, str(m["sector"])])
	lines.sort()
	var h32: int = _fnv1a32("\n".join(lines))
	if bad_h + bad_fp + bad_sec + bad_tri + bad_nan > 0:
		_fail("metrics", ["h=%d fp=%d sec=%d tri=%d nan=%d" % [bad_h, bad_fp, bad_sec, bad_tri, bad_nan]])
		return
	print("BUILDINGS_METRICS " + JSON.stringify({
		"count": buildings.size(), "checksum32": "%08x" % h32,
		"tol_h": TOL_H, "tol_fp": TOL_FP,
	}))
	quit(0)
