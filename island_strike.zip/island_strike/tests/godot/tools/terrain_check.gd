extends SceneTree
## Terrain CLI twin (Prompt 02): dump + validate.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/terrain_check.gd
##     -- --dump <out.json>
##     -- --validate [--coast <path>] [--authoring <path>]
## Exit: 0 = TERRAIN_OK (+JSON dump for --dump), 2 = TERRAIN_FAIL.

const TerrainField = preload("res://scripts/terrain/terrain_field.gd")
const Seed = preload("res://scripts/core/seed_service.gd")
const Benchmark = preload("res://scripts/core/benchmark_service.gd")

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	if args.has("--dump"):
		_cmd_dump(_flag(args, "--dump", ""))
	elif args.has("--validate"):
		_cmd_validate(_flag(args, "--coast", ""), _flag(args, "--authoring", ""))
	elif args.has("--bench"):
		_cmd_bench(int(_flag(args, "--bench", "2000")))
	else:
		_fail("usage", ["want --dump <path> or --validate or --bench N"])
	return true


func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "missing " + path}
	var txt: String = FileAccess.get_file_as_string(path)
	var v: Variant = JSON.parse_string(txt)
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _load_all(coast_p: String, au_p: String) -> Dictionary:
	var t: Dictionary = _load_json("res://data/world/terrain_contract.json")
	var c: Dictionary = _load_json(coast_p if coast_p != "" else "res://data/world/coast_contract.json")
	var a: Dictionary = _load_json(au_p if au_p != "" else "res://data/terrain/authoring.json")
	var w: Dictionary = _load_json("res://data/world/world_contract.json")
	for e in [t, c, a, w]:
		if not e["ok"]:
			return {"ok": false, "error": str(e["error"])}
	return {"ok": true, "tc": t["data"], "cc": c["data"], "au": a["data"], "wc": w["data"]}


func _build(all: Dictionary) -> Array:
	var f := TerrainField.new()
	var r: Dictionary = f.initialize(all["tc"], all["cc"], all["au"], all["wc"])
	if not r["ok"]:
		return [null, str(r.get("error", "init failed"))]
	return [f, ""]


func _cmd_dump(dump_path: String) -> void:
	if dump_path == "":
		_fail("dump", ["missing path"])
		return
	var all: Dictionary = _load_all("", "")
	if not all["ok"]:
		_fail("load", [str(all["error"])])
		return
	var bf: Array = _build(all)
	if bf[0] == null:
		_fail("build", [str(bf[1])])
		return
	var f: TerrainField = bf[0]
	# LUT rows (full table).
	var lut: Array = []
	for i in range(f.lut.size()):
		var e: Dictionary = f.lut[i]
		lut.append({"i": i, "theta": float(e["theta"]), "rs": float(e["rs"]), "arc": float(e["arc"]),
			"width": float(e["width"]), "rwidth": float(e["rwidth"]), "berm": float(e["berm"]),
			"curv": float(e["curv"]), "curv_meso": float(e["curv_meso"]),
			"class": str(e["class"]), "region": str(e["region"])})
	# Deterministic sample set: coarse grid + authored sites.
	var pts: Array = []
	var seen := {}
	var add_pt := func(x: float, z: float) -> void:
		var k: String = "%d,%d" % [int(roundf(x)), int(roundf(z))]
		if seen.has(k):
			return
		seen[k] = true
		pts.append([x, z])
	var g: int = -2000
	while g <= 2000:
		var h: int = -2000
		while h <= 2000:
			if g * g + h * h <= 2000 * 2000:
				add_pt.call(float(g), float(h))
			h += 300
		g += 300
	var au: Dictionary = all["au"]
	for c in au["corridors"]:
		if c["type"] == "ring":
			continue
		for q in c.get("points", []):
			add_pt.call(float(q[0]), float(q[1]))
		for q in c.get("portals", []):
			add_pt.call(float(q[0]), float(q[1]))
	for lk in au["drainage"].get("lakes", []):
		add_pt.call(float(lk["cx"]), float(lk["cz"]))
	for pd in au.get("pads", []):
		add_pt.call(float(pd["cx"]), float(pd["cz"]))
	add_pt.call(float(au["runway"]["center"][0]), float(au["runway"]["center"][1]))
	var hsamples: Array = []
	var nsamples: Array = []
	var census := {}
	for q in pts:
		var x: float = float(q[0])
		var z: float = float(q[1])
		var hh: float = f.height(x, z)
		var reg: String = f.region_at(x, z)
		hsamples.append({"x": x, "z": z, "h": hh, "region": reg})
		nsamples.append({"x": x, "z": z, "g": f.height_raw(x, z, false)})
		census[reg] = int(census.get(reg, 0)) + 1
	# Sector-seam probes: heights at ±1 m across every 256 m grid line (cross-engine ±ε).
	var seams: Array = []
	for k in range(1, 16):
		var s: float = -2048.0 + 256.0 * float(k)
		var q: float = -1980.0
		while q <= 1980.0:
			for o in [[[s, q], 1.0, 0.0], [[q, s], 0.0, 1.0]]:
				var bx: float = float(o[0][0])
				var bz: float = float(o[0][1])
				if bx * bx + bz * bz > 1980.0 * 1980.0:
					continue
				seams.append(f.height(bx + float(o[1]), bz + float(o[2])))
				seams.append(f.height(bx - float(o[1]), bz - float(o[2])))
			q += 64.0
	# LUT digest: FNV over quantized canonical rows (exact-match stability).
	var canon: String = ""
	for e in lut:
		canon += "%s|%d|%d|%d|%d|%d|%s|%s;" % [e["class"], int(roundf(float(e["width"]) * 1e6)),
			int(roundf(float(e["rwidth"]) * 1e6)), int(roundf(float(e["berm"]) * 1e6)),
			int(roundf(float(e["rs"]) * 1e6)), int(roundf(float(e["arc"]) * 1e6)),
			e["region"], e["class"]]
	var digest: String = Seed.fnv1a64_hex(canon)
	var vi: Dictionary = Engine.get_version_info()
	var report := {
		"generated_at": Benchmark.utc_stamp(),
		"engine": {"version": "%s.%s.%s.%s" % [vi["major"], vi["minor"], vi["patch"], vi["status"]], "os": OS.get_name()},
		"lut_digest": digest,
		"lut": lut,
		"height_samples": hsamples,
		"noise_samples": nsamples,
		"seams": seams,
		"census": census,
		"coast_length": f.coast_length,
		"lut_n": f.lut_n,
	}
	var bench := Benchmark.new()
	var w: Dictionary = bench.write_json(dump_path, report)
	if not w["ok"]:
		_fail("dump-write", [str(w["error"])])
		return
	print("TERRAIN_OK dump=%s lut=%d samples=%d digest=%s" % [dump_path, lut.size(), hsamples.size(), digest])
	quit(0)


func _cmd_validate(coast_p: String, au_p: String) -> void:
	# Structural + semantic gate: every injection mutation MUST trip one check.
	var all: Dictionary = _load_all(coast_p, au_p)
	if not all["ok"]:
		_fail("load", [str(all["error"])])
		return
	var cc: Dictionary = all["cc"]
	var au: Dictionary = all["au"]
	var bad: Array = []
	# 1. node table matches segment boundaries (catches nodes-truncated).
	var bounds: Array = []
	for s in cc["class_rules"]["segments"]:
		bounds.append(float(s["from_deg"]))
		bounds.append(float(s["to_deg"]))
	bounds.sort()
	var nodes: Array = []
	for v in cc["class_rules"]["nodes_deg"]:
		nodes.append(float(v))
	nodes.sort()
	if bounds != nodes:
		bad.append("nodes-vs-segments mismatch")
	# 2. shares sane (catches share-negative).
	var share_tot: float = 0.0
	for c in cc["beach_classes"]:
		if float(c["share_pct"]) < 0.0:
			bad.append("share-negative:" + str(c["key"]))
		share_tot += float(c["share_pct"])
	if absf(share_tot - 100.0) > 1.0:
		bad.append("share-total=%.1f" % share_tot)
	# 3. spacing positive (catches spacing-zero).
	if float(cc["sample_spacing_m"]) <= 0.0:
		bad.append("spacing<=0")
	# 4. cliff safety present (catches cliff-missing).
	if (cc.get("cliff_safety", []) as Array).is_empty():
		bad.append("cliff_safety empty")
	# 5/6. corridors: width>0, tunnels have portals.
	for c in au["corridors"]:
		if float(c.get("width_m", 1.0)) <= 0.0 and c["type"] != "ring":
			bad.append("width-zero:" + str(c["id"]))
		if c["type"] == "tunnel" and (c.get("portals", []) as Array).is_empty():
			bad.append("tunnel-no-portals:" + str(c["id"]))
	# 7. pads need targets.
	for pd in au.get("pads", []):
		if not pd.has("target_m"):
			bad.append("pad-no-target:" + str(pd.get("id", "?")))
	# 9. runway blend non-negative.
	if float(au["runway"]["blend_m"]) < 0.0:
		bad.append("runway-neg-blend")
	# 10. loop regions exist.
	var ids := {}
	for r in au["regions"]:
		ids[r["id"]] = true
	for lp in au.get("loops", []):
		for rid in lp.get("sequence", []):
			if not ids.has(rid):
				bad.append("loop-bad-region:" + str(rid))
	if not bad.is_empty():
		_fail("structural", bad)
		return
	# Build the field (crash gate) + semantic water check.
	var bf: Array = _build(all)
	if bf[0] == null:
		_fail("build", [str(bf[1])])
		return
	var f: TerrainField = bf[0]
	for lk in au["drainage"].get("lakes", []):
		# 8. floor below level (catches lake-unenclosed floor=99).
		if float(lk["floor_m"]) >= float(lk["level_m"]):
			_fail("semantic", ["lake-floor-above-level:" + str(lk["id"])])
			return
		var hc: float = f.height(float(lk["cx"]), float(lk["cz"]))
		if absf(hc - float(lk["floor_m"])) > 0.05:
			_fail("semantic", ["lake-floor-mismatch:" + str(lk["id"])])
			return
		var rim: float = 1e18
		for k in range(16):
			var a: float = float(k) * TAU / 16.0
			rim = minf(rim, f.height(float(lk["cx"]) + 1.6 * float(lk["rx"]) * sin(a),
				float(lk["cz"]) - 1.6 * float(lk["rz"]) * cos(a)))
		if rim <= float(lk["level_m"]):
			_fail("semantic", ["lake-unenclosed:" + str(lk["id"])])
			return
	if f.lut_n < 360:
		_fail("semantic", ["lut too small"])
		return
	print("TERRAIN_OK checks passed (structural + semantic)")
	quit(0)


func _cmd_bench(n: int) -> void:
	var all: Dictionary = _load_all("", "")
	if not all["ok"]:
		_fail("load", [str(all["error"])])
		return
	var t0: int = Time.get_ticks_msec()
	var bf: Array = _build(all)
	if bf[0] == null:
		_fail("build", [str(bf[1])])
		return
	var build_ms: int = Time.get_ticks_msec() - t0
	var f: TerrainField = bf[0]
	# Deterministic LCG points in [-2000, 2000]^2 (rejected outside r=2000).
	var st: int = 123456789
	var pts: Array = []
	while pts.size() < n:
		st = (st * 1103515245 + 12345) & 0x7fffffff
		var x: float = float(st) / 2147483647.0 * 4000.0 - 2000.0
		st = (st * 1103515245 + 12345) & 0x7fffffff
		var z: float = float(st) / 2147483647.0 * 4000.0 - 2000.0
		if x * x + z * z <= 2000.0 * 2000.0:
			pts.append([x, z])
	var t1: int = Time.get_ticks_usec()
	var acc: float = 0.0
	for q in pts:
		acc += f.height(float(q[0]), float(q[1]))
	var h_us: int = Time.get_ticks_usec() - t1
	var t2: int = Time.get_ticks_usec()
	for q in pts:
		f.region_at(float(q[0]), float(q[1]))
	var r_us: int = Time.get_ticks_usec() - t2
	print("BENCH " + JSON.stringify({"n": n, "build_ms": build_ms,
		"height_us_total": h_us, "height_us_per": float(h_us) / float(n),
		"region_us_total": r_us, "region_us_per": float(r_us) / float(n),
		"acc": acc}))
	quit(0)


func _fail(where: String, errors: Array) -> void:
	print("TERRAIN_FAIL %s" % where)
	for e in errors:
		print("TERRAIN_ERROR %s" % str(e))
	quit(2)


func _flag(args: PackedStringArray, name: String, default_value: String) -> String:
	for i in range(args.size()):
		if args[i] == name and i + 1 < args.size():
			return args[i + 1]
	return default_value
