extends SceneTree
## Gameplay verifier (Prompt 10): independently validates P10 contracts,
## mission/objective/economy/wanted/event/save artifacts + runtime dump.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/gameplay_check.gd
##     -- --contracts data/world --derived data/derived
##     [--runtime <dump.json>] [--metrics <out.json>]
## Output: GAMEPLAY_METRICS <json> or GAMEPLAY_FAIL. Exit 0 = GAMEPLAY_OK.

const Seed = preload("res://scripts/core/seed_service.gd")

var _ran := false


func _initialize() -> void:
	if _ran:
		return
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	var cdir: String = _flag(args, "--contracts", "")
	var ddir: String = _flag(args, "--derived", "")
	var rpath: String = _flag(args, "--runtime", "")
	var mpath: String = _flag(args, "--metrics", "")
	if cdir == "" or ddir == "":
		_fail("usage", ["want --contracts <dir> --derived <dir>"])
		return
	_run(cdir, ddir, rpath, mpath)


func _flag(args: PackedStringArray, name: String, dflt: String) -> String:
	var i: int = args.find(name)
	if i < 0 or i + 1 >= args.size():
		return dflt
	return args[i + 1]


func _load(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "missing " + path}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _fail(stage: String, reasons: Array) -> void:
	print("GAMEPLAY_FAIL stage=", stage, " reasons=", JSON.stringify(reasons))
	quit(2)


func _canon(v: Variant) -> String:
	if v is Dictionary:
		var keys: Array = (v as Dictionary).keys()
		keys.sort()
		var parts: PackedStringArray = []
		for k in keys:
			parts.append(JSON.stringify(str(k)) + ":" + _canon((v as Dictionary)[k]))
		return "{" + ",".join(parts) + "}"
	if v is Array:
		var items: PackedStringArray = []
		for e in (v as Array):
			items.append(_canon(e))
		return "[" + ",".join(items) + "]"
	if v is String:
		return JSON.stringify(v)
	if v is bool:
		return "true" if v else "false"
	if v == null:
		return "null"
	if v is float and (v as float) == floorf(v as float) and absf(v as float) < 1e15:
		return str(int(v as float)) + ".0"
	return str(v)


func _sha16(path: String) -> String:
	var ctx := HashingContext.new()
	ctx.start(HashingContext.HASH_SHA256)
	ctx.update(FileAccess.get_file_as_bytes(path))
	return ctx.finish().hex_encode().left(16)


func _has_cycle(nodes: Array, edges: Array) -> bool:
	var adj := {}
	for n in nodes:
		adj[str(n)] = []
	for e in edges:
		var a: String = str((e as Array)[0])
		var b: String = str((e as Array)[1])
		if adj.has(a):
			(adj[a] as Array).append(b)
	var color := {}
	for n in nodes:
		color[str(n)] = 0
	for n in nodes:
		if color[str(n)] == 0 and _dfs(str(n), adj, color):
			return true
	return false


func _dfs(u: String, adj: Dictionary, color: Dictionary) -> bool:
	color[u] = 1
	for v in (adj.get(u, []) as Array):
		var w: String = str(v)
		if color.get(w, 0) == 1:
			return true
		if color.get(w, 0) == 0 and _dfs(w, adj, color):
			return true
	color[u] = 2
	return false


func _run(cdir: String, ddir: String, rpath: String, mpath: String) -> void:
	var bad: Array = []
	var gc: Dictionary = _load(cdir + "/gameplay_contract.json").get("data", {})
	var ec: Dictionary = _load(cdir + "/economy_contract.json").get("data", {})
	var wc: Dictionary = _load(cdir + "/wanted_contract.json").get("data", {})
	var mani: Dictionary = _load(ddir + "/gameplay_manifest.json").get("data", {})
	var midx: Dictionary = _load(ddir + "/gameplay_mission_index.json").get("data", {})
	var ogr: Dictionary = _load(ddir + "/gameplay_objective_graph.json").get("data", {})
	var eco: Dictionary = _load(ddir + "/gameplay_economy.json").get("data", {})
	var wtd: Dictionary = _load(ddir + "/gameplay_wanted.json").get("data", {})
	var evg: Dictionary = _load(ddir + "/gameplay_events.json").get("data", {})
	var svg: Dictionary = _load(ddir + "/gameplay_save_schema.json").get("data", {})
	if gc.is_empty() or ec.is_empty() or wc.is_empty() or mani.is_empty():
		_fail("load", ["contract/manifest load failed"])
		return
	# ---- contract schema keys ----
	for k in ["schema_version", "gameplay_version", "mission_version",
			"economy_version", "wanted_version", "event_version",
			"save_version", "reward_version", "sources", "mission_policy",
			"objective_policy", "save_policy", "validation_policy"]:
		if not gc.has(k):
			bad.append("contract-missing:" + k)
	# ---- mission defs ----
	var need_m := ["mission_id", "version", "title_key", "description_key",
		"type", "availability", "start_conditions", "objectives",
		"checkpoints", "failure_conditions", "success_conditions",
		"rewards", "world_effects", "npc_roles", "vehicle_roles",
		"route_requirements", "wanted_policy", "economy_policy",
		"cleanup_policy"]
	var templates: Array = ((gc.get("mission_policy", {}) as Dictionary).get("templates", []) as Array)
	var mids := {}
	for m in (midx.get("missions", []) as Array):
		var d: Dictionary = m
		for k in need_m:
			if not d.has(k):
				bad.append("mission-field:%s:%s" % [str(d.get("mission_id", "?")), k])
		var mid: String = str(d.get("mission_id", ""))
		if mid == "" or mids.has(mid):
			bad.append("mission-id:" + mid)
		mids[mid] = true
		if not (str(d.get("type", "")) in templates):
			bad.append("mission-template:" + mid)
		var rr: Dictionary = d.get("route_requirements", {})
		if not rr.has("origin_ref") or not rr.has("dest_ref"):
			bad.append("mission-route-refs:" + mid)
	# ---- objective graphs: recompute acyclicity + shape ----
	var graphs: Dictionary = ogr.get("graphs", {})
	for mid in mids.keys():
		if not graphs.has(mid):
			bad.append("graph-missing:" + str(mid))
			continue
		var g: Dictionary = graphs[mid]
		var nodes: Array = g.get("nodes", [])
		var edges: Array = g.get("edges", [])
		var seen := {}
		for n in nodes:
			if seen.has(str(n)):
				bad.append("graph-dup:" + str(mid))
			seen[str(n)] = true
		for e in edges:
			if not seen.has(str((e as Array)[0])) or not seen.has(str((e as Array)[1])):
				bad.append("graph-dangle:" + str(mid))
		if _has_cycle(nodes, edges):
			bad.append("graph-cycle:" + str(mid))
	# ---- machines embedded == contract ----
	var mm: Dictionary = (gc.get("mission_policy", {}) as Dictionary).get("transitions", {})
	if JSON.stringify(mm) != JSON.stringify(midx.get("mission_machine", {})):
		bad.append("mission-machine-divergence")
	# ---- economy/wanted/events/save shapes ----
	if (eco.get("shops", []) as Array).is_empty() or (eco.get("prices", []) as Array).is_empty():
		bad.append("economy-empty")
	for p in (eco.get("prices", []) as Array):
		if float((p as Dictionary).get("price", -1.0)) <= 0.0:
			bad.append("price-nonpositive")
			break
	if (wtd.get("offenses", []) as Array).size() != 7:
		bad.append("offense-count")
	var fines: Dictionary = wtd.get("fines", {})
	for k in fines.keys():
		if float(fines[k]) <= 0.0:
			bad.append("fine-nonpositive:" + str(k))
	if (evg.get("events", []) as Array).is_empty():
		bad.append("events-empty")
	var sv: Dictionary = svg.get("versions", {})
	if int(sv.get("current", 0)) != 1:
		bad.append("save-current-version")
	# ---- checksum recompute (fnv over canonical cores) ----
	var mcore := {"missions": midx.get("missions", []),
		"mission_machine": midx.get("mission_machine", {}),
		"objective_machine": midx.get("objective_machine", {}),
		"mission_version": midx.get("mission_version", ""),
		"sources": midx.get("sources", {})}
	if Seed.fnv1a64_hex(_canon(mcore)) != str(midx.get("mission_checksum", "")):
		bad.append("mission-checksum-mismatch")
	var gcore := {"graphs": ogr.get("graphs", {}),
		"mission_version": ogr.get("mission_version", ""),
		"sources": ogr.get("sources", {})}
	if Seed.fnv1a64_hex(_canon(gcore)) != str(ogr.get("objective_graph_checksum", "")):
		bad.append("objgraph-checksum-mismatch")
	# ---- upstream integration: recompute sha pins ----
	var sources: Dictionary = mani.get("sources", {})
	var checked := 0
	for k in sources.keys():
		if str(k) == "pin_method":
			continue
		var fpath: String = ""
		if str(k).ends_with("_contract"):
			fpath = cdir + "/" + str(k) + ".json"
		else:
			fpath = ddir + "/" + str(k) + ".json"
		if FileAccess.file_exists(fpath):
			if _sha16(fpath) != str(sources[k]):
				bad.append("upstream-pin:" + str(k))
			checked += 1
	if checked < 10:
		bad.append("upstream-coverage:%d" % checked)
	# ---- runtime dump (lifecycle/pins/bus/txns) ----
	var rt := {}
	if rpath != "":
		rt = _load(rpath).get("data", {})
		if (rt as Dictionary).is_empty():
			bad.append("runtime-load")
		else:
			var mstates: Dictionary = (rt as Dictionary).get("mission_states", {})
			for mid2 in mstates.keys():
				if not (mm as Dictionary).has(str(mstates[mid2])):
					bad.append("runtime-mstate:" + str(mid2))
			for p in (((rt as Dictionary).get("npc_pins", []) as Array) + ((rt as Dictionary).get("traffic_pins", []) as Array)):
				if str((p as Dictionary).get("owner", "")) == "":
					bad.append("runtime-pin-ownerless")
					break
			var bal: float = float((rt as Dictionary).get("balance", 0.0))
			var seen_tx := {}
			var txns: Array = (rt as Dictionary).get("txns", [])
			for t in txns:
				var td: Dictionary = t
				var tid: String = str(td.get("transaction_id", ""))
				if seen_tx.has(tid):
					bad.append("runtime-txn-dup:" + tid)
					break
				seen_tx[tid] = true
				var before: float = float(td.get("balance_before", 0.0))
				var after: float = float(td.get("balance_after", 0.0))
				var amt: float = float(td.get("amount", 0.0))
				var op: String = str(td.get("op", ""))
				var want: float = before
				if op == "CREDIT" or op == "REFUND":
					want = before + amt
				elif op == "DEBIT":
					want = before - amt
				if absf(want - after) > 0.01:
					bad.append("runtime-txn-link:" + tid)
					break
			if not txns.is_empty():
				var last: Dictionary = txns[txns.size() - 1]
				if absf(float(last.get("balance_after", 0.0)) - bal) > 0.01:
					bad.append("runtime-txn-balance")
			var wchain: String = str(((rt as Dictionary).get("wanted", {}) as Dictionary).get("chain", ""))
			var wm: Dictionary = (wc.get("wanted_policy", {}) as Dictionary).get("transitions", {})
			if wchain != "" and not wm.has(wchain) and wchain != "NONE":
				bad.append("runtime-wanted-chain:" + wchain)
	if not bad.is_empty():
		_fail("verify", bad)
		return
	var metrics := {
		"gameplay_checksum": str(mani.get("gameplay_checksum", "")),
		"mission_checksum": str(midx.get("mission_checksum", "")),
		"missions": (midx.get("missions", []) as Array).size(),
		"shops": (eco.get("shops", []) as Array).size(),
		"upstream_checked": checked,
		"runtime": rpath != "",
		"result": "GAMEPLAY_OK",
	}
	if mpath != "":
		var f := FileAccess.open(mpath, FileAccess.WRITE)
		f.store_string(JSON.stringify(metrics, "\t"))
		f.close()
	print("GAMEPLAY_METRICS ", JSON.stringify(metrics))
	print("GAMEPLAY_OK contracts=", cdir)
	quit(0)
