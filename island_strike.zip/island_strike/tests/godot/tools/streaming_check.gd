extends SceneTree
## Streaming lightweight verifier (Prompt 07): independently re-verifies
## the sector manifest + LOD policy + dependency graph + state machine
## contract inside the engine.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/streaming_check.gd
##     -- --manifest <world_stream_manifest.json> --lod <lod_policy.json>
##     [--golden <p07_golden_stream.json>]
## Output: STREAMING_METRICS <json> or STREAMING_FAIL.
## Exit: 0 = STREAMING_OK, 2 = STREAMING_FAIL.
##
## Semantic parity, explicit tolerances:
##   bounds:   recomputed grid_min+sx*size, tol 1e-6 m
##   mapping:  left-closed floor mapping, exact (incl. negatives/edges)
##   vs_world: corner-test classification, exact
##   checksum: fnv1a32 over semantic lines, exact
##   LOD:      exit > enter for every level, exact
##   deps:     acyclic (Kahn), exact
##   states:   transition table mirror, exact

const GRID_MIN := -2048.0
const WORLD_R := 2000.0

const LEGAL := {
	"UNLOADED": ["REQUESTED", "QUEUED"],
	"REQUESTED": ["QUEUED", "CANCELLED", "FAILED"],
	"QUEUED": ["LOADING", "CANCELLED", "FAILED"],
	"LOADING": ["LOADED", "FAILED", "CANCELLED"],
	"LOADED": ["ACTIVATING", "CACHED", "FAILED"],
	"ACTIVATING": ["ACTIVE", "FAILED", "CANCELLED"],
	"ACTIVE": ["DEACTIVATING", "FAILED"],
	"DEACTIVATING": ["UNLOADING", "FAILED"],
	"UNLOADING": ["CACHED", "UNLOADED", "FAILED"],
	"CACHED": ["QUEUED", "UNLOADED", "REQUESTED"],
	"FAILED": ["QUEUED", "UNLOADED", "REQUESTED"],
	"CANCELLED": ["UNLOADED", "REQUESTED", "QUEUED"],
}

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	if args.has("--manifest") and args.has("--lod"):
		_cmd_verify(_flag(args, "--manifest", ""), _flag(args, "--lod", ""),
				_flag(args, "--golden", ""))
	else:
		_fail("usage", ["want --manifest <json> --lod <json> [--golden <json>]"])
	return true


func _flag(args: PackedStringArray, key: String, dflt: String) -> String:
	var i: int = args.find(key)
	if i < 0 or i + 1 >= args.size():
		return dflt
	return args[i + 1]


func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "missing " + path}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _fail(stage: String, notes: Array) -> void:
	print("STREAMING_FAIL " + JSON.stringify({"stage": stage, "notes": notes}))
	quit(2)


func _fnv1a32(s: String) -> int:
	var h: int = 2166136261
	for i in range(s.length()):
		h = h ^ s.unicode_at(i)
		h = (h * 16777619) & 0xFFFFFFFF
	return h


func _sector_of(x: float, z: float, size_m: float) -> Vector2i:
	return Vector2i(floori((x - GRID_MIN) / size_m), floori((z - GRID_MIN) / size_m))


func _parse_sid(sid: String) -> Vector2i:
	var parts: PackedStringArray = sid.substr(2).split("Z", false, 2)
	return Vector2i(parts[0].to_int(), parts[1].to_int())


func _bounds_min(sx: int, sz: int, size_m: float) -> Vector2:
	return Vector2(GRID_MIN + float(sx) * size_m, GRID_MIN + float(sz) * size_m)


func _vs_world(sx: int, sz: int, size_m: float) -> String:
	var mn: Vector2 = _bounds_min(sx, sz, size_m)
	var mx: Vector2 = mn + Vector2(size_m, size_m)
	var cx: float = clampf(0.0, mn.x, mx.x)
	var cz: float = clampf(0.0, mn.y, mx.y)
	if sqrt(cx * cx + cz * cz) > WORLD_R:
		return "FULLY_OUTSIDE"
	var d_max := 0.0
	for px in [mn.x, mx.x]:
		for pz in [mn.y, mx.y]:
			d_max = maxf(d_max, sqrt(px * px + pz * pz))
	if d_max <= WORLD_R:
		return "FULLY_INSIDE"
	return "PARTIAL"


func _cmd_verify(manifest_path: String, lod_path: String, golden_path: String) -> void:
	if manifest_path == "" or lod_path == "":
		_fail("verify", ["missing path"])
		return
	var mj: Dictionary = _load_json(manifest_path)
	var lj: Dictionary = _load_json(lod_path)
	for e in [mj, lj]:
		if not e["ok"]:
			_fail("load", [str(e["error"])])
			return
	var man: Dictionary = mj["data"]
	var lod: Dictionary = lj["data"]
	var meta: Dictionary = man["meta"]
	var size_m: float = float(meta["sector_size_m"])
	var count: int = int(meta["grid_count"])
	if not [128.0, 256.0, 512.0].has(size_m):
		_fail("meta", ["bad sector_size_m"])
		return
	var sectors: Array = man["sectors"]
	if sectors.size() != count * count:
		_fail("counts", ["sectors=%d want=%d" % [sectors.size(), count * count]])
		return
	# math: bounds / mapping / world-state for every sector
	var bad_b := 0
	var bad_map := 0
	var bad_ws := 0
	var lines: PackedStringArray = []
	for sec in sectors:
		var sid: String = str(sec["sector_id"])
		var ss: Vector2i = _parse_sid(sid)
		if "SX%02dZ%02d" % [ss.x, ss.y] != sid:
			bad_map += 1
		var mn: Vector2 = _bounds_min(ss.x, ss.y, size_m)
		var b: Array = sec["bounds"]
		if abs(float(b[0]) - mn.x) > 1e-6 or abs(float(b[1]) - mn.y) > 1e-6 \
				or abs(float(b[2]) - mn.x - size_m) > 1e-6 \
				or abs(float(b[3]) - mn.y - size_m) > 1e-6:
			bad_b += 1
		var back: Vector2i = _sector_of(mn.x + size_m * 0.5, mn.y + size_m * 0.5, size_m)
		if back != ss:
			bad_map += 1
		if _sector_of(mn.x, mn.y, size_m) != ss:
			bad_map += 1
		if _vs_world(ss.x, ss.y, size_m) != str(sec["world_state"]):
			bad_ws += 1
		var c: Dictionary = sec["content_counts"]
		lines.append("%s|%s|%d,%d,%d,%d,%d,%d,%d,%d,%d" % [
			sid, str(sec["world_state"]), int(c["districts"]), int(c["blocks"]),
			int(c["parcels"]), int(c["buildings"]), int(c["landmarks"]),
			int(c["open"]), int(c["fragments"]), int(c["structures"]),
			int(c["reservations"])])
	if bad_b > 0 or bad_map > 0 or bad_ws > 0:
		_fail("math", ["bounds=%d map=%d world=%d" % [bad_b, bad_map, bad_ws]])
		return
	# boundary fixtures: left-closed, negatives, epsilon
	var edge: float = GRID_MIN + size_m
	var edge_ok: bool = _sector_of(edge, 0.0, size_m).x == 1 \
		and _sector_of(edge - 1e-9, 0.0, size_m).x == 0 \
		and _sector_of(GRID_MIN, GRID_MIN, size_m) == Vector2i(0, 0) \
		and _sector_of(-100.0, -100.0, size_m) == _sector_of(-100.0, -100.0, size_m)
	if not edge_ok:
		_fail("math", ["boundary fixtures"])
		return
	# semantic checksum parity
	lines.sort()
	var h32: int = _fnv1a32("\n".join(lines))
	var want_sem: String = str(meta.get("semantic_checksum32", ""))
	if "%08x" % h32 != want_sem:
		_fail("checksum", ["engine=%08x manifest=%s" % [h32, want_sem]])
		return
	# LOD policy
	var lod_bad := 0
	var cats: Dictionary = lod["categories"]
	for kind in cats:
		var cat: Dictionary = cats[kind]
		var th: Dictionary = cat["threshold_m"]
		var ex: Dictionary = cat["exit_m"]
		for lv in th:
			if not (float(th[lv]) > 0.0 and float(ex[lv]) > float(th[lv])):
				lod_bad += 1
	if lod_bad > 0:
		_fail("lod", ["bad=%d" % lod_bad])
		return
	# dependency graph: node format + acyclic (Kahn)
	var indeg: Dictionary = {}
	var adj: Dictionary = {}
	var debad := 0
	for e in man["dependency_edges"]:
		var a: String = str(e["source"])
		var bb: String = str(e["target"])
		if a.begins_with("STRUCT-"):
			pass
		elif not (a.begins_with("SX") and a.contains(":")):
			debad += 1
		if bb.begins_with("STRUCT-"):
			pass
		elif not (bb.begins_with("SX") and bb.contains(":")):
			debad += 1
		if not adj.has(a):
			adj[a] = []
		(adj[a] as Array).append(bb)
		indeg[bb] = int(indeg.get(bb, 0)) + 1
		if not indeg.has(a):
			indeg[a] = int(indeg.get(a, 0))
	if debad > 0:
		_fail("deps", ["bad-nodes=%d" % debad])
		return
	var fringe: Array = []
	for n in indeg:
		if int(indeg[n]) == 0:
			fringe.append(n)
	var seen := 0
	while not fringe.is_empty():
		var u: String = str(fringe.pop_back())
		seen += 1
		for v in (adj.get(u, []) as Array):
			indeg[v] = int(indeg[v]) - 1
			if int(indeg[v]) == 0:
				fringe.append(v)
	if seen != indeg.size():
		_fail("deps", ["cycle: seen=%d nodes=%d" % [seen, indeg.size()]])
		return
	# state machine contract mirror
	var st_ok: bool = LEGAL.size() == 12 \
		and not LEGAL["UNLOADED"].has("ACTIVE") \
		and not LEGAL["FAILED"].has("ACTIVE") \
		and LEGAL["UNLOADED"].has("REQUESTED") \
		and LEGAL["ACTIVE"].has("DEACTIVATING") \
		and LEGAL["FAILED"].has("QUEUED")
	if not st_ok:
		_fail("states", ["table mismatch"])
		return
	# golden replay: static contexts must equal engine-computed want set
	var golden_note := "skipped"
	var gcount := 0
	if golden_path != "":
		var gj: Dictionary = _load_json(golden_path)
		if not gj["ok"]:
			_fail("golden", [str(gj["error"])])
			return
		var gold: Dictionary = gj["data"]
		var all_ids: Dictionary = {}
		for sec in sectors:
			all_ids[str(sec["sector_id"])] = _parse_sid(str(sec["sector_id"]))
		for ctx in gold:
			var g: Dictionary = gold[ctx]
			if not g.has("cam"):
				continue
			var cam: Array = g["cam"]
			if float(cam[2]) != 0.0 or float(cam[3]) != 0.0:
				continue  # moving contexts: scheduler-dependent, python-owned
			if str(ctx) == "teleport":
				continue
			var cc: Vector2i = _sector_of(float(cam[0]), float(cam[1]), size_m)
			var want: Dictionary = {}
			for sid in all_ids:
				var ss2: Vector2i = all_ids[sid]
				if maxi(absi(ss2.x - cc.x), absi(ss2.y - cc.y)) <= 1:
					want[sid] = true
			var core: Dictionary = g["core"]
			var got: Array = core["active"]
			var matched: bool = got.size() == want.size()
			if matched:
				for sid2 in got:
					if not want.has(str(sid2)):
						matched = false
						break
			if not matched:
				_fail("golden", ["ctx=" + str(ctx)])
				return
			gcount += 1
		golden_note = "replayed=%d" % gcount
	print("STREAMING_METRICS " + JSON.stringify({
		"sectors": sectors.size(), "size_m": size_m,
		"semantic_checksum32": "%08x" % h32,
		"dep_edges": (man["dependency_edges"] as Array).size(),
		"dep_nodes": indeg.size(), "states": LEGAL.size(),
		"golden": golden_note, "result": "STREAMING_OK",
	}))
	quit(0)
