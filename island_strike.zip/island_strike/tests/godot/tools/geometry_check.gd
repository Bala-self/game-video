extends SceneTree
## Geometry lightweight verifier (Prompt 04): independently re-verifies the
## exported road mesh (data/derived/road_geometry.json) inside the engine.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/geometry_check.gd
##     -- --verify <road_geometry.json> [--metrics <out.json>]
## Output: GEOMETRY_METRICS <json> (part counts, index ranges, up-facing
## recompute over EVERY tri, bounds) or GEOMETRY_FAIL. Scalar floats only.
## Exit: 0 = GEOMETRY_OK, 2 = GEOMETRY_FAIL.

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	if args.has("--verify"):
		_cmd_verify(_flag(args, "--verify", ""), _flag(args, "--metrics", ""))
	else:
		_fail("usage", ["want --verify <road_geometry.json>"])
	return true


func _flag(args: PackedStringArray, key: String, dflt: String) -> String:
	var i: int = args.find(key)
	if i < 0 or i + 1 >= args.size():
		return dflt
	return args[i + 1]


func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "missing " + path}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _fail(stage: String, info: Array) -> void:
	print("GEOMETRY_FAIL " + stage + " " + JSON.stringify(info))
	quit(2)


func _cmd_verify(geo_path: String, metrics_path: String) -> void:
	if geo_path == "":
		_fail("verify", ["missing path"])
		return
	var gj: Dictionary = _load_json(geo_path)
	if not gj["ok"]:
		_fail("load", [str(gj["error"])])
		return
	var g: Dictionary = gj["data"]
	var parts: Array = g["parts"]
	var n_verts: int = 0
	var n_tris: int = 0
	var n_up: int = 0
	var min_area: float = 1e300
	var bad_idx: Array = []
	var down: Array = []
	var bounds := {}
	for p in parts:
		var pid: String = str(p["id"])
		var vv: Array = p["verts"]
		var tt: Array = p["tris"]
		n_verts += vv.size()
		n_tris += tt.size()
		var blo: Array = [1e300, 1e300, 1e300]
		var bhi: Array = [-1e300, -1e300, -1e300]
		for q in vv:
			for k in range(3):
				var f: float = float(q[k])
				blo[k] = minf(blo[k], f)
				bhi[k] = maxf(bhi[k], f)
		bounds[pid] = {"lo": blo, "hi": bhi}
		for tri in tt:
			var a: int = int(tri[0])
			var b: int = int(tri[1])
			var c: int = int(tri[2])
			if a < 0 or b < 0 or c < 0 or a >= vv.size() or b >= vv.size() or c >= vv.size():
				bad_idx.append([pid, tri])
				continue
			var ax: float = float(vv[a][0])
			var ay: float = float(vv[a][1])
			var az: float = float(vv[a][2])
			var bx: float = float(vv[b][0])
			var by: float = float(vv[b][1])
			var bz: float = float(vv[b][2])
			var cx: float = float(vv[c][0])
			var cy: float = float(vv[c][1])
			var cz: float = float(vv[c][2])
			var ux: float = bx - ax
			var uy: float = by - ay
			var uz: float = bz - az
			var vx: float = cx - ax
			var vy: float = cy - ay
			var vz: float = cz - az
			var nx: float = uy * vz - uz * vy
			var ny: float = uz * vx - ux * vz
			var nz: float = ux * vy - uy * vx
			var area: float = sqrt(nx * nx + ny * ny + nz * nz) / 2.0
			min_area = minf(min_area, area)
			if ny > 0.0:
				n_up += 1
			else:
				down.append([pid, tri])
	var metrics := {
		"parts": parts.size(), "verts": n_verts, "tris": n_tris,
		"up": n_up, "min_area": min_area,
		"bad_index": bad_idx.size(), "down": down.size(),
		"checksum": str(g["checksum"]["geometry"]),
		"lips": (g["lips"] as Array).size(),
		"bounds": bounds,
	}
	if metrics_path != "":
		FileAccess.open(metrics_path, FileAccess.WRITE).store_string(JSON.stringify(metrics))
	if not bad_idx.is_empty():
		_fail("index", bad_idx.slice(0, 3))
		return
	if not down.is_empty():
		_fail("facing", down.slice(0, 3))
		return
	print("GEOMETRY_METRICS " + JSON.stringify({
		"parts": parts.size(), "verts": n_verts, "tris": n_tris,
		"up": n_up, "min_area": min_area, "checksum": str(g["checksum"]["geometry"]),
		"lips": (g["lips"] as Array).size()}))
	print("GEOMETRY_OK")
	quit(0)
