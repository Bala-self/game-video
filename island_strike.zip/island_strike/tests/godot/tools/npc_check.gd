extends SceneTree
## NPC verifier (Prompt 09): independently verifies derived NPC navigation
## + population artifacts inside the engine. Mirrors traffic_check.gd.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/npc_check.gd
##     -- --verify <nav_manifest> --population <pop_manifest>
##     --contract <npc_contract> [--metrics <out.json>]
## Output: NPC_METRICS <json> or NPC_FAIL (reasons). Scalar-safe.
## Exit: 0 = NPC_OK, 2 = NPC_FAIL.

const Seed = preload("res://scripts/core/seed_service.gd")

var _ran := false


func _initialize() -> void:
	if _ran:
		return
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	var vpath: String = _flag(args, "--verify", "")
	var ppath: String = _flag(args, "--population", "")
	var cpath: String = _flag(args, "--contract", "")
	var mpath: String = _flag(args, "--metrics", "")
	if vpath == "" or ppath == "" or cpath == "":
		_fail("usage", ["want --verify <nav> --population <pop> --contract <tc>"])
		return
	_run(vpath, ppath, cpath, mpath)


func _flag(args: PackedStringArray, name: String, default_value: String) -> String:
	var i: int = args.find(name)
	if i < 0 or i + 1 >= args.size():
		return default_value
	return args[i + 1]


func _load(path: String) -> Dictionary:
	var txt: String = FileAccess.get_file_as_string(path)
	var v: Variant = JSON.parse_string(txt)
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _fail(stage: String, reasons: Array) -> void:
	print("NPC_FAIL stage=", stage, " reasons=", JSON.stringify(reasons))
	quit(2)


# Canonical JSON: sorted keys, compact separators, floats via str().
func _canon(v: Variant) -> String:
	if v is Dictionary:
		var keys: Array = (v as Dictionary).keys()
		keys.sort()
		var parts: PackedStringArray = []
		for k in keys:
			parts.append(JSON.stringify(str(k)) + ":" + _canon((v as Dictionary)[k]))
		return "{" + ",".join(parts) + "}"
	if v is Array:
		var items: PackedStringArray = []
		for e in (v as Array):
			items.append(_canon(e))
		return "[" + ",".join(items) + "]"
	if v is String:
		return JSON.stringify(v)
	if v is bool:
		return "true" if v else "false"
	if v == null:
		return "null"
	if v is float and (v as float) == floorf(v as float) and absf(v as float) < 1e15:
		return str(int(v as float)) + ".0"
	return str(v)


func _fnv1a64_hex(s: String) -> String:
	return Seed.fnv1a64_hex(s)


func _run(vpath: String, ppath: String, cpath: String, mpath: String) -> void:
	var bad: Array = []
	var nav: Dictionary = (_load(vpath).get("data", {}))
	var pop: Dictionary = (_load(ppath).get("data", {}))
	var tc: Dictionary = (_load(cpath).get("data", {}))
	if nav.is_empty() or pop.is_empty() or tc.is_empty():
		_fail("load", ["json load failed"])
		return
	# ---- contract: policy versions ----
	for k in ["seed_policy", "spawn_policy", "movement_policy",
			"perception_policy", "behavior_policy", "interaction_policy",
			"simulation_tier_policy", "lod_policy", "performance_policy",
			"validation_policy", "walkability"]:
		if not (tc.get(k, {}) is Dictionary and (tc[k] as Dictionary).has("policy_version")):
			bad.append("contract-missing:" + k)
	var sources: Dictionary = tc.get("sources", {})
	# ---- provenance: manifest sources match contract ----
	for k in sources.keys():
		if str((nav.get("sources", {}) as Dictionary).get(k, "")) != str(sources[k]):
			bad.append("nav-source-mismatch:" + k)
		if str((pop.get("sources", {}) as Dictionary).get(k, "")) != str(sources[k]):
			bad.append("pop-source-mismatch:" + k)
	# ---- checksum recompute ----
	var nav_core := {"areas": nav.get("areas", []), "nodes": nav.get("nodes", []),
		"edges": nav.get("edges", []), "crossings": nav.get("crossings", []),
		"settings": nav.get("settings", {}),
		"sources": nav.get("sources", {})}
	var nav_sum: String = _fnv1a64_hex(_canon(nav_core))
	if nav_sum != str(nav.get("npc_navigation_checksum", "")):
		bad.append("nav-checksum-mismatch")
	var pop_core := {"zones": pop.get("zones", []),
		"archetypes": pop.get("archetypes", {}),
		"population_version": pop.get("population_version", ""),
		"sources": pop.get("sources", {})}
	var pop_sum: String = _fnv1a64_hex(_canon(pop_core))
	if pop_sum != str(pop.get("npc_population_checksum", "")):
		bad.append("pop-checksum-mismatch")
	var pol_core := {"movement": tc.get("movement_policy", {}),
		"perception": tc.get("perception_policy", {}),
		"behavior": tc.get("behavior_policy", {}),
		"tiers": tc.get("simulation_tier_policy", {}),
		"lod": tc.get("lod_policy", {}),
		"performance": tc.get("performance_policy", {})}
	var pol_sum: String = _fnv1a64_hex(_canon(pol_core))
	if pol_sum != str(pop.get("npc_policy_checksum", "")):
		bad.append("policy-checksum-mismatch")
	# ---- graph integrity ----
	var nodes: Array = nav.get("nodes", [])
	var ids := {}
	for n in nodes:
		var nid: String = str((n as Dictionary).get("id", ""))
		if nid == "" or ids.has(nid):
			bad.append("node-id:" + nid)
		ids[nid] = true
	var max_slope: float = float((tc.get("walkability", {}) as Dictionary).get("max_slope_grade", 0.25))
	var blocked: Array = (tc.get("walkability", {}) as Dictionary).get("blocked_regions", [])
	var ev_bad := 0
	for n in nodes:
		var d: Dictionary = n
		if float(d.get("slope_grade", 0.0)) > max_slope + 1e-9:
			ev_bad += 1
		if str(d.get("region", "")) in blocked:
			ev_bad += 1
	if ev_bad > 0:
		bad.append("node-evidence:%d" % ev_bad)
	var edges: Array = nav.get("edges", [])
	for e in edges:
		var d: Dictionary = e
		if not ids.has(str(d.get("a", ""))) or not ids.has(str(d.get("b", ""))):
			bad.append("edge-dangle:%s-%s" % [str(d.get("a", "")), str(d.get("b", ""))])
	var crossings: Array = nav.get("crossings", [])
	for c in crossings:
		var d: Dictionary = c
		if not ids.has(str(d.get("a", ""))) or not ids.has(str(d.get("b", ""))):
			bad.append("crossing-dangle:" + str(d.get("id", "")))
		if float(d.get("width_m", 0.0)) <= 0.0:
			bad.append("crossing-width:" + str(d.get("id", "")))
	# ---- population ----
	var zones: Array = pop.get("zones", [])
	var archs: Dictionary = pop.get("archetypes", {})
	if archs.size() != 9:
		bad.append("archetypes:%d" % archs.size())
	var targets := 0
	for z in zones:
		var t: int = int((z as Dictionary).get("target_population", -1))
		if t < 0:
			bad.append("zone-target:" + str((z as Dictionary).get("zone_id", "")))
		targets += maxi(t, 0)
	if not bad.is_empty():
		_fail("verify", bad)
		return
	var metrics := {
		"npc_navigation_checksum": nav_sum,
		"npc_population_checksum": pop_sum,
		"npc_policy_checksum": pol_sum,
		"areas": (nav.get("areas", []) as Array).size(),
		"nodes": nodes.size(), "edges": edges.size(),
		"crossings": crossings.size(), "zones": zones.size(),
		"targets": targets, "result": "NPC_OK",
	}
	if mpath != "":
		var f := FileAccess.open(mpath, FileAccess.WRITE)
		f.store_string(JSON.stringify(metrics, "\t"))
		f.close()
	print("NPC_METRICS ", JSON.stringify(metrics))
	print("NPC_OK verify=", vpath)
	quit(0)
