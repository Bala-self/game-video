extends SceneTree
## Structure lightweight verifier (Prompt 05): independently re-verifies the
## exported transport meshes (data/derived/transport_{structures,markings}.json)
## plus reservation checksum echo inside the engine.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/structure_check.gd
##     -- --verify <transport_structures.json> --marks <transport_markings.json>
##     --resv <transport_reservations.json> [--metrics <out.json>]
## Output: STRUCTURE_METRICS <json> (part/tri counts, index ranges,
## min area, marking up-facing recompute over EVERY marking tri, bounds)
## or STRUCTURE_FAIL. Scalar floats only.
## Exit: 0 = STRUCTURE_OK, 2 = STRUCTURE_FAIL.

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	if args.has("--verify"):
		_cmd_verify(
			_flag(args, "--verify", ""),
			_flag(args, "--marks", ""),
			_flag(args, "--resv", ""),
			_flag(args, "--metrics", ""))
	else:
		_fail("usage", ["want --verify <transport_structures.json>"])
	return true


func _flag(args: PackedStringArray, key: String, dflt: String) -> String:
	var i: int = args.find(key)
	if i < 0 or i + 1 >= args.size():
		return dflt
	return args[i + 1]


func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "missing " + path}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _fail(stage: String, info: Array) -> void:
	print("STRUCTURE_FAIL " + stage + " " + JSON.stringify(info))
	quit(2)


func _scan(parts: Array, want_up: bool, bounds: Dictionary) -> Dictionary:
	var n_verts: int = 0
	var n_tris: int = 0
	var n_up: int = 0
	var min_area: float = 1e300
	var bad_idx: Array = []
	var down: Array = []
	for p in parts:
		var pid: String = str(p["id"])
		var vv: Array = p["verts"]
		var tt: Array = p["tris"]
		n_verts += vv.size()
		n_tris += tt.size()
		var blo: Array = [1e300, 1e300, 1e300]
		var bhi: Array = [-1e300, -1e300, -1e300]
		for q in vv:
			for k in range(3):
				var f: float = float(q[k])
				blo[k] = minf(blo[k], f)
				bhi[k] = maxf(bhi[k], f)
		bounds[pid] = {"lo": blo, "hi": bhi}
		for tri in tt:
			var a: int = int(tri[0])
			var b: int = int(tri[1])
			var c: int = int(tri[2])
			if a < 0 or b < 0 or c < 0 or a >= vv.size() or b >= vv.size() or c >= vv.size():
				bad_idx.append([pid, tri])
				continue
			var ax: float = float(vv[a][0])
			var ay: float = float(vv[a][1])
			var az: float = float(vv[a][2])
			var bx: float = float(vv[b][0])
			var by: float = float(vv[b][1])
			var bz: float = float(vv[b][2])
			var cx: float = float(vv[c][0])
			var cy: float = float(vv[c][1])
			var cz: float = float(vv[c][2])
			var ux: float = bx - ax
			var uy: float = by - ay
			var uz: float = bz - az
			var vx: float = cx - ax
			var vy: float = cy - ay
			var vz: float = cz - az
			var nx: float = uy * vz - uz * vy
			var ny: float = uz * vx - ux * vz
			var nz: float = ux * vy - uy * vx
			var area: float = sqrt(nx * nx + ny * ny + nz * nz) / 2.0
			min_area = minf(min_area, area)
			if not want_up:
				continue
			if ny > 0.0:
				n_up += 1
			else:
				down.append([pid, tri])
	return {
		"verts": n_verts, "tris": n_tris, "up": n_up,
		"min_area": min_area, "bad_index": bad_idx, "down": down,
	}


func _cmd_verify(s_path: String, m_path: String, r_path: String, metrics_path: String) -> void:
	if s_path == "" or m_path == "" or r_path == "":
		_fail("verify", ["missing path"])
		return
	var sj: Dictionary = _load_json(s_path)
	var mj: Dictionary = _load_json(m_path)
	var rj: Dictionary = _load_json(r_path)
	if not sj["ok"]:
		_fail("load", [str(sj["error"])])
		return
	if not mj["ok"]:
		_fail("load", [str(mj["error"])])
		return
	if not rj["ok"]:
		_fail("load", [str(rj["error"])])
		return
	var s: Dictionary = sj["data"]
	var m: Dictionary = mj["data"]
	var rv: Dictionary = rj["data"]
	var bounds := {}
	var ss: Dictionary = _scan(s["parts"], false, bounds)
	var ms: Dictionary = _scan(m["parts"], true, bounds)
	var min_area: float = minf(float(ss["min_area"]), float(ms["min_area"]))
	var metrics := {
		"structure_parts": (s["parts"] as Array).size(),
		"structure_tris": int(ss["tris"]),
		"marking_parts": (m["parts"] as Array).size(),
		"marking_tris": int(ms["tris"]),
		"marking_up": int(ms["up"]),
		"min_area": min_area,
		"structures": str(s["checksum"]),
		"markings": str(m["checksum"]),
		"reservations": str(rv["checksum"]),
		"bounds": bounds,
	}
	if metrics_path != "":
		FileAccess.open(metrics_path, FileAccess.WRITE).store_string(JSON.stringify(metrics))
	var bad: Array = (ss["bad_index"] as Array) + (ms["bad_index"] as Array)
	if not bad.is_empty():
		_fail("index", bad.slice(0, 3))
		return
	if not (ms["down"] as Array).is_empty():
		_fail("facing", (ms["down"] as Array).slice(0, 3))
		return
	print("STRUCTURE_METRICS " + JSON.stringify({
		"structure_parts": (s["parts"] as Array).size(),
		"structure_tris": int(ss["tris"]),
		"marking_parts": (m["parts"] as Array).size(),
		"marking_tris": int(ms["tris"]),
		"marking_up": int(ms["up"]),
		"min_area": min_area}))
	print("STRUCTURE_OK")
	quit(0)
