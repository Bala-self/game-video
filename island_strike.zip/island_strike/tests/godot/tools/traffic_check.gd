extends SceneTree
## Traffic verifier (Prompt 08): independently re-verifies the derived
## traffic graph inside the engine. Mirrors the terrain/structure check tools.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/traffic_check.gd
##     -- --verify <traffic_graph.json> --contract <traffic_contract.json>
##     --roads <roads.json> [--metrics <out.json>]
## Output: TRAFFIC_METRICS <json> or TRAFFIC_FAIL (reasons). Scalar-safe.
## Exit: 0 = TRAFFIC_OK, 2 = TRAFFIC_FAIL.

const Seed = preload("res://scripts/core/seed_service.gd")

var _ran := false


func _initialize() -> void:
	if _ran:
		return
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	var gpath: String = _flag(args, "--verify", "")
	var cpath: String = _flag(args, "--contract", "")
	var rpath: String = _flag(args, "--roads", "")
	var mpath: String = _flag(args, "--metrics", "")
	if gpath == "" or cpath == "" or rpath == "":
		_fail("usage", ["want --verify <graph> --contract <tc> --roads <roads>"])
		return
	_run(gpath, cpath, rpath, mpath)


func _flag(args: PackedStringArray, name: String, default_value: String) -> String:
	var i: int = args.find(name)
	if i < 0 or i + 1 >= args.size():
		return default_value
	return args[i + 1]


func _load(path: String) -> Dictionary:
	var txt: String = FileAccess.get_file_as_string(path)
	var v: Variant = JSON.parse_string(txt)
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _q(v: float) -> int:
	return int(roundf(v * 1000.0))


func _run(gpath: String, cpath: String, rpath: String, mpath: String) -> void:
	var bad: Array = []
	var g: Dictionary = (_load(gpath).get("data", {}))
	var tc: Dictionary = (_load(cpath).get("data", {}))
	var roads: Dictionary = (_load(rpath).get("data", {}))
	if g.is_empty() or tc.is_empty() or roads.is_empty():
		_fail("load", ["json load failed"])
		return
	var sc: Dictionary = (_load("res://data/world/sector_contract.json").get("data", {}))
	var size_m: int = int(sc.get("sector_size_m", 256))
	var gmin: float = float((sc.get("grid_origin", {})).get("min_m", -2048.0))
	var lanes: Dictionary = g.get("lanes", {})
	var moves: Dictionary = g.get("movements", {})
	var juncs: Dictionary = g.get("junctions", {})
	var sigs: Dictionary = g.get("signals", {})
	var spawns: Dictionary = g.get("spawn_zones", {})
	var hands: Dictionary = g.get("sector_handoffs", {})
	var nodes: Dictionary = roads.get("nodes", {})
	var runway: Array = roads.get("runway_rect", [])

	# ---- contract: policy versions + vehicle classes ----
	for k in ["lane_policy", "signal_policy", "speed_policy", "spawn_policy",
			"routing_policy", "seed_policy"]:
		if not (tc.get(k, {}) is Dictionary and (tc[k] as Dictionary).has("policy_version")):
			bad.append("contract-missing:" + k)
	var classes: Dictionary = tc.get("vehicle_classes", {})
	var widest: float = 0.0
	for cn in classes.keys():
		var p: Dictionary = classes[cn]
		for f in ["length_m", "width_m", "accel_ms2", "brake_ms2",
				"top_speed_kph", "turn_radius_m", "reaction_s",
				"lane_change_s", "spawn_weight"]:
			if not p.has(f) or float(p[f]) < 0.0:
				bad.append("class-param:%s:%s" % [cn, f])
		if float(p.get("top_speed_kph", 0.0)) <= 0.0 and cn != "emergency_hook":
			bad.append("class-speed:%s" % cn)
		widest = maxf(widest, float(p.get("width_m", 0.0)))

	# ---- lanes ----
	var lane_rows: Array = []
	var min_lw: float = 1e9
	for lid in lanes.keys():
		var l: Dictionary = lanes[lid]
		var pts: Array = l.get("pts", [])
		if pts.size() < 2:
			bad.append("lane-short:" + str(lid))
			continue
		for i in range(pts.size() - 1):
			var a: Array = pts[i]
			var b: Array = pts[i + 1]
			var d: float = Vector3(a[0], a[1], a[2]).distance_to(Vector3(b[0], b[1], b[2]))
			if d < 0.05 or d > 3.5:
				bad.append("lane-spacing:%s:%d" % [str(lid), i])
				break
		if not nodes.has(str(l.get("entry_node", ""))):
			bad.append("lane-entry-node:" + str(lid))
		if not nodes.has(str(l.get("exit_node", ""))):
			bad.append("lane-exit-node:" + str(lid))
		if float(l.get("speed_min_kph", 0.0)) > float(l.get("speed_legal_kph", 0.0)) + 0.01:
			bad.append("lane-speed:" + str(lid))
		min_lw = minf(min_lw, float(l.get("width_m", 0.0)))
		# sector math parity (P07 formula, recomputed here)
		for pi in [0, pts.size() / 2, pts.size() - 1]:
			var p: Array = pts[int(pi)]
			var sx: int = int(floor((float(p[0]) - gmin) / float(size_m)))
			var sz: int = int(floor((float(p[2]) - gmin) / float(size_m)))
			var sid: String = "SX%02dZ%02d" % [sx, sz]
			if not (l.get("sectors", []) as Array).has(sid):
				bad.append("lane-sector:%s:%s" % [str(lid), sid])
				break
		# runway exclusion
		if runway.size() == 4:
			for p in pts:
				var px: float = float(p[0])
				var pz: float = float(p[2])
				if px >= float(runway[0]) and px <= float(runway[2]) and pz >= float(runway[1]) and pz <= float(runway[3]):
					bad.append("lane-runway:%s" % str(lid))
					break
		var p0: Array = pts[0]
		var p1: Array = pts[pts.size() - 1]
		lane_rows.append("%s|%d|%d|%d|%d|%d|%d|%d|%d|%d;" % [str(lid), pts.size(),
			_q(p0[0]), _q(p0[1]), _q(p0[2]), _q(p1[0]), _q(p1[1]), _q(p1[2]),
			_q(float(l.get("length_m", 0.0))), _q(float(l.get("speed_min_kph", 0.0)))])
	lane_rows.sort()
	var lane_canon: String = "".join(lane_rows)
	var digest_lanes: String = Seed.fnv1a64_hex(lane_canon)

	# ---- movements ----
	var move_rows: Array = []
	var ctrls: Array = ["SIGNAL", "YIELD", "MERGE", "UNCONTROLLED",
		"UNCONTROLLED_THROUGH"]
	for mid in moves.keys():
		var m: Dictionary = moves[mid]
		if not lanes.has(str(m.get("from_lane", ""))):
			bad.append("move-from:" + str(mid))
		if not lanes.has(str(m.get("to_lane", ""))):
			bad.append("move-to:" + str(mid))
		if m.get("junction", null) != null and not juncs.has(str(m["junction"])):
			bad.append("move-junction:" + str(mid))
		if not ctrls.has(str(m.get("control", ""))):
			bad.append("move-control:" + str(mid))
		if m.get("connector_ref", null) != null and not (m["connector_ref"] is String):
			bad.append("move-connector-type:" + str(mid))
		move_rows.append("%s|%s|%s|%s|%s;" % [str(mid), str(m.get("from_lane", "")),
			str(m.get("to_lane", "")), str(m.get("type", "")), str(m.get("control", ""))])
	move_rows.sort()
	var digest_moves: String = Seed.fnv1a64_hex("".join(move_rows))

	# ---- roundabout island exclusion (hub circulates, never crosses center) ----
	var hub: Dictionary = (roads.get("nodes", {}) as Dictionary).get("hub_city", {})
	if not hub.is_empty():
		var hx: float = float(hub.get("x", 0.0))
		var hz: float = float(hub.get("z", 0.0))
		for mid in moves.keys():
			var m: Dictionary = moves[mid]
			if str(m.get("type", "")) != "ROUNDABOUT" or not (m.get("turn_pts", null) is Array):
				continue
			for p in (m["turn_pts"] as Array):
				var dd: float = Vector2(float(p[0]) - hx, float(p[2]) - hz).length()
				if dd < 10.0:
					bad.append("roundabout-island:%s" % str(mid))
					break

	# ---- signals ----
	for sid in sigs.keys():
		var s: Dictionary = sigs[sid]
		var covered: Array = []
		var cyc: int = 0
		for ph in (s.get("phases", []) as Array):
			cyc += int(ph.get("green_ticks", 0)) + int(ph.get("yellow_ticks", 0))
			for mm in (ph.get("movements", []) as Array):
				covered.append(str(mm))
		if cyc != int(s.get("cycle_ticks", -1)):
			bad.append("signal-cycle:" + str(sid))
		var want: Array = []
		for mid in moves.keys():
			var m: Dictionary = moves[mid]
			if str(m.get("control", "")) == "SIGNAL" and ("SIG:" + str(m.get("junction", ""))) == str(sid):
				want.append(str(mid))
		covered.sort()
		want.sort()
		if covered != want:
			bad.append("signal-cover:%s" % str(sid))

	# ---- spawn zones + handoffs ----
	for zid in spawns.keys():
		var z: Dictionary = spawns[zid]
		for ll in (z.get("lanes", []) as Array):
			if not lanes.has(str(ll)):
				bad.append("spawn-lane:%s" % str(zid))
		var zp: Array = z.get("pos", [])
		if zp.size() == 3:
			var sx2: int = int(floor((float(zp[0]) - gmin) / float(size_m)))
			var sz2: int = int(floor((float(zp[2]) - gmin) / float(size_m)))
			if ("SX%02dZ%02d" % [sx2, sz2]) != str(z.get("sector", "")):
				bad.append("spawn-sector:%s" % str(zid))
	for sid2 in hands.keys():
		var h: Dictionary = hands[sid2]
		for ll in (h.get("lanes", []) as Array):
			if not lanes.has(str(ll)):
				bad.append("hand-lane:%s" % str(sid2))
				break

	if not bad.is_empty():
		_fail("verify", bad.slice(0, 19))
		return
	var metrics: Dictionary = {
		"lanes": lanes.size(), "movements": moves.size(),
		"junctions": juncs.size(), "signals": sigs.size(),
		"spawn_zones": spawns.size(), "digest_lanes": digest_lanes,
		"digest_moves": digest_moves, "min_lane_width": min_lw,
		"widest_class": widest,
		"graph_checksum": str((g.get("checksums", {}) as Dictionary).get("traffic_graph_checksum", "")),
	}
	print("TRAFFIC_METRICS " + JSON.stringify(metrics))
	if mpath != "":
		var f := FileAccess.open(mpath, FileAccess.WRITE)
		if f != null:
			f.store_string(JSON.stringify(metrics))
			f.close()
	print("TRAFFIC_OK verify=%s" % gpath)
	quit(0)


func _fail(tag: String, reasons: Array) -> void:
	print("TRAFFIC_FAIL " + tag + " :: " + str(reasons).left(600))
	quit(2)


func _process(_delta: float) -> bool:
	return true
