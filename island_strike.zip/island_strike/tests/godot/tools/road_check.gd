extends SceneTree
## Road lightweight verifier (Prompt 03): independently re-verifies the
## exported road network (data/derived/roads.json) inside the engine.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/road_check.gd
##     -- --verify <roads.json>
## Output: ROAD_METRICS <json> (edge lengths/grades, node elevations,
## checksum, route results) or ROAD_FAIL. Scalar floats only (no Vector2).
## Exit: 0 = ROAD_OK, 2 = ROAD_FAIL.

const TerrainField = preload("res://scripts/terrain/terrain_field.gd")
const Seed = preload("res://scripts/core/seed_service.gd")

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	if args.has("--verify"):
		_cmd_verify(_flag(args, "--verify", ""))
	else:
		_fail("usage", ["want --verify <roads.json>"])
	return true


func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "missing " + path}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if v == null or not (v is Dictionary):
		return {"ok": false, "error": "bad json " + path}
	return {"ok": true, "data": v}


func _cmd_verify(roads_path: String) -> void:
	if roads_path == "":
		_fail("verify", ["missing path"])
		return
	var t: Dictionary = _load_json("res://data/world/terrain_contract.json")
	var c: Dictionary = _load_json("res://data/world/coast_contract.json")
	var a: Dictionary = _load_json("res://data/terrain/authoring.json")
	var w: Dictionary = _load_json("res://data/world/world_contract.json")
	var rj: Dictionary = _load_json(roads_path)
	for e in [t, c, a, w, rj]:
		if not e["ok"]:
			_fail("load", [str(e["error"])])
			return
	var f := TerrainField.new()
	var r: Dictionary = f.initialize(t["data"], c["data"], a["data"], w["data"])
	if not r["ok"]:
		_fail("build", [str(r.get("error", "init failed"))])
		return
	var roads: Dictionary = rj["data"]
	var nodes: Dictionary = roads["nodes"]
	var edges: Dictionary = roads["edges"]
	# edge lengths from sample chords (same left-to-right order as Python)
	var lengths := {}
	var eids: Array = edges.keys()
	eids.sort()
	for eid in eids:
		var sl: Array = edges[eid]["samples"]
		var L: float = 0.0
		for i in range(sl.size() - 1):
			var dx: float = float(sl[i + 1]["x"]) - float(sl[i]["x"])
			var dz: float = float(sl[i + 1]["z"]) - float(sl[i]["z"])
			L += sqrt(dx * dx + dz * dz)
		lengths[eid] = L
	# node elevations via the terrain twin (independent query)
	var nelev := {}
	var nids: Array = nodes.keys()
	nids.sort()
	for nid in nids:
		nelev[nid] = f.height(float(nodes[nid]["x"]), float(nodes[nid]["z"]))
	# grades: route-full profile recipe on twin heights (P02 method; sliced
	# per edge afterwards so smoothing matches the generator exactly).
	# Tunnel excluded: twin samples the surface, the bore is authored.
	var grades := {}
	var by_route := {}
	for eid in eids:
		if bool(edges[eid]["tunnel"]):
			continue
		var rk: String = str(edges[eid]["route"])
		if not by_route.has(rk):
			by_route[rk] = []
		by_route[rk].append(eid)
	for rid in by_route.keys():
		var rids: Array = by_route[rid]
		rids.sort()
		var full: Array = []
		for eid2 in rids:
			var sl2: Array = edges[eid2]["samples"]
			for i in range(sl2.size()):
				if not full.is_empty() and i == 0:
					continue
				full.append(sl2[i])
		var hs: Array = []
		for s in full:
			hs.append(f.height(float(s["x"]), float(s["z"])))
		var ds: Array = [0.0]
		for i in range(1, full.size()):
			var dx: float = float(full[i]["x"]) - float(full[i - 1]["x"])
			var dz: float = float(full[i]["z"]) - float(full[i - 1]["z"])
			ds.append(float(ds[i - 1]) + sqrt(dx * dx + dz * dz))
		var win: int = 5
		var sm: Array = []
		for i in range(hs.size()):
			var lo: int = maxi(0, i - win)
			var hi: int = mini(hs.size(), i + win + 1)
			var acc: float = 0.0
			for j in range(lo, hi):
				acc += float(hs[j])
			sm.append(acc / float(hi - lo))
		var step: float = float(ds[1]) - float(ds[0]) if ds.size() > 1 else 10.0
		var gr: Array = []
		for i in range(sm.size() - 1):
			gr.append(abs(float(sm[i + 1]) - float(sm[i])) / step * 100.0)
		var w200: int = maxi(1, int(200.0 / step))
		var roll: Array = []
		for i in range(gr.size()):
			var lo2: int = maxi(0, i - w200 + 1)
			var acc2: float = 0.0
			for j in range(lo2, i + 1):
				acc2 += float(gr[j])
			roll.append(acc2 / float(i + 1 - lo2))
		var off: int = 0
		for eid2 in rids:
			var n: int = (edges[eid2]["samples"] as Array).size()
			var mx: float = 0.0
			var mxr: float = 0.0
			for i in range(off, off + n - 1):
				mx = maxf(mx, float(gr[i]))
				mxr = maxf(mxr, float(roll[i]))
			off += n - 1
			grades[eid2] = [mx, mxr]
	# canonical checksum from parsed values (same recipe as road_model.py)
	var parts: Array = []
	var m: Dictionary = roads["meta"]
	parts.append("road=%s terra=%s coast=%s world=%s auth=%s" % [
		m["road_version"], m["terrain_version"], m["coast_version"],
		m["world_version"], m["road_authoring_version"]])
	for nid in nids:
		var n: Dictionary = nodes[nid]
		parts.append("N|%s|%d|%d|%d|%s|%s|%s|%d" % [
			nid, int(roundf(float(n["x"]) * 1000.0)),
			int(roundf(float(n["z"]) * 1000.0)),
			int(roundf(float(n["elev"]) * 1000.0)),
			str(n["region"]), str(n["type"]), str(n["access"]), int(n["degree"])])
	for eid in eids:
		var e: Dictionary = edges[eid]
		var mr: float = minf(float(e["min_radius_m"]), 1e8)
		parts.append("E|%s|%s|%s|%s|%s|%s|%d|%d|%d|%d|%d|%d|%d|%s|%d" % [
			eid, str(e["from_node"]), str(e["to_node"]), str(e["route"]),
			str(e["class"]), str(e["access"]),
			int(roundf(float(e["length_m"]) * 1000.0)),
			int(roundf(float(e["elev_start"]) * 1000.0)),
			int(roundf(float(e["elev_end"]) * 1000.0)),
			int(roundf(float(e["max_grade_short"]) * 1000.0)),
			int(roundf(float(e["max_grade_sustained"]) * 1000.0)),
			int(roundf(mr * 100.0)),
			int(roundf(float(e["coast_min_m"]) * 1000.0)),
			str(e["region"]), int(e["n_samples"])])
		for s in e["samples"]:
			parts.append("S|%s|%d|%d|%d|%d|%s" % [
				eid, int(roundf(float(s["x"]) * 1000.0)),
				int(roundf(float(s["z"]) * 1000.0)),
				int(roundf(float(s["elev"]) * 1000.0)),
				int(roundf(float(s["coast_d"]) * 1000.0)), str(s["region"])])
		for fl in e["fillets"]:
			var an: Array = fl["anchor"]
			parts.append("F|%s|%d|%d|%d|%d" % [
				eid, int(roundf(float(an[0]) * 1000.0)),
				int(roundf(float(an[1]) * 1000.0)),
				int(roundf(float(fl["radius_m"]) * 100.0)),
				int(roundf(float(fl["deviation_m"]) * 1000.0))])
	var bridges: Array = roads["bridges"]
	var bids: Array = []
	for b in bridges:
		bids.append(str(b["id"]))
	bids.sort()
	for bid in bids:
		for b in bridges:
			if str(b["id"]) == bid:
				parts.append("B|%s|%s|%s|%s|%d" % [
					bid, str(b["road_edge"]), str(b["crossing_type"]),
					str(b["water_feature"]),
					int(roundf(float(b["length_m"]) * 1000.0))])
	var digest: String = Seed.fnv1a64_hex(";".join(parts) + ";")
	# fixed route query set (Dijkstra, access-filtered, deterministic)
	var queries: Array = [
		["hub_city", "port_gate", "public"],
		["hub_city", "air_gate", "public"],
		["hub_city", "village_center", "public"],
		["hub_city", "sub_center", "public"],
		["hub_city", "resort_waterfront", "public"],
		["hub_city", "ridge_end", "public"],
		["hub_city", "waterfront_access", "public"],
		["hub_city", "jn_W_portal", "public"],
		["hub_city", "forest_depot", "service"],
		["hub_city", "gate_restricted", "restricted"],
		["jn_ring_W", "jn_ring_S", "public"],
		["port_gate", "air_gate", "public"],
	]
	var routes := {}
	for q in queries:
		routes["%s>%s:%s" % [q[0], q[1], q[2]]] = _route(edges, str(q[0]), str(q[1]), str(q[2]))
	print("ROAD_METRICS " + JSON.stringify({
		"lengths": lengths, "node_elev": nelev, "grades": grades,
		"checksum": digest, "routes": routes,
		"counts": {"nodes": nids.size(), "edges": eids.size()}}))
	print("ROAD_OK verify=%s checksum=%s" % [roads_path, digest])
	quit(0)


func _route(edges: Dictionary, start: String, goal: String, prof: String) -> Dictionary:
	var allow: Array = {"public": ["PUBLIC"], "service": ["PUBLIC", "SERVICE"],
		"restricted": ["PUBLIC", "SERVICE", "RESTRICTED"]}[prof]
	var adj := {}
	for eid in edges.keys():
		var e: Dictionary = edges[eid]
		if not allow.has(str(e["access"])):
			continue
		var w: float = float(e["length_m"]) / maxf(1.0, float(e["effective_speed_kph"]))
		if not adj.has(e["from_node"]):
			adj[e["from_node"]] = []
		if not adj.has(e["to_node"]):
			adj[e["to_node"]] = []
		adj[e["from_node"]].append([e["to_node"], w, eid])
		adj[e["to_node"]].append([e["from_node"], w, eid])
	for k in adj.keys():
		adj[k].sort()
	if not adj.has(start) or not adj.has(goal):
		return {}
	var dist := {start: 0.0}
	var prev := {}
	var pq: Array = [[0.0, start]]
	while not pq.is_empty():
		pq.sort()
		var top: Array = pq.pop_front()
		var d: float = top[0]
		var u: String = top[1]
		if u == goal:
			break
		if d > float(dist.get(u, 1e18)) + 1e-12:
			continue
		for it in adj.get(u, []):
			var v: String = it[0]
			var nd: float = d + float(it[1])
			if nd < float(dist.get(v, 1e18)) - 1e-12:
				dist[v] = nd
				prev[v] = [u, it[2]]
				pq.append([nd, v])
	if not prev.has(goal) and goal != start:
		return {}
	var rnodes: Array = [goal]
	var redges: Array = []
	var u2: String = goal
	var total: float = 0.0
	while u2 != start:
		var pr: Array = prev[u2]
		rnodes.append(pr[0])
		redges.append(pr[1])
		total += float(edges[pr[1]]["length_m"])
		u2 = pr[0]
	rnodes.reverse()
	redges.reverse()
	return {"nodes": rnodes, "edges": redges, "length_m": total}


func _fail(where: String, errors: Array) -> void:
	print("ROAD_FAIL %s :: %s" % [where, "; ".join(errors)])
	quit(2)


func _flag(args: PackedStringArray, name: String, default_value: String) -> String:
	var i: int = args.find(name)
	if i < 0 or i + 1 >= args.size():
		return default_value
	return args[i + 1]
