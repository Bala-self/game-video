extends SceneTree
## Contract CLI (Prompt 01, §37–38, §53): load + validate + optional dump.
## Usage:
##   godot --headless --path . --script res://tests/godot/tools/contract_check.gd
##     -- --contract <path> --golden <path> [--dump <out.json>] [--allow-missing-golden]
## Exit: 0 = CONTRACT_OK, 2 = CONTRACT_FAIL.

const ContractData = preload("res://scripts/core/world_contract_data.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")
const Sector = preload("res://scripts/core/sector_service.gd")
const Seed = preload("res://scripts/core/seed_service.gd")
const Checksum = preload("res://scripts/core/world_checksum.gd")
const Validation = preload("res://scripts/core/validation_service.gd")
const Benchmark = preload("res://scripts/core/benchmark_service.gd")

var _ran := false


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()
	var contract_path: String = _flag(args, "--contract", "res://data/world/world_contract.json")
	var golden_path: String = _flag(args, "--golden", "res://data/world/contract_checksum.txt")
	var dump_path: String = _flag(args, "--dump", "")
	var allow_missing: bool = args.has("--allow-missing-golden")

	var loaded: Dictionary = ContractData.load_from_path(contract_path)
	if not loaded["ok"]:
		_fail("load", loaded["errors"])
		return true
	var reg := WorldRegistry.new()
	var init_r: Dictionary = reg.initialize(loaded["data"])
	if not init_r["ok"]:
		_fail("registry", init_r["errors"])
		return true
	var val := Validation.new(reg)
	for c in val.check_locked_values():
		if not c["pass"]:
			_fail("locked-value:" + c["name"], [c["detail"]])
			return true
	for c in val.check_registry_consistency(contract_path):
		if not c["pass"]:
			_fail("consistency:" + c["name"], [c["detail"]])
			return true
	if FileAccess.file_exists(golden_path):
		for c in val.check_checksum(golden_path):
			if not c["pass"]:
				_fail("checksum:" + c["name"], [c["detail"]])
				return true
	elif not allow_missing:
		_fail("golden-missing", [golden_path])
		return true
	else:
		print("CONTRACT_NOTE golden skipped (--allow-missing-golden)")

	if dump_path != "":
		if not _write_dump(reg, dump_path):
			return true
	var core_r: Dictionary = Checksum.core_from_registry(reg)
	var h: Dictionary = Checksum.checksum_of_core(core_r["core"])
	print("CONTRACT_OK radius=%.1f seed=%d checksum=%s" % [reg.radius_m(), reg.master_seed(), h["checksum_hex"]])
	quit(0)
	return true


func _write_dump(reg: WorldRegistry, dump_path: String) -> bool:
	var core_r: Dictionary = Checksum.core_from_registry(reg)
	var h: Dictionary = Checksum.checksum_of_core(core_r["core"])
	if not h["ok"]:
		_fail("dump-checksum", [h["error"]])
		return false
	var svc := Sector.new(reg)
	var seeds := {}
	for spec in [["sector", "7,9"], ["region", "R1"], ["terrain", "8,8"]]:
		var r: Dictionary = Seed.derive(reg.world_version(), reg.master_seed(), spec[0], spec[1])
		seeds["%s:%s" % [spec[0], spec[1]]] = r
	var vi: Dictionary = Engine.get_version_info()
	var report := {
		"generated_at": Benchmark.utc_stamp(),
		"engine": {"version": "%s.%s.%s.%s" % [vi["major"], vi["minor"], vi["patch"], vi["status"]], "os": OS.get_name()},
		"dump": reg.to_dump(),
		"canonical": h["canonical"],
		"checksum_hex": h["checksum_hex"],
		"seeds": seeds,
		"census": svc.grid_census(),
	}
	var bench := Benchmark.new()
	var w: Dictionary = bench.write_json(dump_path, report)
	if not w["ok"]:
		_fail("dump-write", [w["error"]])
		return false
	print("CONTRACT_DUMP %s" % dump_path)
	return true


func _fail(where: String, errors: Array) -> void:
	print("CONTRACT_FAIL %s" % where)
	for e in errors:
		print("CONTRACT_ERROR %s" % str(e))
	quit(2)


func _flag(args: PackedStringArray, name: String, default_value: String) -> String:
	for i in range(args.size()):
		if args[i] == name and i + 1 < args.size():
			return args[i + 1]
	return default_value
