extends "res://tests/godot/test_suite.gd"
## L2 coordinate tests (Prompt 01, §12–13, §27–28): radius, boundary, GPS, headings.

const Coord = preload("res://scripts/core/coordinate_service.gd")
const Units = preload("res://scripts/core/units.gd")

const R := 2000.0
const OFF := Vector2(2000.0, 2000.0)


func run_suite(_tree) -> void:
	suite_name = "coordinates"
	# --- scalar radius (double precision) ---
	check("r-origin", Coord.radius_from_xz(0.0, 0.0) == 0.0)
	check("r-345", Coord.radius_from_xz(3.0, 4.0) == 5.0)
	check("r-east-edge", Coord.radius_from_xz(2000.0, 0.0) == 2000.0)
	check("r-north-edge", Coord.radius_from_xz(0.0, -2000.0) == 2000.0)
	check_approx("r-diag-exact", Coord.radius_from_xz(1414.2135623730951, -1414.2135623730951), 2000.0, Units.DOUBLE_EPS)
	var rc: float = Coord.radius_from_xz(1414.21356, -1414.21356)
	check_approx("r-contract-diag", rc, 2000.0, Units.BOUNDARY_EPS_M, "r=%s" % rc)
	# --- Vector3 wrapper ---
	check("r-v3", Coord.radius_of(Vector3(100, 0, 0)) == 100.0)
	check("r-v3-y-ignored", Coord.radius_of(Vector3(0, 999, 0)) == 0.0, "boundary is cylindrical")
	# --- boundary classification ---
	check("b-inside", Coord.boundary_class_of_r(1999.5, R) == Coord.BoundaryClass.INSIDE)
	check("b-center", Coord.boundary_class_of_r(0.0, R) == Coord.BoundaryClass.INSIDE)
	check("b-exact-edge", Coord.boundary_class_of_r(2000.0, R) == Coord.BoundaryClass.EDGE)
	check("b-edge-lo", Coord.boundary_class_of_r(1999.9995, R) == Coord.BoundaryClass.EDGE)
	check("b-edge-hi", Coord.boundary_class_of_r(2000.0005, R) == Coord.BoundaryClass.EDGE)
	check("b-contract-diag-edge", Coord.boundary_class_of_r(rc, R) == Coord.BoundaryClass.EDGE)
	check("b-outside", Coord.boundary_class_of_r(2000.5, R) == Coord.BoundaryClass.OUTSIDE)
	check("b-far-outside", Coord.boundary_class_of_r(4000.0, R) == Coord.BoundaryClass.OUTSIDE)
	# --- inside fail-open (1 mm) ---
	check("in-2000", Coord.is_inside_world_r(2000.0, R))
	check("in-edge-hi", Coord.is_inside_world_r(2000.0005, R))
	check("out-2000.5", not Coord.is_inside_world_r(2000.5, R))
	# --- GPS mapping (§13 cases; game grid, NOT lat/long) ---
	_check_gps("gps-center", Vector3.ZERO, Vector2(2000, 2000))
	_check_gps("gps-north", Vector3(0, 0, -2000), Vector2(2000, 0))
	_check_gps("gps-south", Vector3(0, 0, 2000), Vector2(2000, 4000))
	_check_gps("gps-east", Vector3(2000, 0, 0), Vector2(4000, 2000))
	_check_gps("gps-west", Vector3(-2000, 0, 0), Vector2(0, 2000))
	_check_gps("gps-neg", Vector3(-100, 0, -100), Vector2(1900, 1900))
	_check_gps("gps-outside", Vector3(2500, 0, 0), Vector2(4500, 2000), "mapping defined everywhere")
	var gd: Vector2 = Coord.world_to_map_gps_xz(1414.21356, -1414.21356, OFF)
	# Vector2 stores float32 (quantum ~5e-4 here): 1 mm per float32 policy.
	check_approx("gps-diag-x", gd.x, 3414.21356, Units.BOUNDARY_EPS_M)
	check_approx("gps-diag-y", gd.y, 585.78644, Units.BOUNDARY_EPS_M)
	# --- GPS round-trips ---
	for p in [Vector3.ZERO, Vector3(100, 0, -50), Vector3(-2000, 0, 2000), Vector3(2500, 0, -2500)]:
		var g: Vector2 = Coord.world_to_map_gps_xz(p.x, p.z, OFF)
		var back: Vector2 = Coord.map_gps_to_world_xz(g.x, g.y, OFF)
		check_approx("rt-x:%s" % str(p), back.x, p.x, Units.DOUBLE_EPS)
		check_approx("rt-z:%s" % str(p), back.y, p.z, Units.DOUBLE_EPS)
	# --- movement semantics (§27) ---
	var n: Vector3 = Coord.north_offset(Vector3.ZERO, 100.0)
	check("move-north", n == Vector3(0, 0, -100), "X/Y unchanged, Z decreases: %s" % str(n))
	var e: Vector3 = Coord.east_offset(Vector3(5, 7, 9), 100.0)
	check("move-east", e == Vector3(105, 7, 9), "X increases: %s" % str(e))
	var u: Vector3 = Coord.up_offset(Vector3.ZERO, 50.0)
	check("move-up", u == Vector3(0, 50, 0))
	# --- headings (0=N, clockwise) ---
	_check_heading("head-n", Vector3(0, 0, -1), 0.0)
	_check_heading("head-e", Vector3(1, 0, 0), PI / 2.0)
	_check_heading("head-s", Vector3(0, 0, 1), PI)
	_check_heading("head-w", Vector3(-1, 0, 0), -PI / 2.0)
	check("head-zero-invalid", not Coord.heading_from_direction(Vector3.ZERO)[0])
	# --- clamp-or-reject gate ---
	var c1: Dictionary = Coord.clamp_or_reject(Vector3(100, 5, 0), R)
	check("gate-inside", c1["ok"] and c1["pos"] == Vector3(100, 5, 0))
	var c2: Dictionary = Coord.clamp_or_reject(Vector3(3000, 5, 0), R)
	check("gate-outside-flag", not c2["ok"], "must flag, never silent")
	check_approx("gate-clamp-x", (c2["pos"] as Vector3).x, 2000.0, Units.DOUBLE_EPS)
	check("gate-clamp-y", (c2["pos"] as Vector3).y == 5.0)
	check("gate-reports-r", (c2 as Dictionary)["r"] == 3000.0)


func _check_gps(test_name: String, world: Vector3, expected: Vector2, detail: String = "") -> void:
	var g: Vector2 = Coord.world_to_map_gps_xz(world.x, world.z, OFF)
	var d := detail
	if d == "":
		d = "got %s want %s" % [str(g), str(expected)]
	check(test_name, g == expected, d)


func _check_heading(test_name: String, dir: Vector3, expected: float) -> void:
	var r: Array = Coord.heading_from_direction(dir)
	check(test_name, bool(r[0]) and absf(float(r[1]) - expected) <= Units.DOUBLE_EPS,
		"got %s want %s" % [str(r[1]), str(expected)])
