extends "res://tests/godot/test_suite.gd"
## L2 seed tests: FNV-1a spec vectors, hex codec, derivation reproducibility + separation.

const Seed = preload("res://scripts/core/seed_service.gd")


func run_suite(_tree) -> void:
	suite_name = "seeds"
	# Spec vectors (FNV-1a 64-bit; independently asserted by Python too).
	check("fnv-empty", Seed.fnv1a64_hex("") == "cbf29ce484222325", Seed.fnv1a64_hex(""))
	check("fnv-a", Seed.fnv1a64_hex("a") == "af63dc4c8601ec8c", Seed.fnv1a64_hex("a"))
	check("fnv-foobar", Seed.fnv1a64_hex("foobar") == "85944171f73967e8", Seed.fnv1a64_hex("foobar"))
	# Hex codec edges.
	check("hex-zero", Seed.u64_to_hex(0) == "0000000000000000")
	check("hex-neg1", Seed.u64_to_hex(-1) == "ffffffffffffffff")
	check("hex-255", Seed.u64_to_hex(255) == "00000000000000ff")
	check("hex-len", Seed.u64_to_hex(123456789).length() == 16)
	# Canonical input format is exact.
	check("canonical", Seed.canonical_input("0.1.0", 13371337, "sector", "7,9")
		== "IS-SEED/1|v=0.1.0|m=13371337|d=sector|k=7,9")
	# Reproducibility: same inputs -> identical derivation.
	var a: Dictionary = Seed.derive("0.1.0", 13371337, "sector", "7,9")
	var b: Dictionary = Seed.derive("0.1.0", 13371337, "sector", "7,9")
	check("derive-ok", a["ok"], str(a.get("error", "")))
	check("derive-repro", a["seed_hex"] == b["seed_hex"] and a["seed_i64"] == b["seed_i64"])
	check("derive-scheme", a["scheme"] == "IS-SEED/1")
	# Separation: distinct (domain,key) -> distinct digests over a sample grid.
	var seen := {}
	var distinct := true
	for d in ["region", "sector", "terrain", "roads"]:
		for k in ["0,0", "7,9", "15,15", "R1"]:
			var r: Dictionary = Seed.derive("0.1.0", 13371337, d, k)
			if not r["ok"] or seen.has(r["seed_hex"]):
				distinct = false
			seen[r["seed_hex"]] = true
	check("derive-separation-16", distinct, "16 derivations must be pairwise distinct")
	# Sensitivity: each input dimension changes the digest.
	var base: String = a["seed_hex"]
	check("sens-version", (Seed.derive("0.1.1", 13371337, "sector", "7,9"))["seed_hex"] != base)
	check("sens-master", (Seed.derive("0.1.0", 13371338, "sector", "7,9"))["seed_hex"] != base)
	check("sens-domain", (Seed.derive("0.1.0", 13371337, "terrain", "7,9"))["seed_hex"] != base)
	check("sens-key", (Seed.derive("0.1.0", 13371337, "sector", "7,10"))["seed_hex"] != base)
	# Rejections.
	check("reject-domain", not (Seed.derive("0.1.0", 13371337, "nope", "x"))["ok"])
	check("reject-key", not (Seed.derive("0.1.0", 13371337, "sector", ""))["ok"])
	check("reject-version", not (Seed.derive("", 13371337, "sector", "x"))["ok"])
	# RNG helper is seeded deterministically (same seed -> same first value).
	var r1: RandomNumberGenerator = Seed.rng_for_seed(a["seed_i64"])
	var r2: RandomNumberGenerator = Seed.rng_for_seed(a["seed_i64"])
	check("rng-repro", r1.randi() == r2.randi(), "engine stream reproducible within version")
