extends "res://tests/godot/test_suite.gd"
## L1 contract-loader tests: real file loads; shape violations fail loudly (§51/52).

const ContractData = preload("res://scripts/core/world_contract_data.gd")

const PATH := "res://data/world/world_contract.json"


func run_suite(_tree) -> void:
	suite_name = "contract_loader"
	# Real artifact loads cleanly.
	var loaded: Dictionary = ContractData.load_from_path(PATH)
	check("real-loads", loaded["ok"], str(loaded.get("errors", [])))
	if not loaded["ok"]:
		return
	var norm: Dictionary = loaded["data"]
	check("norm-radius", norm["radius_m"] == 2000.0)
	check("norm-seed-int", norm["master_seed"] is int and norm["master_seed"] == 13371337)
	check("norm-sector-int", norm["sector_size_m"] is int and norm["sector_size_m"] == 256)
	check("norm-origin", norm["origin"] == [0, 0, 0])
	# Shape violations on mutated copies (parsed-dict level).
	var base: Dictionary = _raw()
	check("mut-missing-key", not ContractData.validate(_mut(base, "radius_m", null, true))["ok"])
	check("mut-neg-radius", not ContractData.validate(_mut(base, "radius_m", -5.0))["ok"])
	check("mut-zero-radius", not ContractData.validate(_mut(base, "radius_m", 0.0))["ok"])
	check("mut-diameter", not ContractData.validate(_mut(base, "diameter_m", 3999.0))["ok"])
	check("mut-origin", not ContractData.validate(_mut(base, "origin", [1, 0, 0]))["ok"])
	check("mut-convention", not ContractData.validate(_mut(base, "coordinate_convention", "left-handed"))["ok"])
	check("mut-status", not ContractData.validate(_mut(base, "sector_status", "final"))["ok"])
	check("mut-seed-float", not ContractData.validate(_mut(base, "master_seed", 1.5))["ok"])
	check("mut-seed-neg", not ContractData.validate(_mut(base, "master_seed", -1))["ok"])
	check("mut-scheme", not ContractData.validate(_mut(base, "seed_scheme", "RAND"))["ok"])
	check("mut-gps", not ContractData.validate(_mut(base, "gps_origin_offset", [0, 0]))["ok"])
	check("mut-terrain", not ContractData.validate(_mut(base, "terrain_target_max_m", 999.0))["ok"])
	var bad_axes: Dictionary = (base["axes"] as Dictionary).duplicate()
	bad_axes["north"] = "+Z"
	check("mut-axes", not ContractData.validate(_mut(base, "axes", bad_axes))["ok"])
	var bad_b: Dictionary = (base["boundary"] as Dictionary).duplicate()
	bad_b["r_coast0_m"] = 1900.0
	bad_b["r_beach0_m"] = 1800.0
	check("mut-rings", not ContractData.validate(_mut(base, "boundary", bad_b))["ok"])
	# NaN / inf rejection at the coercion layer.
	check("rej-nan", not ContractData._to_finite_float(NAN)[0])
	check("rej-inf", not ContractData._to_finite_float(INF)[0])
	check("rej-nan-int", not ContractData._to_int(NAN)[0])
	check("rej-frac-int", not ContractData._to_int(3.5)[0])
	check("rej-str-int", not ContractData._to_int("256")[0], "no silent string coercion")
	# Missing file fails loudly.
	check("missing-file", not ContractData.load_from_path("res://data/world/does_not_exist.json")["ok"])


func _raw() -> Dictionary:
	var parser := JSON.new()
	var err: int = parser.parse(FileAccess.get_file_as_string(PATH))
	assert(err == OK)
	return (parser.data as Dictionary).duplicate(true)


func _mut(base: Dictionary, key: String, value: Variant, erase := false) -> Dictionary:
	var c: Dictionary = base.duplicate(true)
	if erase:
		c.erase(key)
	else:
		c[key] = value
	return c
