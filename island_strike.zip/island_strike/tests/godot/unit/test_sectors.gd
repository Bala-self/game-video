extends "res://tests/godot/test_suite.gd"
## L2 sector tests (Prompt 01, §14–15). Formula + boundaries + census goldens.
## Census goldens (164/60/32/224) were computed by an INDEPENDENT Python
## implementation — agreement cross-validates both.

const Sector = preload("res://scripts/core/sector_service.gd")

const SIZE := 256
const GMIN := -2048.0
const COUNT := 16


func run_suite(_tree) -> void:
	suite_name = "sectors"
	# --- formula anchors (§14 list; scalar-double, exact) ---
	_check_sx("sx--2048", -2048.0, 0)
	_check_sx("sx--1792", -1792.0, 1, "exact boundary -> higher sector (left-closed)")
	_check_sx("sx--1536", -1536.0, 2)
	_check_sx("sx--1024", -1024.0, 4)
	_check_sx("sx--256", -256.0, 7)
	_check_sx("sx-0", 0.0, 8)
	_check_sx("sx-256", 256.0, 9)
	_check_sx("sx-512", 512.0, 10)
	_check_sx("sx-1024", 1024.0, 12)
	_check_sx("sx-1536", 1536.0, 14)
	_check_sx("sx-1792", 1792.0, 15)
	_check_sx("sx-2048", 2048.0, 16, "grid max is exclusive -> outside index 16")
	# --- epsilon offsets around boundaries (scalar) ---
	_check_sx("sx--1792.01", -1792.01, 0)
	_check_sx("sx--1791.99", -1791.99, 1)
	_check_sx("sx-2047.99", 2047.99, 15)
	_check_sx("sx--2048.01", -2048.01, -1, "below grid -> negative index (deterministic)")
	# --- Vector3 path (float32 storage; ±0.01 offsets clear the ~2e-4 quantum) ---
	check("v3-neg", Sector.sector_of_pos(Vector3(-2048, 0, -2048), SIZE, GMIN) == Vector2i(0, 0))
	check("v3-bound", Sector.sector_of_pos(Vector3(-1792, 5, -1792), SIZE, GMIN) == Vector2i(1, 1))
	check("v3-below", Sector.sector_of_pos(Vector3(-1792.01, 0, 0), SIZE, GMIN).x == 0)
	check("v3-above", Sector.sector_of_pos(Vector3(-1791.99, 0, 0), SIZE, GMIN).x == 1)
	check("v3-max", Sector.sector_of_pos(Vector3(2047.99, 0, 2047.99), SIZE, GMIN) == Vector2i(15, 15))
	# --- grid membership ---
	check("grid-00", Sector.is_in_grid(Vector2i(0, 0), COUNT))
	check("grid-1515", Sector.is_in_grid(Vector2i(15, 15), COUNT))
	check("grid-168", not Sector.is_in_grid(Vector2i(16, 8), COUNT))
	check("grid-neg", not Sector.is_in_grid(Vector2i(-1, 0), COUNT))
	# --- bounds / center / round-trips (§28) ---
	check("b88-min", Sector.sector_bounds_min(Vector2i(8, 8), SIZE, GMIN) == Vector2(0, 0))
	check("b88-max", Sector.sector_bounds_max(Vector2i(8, 8), SIZE, GMIN) == Vector2(256, 256))
	check("b88-ctr", Sector.sector_center(Vector2i(8, 8), SIZE, GMIN) == Vector2(128, 128))
	check("b00-min", Sector.sector_bounds_min(Vector2i(0, 0), SIZE, GMIN) == Vector2(-2048, -2048))
	for s in [Vector2i(0, 0), Vector2i(15, 15), Vector2i(0, 15), Vector2i(15, 0), Vector2i(7, 3)]:
		var c: Vector2 = Sector.sector_center(s, SIZE, GMIN)
		check("rt-center:%s" % str(s), Sector.sector_of_xz(c.x, c.y, SIZE, GMIN) == s)
	# --- id serialization ---
	check("id-str", Sector.sector_id_string(Vector2i(7, 9)) == "7,9")
	var p: Dictionary = Sector.parse_sector_id("7,9")
	check("id-parse", p["ok"] and p["sector"] == Vector2i(7, 9))
	check("id-bad1", not (Sector.parse_sector_id("a,b"))["ok"])
	check("id-bad2", not (Sector.parse_sector_id("7"))["ok"])
	check("id-bad3", not (Sector.parse_sector_id(""))["ok"])
	# --- neighbors / distance ---
	var n4: Array = Sector.neighbors_4(Vector2i(8, 8))
	check("n4-size", n4.size() == 4)
	check("n4-has", n4.has(Vector2i(9, 8)) and n4.has(Vector2i(7, 8)) and n4.has(Vector2i(8, 9)) and n4.has(Vector2i(8, 7)))
	check("n8-size", Sector.neighbors_8(Vector2i(8, 8)).size() == 8)
	check("cheby", Sector.sector_chebyshev(Vector2i(0, 0), Vector2i(3, 4)) == 4)
	check("dist-adj", Sector.sector_center_distance_m(Vector2i(8, 8), Vector2i(9, 8), SIZE, GMIN) == 256.0)
	# --- contains (left-closed) ---
	check("has-min", Sector.sector_contains(Vector2i(8, 8), 0.0, 0.0, SIZE, GMIN))
	check("has-inner", Sector.sector_contains(Vector2i(8, 8), 255.99, 255.99, SIZE, GMIN))
	check("has-not-max", not Sector.sector_contains(Vector2i(8, 8), 256.0, 0.0, SIZE, GMIN))
	check("has-not-neg", not Sector.sector_contains(Vector2i(8, 8), -0.1, 0.0, SIZE, GMIN))
	# --- sector vs island disc ---
	check("vsw-inner", Sector.sector_vs_world(Vector2i(8, 8), SIZE, GMIN, 2000.0) == Sector.SectorVsWorld.FULLY_INSIDE)
	check("vsw-corner", Sector.sector_vs_world(Vector2i(0, 0), SIZE, GMIN, 2000.0) == Sector.SectorVsWorld.FULLY_OUTSIDE)
	check("vsw-edge", Sector.sector_vs_world(Vector2i(15, 8), SIZE, GMIN, 2000.0) == Sector.SectorVsWorld.PARTIAL)


func _check_sx(test_name: String, x: float, expected: int, detail: String = "") -> void:
	var s: Vector2i = Sector.sector_of_xz(x, 0.0, SIZE, GMIN)
	var d := detail
	if d == "":
		d = "x=%s got sx=%d want %d" % [str(x), s.x, expected]
	check(test_name, s.x == expected, d)
