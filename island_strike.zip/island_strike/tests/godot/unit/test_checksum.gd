extends "res://tests/godot/test_suite.gd"
## L1 checksum tests: canonical form, escaping, determinism (§17).

const Checksum = preload("res://scripts/core/world_checksum.gd")


func run_suite(_tree) -> void:
	suite_name = "checksum"
	# Canonical form: sorted keys, tight separators.
	var c1: Dictionary = Checksum.canonical_json({"b": 2, "a": "x"})
	check("canon-basic", c1["ok"] and c1["text"] == "{\"a\":\"x\",\"b\":2}", str(c1.get("text", c1.get("error", ""))))
	var c2: Dictionary = Checksum.canonical_json({})
	check("canon-empty", c2["ok"] and c2["text"] == "{}")
	var c3: Dictionary = Checksum.canonical_json({"n": -25, "s": "E:+X,W:-X"})
	check("canon-neg", c3["ok"] and c3["text"] == "{\"n\":-25,\"s\":\"E:+X,W:-X\"}", str(c3.get("text", "")))
	# Escaping matches JSON string rules for the ASCII subset.
	var c4: Dictionary = Checksum.canonical_json({"q": "a\"b\\c\nd"})
	check("canon-escape", c4["ok"] and c4["text"] == "{\"q\":\"a\\\"b\\\\c\\nd\"}", str(c4.get("text", "")))
	# Loud failures (never silent re-encoding).
	check("rej-nonascii", not Checksum.canonical_json({"k": "caf\u00e9"})["ok"])
	check("rej-float", not Checksum.canonical_json({"k": 1.5})["ok"], "mm-ints only, no floats")
	check("rej-bool", not Checksum.canonical_json({"k": true})["ok"])
	check("rej-nonstr-key", not Checksum.canonical_json({7: 1})["ok"])
	# Determinism + sensitivity.
	var core := {"a": "x", "b": 2}
	var h1: Dictionary = Checksum.checksum_of_core(core)
	var h2: Dictionary = Checksum.checksum_of_core({"b": 2, "a": "x"})
	check("sum-ok", h1["ok"], str(h1.get("error", "")))
	check("sum-order-free", h1["checksum_hex"] == h2["checksum_hex"], "key order must not matter")
	check("sum-hexlen", (h1["checksum_hex"] as String).length() == 16)
	var h3: Dictionary = Checksum.checksum_of_core({"a": "x", "b": 3})
	check("sum-sensitive", h3["checksum_hex"] != h1["checksum_hex"])
	# Golden verification gate.
	check("verify-pass", Checksum.verify_against_golden(core, h1["checksum_hex"])["ok"])
	var bad: Dictionary = Checksum.verify_against_golden(core, "0000000000000000")
	check("verify-fail", not bad["ok"] and bad["actual"] == h1["checksum_hex"])
