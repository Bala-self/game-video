extends "res://tests/godot/test_suite.gd"
## L2 diagnostics + benchmark-service tests (§19, §21–22).

const Diagnostics = preload("res://scripts/core/diagnostics_service.gd")
const Benchmark = preload("res://scripts/core/benchmark_service.gd")


func run_suite(_tree) -> void:
	suite_name = "diag_bench"
	# --- diagnostics counters ---
	var d := Diagnostics.new()
	d.reset_counts()
	d.info(Diagnostics.CAT_TEST, "hello")
	d.warning(Diagnostics.CAT_TEST, "w1")
	d.error(Diagnostics.CAT_TEST, "e1")
	d.fatal(Diagnostics.CAT_TEST, "f1")
	check("counts", d.warning_count == 1 and d.error_count == 2 and d.fatal_count == 1,
		"w=%d e=%d f=%d" % [d.warning_count, d.error_count, d.fatal_count])
	# --- repeat suppression (200 rapid identical logs; robust to msec rollover) ---
	var d2 := Diagnostics.new()
	for i in range(200):
		d2.info(Diagnostics.CAT_TEST, "flood-probe")
	check("suppress", d2.suppressed_total() >= 50, "suppressed=%d" % d2.suppressed_total())
	# --- min_level gate ---
	var d3 := Diagnostics.new()
	d3.min_level = Diagnostics.Level.ERROR
	d3.info(Diagnostics.CAT_TEST, "invisible")
	check("min-level-no-crash", d3.error_count == 0)
	# --- benchmark stats ---
	var b := Benchmark.new()
	var s5: Dictionary = b.measure("noop5", func(): pass, 5)
	check("stats-n", s5["samples"] == 5 and s5["unit"] == "s" and s5["status"] == "measured")
	check("stats-order", float(s5["min"]) <= float(s5["mean"]) and float(s5["mean"]) <= float(s5["max"])
		and float(s5["min"]) <= float(s5["median"]) and float(s5["median"]) <= float(s5["max"]))
	check("stats-p95-null", s5["p95"] == null, "p95 forbidden when n<20")
	var s21: Dictionary = b.measure("noop21", func(): pass, 21)
	check("stats-p95-set", s21["p95"] != null and float(s21["min"]) <= float(s21["p95"])
		and float(s21["p95"]) <= float(s21["max"]))
	var once: Dictionary = b.measure_once("once", func(): return 7)
	check("once-flag", once.get("one_shot", false) and once["samples"] == 1)
	var una: Dictionary = Benchmark.unavailable("gpu_frame", "s", "no GPU counters headless")
	check("unavail", una["value"] == null and una["status"] == "unavailable" and una["reason"] != "")
	# --- memory source exists ---
	check("mem", Benchmark.memory_bytes() > 0, "static=%d" % Benchmark.memory_bytes())
	check("mem-peak", Benchmark.memory_peak_bytes() >= Benchmark.memory_bytes())
	# --- static stats_for correctness on known values ---
	var known: Dictionary = Benchmark.stats_for("k", "s", [3.0, 1.0, 2.0])
	check("known", known["min"] == 1.0 and known["max"] == 3.0 and known["median"] == 2.0
		and known["mean"] == 2.0, str(known))
