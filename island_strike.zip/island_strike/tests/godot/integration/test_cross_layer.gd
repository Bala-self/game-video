extends "res://tests/godot/test_suite.gd"
## L3 cross-layer (§53): disk contract == registry == checksum core == seeds.

const ContractData = preload("res://scripts/core/world_contract_data.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")
const Sector = preload("res://scripts/core/sector_service.gd")
const Seed = preload("res://scripts/core/seed_service.gd")
const Checksum = preload("res://scripts/core/world_checksum.gd")
const Units = preload("res://scripts/core/units.gd")

const PATH := "res://data/world/world_contract.json"


func run_suite(_tree) -> void:
	suite_name = "cross_layer"
	var loaded: Dictionary = ContractData.load_from_path(PATH)
	check("x-load", loaded["ok"])
	if not loaded["ok"]:
		return
	var reg := WorldRegistry.new()
	reg.initialize(loaded["data"])
	# Disk vs registry dump, field by field.
	var dump: Dictionary = reg.to_dump()
	var disk: Dictionary = loaded["data"]
	var all_same := true
	for key in disk.keys():
		var a: Variant = disk[key]
		var b: Variant = dump.get(key, null)
		var same := false
		if a is float and b is float:
			same = Units.approx_eq(float(a), float(b))
		else:
			same = str(a) == str(b)
		if not same:
			all_same = false
			check("x-field:" + str(key), false, "disk=%s reg=%s" % [str(a), str(b)])
	check("x-disk-eq-reg", all_same, "every disk field must match the live registry")
	# Derived values from the SAME radius (Rule 10: no duplicated constants).
	check("x-area", Units.approx_eq(reg.area_m2(), PI * reg.radius_m() * reg.radius_m()))
	check("x-circ", Units.approx_eq(reg.circumference_m(), TAU * reg.radius_m()))
	var aabb: AABB = reg.world_bounds_aabb()
	check("x-aabb", aabb.position == Vector3(-2000, -25, -2000)
		and aabb.size == Vector3(4000, 275, 4000), str(aabb))
	# Checksum core stable across independent builds.
	var c1: Dictionary = Checksum.core_from_registry(reg)
	var reg2 := WorldRegistry.new()
	reg2.initialize(loaded["data"])
	var c2: Dictionary = Checksum.core_from_registry(reg2)
	check("x-core-built", c1["ok"] and c2["ok"])
	var h1: Dictionary = Checksum.checksum_of_core(c1["core"])
	var h2: Dictionary = Checksum.checksum_of_core(c2["core"])
	check("x-sum-stable", h1["checksum_hex"] == h2["checksum_hex"], str(h1.get("checksum_hex", "?")))
	# Candidate status preserved (never silently promoted, §14).
	check("x-sector-candidate", reg.sector_status() == "candidate" and reg.sector_size_m() == 256)
	# Sector census goldens through the wired service (independent Python census).
	var svc := Sector.new(reg)
	var census: Dictionary = svc.grid_census()
	check("x-census-total", census["total"] == 256)
	check("x-census-in", census["fully_inside"] == 164, str(census))
	check("x-census-partial", census["partial"] == 60)
	check("x-census-out", census["fully_outside"] == 32)
	check("x-census-inter", census["intersecting"] == 224)
	# Seed samples deterministic through the registry's version+master.
	var s1: Dictionary = Seed.derive(reg.world_version(), reg.master_seed(), "sector", "7,9")
	var s2: Dictionary = Seed.derive(reg.world_version(), reg.master_seed(), "sector", "7,9")
	check("x-seed-stable", s1["ok"] and s1["seed_hex"] == s2["seed_hex"], str(s1.get("seed_hex", "?")))
