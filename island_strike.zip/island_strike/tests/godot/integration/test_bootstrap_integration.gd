extends "res://tests/godot/test_suite.gd"
## L3 integration: contract -> registry -> validation -> world shell (§24–28).
## Instantiates the real shell under the live root and verifies node truth.

const ContractData = preload("res://scripts/core/world_contract_data.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")
const Coord = preload("res://scripts/core/coordinate_service.gd")
const Diagnostics = preload("res://scripts/core/diagnostics_service.gd")
const Validation = preload("res://scripts/core/validation_service.gd")
const WorldShell = preload("res://scripts/world/world_shell.gd")

const PATH := "res://data/world/world_contract.json"
const GOLDEN := "res://data/world/contract_checksum.txt"


func run_suite(tree: SceneTree) -> void:
	suite_name = "bootstrap_integration"
	var diag := Diagnostics.new()
	var loaded: Dictionary = ContractData.load_from_path(PATH)
	check("boot-load", loaded["ok"], str(loaded.get("errors", [])))
	if not loaded["ok"]:
		return
	var reg := WorldRegistry.new()
	check("boot-reg-init", (reg.initialize(loaded["data"]))["ok"])
	var val := Validation.new(reg)
	var v1: Array = val.check_locked_values()
	var v1ok := true
	for c in v1:
		if not c["pass"]:
			v1ok = false
			check("boot-v1:" + c["name"], false, c["detail"])
	check("boot-v1-all", v1ok, "14 locked-value checks")
	check("boot-reg-frozen", not (reg.initialize(loaded["data"]))["ok"], "re-init must fail (frozen)")
	# Shell build under the live root.
	var shell := WorldShell.new()
	shell.name = "WorldShell"
	tree.root.add_child(shell)
	var built: Dictionary = shell.build(reg, diag)
	check("shell-build", built["ok"], str(built.get("errors", [])))
	if not built["ok"]:
		return
	var n: Dictionary = built["nodes"]
	# Node truth (§25–27).
	check("shell-origin", (n["origin_marker"] as Node3D).position == Vector3.ZERO)
	check("shell-north", (n["NorthMarker"] as Dictionary)["tip"] == Vector3(0, 0, -300.0),
		"north marker must sit at -Z")
	check("shell-east", (n["EastMarker"] as Dictionary)["tip"] == Vector3(300.0, 0, 0))
	check("shell-up", (n["UpMarker"] as Dictionary)["tip"] == Vector3(0, 300.0, 0))
	check("shell-ring-world", (n["Ring_world"] as Dictionary)["r"] == 2000.0)
	check("shell-ring-land", (n["Ring_land"] as Dictionary)["r"] == 1950.0)
	check("shell-ring-count", n.has("Ring_coast0") and n.has("Ring_beach0") and n.has("Ring_shore"))
	check("shell-camera", (n["camera"] as Camera3D).current, "debug camera is current")
	check("shell-grid", n.has("sector_grid"))
	check("shell-ocean", (n["ocean"] as Node3D).position.y == 0.0, "ocean plane at y=0")
	var overlay_text: String = (n["overlay"] as Label).text
	check("shell-overlay-r", overlay_text.contains("R=2000.0"), overlay_text.split("\n")[2])
	check("shell-overlay-seed", overlay_text.contains("seed=13371337"))
	check("shell-overlay-north", overlay_text.contains("NORTH=-Z"))
	# Runtime axis movement semantics on live nodes (§27).
	var probe := Node3D.new()
	tree.root.add_child(probe)
	probe.position = Coord.north_offset(Vector3.ZERO, 100.0)
	check("live-north", probe.position == Vector3(0, 0, -100.0))
	probe.position = Coord.east_offset(probe.position, 100.0)
	check("live-east", probe.position == Vector3(100.0, 0, -100.0))
	check("diag-clean", diag.error_count == 0 and diag.fatal_count == 0,
		"e=%d f=%d" % [diag.error_count, diag.fatal_count])
	# Golden-file presence (V3 runs in contract_check + full validation below).
	var v3: Array = val.check_checksum(GOLDEN)
	var v3ok := true
	for c in v3:
		if not c["pass"]:
			v3ok = false
	check("boot-v3", v3ok, "checksum vs committed golden")
	# Cleanup (explicit; no frame pump in runner).
	tree.root.remove_child(probe)
	probe.free()
	tree.root.remove_child(shell)
	shell.free()
