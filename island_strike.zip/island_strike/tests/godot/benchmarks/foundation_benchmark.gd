extends SceneTree
## Foundation micro-benchmarks (Prompt 01, §21–23). NON-GATING measurements.
## Writes res://reports/performance/foundation_baseline.json + environment.json.
## Usage: godot --headless --path . --script res://tests/godot/benchmarks/foundation_benchmark.gd

const ContractData = preload("res://scripts/core/world_contract_data.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")
const Coord = preload("res://scripts/core/coordinate_service.gd")
const Sector = preload("res://scripts/core/sector_service.gd")
const Seed = preload("res://scripts/core/seed_service.gd")
const Validation = preload("res://scripts/core/validation_service.gd")
const Diagnostics = preload("res://scripts/core/diagnostics_service.gd")
const Benchmark = preload("res://scripts/core/benchmark_service.gd")
const WorldShell = preload("res://scripts/world/world_shell.gd")

const CONTRACT_PATH := "res://data/world/world_contract.json"
const GOLDEN_PATH := "res://data/world/contract_checksum.txt"
const OUT_BASE := "res://reports/performance/foundation_baseline.json"
const OUT_ENV := "res://reports/performance/environment.json"

var _ran := false
var _reg: WorldRegistry
var _norm: Dictionary = {}
var _diag: Diagnostics
var _bench: Benchmark


func _process(_delta: float) -> bool:
	if _ran:
		return true
	_ran = true
	_diag = Diagnostics.new()
	_diag.min_level = Diagnostics.Level.WARNING
	_bench = Benchmark.new(_diag)
	var loaded: Dictionary = ContractData.load_from_path(CONTRACT_PATH)
	if not loaded["ok"]:
		print("BENCH_FAIL contract load: %s" % "; ".join(PackedStringArray(loaded["errors"])))
		quit(2)
		return true
	_norm = loaded["data"]
	_reg = WorldRegistry.new()
	_reg.initialize(_norm)

	var mem_before: int = Benchmark.memory_bytes()
	var results: Array = []
	# A. Node-based world shell build (real tree add + build + free).
	results.append(_bench.measure("A.shell_build", func(): _do_shell_build(), 5))
	# B. Script Resource loading (warm cache) + icon load one-shot.
	results.append(_bench.measure("B.script_resource_load", func(): _do_script_load(), 21))
	results.append(_bench.measure_once("B.icon_load", func(): return _do_icon_load()))
	# C. JSON contract file load + parse.
	results.append(_bench.measure("C.json_load_parse", func(): _do_json_load(), 21))
	# D. Registry initialization.
	results.append(_bench.measure("D.registry_init", func(): _do_registry_init(), 21))
	# E. Sector metadata: full census + 5000-conversion batch.
	results.append(_bench.measure("E.sector_census", func(): _do_census(), 11))
	results.append(_bench.measure_once("E.sector_batch_5000", func(): return _do_sector_batch(5000)))
	# F. Seed derivation: single + 1000-batch.
	results.append(_bench.measure("F.seed_derive", func(): _do_seed_one(), 21))
	results.append(_bench.measure_once("F.seed_batch_1000", func(): return _do_seed_batch(1000)))
	# G. Full validation run (V1+V2+V3).
	results.append(_bench.measure("G.validation_run", func(): _do_validation(), 11))
	# H. Diagnostics: 100 log lines.
	results.append(_bench.measure("H.diagnostics_100", func(): _do_logs(100), 11))
	# Memory + unavailable metrics (§22 honesty).
	var mem_after: int = Benchmark.memory_bytes()
	results.append(Benchmark.unavailable("gpu_frame_time", "s",
		"no GPU counters under HEADLESS_DUMMY driver", {"mode": "HEADLESS_DUMMY"}))
	results.append(Benchmark.unavailable("render_draw_calls", "count",
		"dummy renderer reports no draw statistics", {"mode": "HEADLESS_DUMMY"}))

	var env: Dictionary = _environment()
	var report := {
		"generated_at": Benchmark.utc_stamp(),
		"mode": "HEADLESS_DUMMY",
		"gating": "NON-GATING (Prompt 01 baseline; final budgets lock at Prompt 07)",
		"environment": env,
		"memory": {"before_bytes": mem_before, "after_bytes": mem_after,
			"peak_bytes": Benchmark.memory_peak_bytes(), "source": "OS.get_static_memory_*"},
		"results": results,
	}
	var w1: Dictionary = _bench.write_json(OUT_BASE, report)
	var w2: Dictionary = _bench.write_json(OUT_ENV, env)
	if not w1["ok"] or not w2["ok"]:
		print("BENCH_FAIL write: %s %s" % [w1.get("error", ""), w2.get("error", "")])
		quit(2)
		return true
	print("BENCH_OK %s (%d records)" % [OUT_BASE, results.size()])
	quit(0)
	return true


func _environment() -> Dictionary:
	var vi: Dictionary = Engine.get_version_info()
	var arch := "unknown"
	if OS.has_feature("x86_64"):
		arch = "x86_64"
	elif OS.has_feature("arm64"):
		arch = "arm64"
	elif OS.has_feature("x86_32"):
		arch = "x86_32"
	return {
		"engine_version": "%s.%s.%s.%s (%s)" % [vi["major"], vi["minor"], vi["patch"], vi["status"], vi.get("build", "?")],
		"os": OS.get_name(),
		"arch": arch,
		"cpu_count": OS.get_processor_count(),
		"cpu_name": OS.get_processor_name(),
		"renderer_method": ProjectSettings.get_setting("rendering/renderer/rendering_method", "default"),
		"display_server": DisplayServer.get_name(),
		"mode": "HEADLESS_DUMMY",
		"world_version": _reg.world_version(),
		"contract_version": _reg.contract_version(),
	}


func _do_shell_build() -> void:
	var shell := WorldShell.new()
	root.add_child(shell)
	shell.build(_reg, _diag)
	root.remove_child(shell)
	shell.free()


func _do_script_load() -> void:
	var r: Resource = load("res://scripts/core/sector_service.gd")
	assert(r != null)


func _do_icon_load() -> int:
	var tex: Texture2D = load("res://icon.svg")
	return 1 if tex != null else 0


func _do_json_load() -> void:
	var text: String = FileAccess.get_file_as_string(CONTRACT_PATH)
	var parser := JSON.new()
	assert(parser.parse(text) == OK)


func _do_registry_init() -> void:
	var r := WorldRegistry.new()
	assert((r.initialize(_norm))["ok"])


func _do_census() -> void:
	var svc := Sector.new(_reg)
	svc.grid_census()


func _do_sector_batch(n: int) -> int:
	var acc := 0
	for i in range(n):
		var x: float = -2048.0 + float(i % 4096)
		var z: float = -2048.0 + float((i * 7) % 4096)
		var s: Vector2i = Sector.sector_of_xz(x, z, 256, -2048.0)
		acc += s.x + s.y
	return acc


func _do_seed_one() -> void:
	Seed.derive("0.1.0", 13371337, "sector", "7,9")


func _do_seed_batch(n: int) -> int:
	var acc := 0
	for i in range(n):
		var r: Dictionary = Seed.derive("0.1.0", 13371337, "sector", "%d,%d" % [i % 16, (i / 16) % 16])
		acc += int(r["seed_i64"]) & 0xFF
	return acc


func _do_validation() -> void:
	var v := Validation.new(_reg)
	v.run_all(CONTRACT_PATH, GOLDEN_PATH)


func _do_logs(n: int) -> void:
	var d := Diagnostics.new()
	d.min_level = Diagnostics.Level.WARNING
	for i in range(n):
		d.warning(Diagnostics.CAT_TEST, "bench-probe-%d" % i)
