# NPC NAVIGATION (P09) — LOCKED

Generator: `tools/npc_gen.py` → `data/derived/npc_navigation_manifest.json`
Checksum: `npc_navigation_checksum = 3f9a234fcffe672a`
Census: 127 areas · 1087 nodes · 2348 edges · 34 crossings · 26 zones.

## 1. Representation (P09-D1)

Derived hybrid, no engine nav stack (none exists in-repo to extend):

- **AREAS**: 127 walkable polygons from P06 open spaces with
  `navigation_policy == walkable`, plus arrival envelopes and beach
  access. Each area records samples/coverage/blocked counts as evidence.
- **NODES** (1087): AREA_CENTROID (126), ENTRY (403, from P06
  nav-handoff rows), LANDMARK (33 of 34 `at` rows; 1 dropped, recorded),
  AREA_MID (450), ARRIVAL (7), CROSSING_END (68).
- **EDGES** (2348, explicit typed links only): AREA_ADJACENCY,
  BUILDING_ENTRY, CROSSING, SECTOR_PORTAL, plus internal area/crossing
  scaffolding. No implicit road crossing: roads are blockers (§23).
- Straight-line movement inside areas; corridor follow + validated local
  avoidance on edges.

## 2. Walkability evidence

Every node carries `slope_grade ≤ max_slope_grade` (0.25) and a region
outside `blocked_regions`. Generator drops violating candidates and
records counts (`dropped`: entry 0, landmark 1, arrival 0, area 1).
Water: river polylines clear nodes/edges by `river_clear` (32 m);
beach_access areas are the only water-adjacent walkables.

## 3. Structures (P09-D2)

P05 carries no walkway/sidewalk evidence for BC-01, BC-02, or the tunnel
bore, so the generator emits NO pedestrian links onto those structures
and the navigation suite asserts zero crossings on their station ranges
and zero tunnel-lane crossings. If P05 ever gains walkway evidence, the
generator accepts it through the same typed-link path; until then the
rejection is tested, not assumed.

## 4. Crossings

34 crossings after (edge, station) dedupe (72 parallel-lane duplicates
removed, 13 bad-endpoint + 88 unattached candidates recorded, not
silently dropped). Rule: speed ≤ 50 km/h, station spacing 120 m,
link radius 80 m. Crossing decision (P08 never bypassed): the sim reads
live P08 vehicle snapshots; commit iff min vehicle time-to-arrival over
the corridor exceeds width/cross_speed + 2.0 s margin; where a P08
signal governs the crossed edge, conflicting movements must be RED
(signal_hook). WAIT / COMMIT / CANCEL only; timeouts recover, never trap.

## 5. Pathfinding service

A* over the graph with sector READY gating (no routes through UNLOADED
sectors), deterministic tie-breaks, path cache (2000 entries, LRU-clear
counted as `path_invalidated`), budget 8 queries/tick with observable
`path_deferred`. Stale paths are voided at request time (P09-D14): a
deferred repath holds position, never executes the old route.

## 6. Tiers of navigation fidelity

T3 full movement + crossing protocol; T2 simplified stepping (2-tick
cadence); T1 proxy integration along cached routes; T0 abstract counts.
Tier radii (boundaries): T3 < 60 m < T2 < 150 m < T1 < 400 m < T0.
