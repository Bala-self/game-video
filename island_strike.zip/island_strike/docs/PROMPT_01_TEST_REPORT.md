# ISLAND STRIKE — PROMPT 01 TEST REPORT (§55)

Every number below comes from actual execution on 2026-09-20 (Godot 4.7.2, Linux x86_64).

## Suite totals

| Suite | Passed | Failed | Skipped | Expected-fail |
|---|---:|---:|---:|---:|
| Prompt 00 math validator (53 checks) | 53 | 0 | 0 | 0 |
| Foundation static (78 checks) | 78 | 0 | 0 | 0 |
| In-engine unit+integration (8 suites) | 207 | 0 | 0 | 0 |
| Cross-layer GDScript↔Python (31) | 31 | 0 | 0 | 0 |
| Failure injection (13 mutants) | 13 detected | 0 missed | 0 | 0 |
| Reproducibility (7) | 7 | 0 | 0 | 0 |
| Log audits (import, smoke) | 2/2 clean | 0 | 0 | 0 |
| Macro benchmarks (10) | 10 | 0 | 0 | 0 |
| Parse checks (24 scripts) | 24 | 0 | 0 | 0 |

## Runtime smoke

Main scene `--quit-after 30`: exit 0. Lifecycle BOOT→…→SHUTDOWN logged;
validation 41/41 at boot; shell 17 children; stderr EMPTY (0 lines).
Boot 8.19–9.86 ms across 5 cold runs.

## Headless results

All engine execution headless (dummy driver). 30+ invocations, zero flakes.
`--script` SceneTree runner works; user args after `--` work; exit codes
0/1/2 verified on pass/fail/contract-fail paths; exit 3 path reviewed
(bootstrap fail-fast; not triggered since contract is healthy — triggering it
would require corrupting the repo, covered instead by contract_check exit-2
mutants + design review).

## Determinism results

Two independent runs: canonical bytes, checksum `ad20e1fde64f051e`, registry
dump, 3 seed samples, sector census — all IDENTICAL (timestamps stripped by
design). GDScript↔Python canonical strings byte-identical; FNV spec vectors
pass in both implementations.

## Failure-injection results

13/13 mutants detected with exit 2 + CONTRACT_FAIL marker: negative/zero
radius, diameter mismatch, wrong axes/origin, final status, fractional seed,
locked-radius-2500 (shape-valid, value-wrong → V1), locked-seed-999,
locked-sector-128, unordered rings, missing file. Repo byte-identical after
(all mutants in /tmp).

## Recovery probes (§39)

- Unwritable dump path → `CONTRACT_FAIL dump-write` + clear error, exit 2 (loud, no crash).
- Missing golden + `--allow-missing-golden` → documented NOTE + CONTRACT_OK (explicit degraded path).
- No optional resource dependencies exist in the foundation (all diagnostic
  visuals procedural) — nothing to silently degrade.

## Issues found during testing (all fixed, none outstanding)

1. `ISDiagnostics.log()` collided with built-in global `log()` → parse error.
   Fixed: renamed to `record()`. Re-verified: clean import + 24/24 parse.
2. 5 initial engine-test failures, all TEST bugs (Vector3.z vs .y mixup;
   float32 Vector2 tolerance). Fixed with derived tolerances; 207/207 green.
   Service code was correct in all 5 cases (failures proved the tests execute).
3. CI exit-code masking by shell pipes (grep `$?`). Fixed: redirect-to-file
   pattern in run_all_tests.sh; exit codes re-verified end to end.
4. Parallel same-file edits raced (one lost). Fixed by sequential edit; noted
   as process lesson, no code impact.

## Not run (honest accounting)

- Graphical window smoke: ENVIRONMENT-LIMITED (no display/GPU; x11 attempt
  exits 1 "X11 Display is not available"). Structural scene-tree verification
  (node positions, camera, overlay) executed instead — 22/22 integration
  checks green.
- Bootstrap exit-3 path: not live-triggered (see Headless note above).
