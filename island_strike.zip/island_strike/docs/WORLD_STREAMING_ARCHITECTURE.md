# WORLD STREAMING ARCHITECTURE (P07)

One authoritative streaming owner: `tools/streaming_sim.py`.

## Components

```
WorldSectorRegistry    sector identity + bounds (from manifest)
SectorManifestService  content references per sector
SectorDependencyGraph  layer chain + STRUCT units, cycle-checked
StreamingManager       global orchestration, contexts, pins
StreamingScheduler     band queues + aging + dedup + cancel + budgets
SectorLoader           cache -> payload assembly (real source slices)
SectorActivator        dependency-ordered, frame-budgeted activation
SectorDeactivator      reverse-order release -> cache
SectorCache            versioned memory cache, DISTANCE eviction
LODPolicyManager       thresholds + hysteresis + importance
StreamingBudgetManager caps (ops, ms, entries, backlog)
StreamingDiagnostics   bounded §93 event log + HUD snapshot
StreamingProfiler      per-op timings (mean/median/p95/max)
StreamingValidator     tools/validate_p07.py (9 suites)
```

No per-domain streaming managers: terrain/roads/structures/
buildings all flow through this scheduler.

## Lifecycle

UNLOADED → REQUESTED → QUEUED → LOADING → LOADED → ACTIVATING →
ACTIVE → DEACTIVATING → UNLOADING → CACHED → (QUEUED | UNLOADED).
FAILED on loader/activator error; CANCELLED on stale/dup-cancel;
retry via FAILED → QUEUED. FAILED → ACTIVE is impossible
(transition table enforced; inject-tested).

## Activation order (dependency-verified)

TERRAIN → ROAD → STRUCTURE → BUILDING → DETAIL within a sector;
STRUCT units span sectors and activate once (refcounted users).
Deactivation reverses. A building is never exposed before its road
+ structure foundation is active.

## Requests

Deterministic ids (RQ-%06d), bands CRITICAL/HIGH/NORMAL/BACKGROUND,
reasons PLAYER/ROUTE/PREFETCH/MISSION/STRUCTURE/DEBUG/CACHE_RESTORE.
Duplicates merge (priority raised, single load). Stale requests
(left the want-set) cancel before dispatch. Aging promotes
long-waiting low-band requests (300 ticks).

## Prefetch / unload / pins

Ahead-cone prefetch within radius 2, budgeted (2 issues/tick, cap 8
sectors); efficiency tracked (requested/used/wasted). Unload needs:
outside radius 3 + zero pins + no dependency. Pins carry owner,
reason, created tick, optional expiry; temporary pins expire.

## Determinism

Tick = 1/60 s simulated; no wall-clock or unseeded randomness in
logic (perf_counter measures cost only). Repeats are bit-identical
on snapshot core; 8 golden contexts pinned (center/city/port/
highland/resort/coast/fast/teleport).
