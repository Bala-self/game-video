# P06 HANDOFF — NAVIGATION

Consumer file: `data/derived/p06_handoff_nav.json` (403 rows, no orphans).

Each row: building → entrance point → `connects_to` road edge →
parcel access type (DIRECT / LANE_VIA / CAMPUS / DRIVEWAY) →
optional service side. Arrival zones (`places.json` arrivals, 7)
give approach road + entry point + heading + 80 m envelope for
spawn/drive-in logic. Open-space records carry
`navigation_policy`: walkable / operational / restricted /
no_access (runway safety).

Guarantees (validated):

- every entrance is on land, reservation-clear, and its edge exists;
- entrance→road paths are hard-clear for their first 60% (smoke);
- arrival entries sit on the approach-road surface;
- no entrance faces road center / water / cliff (frontage-tested).

Future work (not P06): sidewalk graph synthesis, lane-to-lot
driveway splines, trailhead links for BEACH_PATH parcels.
