# PROMPT 09 — NPC + PEDESTRIAN + NAVIGATION + PERCEPTION + AI REPORT — LOCKED

Result: **COMPLETE — 12/12 suites, 103/103 checks, NPC_OK, rebuild ×2.**

## 1. Pins (locked)

| Artifact | Checksum |
|----------|----------|
| navigation | `3f9a234fcffe672a` |
| population | `fd1f5bdeeb7e95e7` |
| policy | `5b59d290bb0de76b` |
| behavior | `0f3fde2cdb1da2c8` |
| perception | `71e6e20d666e14df` |

Engine `npc_check.gd` independently recomputes nav/pop/pol → NPC_OK.

## 2. Census

127 areas · 1087 nodes · 2348 edges · 34 crossings · 26 zones ·
1263 target population · 9 archetypes · 18 zone classes.

## 3. Suites (tools/validate_npc.py)

| Suite | Checks | Verdict |
|-------|--------|---------|
| static | 26 | pins, schema, machines-as-data, engine parse |
| cross | 13 | single-truth refs, provenance |
| navigation | 11 | reachability, structures reject, budgets |
| perception | 8 | 512-ray law, senses, witness |
| behavior | 5 | machines, destinations, illegal-recorded |
| population | 6 | spawn §10, despawn, tiers |
| inject | 12 | mutants rejected with reasons |
| reproduce | 5 | identical, wall-independent, seed-sensitive |
| smoke | 2 | 12 scenarios + gameplay 28/28 |
| perf | 8 | ladder, 4 gates, T3 crowd |
| regress | 2 | 7 goldens + upstream pins |
| stress | 5 | 4 hotspots + 2000-tick long run |

## 4. Budgets & gates

Path 8/tick · perception 64/tick · LOS ≤512/tick (8/scan) · hearing
16/tick. Gates @100: ai 4.0 (1.79) · nav 0.5 (0.19) · perc 0.5 (0.12);
memory 256 MB @1000 (71). P08-D12 CPU-time method throughout.

## 5. Determinism

Fixed-step 10 Hz, six seed streams, canonical records. Replay suite
proves identical event streams, wall-timing independence, and seed
sensitivity. Rebuild ×2 reproduces all five pins exactly.

## 6. Scope kept

Missions/economy/police/combat/social ship as typed tested hooks
(`P09_HANDOFF_MISSIONS.md`) — no logic, no TODOs. P09-D2 structures
reject keeps bridge/tunnel honest (smoke steps 14/16 evidence it).

## 7. Bugs found by never weakening tests (all fixed at source)

1. Area-less zones had no spawns → ENTRY fallback (D3).
2. 72 duplicate crossings → (edge, station) dedupe (D4).
3. Incoherent LOS budget → 512-ray construction law (D5).
4. Same-goal cache-hit test → distinct-goal path-budget proof.
5. Stale path executed after deferred repath → void-on-request (D14).
6. Same-tick-only hearing starved → windowed delivery (D15).
7. Phantom beh self-transition → arrival-confirms-idle (D16).
8. Perf measured stuck NPCs → node-anchored, N-held, arrivals-proven.
9. pol checksum missed performance gates → pol_core extended.
10. Parallel same-file edits raced → sequential editing discipline.

## 8. Absolute rules

P00–P08 untouched (8 sha pins) · checksums verified in Python AND
GDScript · no second truth (cross 13/13) · P07 never bypassed ·
deterministic · no teleport (`repairs_teleport` = 0 everywhere) ·
no unloaded-data AI (READY gating + T1-max) · pins owner+expiry,
zero leaks · provenance on all derived artifacts · CPU-time
comparability documented.

## 9. Rebuild evidence

Two clean rebuilds (`npc_*` + `reports/p09` removed, regen, full
12-suite rerun): all five pins identical, 103/103 both times.

## 10. Unresolved / TODO / broken: ZERO.
