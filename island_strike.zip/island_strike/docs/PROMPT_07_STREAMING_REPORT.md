# PROMPT 07 STREAMING REPORT

PROMPT: 07
TITLE: MASTER WORLD STREAMING + SECTOR ARCHITECTURE + LOD + PERFORMANCE
STATUS: LOCKED
UPSTREAM: P01 / P02 / P03 / P04 / P05 / P06 (all PASS, checksums pinned)

## SECTOR CANDIDATES

128 / 256 / 512 (p07bench1, identical world state + paths, 2 reps).

## CHOSEN SECTOR

256 m — SELECTED FOR THIS PROJECT. Balanced mem/frame/load/churn
(5.5 MB / 69 ms / 8.3 ms / 71 / 101 on crossing) with 1:1 alignment
to the P05/P06 256 m batch grid. 128 rejected (2.8× churn, 2×
requests; equal-coverage R=2 worse on all axes). 512 rejected
(hotspot 102 bld, load p95 34 ms, fmax 193 ms, 2× residents).
Evidence: reports/p07_size_compare.json + docs/P07_DECISIONS.md.

## WORLD GRID

16×16 = 256 sectors; 224 intersecting (164 inside / 60 partial /
32 outside; P01 census reproduced exactly).

## MANIFEST

`data/derived/world_stream_manifest.json` = `3970e8e7e96b4e17`
(references only; sources win disagreements).

## STREAM GRAPH

`fd1574c71d359143` — 1269 edges, 251 STRUCT units, acyclic
(validator + engine Kahn check).

## STATE MACHINE

12 states, enforced transition table; FAILED → ACTIVE impossible;
retry path validated. Result: PASS (inject 21/21).

## SCHEDULER

Band queues + aging + dedup + stale-cancel + budgets; starvation
test (300 BACKGROUND + CRITICAL) and flood-drain pass.

## PREFETCH

Ahead-cone, radius 2, 2 issues/tick, cap 8; requested/used/wasted
tracked (ring: 44/35/0 class of efficiency).

## UNLOAD

Radius 3 + zero pins + no dependency; churn counted; hysteresis
band verified.

## PINNING

owner/reason/expiry pins; 50-cycle leak test clean; stress clean.

## CACHE

DISTANCE eviction (measured best: 0.228 vs 0.214 vs 0.124
pressured); versioned keys; corruption + stale-version rejection
tested; peak 4.169 MB.

## LOD

Policy `b8df59a10ec1f39d`; FULL/SIMPLIFIED/PROXY/UNLOADED with
×1.15 hysteresis; importance shifts; route-pinned roads; shared
proxies (no 403 far meshes); oscillation-tested.

## MEMORY

Baseline/city 2.0 MB; steady active+cache ~5.5 MB peak traversal;
hotspot 2.2 MB; empty sector 6.4 KB; long-run bounded (ring ×3,
no leaks). GPU: NULL (headless, no approximation).

## CPU

Steady p95 5.2 ms; traversal p95 4.5 ms; load p95 15.4 ms (hotspot
inclusive); activation 0.4 ms; manifest query 0.8 ms; LOD 2.8 ms.

## SPIKES

Genuine worst 61.3 ms (multi-sector activation); 2 spikes/traversal
at 50 ms threshold. Instrumentation spikes (memory sampler) were
found, attributed, and moved outside the frame clock (P07-D4).

## TRAVERSALS

Ring full-loop (coverage: every ring sector ACTIVE, no failures),
north-south, east-west+return, coastal (≥3 coast sectors stream),
fast 40 m/s (all wanted available), teleports (dest-first,
bounded). All PASS (smoke 8/8).

## LONG-RUN

Ring ×3 + pin ×50 + flood + teleport storm: memory bounded, no
pins left, queues drained, no stuck sectors, no dup objects.
PASS (stress 10/10).

## STRESS

See LONG-RUN + hotspot activation + empty-sector cost. PASS.

## FAILURE INJECTION

18 fixtures (bad size/bounds/dup/orphan/cycle/illegal/dup/stale/
corrupt/version/LOD/flicker/budget/starvation/pinleak/dupobj/
retry/no-jump). Every mutation fails the correct layer. PASS.

## ENGINE

Godot 4.7.2 headless: STREAMING_OK, semantic `e5f12b8d` both
sides, 6 goldens replayed, deps acyclic, 12-state table mirrored.
No visual inspection claimed (no display).

## REGRESSION

P01–P05 run_all_tests green; P06 golden stable; P07 golden stable.
PASS (regress 3/3).

## CHECKSUMS

- manifest `3970e8e7e96b4e17`, graph `fd1574c71d359143`
- semantic32 `e5f12b8d` == `e5f12b8d`
- lod `b8df59a10ec1f39d`, baseline `6586663644bed80f`
- P06 aggregate `a808c338fc8ae499`; upstream pins unchanged

## TARGET HARDWARE

PROVISIONAL (current-environment evidence only; no certification).

## ISSUES FOUND / FIXED

1. P06 quirk: 2 block centers outside corner quads → geometric
   primary fallback (manifest-side; upstream untouched).
2. LOD gating gap for terrain/structure objects → state-gated.
3. Region sampling missed sector centers (3 sectors) → center probe.
4. Memory sampler polluted frame clock (131/132 spikes) → moved out.
5. Golden tuple/list serialization → JSON-native lists.
6. Spike counts in determinism scope → excluded (timing ≠ state).

## KNOWN LIMITATIONS

- CPU-sim budgets; engine runtime must re-verify on target hardware.
- Radii tuned for 256 m; resizing needs re-lock + re-bench.
- Cache value concentrates on revisit paths (linear ~0 by design).
- LOD thresholds engineering-selected, oscillation-validated.

## DEFERRED (owner: future prompt)

Traffic/pedestrians/NPC/nav-AI/economy/missions/weather/day-night/
vegetation; final save/load; full collision; interior shells;
sidewalk graph; mission logic (pin API ready).

## FILES

Created: sector_contract(+schema), sector_math/manifest/sim/bench/
report tools, validate_p07, streaming_check.gd, world_stream_
manifest, lod_policy, candidates, size/cache compares, goldens,
gates, summary, baseline, matrix, 8 docs, clean-rebuild script.
Modified: none outside P07 ownership.

## GIT

commit (see log). Worktree: P07 files committed; P02–P05 untracked
work + perf baseline side-effects left to owners.

## NEXT

08.
