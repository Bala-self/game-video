# ISLAND STRIKE — WORLD RESEARCH MATRIX

| Field | Value |
|---|---|
| Document | `WORLD_REFERENCE_MATRIX.md` |
| Status | **LOCKED (Prompt 00)** — revision `1.0.0` |
| Date | 2026-09-20 |
| Inputs | `AAA_OPEN_WORLD_REFERENCE_DATABASE.md` (18 records) |
| Output | feeds `ISLAND_STRIKE_WORLD_DESIGN_RULES.md` (DR-01…DR-20) |

Each row: research question → evidence (with confidence) → Strike rule.
`V` = VERIFIED, `R` = REPORTED/CLAIMED, `U` = UNKNOWN.

---

## TERRAIN

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| T-01 | How is elevation structured on islands? | Tsushima: mountain spine + coastal flats (obs.); Far Cry 6: volcanic/mountain interior (obs.); Altis: scrub hills + flats (dev data) | V-obs | North massif + rolling interior + coastal lowlands; peak cap 220 m (DR-11) |
| T-02 | What elevation range stays playable? | RDR2/GTA V: ~200–800 m peaks w/ roads switchbacking (obs.); Death Stranding: steep = puzzle | V-obs | Cap 220 m; avg coast→peak grade <15%; road grades 6–12% by class |
| T-03 | How do flat gameplay pads coexist with relief? | Altis airfields on flats; FH5 festival on plain (obs.) | V-obs | Airfield/runway flat ≤1%/800 m reserved on south plains pre-terrain |
| T-04 | Rivers/lakes on small islands? | Tsushima streams; Mafia lake; Yara rivers (obs.) | V-obs | 1 river + 1 lake + wetlands ≤0.25 km²; no accidental closed basins |
| T-05 | Exact AAA heightfield resolutions? | Not published per-title | U | UNKNOWN — Prompt 02 benchmarks 1 m/2 m/4 m vertex pitch on target HW |

## COAST

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| C-01 | How is shoreline varied? | GTA V: beach/cliff/marina/port; Odyssey: cliffs+ports; Yara: mangrove+beach (obs.) | V-obs | 9 beach classes, ≥150 m runs, full-attribute segments (DR-06) |
| C-02 | Beach width range? | Tourist builds wide (est. 50–100 m obs.); cliffs ~0 m | R | B2 band 1850–1950 m; class widths 0–100 m per class table |
| C-03 | Ports vs natural shore mix? | GTA V ports + marinas + wild shore; Yara docks (obs.) | V-obs | 1 industrial port + 1 marina + urban waterfront + wild coves |
| C-04 | Waterline rendering technique? | Per-title shaders proprietary | U | UNKNOWN — depth-textured shore foam keyed to heightfield (Prompt 03) |
| C-05 | Coastal road setback? | GTA V/FH5 coastal highways sit above wash zone (obs.) | V-obs | Ring highway at r≈1750 (B1), never inside B2 beach band |

## ROADS

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| R-01 | How is traffic connectivity structured? | GTA V ring+radial freeways; FH5 hub-ring-connector (obs./official road miles) | V-obs | Ring + 3 radials + collectors + trails (DR-03) |
| R-02 | Road density by context? | Urban grids dense; rural sparse; FH5 ~500 km roads/107 km² ≈ 4.7 km/km² overall (R) | R | 18–24 urban … 1–2 forest km/km² (Contract §10) |
| R-03 | Grade/corner grammar for fun driving? | FH5 corner banking; GTA Chiliad switchbacks (obs.) | V-obs | Grade caps by class; switchback template for highland arterial |
| R-04 | Bridges/tunnels as gameplay? | WD2 bay bridges; FH5 Guanajuato tunnels; MGSV bridges (obs.) | V-obs | ≥2 bridge/underpass structures; bridge = mission chokepoint (DR-12) |
| R-05 | Exact AAA road-graph formats? | Proprietary | U | UNKNOWN — Godot Resource graph + JSON interchange (Prompt 04) |

## URBAN

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| U-01 | How does density change across districts? | Sleeping Dogs 4 distinct districts/8 km²; Night City districts; Legion boroughs (obs.) | V-obs | Urban core 350–600 bldg/km² → suburban 150–280 → rural 8–20 |
| U-02 | Building height classes? | Night City towers; LS downtown; Esperanza low-rise (obs.) | V-obs | 5 height classes: shack(1F)…tower(20F+); towers only R1 |
| U-03 | Block structure? | Grids + arterials + alleys (obs. all urban refs) | V-obs | Superblock 80–120 m; alley mesh in old town; plaza nodes at L2s |
| U-04 | Interiors scope? | AAA mostly shells + mission interiors (obs.) | V-obs | Shells + mission interiors only (scope exclusion locked) |
| U-05 | Exact building counts/polycounts? | Not published | U | UNKNOWN — Prompt 05 budgets from instancing benchmarks |

## RURAL

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| RU-01 | How are sparse regions structured? | RDR2 homesteads+ranches; SA farms; Yara plantations (obs.) | V-obs | Farmsteads on 200–400 m grid; villages at collector junctions |
| RU-02 | Forest gameplay role? | RDR2 hunting; Tsushima bamboo/duels; Days Gone horde cover (obs.) | V-obs | Hunting/stealth/off-road; lumber camp POI; trail-only access |
| RU-03 | Agriculture as cover/gameplay? | SA fields; Yara tobacco; RDR2 ranches (obs.) | V-obs | Crop rows as stealth cover; harvest-season visual variant |
| RU-04 | Village spacing? | RDR2 towns ~2–4 km apart (obs. est.) | R | 2–3 villages, ≥1.2 km apart, each ≥1 L3 + shop + mission hook |

## NPC / POPULATION

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| N-01 | How is ambient life distributed? | Density follows district/time/weather in all urban refs (obs.) | V-obs | Region profile × time × weather; caps 220 active peds (DR-13) |
| N-02 | Civilian behavior depth? | RDR2 routines; WD crowds; Legion jobs (obs.) | V-obs | 3-tier: ambient / routine / interactive; routines only R1–R2 |
| N-03 | Wildlife/ecology? | RDR2 ecology; Tsushima fauna; FH5 none (obs.) | V-obs | Forest/coast critters tier-1 ambient; no hunting sim at baseline |
| N-04 | Exact ped counts/AI tick rates? | Proprietary | U | UNKNOWN — benchmark crowd LOD in Prompt 08 |

## VEHICLES / TRAFFIC

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| V-01 | How does traversal shape layout? | FH5 roads-first; Days Gone fuel stops; DS terrain-cost (obs.) | V-obs | Fuel/repair nodes on radials; routes cost-tested (DR-11/16) |
| V-02 | Traffic density model? | GTA/WD density by road class + time (obs.) | V-obs | Spawn rate ∝ road class × hour curve; cap 90 active |
| V-03 | Vehicle classes? | Cars/bikes/trucks/boats/aircraft standard (obs.) | V-obs | 6 classes: sedan/SUV/truck/bike/boat/prop-plane(1) |
| V-04 | Parking/prop vehicles? | Parked rows in all urban refs (obs.) | V-obs | ≤400 parked/prop; district-authored, streamed |

## WATER

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| W-01 | Coast/water gameplay integration? | GTA boats/subs; AC naval; JC water stunts (obs.) | V-obs | Swim+boat+3 boat POIs; depth-gated (DR-10) |
| W-02 | Ports/marinas function? | Docks as mission hubs + spawns (obs.) | V-obs | Port = cargo missions; marina = boat spawn + fuel |
| W-03 | Rivers as obstacles? | DS rivers; RDR2 crossings (obs.) | V-obs | 1 ford + 2 bridges on river; current push on player |
| W-04 | Wave/buoyancy tech specifics? | Proprietary per title | U | UNKNOWN — simple Gerstner visual + volume physics (Prompt 03) |

## LAW / SECURITY

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| L-01 | Response/escalation model? | GTA wanted stars; MGSV alerts; FC restricted zones (obs.) | V-obs | 4-tier security geography + escalation ladder (DR-17) |
| L-02 | Patrol/ checkpoint grammar? | FC checkpoints; MGSV posts; Odyssey forts (obs.) | V-obs | Outpost grammar + checkpoint template (DR-08) |
| L-03 | Exact AI perception numbers? | Proprietary | U | UNKNOWN — authored + playtested (Prompt 08) |

## WEATHER / DAY-NIGHT

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| WN-01 | Weather scope? | Rain/fog/storm standard; JC4 tornado extreme (obs.) | V-obs | Baseline: clear/overcast/rain/fog/storm; tornado excluded |
| WN-02 | Day/night effects? | Lighting + NPC/traffic/business shifts (obs.) | V-obs | Full cycle; curfew-lite rural + nightlife urban behaviors |
| WN-03 | Exact cycle lengths? | Varies per title, tunable | R | 24-min day baseline (1 s = 1 game-min), tunable in data |

## STREAMING / PERFORMANCE

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| S-01 | Public streaming architectures? | Godot: bg-load + manual chunks (docs V); AAA: proprietary (U) | V/U | Custom 256 m sector streamer (DR-14); benchmark 128/512 |
| S-02 | LOD/instancing patterns? | MultiMesh/LOD/HLOD standard; crowd-LOD (Days Gone obs.) | V-obs | MultiMesh veg ≤60k visible; HLOD urban; crowd LOD tiers |
| S-03 | Draw-call / poly budgets? | Per-title, unpublished | U | UNKNOWN — locked after Prompt 07 measurement (DR-20) |
| S-04 | Viable Godot world size? | Community 20×20 km w/ chunking (R); Terrain3D ≤65 km (R) | R | 4×4 km = comfortable; validates engine choice |

## MISSIONS / ECONOMY

| # | Research question | Evidence | Conf. | ISLAND STRIKE rule |
|---|---|---|---|---|
| M-01 | Mission-hub structure? | WD safehouses; FC camps; RDR2 camps; WD boards (obs.) | V-obs | 3 hubs (city/suburb/rural) + contract boards at L2s |
| M-02 | Side-loop cadence? | FH5 2-min races; DS deliveries; FC outposts (obs.) | V-obs | Legs ≤3 min highway; errands ≤400 m on foot (DR-16) |
| M-03 | Economy sinks/sources? | Fares, shops, garages standard (obs.) | V-obs | Courier/cargo/fuel/repair/fuel economy v1 (Prompt 09) |

---

*End of research matrix v1.0.0 — 38 questions across 12 categories.*
