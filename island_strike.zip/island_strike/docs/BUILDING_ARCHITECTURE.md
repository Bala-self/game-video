# BUILDING ARCHITECTURE (P06 Gen-E/G)

## Pipeline

```
parcel → candidates (district ∩ role occupancy) → ranked (§48)
  → refusal-tested in order (§49) → committed:
    footprint rect in parcel frame (frontage-aligned, §51)
    height ∩ district cap (stepped near core peaks)
    foundation flat-base / terraced / raised (§50)
    entrance (tested) + service yard + parking + interior metadata
  → massing mesh + roof prism → LOD near/mid/far
  → batches (sector, material, lod) + streaming deps + handoffs
```

## Contracts

- `data/world/building_contract.json`: 47 classes (footprint/height
  ranges, grade limits, coast rules, roof/facade, LOD/streaming
  policies) + schema.
- `data/world/district_contract.json`: 20 district classes (density /
  height / setback profiles, allowed classes, coverage, parcel
  bounds, preferred lots, priority table) + schema.

## Results (this lock)

403 buildings, 23 classes in use (no forced use), LOW 370 / MID 32 /
HIGH 1; tallest 37.5 m. 23 parcels UNBUILDABLE with genuine cause
(setback squeeze 12, steep 8, wedge overlap 3); 153 OPEN_SPACE.

## Meshes & LOD

`data/derived/urban_mesh.json`: 403 near + 403 mid meshes, 180
batches with per-building vert/tri ranges, 1055 streaming nodes
(REGION→…→INTERIOR), sector table on the shared P05 256 m grid.
Far LOD = bounds (+ proxy flag for landmarks). All tris validated
(no NaN, none degenerate). Near 6,900 tris / mid 4,836 total.

## Variation without noise (§52/§53)

Residential: seeded footprint/aspect/position/setback within the
street pattern. Commercial: street-wall first with fallback.
Civic: centrality + open-adjacency ranked (§54). Industrial: service
roads + yards (§55). No random rotation anywhere.
