# ISLAND STRIKE — PROMPT 01 BENCHMARK REPORT (§54)

## Environment

Godot 4.7.2.stable.official.ed1daf0bf, Linux x86_64, 2 CPU, ~2 GB RAM,
renderer forward_plus, display headless (dummy), audio Dummy.
Full record: `reports/performance/environment.json`.

## Stack benchmarks A–H (§23 — feasibility, not gameplay)

| Item | Result | Verdict |
|---|---|---|
| A Node-based world shell (build 17 nodes) | median 1.89 ms (n=5) | feasible |
| B script Resource load (warm) | median 2 µs (n=21); icon 0.36 ms | feasible |
| C JSON contract load+parse | median 33 µs (n=21) | feasible |
| D registry init | median 8 µs (n=21) | feasible |
| E sector census 256 + 5000-batch | 0.66 ms + 1.11 ms (≈0.22 µs/op) | feasible |
| F seed derive + 1000-batch | 7 µs + 6.93 ms (≈6.9 µs/op) | feasible |
| G validation run (41 checks) | median 0.42 ms (n=11) | feasible |
| H diagnostics (100 lines) | median 0.54 ms (n=11) | feasible |

Repeated-init consistency: registry/contract/validation re-runs are stable
(CV < 15% on n≥11 samples; shell-build first-touch warmup noted, 6.87 ms max).
Headless reliability: 30+ consecutive headless invocations, zero flakes.

## Startup / runtime

- Cold-start process wall (5 samples): 0.437–0.442 s, mean 0.440 s.
- In-engine BOOT→READY incl. 41/41 validation + shell: 8.19–9.86 ms, mean 8.91 ms.
- Steady-state frame, dummy driver (3×60 frames): mean-of-means 7.75 ms.
- Memory static: 25.9 → 26.8 MB, peak 29.6 MB (OS.get_static_memory_*).

## Unavailable (explicit, §22)

GPU frame time, draw calls, VRAM, thermals — null+reason in baseline JSON.
No render signal exists under the dummy driver; the frame number is a
process-loop regression tripwire only.

## Provisional observations (NON-GATING)

BOOTSTRAP_TARGET / CONTRACT_LOAD_TARGET / VALIDATION_TARGET / SHELL_STARTUP_TARGET
are recorded as provisional observations in PERFORMANCE_BASELINE.md. No thresholds
gate anything. Prompt 07 owns final budget locking.

## Limitations

1. Sandbox hardware (2 CPU/2 GB) is NOT target hardware — numbers are relative
   signals, not ship budgets.
2. Dummy-driver frames exclude all render cost.
3. Sample counts are modest (n≤21 micro, n=5 macro) — enough for feasibility,
   not for tight percentile claims (p95 reported only where n≥20).
