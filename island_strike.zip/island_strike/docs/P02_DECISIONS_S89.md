# P02 DECISION LOG (§89)

D-01 Float64 scalars only in engine numeric paths. Godot Vector2 is
float32; it injected ~1e-7 curvature noise amplified ×300–600 by width
modulation (X-lut 451→932 bad before the true fix). All twin math is
scalar float; coast_loop.gd header documents the ban permanently.

D-02 Lakes, not ditches. Every drainage trap is an enclosed kettle lake
(15 lakes, 0 ditches): ditch variants V1–V3 each dug pits (inlet pits,
dead-end pits, cut-pits). Water budget 0.244/0.25 km².

D-03 Summit pad on surveyed max + plinth + local cap (196,-1196,r25,
blend60,target207.0). Absolute-target pads on domes dig dimples; the pad
follows the natural dome instead.

D-04 Analytic field + LUT, no heightmap asset. Single source of truth in
JSON; both engines evaluate the same math; checksums replace asset sync.

D-05 Preview mesh is one global triangulation (no chunks): sector seams
are impossible by construction; chunking risk moves to P07 with §6 bounds
as the acceptance test.

D-06 §79 trio applied as authored (restricted relocate; urban node
100→102; wide split 230/240) — verified by B-* checks, not by eye.

D-07 §83 gate 5 m / half-bench flag 3–5 m lives in terrain_contract, not
code. Current worst 4.26 m; 5 spur half-benches pre-classified, no action.

D-08 S-05 length gap (17.31 vs 21.5 km) is authoring-for-grade, surfaced
in REPORT §7. Grade compliance outranks length: no corridor re-route.

D-09 Collision DEFERRED with written future contract (REPORT §10); the
deferred prompt inherits field-twin routing + CROSS re-proof + §6 seam
bounds as acceptance criteria.

D-10 P01-locked bytes are untouchable: the session's accidental baseline
regen was reverted (git checkout); lock criterion 27 enforces a clean
tracked tree at every future lock.
