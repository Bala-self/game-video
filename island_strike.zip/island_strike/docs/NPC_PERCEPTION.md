# NPC PERCEPTION (P09) — LOCKED

Policy: `data/derived/npc_perception_policy.json`
(`npc_perception_checksum = 71e6e20d666e14df`).

## 1. Budget law (provable)

- 64 queries/tick, 8 LOS candidates/scan, 512 LOS rays/tick,
  16 hearing events/tick.
- rays/tick ≤ queries × cap = 512 **by construction** (per-scan cap,
  not a hope). Overflow candidates are counted as `perc_skipped_los`
  (observable), whole scans deferred when the query budget binds
  (`perc_deferred`). Perception suite asserts rays ≤ 512 at 100
  simultaneous scans and exact 64/36 execute/defer split under overload.

## 2. Senses

- **LOS**: segment-vs-building-footprint tests, range/FOV per archetype,
  nearest-candidate priority, player observable as a perceivable.
- **Proximity**: spatial-hash neighbors within archetype radius.
- **Hearing**: events carry radius (30 + 60 × intensity) and a 10-tick
  window; delivery happens on the observer's next executed scan
  (P09-D15 — never same-tick-only), deduped per (observer, event), with
  REACT on intensity ≥ 0.8. Coalescing + cooldowns prevent storms.
- **Witness** (hooks for P10+): `witness(observer, source, event)`
  records observation tuples; police/social/mission consumers are out
  of scope but the tap point is tested (behavior suite).

## 3. Scheduling

One consolidated scan per NPC per tick max (LOS + hearing + proximity
in a single query); T3 every tick, T2 reduced cadence, T1/T0 no scans.
Perception draws come from the `perception` seed stream only, so crowd
size never perturbs spawn/path/behavior determinism.
