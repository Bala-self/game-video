# ISLAND STRIKE — AAA OPEN-WORLD REFERENCE DATABASE

| Field | Value |
|---|---|
| Document | `AAA_OPEN_WORLD_REFERENCE_DATABASE.md` |
| Status | **LOCKED (Prompt 00)** — revision `1.0.0` |
| Date | 2026-09-20 |
| Records | 18 titles + Godot engine notes |
| Evidence rule | Every numeric claim carries `VERIFIED` / `REPORTED` / `UNKNOWN` (§12). No invented internals. |
| Machine-readable | `data/aaa_reference/*.json` (one file per title) |
| Purpose | Engineering research dataset → abstracted into `ISLAND_STRIKE_WORLD_DESIGN_RULES.md`. NOT a source to copy. |

Confidence legend:

- `VERIFIED` — reliable public evidence (official specs, docs, reproducible measurement).
- `REPORTED` — secondary press/community measurement; precision uncertain.
- `UNKNOWN` — insufficient evidence; must not drive exact requirements.

> Scale note: press/community "map size" figures mix land-only, land+water, and
> bounding-box methods. Figures below record the *claimed method* where known.
> ISLAND STRIKE's own 12.566 km² is land-disc (r ≤ 2000 m), water excluded —
> compare against land-only figures where possible.

---

## RECORD 01 — Grand Theft Auto V (2013)

```text
Title:            Grand Theft Auto V
Developer:        Rockstar North        Publisher: Rockstar Games
Release period:   2013 (PS3/X360; re-releases later)
Engine:           RAGE (proprietary) — VERIFIED (widely documented by Rockstar/press)
World type:       Urban + rural island (Los Santos + Blaine County), ocean-surrounded
World dimensions: ~8.45 × 12.01 km bounding box — REPORTED (community measurement)
Playable area:    ~75.8 km² total incl. water; land-only lower (~29–30 sq mi incl. water
                  per community grid math) — REPORTED (method varies by source)
Environment:      Dense city, suburbs, desert, mountains (Chiliad), farmland, coastline
Coastal:          YES — full island perimeter, beaches, cliffs, ports, marinas
Urban:            YES — large (Los Santos ~21 sq mi claimed incl. metro sprawl) — REPORTED
Rural:            YES — desert, hills, forest (Paleto), farms
Road hierarchy:   Freeways / arterials / collectors / rural highways / dirt — VERIFIED (observable)
Vehicle traversal: cars/bikes/trucks/boats/aircraft — VERIFIED (observable)
Pedestrian:       dense urban peds, sparse rural — VERIFIED (observable)
Water:            ocean + swim + boats + submersible; ports/docks — VERIFIED (observable)
Weather:          rain/fog/thunder/wind — VERIFIED (observable)
Day/night:        full cycle w/ behavior + lighting response — VERIFIED (observable)
NPC/traffic:      dense ambient peds + traffic w/ LOD + wanted escalation — VERIFIED (observable);
                  exact counts/algorithms — UNKNOWN
Streaming/LOD:    Proprietary streaming; exact technique — UNKNOWN (no public spec relied upon)
Technical evid.:  RAGE engine lineage; scale via community grid overlay — REPORTED
Confidence:       Scale REPORTED; systems VERIFIED-by-observation; internals UNKNOWN
Lesson →          Island ring-road + radial arterials; city↔wilderness contrast; wanted
ISLAND STRIKE:    escalation as model for security zones; beach/port/marina coastal mix.
```

## RECORD 02 — Red Dead Redemption 2 (2018)

```text
Title:            Red Dead Redemption 2
Developer/Pub:    Rockstar Games            Engine: RAGE — VERIFIED
Release period:   2018
World type:       Rural/frontier open world, 5 regions (Ambarino, New Hanover, Lemoyne,
                  West Elizabeth, New Austin) — VERIFIED (observable/official region names)
World dimensions: no official figure — UNKNOWN
Playable area:    ~29 sq mi (~75 km²) commonly cited; full-map ~43.9 sq mi w/ margins;
                  method-dependent — REPORTED
Environment:      Mountains, snow, plains, swamp, forest, farmland, one city (Saint Denis)
Coastal:          PARTIAL — lakes/rivers/swamp; limited ocean edge — VERIFIED (observable)
Urban:            ONE city + towns/settlements — VERIFIED (observable)
Rural:            dominant — VERIFIED
Road hierarchy:   Trails / dirt / rail / few paved streets — VERIFIED (observable)
Vehicle traversal: horses/trains/wagons (period); no cars — VERIFIED
Water:            rivers/lakes/swimming/boats — VERIFIED (observable)
Weather/day-night: full systems w/ ecological response — VERIFIED (observable)
NPC/traffic:      ambient camps, wildlife ecology, lawmen patrols — VERIFIED (observable);
                  internals — UNKNOWN
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; region/ecology design VERIFIED-by-observation
Lesson →          Region-contrast travel (snow→swamp in one ride); wildlife/ambient
ISLAND STRIKE:    ecology as rural-life model; single-city + frontier-town settlement
                  hierarchy fits a 12.5 km² island well.
```

## RECORD 03 — Far Cry 6 — Yara (2021) [KEY ISLAND REFERENCE]

```text
Title:            Far Cry 6 (Yara + Isla Santuario + archipelago)
Developer/Pub:    Ubisoft Toronto / Ubisoft  Engine: Dunia (proprietary) — VERIFIED
Release period:   2021
World type:       Tropical ISLAND nation (directly analogous: island + capital + regions)
World dimensions: ~9.0 × 9.2 km bounding box incl. ocean — REPORTED (community waypoint math)
Playable area:    ~83–88 km² incl. ocean; land-only substantially less — REPORTED;
                  capital Esperanza ~1.3 km² — REPORTED
Environment:      City, jungle, farms, mountains, beaches, mangroves — VERIFIED (observable)
Coastal:          YES — island perimeter, beaches, cliffs, ports — VERIFIED (observable)
Urban:            capital + towns — VERIFIED
Road hierarchy:   highways / rural / dirt / trails — VERIFIED (observable)
Vehicle traversal: cars/horses/boats/aircraft/tank — VERIFIED (observable)
Water/weather/day-night: full — VERIFIED (observable)
NPC/traffic:      military patrols, checkpoints, civilian ambient — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; island-region structure VERIFIED-by-observation
Lesson →          7-region island organization (capital + 6 territories); checkpoint/
ISLAND STRIKE:    roadblock gameplay on rural roads; capital-city-as-distinct-map-feel;
                  island perimeter boat traversal. Closest structural cousin to Strike Island.
```

## RECORD 04 — Ghost of Tsushima (2020) [KEY ISLAND REFERENCE]

```text
Title:            Ghost of Tsushima (Tsushima Island, 3 prefectures)
Developer/Pub:    Sucker Punch / Sony      Engine: proprietary — REPORTED
Release period:   2020
World type:       ISLAND in 3 regions (Izuhara, Toyotama, Kamiagata) — VERIFIED
World dimensions: no official figure — UNKNOWN
Playable area:    ~11 sq mi (~28–29 km²) — REPORTED (community measurement)
Environment:      Forest, fields, coast, mountains, snow (north), towns — VERIFIED
Coastal:          YES — island perimeter w/ beaches/cliffs — VERIFIED (observable)
Urban:            towns/castles, no modern city — VERIFIED
Road hierarchy:   trails/roads/bridges (period) — VERIFIED (observable)
Traversal:        horse + on-foot + grapple — VERIFIED
Water:            ocean borders; limited water gameplay — VERIFIED (observable)
Weather/day-night: dynamic, guiding-wind navigation — VERIFIED (observable)
NPC:              patrols, camps, wildlife; guiding systems — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; island pacing VERIFIED-by-observation
Lesson →          3-act island gating by region; wind-as-GPS diegetic navigation;
ISLAND STRIKE:    landmark-led exploration (compose haiku spots ≈ micro-landmarks);
                  strongest proof a ~28 km² island sustains 40h+ gameplay — and Strike
                  Island at 12.6 km² must therefore run HIGHER density (see §10).
```

## RECORD 05 — Sleeping Dogs — Hong Kong (2012) [KEY DENSITY REFERENCE]

```text
Title:            Sleeping Dogs (Hong Kong Island districts)
Developer/Pub:    United Front / Square Enix  Engine: proprietary — REPORTED
Release period:   2012
World type:       Dense URBAN island districts (4 regions) — VERIFIED (observable)
World dimensions: ~3 km across — REPORTED
Playable area:    ~8 km² — REPORTED (press/community)
Environment:      Urban districts + Victoria Harbour water + hills fringe — VERIFIED
Coastal:          YES — harbor waterfronts, docks — VERIFIED
Urban:            DOMINANT — 4 distinct districts — VERIFIED
Road hierarchy:   arterials/streets/alleys/highway links — VERIFIED (observable)
Traversal:        cars/bikes/boats — VERIFIED
Water/weather/day-night: harbor water; weather + day/night — VERIFIED (observable)
NPC/traffic:      dense street life + markets — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; density design VERIFIED-by-observation
Lesson →          PROOF that ~8 km² supports a full AAA urban action game via density:
ISLAND STRIKE:    district identity per km², verticality (markets/alley stacks), harbor
                  as gameplay water. Strike Island's 12.6 km² with one urban core +
                  rural surround is validated by this record — density, not area, wins.
```

## RECORD 06 — Watch Dogs 2 — Bay Area (2016) / Legion — London (2020)

```text
Titles:           Watch Dogs 2 (San Francisco Bay) / Watch Dogs: Legion (London)
Developer/Pub:    Ubisoft                       Engine: Disrupt (proprietary) — REPORTED
Release periods:  2016 / 2020
World type:       Urban + water-split districts — VERIFIED (observable)
Playable area:    WD2 ~22 km² (half water) — REPORTED; Legion ~9–24 km² (method varies,
                  central London ~3.5×3.5 km) — REPORTED
Coastal/water:    Bay water + Thames river gameplay (boats) — VERIFIED
Road hierarchy:   full urban hierarchy + freeways — VERIFIED (observable)
Traversal:        cars/bikes/boats; hacking-augmented — VERIFIED
NPC/traffic:      dense crowds + traffic; Legion playable-NPC system — VERIFIED (observable)
Weather/day-night: full — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; urban systems VERIFIED-by-observation
Lesson →          Water-as-district-divider (bridges as chokepoints = mission design);
ISLAND STRIKE:    borough identity system → suburb/ward identity for Portside City.
```

## RECORD 07 — Cyberpunk 2077 — Night City (2020)

```text
Title:            Cyberpunk 2077 (Night City + Badlands)
Developer/Pub:    CD Projekt Red              Engine: REDengine 4 — VERIFIED (official)
Release period:   2020
World type:       Dense vertical city + badlands surround — VERIFIED
World dimensions: ~4×6 km core (~24 km² incl. water); land ~16 km² — REPORTED
Playable area:    ~24 km² total; figures vary by water accounting — REPORTED
Coastal:          PARTIAL — bay/coastal edge — VERIFIED
Urban:            DOMINANT, extreme verticality — VERIFIED (official dev commentary on
                  vertical space; exact floor counts — UNKNOWN)
Road hierarchy:   freeways/arterials/streets — VERIFIED (observable)
Traversal:        cars/bikes; no aircraft for player at launch — VERIFIED
Water/weather/day-night: bay water; weather + full day/night — VERIFIED (observable)
NPC/traffic:      dense crowds + traffic w/ LOD — VERIFIED (observable); counts — UNKNOWN
Streaming/LOD:    proprietary (+ documented asset-streaming rework post-launch) — REPORTED
Confidence:       Scale REPORTED; verticality lesson VERIFIED-by-observation
Lesson →          Verticality multiplies effective area (rooftops, multi-floor shells);
ISLAND STRIKE:    district gangs/territories → zone-ownership gameplay for districts.
```

## RECORD 08 — The Witcher 3 (2015)

```text
Title:            The Witcher 3: Wild Hunt (Velen/Novigrad + Skellige + Kaer Morhen)
Developer/Pub:    CD Projekt Red              Engine: REDengine 3 — VERIFIED (official)
Release period:   2015 (base; +2 expansions incl. Toussaint)
World type:       Multi-map open world (NOT one island): continent + ISLAND chain — VERIFIED
Playable area:    ~136 km² base (Velen/Novigrad ~72 + Skellige ~64); ~142 w/ DLC — REPORTED
Environment:      Farmland, forest, swamp, city (Novigrad/Oxenfurt), SKELLIGE ISLANDS
                  (mountains, coast, sea) — VERIFIED (observable)
Coastal:          YES in Skellige (cliffs, beaches, boats) — VERIFIED
Road hierarchy:   trails/dirt/city streets (period) — VERIFIED
Traversal:        horse/boat/fast-travel — VERIFIED
Water/weather/day-night: sea + storms; full weather/day-night — VERIFIED (observable)
NPC:              villages, notice boards, ambient routines — VERIFIED (observable)
Streaming/LOD:    per-map streaming, fast-travel between maps — VERIFIED (observable);
                  internals — UNKNOWN
Confidence:       Scale REPORTED; multi-map lesson VERIFIED-by-observation
Lesson →          Skellige = island-chain quest design (boat + climb + village loops);
ISLAND STRIKE:    notice-board/contract hubs → mission-board POIs; multi-map separation
                  is REJECTED for Strike Island (single seamless island required).
```

## RECORD 09 — Just Cause 3/4 — Medici/Solís (2015/2018)

```text
Titles:           Just Cause 3 (Medici) / Just Cause 4 (Solís)
Developer/Pub:    Avalanche / Square Enix      Engine: Apex (proprietary) — REPORTED
World type:       HUGE Mediterranean/South-American island nations — VERIFIED
Playable area:    ~1000–1024 km² each (incl. ocean; JC4 more usable land) — REPORTED
                  (official "1000 km²" PR claim for JC3; community notes ocean share)
Environment:      Cities, coasts, mountains, desert, jungle, snow (JC4) — VERIFIED
Coastal:          YES — extensive — VERIFIED
Road hierarchy:   highways/rural/dirt — VERIFIED (observable)
Traversal:        cars/boats/aircraft + wingsuit/grapple (speed-first design) — VERIFIED
Water/weather:   ocean + boats; JC4 extreme weather (tornado) — VERIFIED (observable)
NPC/traffic:      military + sparse civilians — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED (official PR + community); traversal VERIFIED
Lesson →          ANTI-PATTERN for Strike Island: vast area + thin density = emptiness
ISLAND STRIKE:    complaints; ADOPT instead: grapple/wingsuit-class traversal needs
                  vertical relief + stunt props; extreme-weather events as aspirational
                  post-launch system, not baseline.
```

## RECORD 10 — ARMA 3 — Altis (2013)

```text
Title:            ARMA 3 (Altis + Stratis, Malden DLC)
Developer/Pub:    Bohemia Interactive         Engine: Real Virtuality 4 — VERIFIED (official)
Release period:   2013
World type:       Realistic-scale MILITARY island terrain — VERIFIED
Playable area:    Altis ground ~270 km²; total w/ water ~1000 km² (official data) — VERIFIED
                  (Bohemia-published terrain figures)
Environment:      Scrub, hills, towns, airfields, salt flats, coast — VERIFIED
Coastal:          YES — full island perimeter — VERIFIED
Road hierarchy:   highways/rural/dirt/trails + airfields — VERIFIED
Traversal:        on-foot/vehicles/aircraft/boats (sim speeds) — VERIFIED
Water/weather/day-night: full sim weather + tides + day/night — VERIFIED (observable)
NPC:              military AI squads, civilians — VERIFIED (observable)
Streaming/LOD:    terrain paging (documented community knowledge; exact internals — UNKNOWN)
Confidence:       Scale VERIFIED (developer-published); sim lessons VERIFIED
Lesson →          Real-scale terrain + airfields + road truthfulness; grid/UTM-style
ISLAND STRIKE:    map coordinates → GPS/sector mapping precedent; proves island +
                  airfield + military compound coexist (direct template for R4/R11).
```

## RECORD 11 — Assassin's Creed Odyssey (2018)

```text
Title:            Assassin's Creed Odyssey (Greece + Aegean islands)
Developer/Pub:    Ubisoft Quebec / Ubisoft     Engine: AnvilNext 2.0 — REPORTED
Release period:   2018
World type:       Mainland + 20+ ISLANDS, naval traversal — VERIFIED
Playable area:    ~256 km² incl. sea; land ~45 sq mi (~117 km²) — REPORTED
Coastal:          DOMINANT — cliffs, beaches, ports everywhere — VERIFIED
Road hierarchy:   trails/roads (period) — VERIFIED
Traversal:        horse/ship; conquest/territory systems — VERIFIED
Water/weather/day-night: naval combat + storms; full cycle — VERIFIED (observable)
NPC:              mercenaries, soldiers, civilians; conquest AI — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; island/sea gameplay VERIFIED
Lesson →          Island-hopping quest arcs; conquest front-line as dynamic region
ISLAND STRIKE:    ownership model; fort/camp placement grammar (overlook + walls +
                  patrol rings) → restricted-compound + outpost design rules.
```

## RECORD 12 — Forza Horizon 5 — Mexico (2021)

```text
Title:            Forza Horizon 5 (Mexico)
Developer/Pub:    Playground / Xbox           Engine: ForzaTech (proprietary) — REPORTED
Release period:   2021
World type:       Driving-first open world, 11 biomes — VERIFIED (official biome count)
Playable area:    ~107 km² (community estimate; NO official km² figure) — REPORTED;
                  officially "50% larger than FH4; most diverse Horizon world" — VERIFIED claim
Environment:      Desert, jungle, city (Guanajuato), volcano, coast, canyon — VERIFIED
Coastal:          YES — Baja coast + beaches — VERIFIED
Road hierarchy:   500+ km drivable roads (official "321 vs 212 miles" claim) — REPORTED
Traversal:        cars-only world (road grammar is the game) — VERIFIED
Water/weather/day-night: water borders; dynamic weather + seasons-lite + day/night — VERIFIED
NPC/traffic:      traffic + drivatar ghosts; no peds — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; road-design lesson VERIFIED
Lesson →          BEST road-hierarchy reference: festival hub + highway ring + biome
ISLAND STRIKE:    connectors + dirt trails; corner/grade grammar for fun driving;
                  Guanajuato tunnels → underpass/bridge verticality precedent.
```

## RECORD 13 — Ghost Recon Wildlands (2017)

```text
Title:            Ghost Recon Wildlands (Bolivia, 21 provinces)
Developer/Pub:    Ubisoft Paris / Ubisoft      Engine: AnvilNext-based — REPORTED
Release period:   2017
World type:       Rural province-grid open world — VERIFIED
Playable area:    ~400 km² (community; method varies) — REPORTED
Environment:      Mountains, salt flats, jungle, villages, cartel outposts — VERIFIED
Road hierarchy:   highways/dirt/trails + airfields — VERIFIED (observable)
Traversal:        cars/aircraft/boats + co-op — VERIFIED
NPC:              cartel patrols, checkpoints, rebels — VERIFIED (observable)
Streaming/LOD:    proprietary — UNKNOWN
Confidence:       Scale REPORTED; province/outpost grammar VERIFIED
Lesson →          Province = region-with-boss gameplay container (21×) → Strike
ISLAND STRIKE:    Island's 11 regions each get an "owner + outpost + arc" treatment;
                  rebel-support systems → civilian-reputation hooks.
```

## RECORD 14 — Mafia: Definitive Edition — Lost Heaven (2020)

```text
Title:            Mafia: Definitive Edition (Lost Heaven)
Developer/Pub:    Hangar 13 / 2K              Engine: Mafia engine (proprietary) — REPORTED
Release period:   2020 (remake; original 2002)
World type:       Period city + countryside — VERIFIED
Playable area:    no reliable figure — UNKNOWN (not used for scale claims)
Environment:      1930s city, farms, forest, lake, dam — VERIFIED (observable)
Road hierarchy:   city grid + rural highways + dirt — VERIFIED (observable)
Traversal:        period cars;scripted pacing — VERIFIED
Lesson →          Small-city + countryside coexistence; period traffic/ped behavior;
ISLAND STRIKE:    countryside collectible/motel loops → rural POI grammar.
```

## RECORD 15 — Death Stranding (2019)

```text
Title:            Death Stranding (fictional USA regions)
Developer/Pub:    Kojima / Sony               Engine: Decima — VERIFIED (official)
Release period:   2019
World type:       Traversal-puzzle wilderness — VERIFIED
Playable area:    no reliable figure — UNKNOWN
Environment:      Mountains, rivers, snow, beaches, ruins — VERIFIED
Road hierarchy:   player-BUILT roads (asphalt printer) — VERIFIED (observable)
Traversal:        on-foot/bike/truck; terrain-as-enemy — VERIFIED
Water/weather:   rivers/ocean + timefall rain — VERIFIED (observable)
Lesson →          Terrain-difficulty-as-gameplay (slope/grade MATTERS to fun);
ISLAND STRIKE:    road-building progression fantasy; cargo/delivery loops → courier
                  missions on rural roads; chiral-network coverage → radio-tower
                  unlock pacing for highlands (L1 mast!).
```

## RECORD 16 — Days Gone (2019)

```text
Title:            Days Gone (Oregon regions)
Developer/Pub:    Bend Studio / Sony          Engine: Unreal Engine 4 — VERIFIED (official)
Release period:   2019
World type:       Forested rural + small towns — VERIFIED
Playable area:    no reliable single figure — UNKNOWN (press varies; unused)
Environment:      Pine forest, mountains, lakes, highways, camps — VERIFIED
Road hierarchy:   highways/rural/dirt/trails — VERIFIED (observable)
Traversal:        motorcycle-first (fuel/repair loops) — VERIFIED
NPC:              hordes (crowd tech), patrols, wildlife — VERIFIED (observable)
Weather/day-night: dynamic + snow — VERIFIED (observable)
Lesson →          Bike-first road grammar (fuel stops shape routes); horde tech =
ISLAND STRIKE:    crowd-LOD precedent; camp-reputation → settlement-favor systems.
```

## RECORD 17 — Metal Gear Solid V (2015)

```text
Title:            Metal Gear Solid V (Afghanistan + Africa maps)
Developer/Pub:    Kojima / Konami             Engine: Fox Engine — VERIFIED (official)
Release period:   2015
World type:       Outpost-dotted tactical maps — VERIFIED
Playable area:    no reliable figure — UNKNOWN
Environment:      Desert, savanna, cliffs, villages, bases — VERIFIED
Road hierarchy:   dirt/trails + few paved — VERIFIED
Traversal:        on-foot/vehicle/horse/heli-extract — VERIFIED
NPC:              guard patrols, shifts,Morale/adaptation AI — VERIFIED (observable)
Lesson →          Outpost grammar (guard posts + watchtowers + patrol rings) =
ISLAND STRIKE:    THE template for restricted compound + checkpoints; adaptive enemy
                  equipment → escalation design; heli-extract → airfield gameplay.
```

## RECORD 18 — Grand Theft Auto: San Andreas (2004) [STRUCTURAL ANCESTOR]

```text
Title:            Grand Theft Auto: San Andreas (Los Santos + San Fierro + Las Venturas)
Developer/Pub:    Rockstar North / Rockstar    Engine: RenderWare — VERIFIED (documented)
Release period:   2004
World type:       THREE cities + countryside/desert/forest ONE map — VERIFIED
Playable area:    ~36 km² commonly cited — REPORTED
Environment:      3 distinct city biomes + Mt. Chiliad + desert + forest + coast — VERIFIED
Road hierarchy:   freeways/highways/streets/dirt/trails + rail + airfields — VERIFIED
Traversal:        full multi-modal incl. bicycles — VERIFIED
Lesson →          Multi-city contrast on ONE map; countryside as connective tissue;
ISLAND STRIKE:    rail + airfields as fast-travel + mission spine. Strike Island adapts
                  this at 1 city + towns + villages scale (density-scaled to 12.6 km²).
```

---

## ENGINE NOTE — Godot 4.x open-world capability (context, not a game record)

```text
Coordinate system:  right-handed, Y-up, −Z forward — VERIFIED (official docs:
                    "Using 3D transforms"; "Importing 3D scenes")
Terrain options:    community Terrain3D (≤65.5×65.5 km claimed), Voxel Tools,
                    heightmap clipmaps — REPORTED (community); NO built-in AAA
                    terrain streamer — VERIFIED-by-docs-absence (must be authored)
Instancing/LOD:     MultiMeshInstance3D, LOD ranges, VisibilityRange, HLOD via
                    code — VERIFIED (official docs)
Streaming:          ResourceLoader background loading + manual SceneTree chunk
                    management — VERIFIED (official docs); no Unity-style world
                    streamer built in — VERIFIED-by-docs-absence
Implication:        Strike Island's 4×4 km footprint is well within Godot's
                    comfortable range (community 20×20 km worlds reported workable
                    with chunking); sector streaming MUST be custom-authored (Prompt 07).
```

---

## SCALE COMPARISON TABLE (land-disc context for 12.566 km²)

| Title | Claimed area | Method / confidence | × Strike Island |
|---|---|---|---|
| Sleeping Dogs | ~8 km² | REPORTED (urban) | 0.64× |
| Watch Dogs: Legion | ~9–24 km² | REPORTED (varies) | 0.7–1.9× |
| Cyberpunk 2077 | ~24 km² | REPORTED (incl. water) | ~1.9× |
| Ghost of Tsushima | ~28 km² | REPORTED | ~2.2× |
| GTA: San Andreas | ~36 km² | REPORTED | ~2.9× |
| GTA V | ~75.8 km² | REPORTED (incl. water) | ~6× |
| RDR2 | ~75 km² | REPORTED | ~6× |
| Far Cry 6 | ~83–88 km² | REPORTED (incl. ocean) | ~7× |
| Forza Horizon 5 | ~107 km² | REPORTED (unofficial) | ~8.5× |
| Witcher 3 | ~142 km² | REPORTED | ~11× |
| AC Odyssey | ~256 km² | REPORTED (incl. sea) | ~20× |
| ARMA 3 Altis | ~270 km² land | VERIFIED (developer) | ~21× |
| Just Cause 3/4 | ~1000 km² | REPORTED (PR, incl. sea) | ~80× |

**Engineering conclusion:** Strike Island (12.566 km²) sits between Sleeping Dogs
(8 km², full AAA urban game) and Ghost of Tsushima (28 km², full AAA island game).
Scale is sufficient **iff** density follows the Sleeping Dogs urban precedent and the
Tsushima island-pacing precedent — the contract's density ranges (§10) encode exactly this.

---

*End of AAA reference database v1.0.0 — 18 records + engine note.*
