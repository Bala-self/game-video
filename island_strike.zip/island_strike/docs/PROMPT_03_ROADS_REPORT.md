# ISLAND STRIKE — PROMPT 03 REPORT (master road network reconstruction)

Date: 2026-09-21. Status: COMPLETE, all suites green, ready to LOCK.
Scope: hybrid urban network (arterials + collectors + selected locals, no full
grid). Python-authoritative generator (`tools/road_model.py`) + lightweight
GDScript reference verifier (`tests/godot/tools/road_check.gd`). Numeric
smoke on centerlines + terrain + matplotlib evidence (no preview road mesh).

## §1 INPUTS (pinned versions)

| input | version | path |
|---|---|---|
| road contract | 0.1.0 | `data/world/road_contract.json` |
| road authoring | 0.1.0 | `data/roads/authoring.json` |
| terrain contract | 0.1.0 | `data/world/terrain_contract.json` (P02 LOCKED) |
| coast contract | 0.1.0 | `data/world/coast_contract.json` (P02 LOCKED) |
| world contract | 0.1.0 | `data/world/world_contract.json` (P01 LOCKED) |
| terrain authoring | 0.1.0 | `data/terrain/authoring.json` (P02 LOCKED) |

Generator refuses stale/mismatched inputs (`I-version-roof` proves it). All
height/slope/grade/region/coast math is consumed from the P02 Field API only
(`tools/terrain_model.py`); no duplication (§2 rule holds).

## §2 NETWORK DEFINITION (what "roads" is)

- 22 nodes / 25 edges / 23.14 km. Classes: primary 11.92, secondary 7.21,
  local 1.60, service 0.98, tertiary 0.51, rural 0.41, trail 0.50 km.
- Node types: 8 terminal, 1 gate, 1 six-arm roundabout (`hub_city`, r=25 m),
  1 junction, 2 merge, 8 T-junction, 1 trailhead.
- Centerlines: P02 corridor migration + authored anchors, 10 m samples,
  corner fillets (T=R·tan(d/2), center on bisector at R/cos(d/2),
  deviation R(sec(d/2)−1)). 42 fillets applied, 28 corners skipped with
  recorded reasons (junction discs, portal works discs, infeasible).
- Grades are analytical along-polyline deltas on 50 m-window smoothed
  elevations (P02 recipe, route-full — never sliced — so the smoothing
  window never truncates at junctions). Caps: primary 12/10,
  secondary 15/12, enforced open-alignment (works discs excluded, P04 owns).
- Special structures: 1 tunnel (`TN-RING-HW-NORTH-TUNNEL`, grade 0.03%,
  cover 42 m, bend 12.74°, portal turns E120.5°/W164.2°), 2 river bridges
  (`BC-01` on `E_radial_west_01`, `BC-02` on `E_ring_hw_02`, 60 m each,
  `river_south`, validation `candidate` for P04 construction).
- Access profiles: public / service / restricted. Destination `forest` is
  a SERVICE depot (public view intentionally excludes the spur); 12
  fixed route queries cover all destinations in all three profiles.

## §3 VALIDATION SUITES (all green, real execution)

| suite | checks | result |
|---|---|---|
| STATIC-ROAD | 62 (S/N/E/G/V/B/W/T/X/K/Q/H/C) | 62/62 |
| CROSS-ROAD (Godot 4.7.2 verifier) | 7 | 7/7 |
| INJECT-ROAD | 8 | 8/8 |
| REPRODUCE-ROAD | 4 | 4/4 |
| SMOKE-ROAD (13 kinematic trips) | 4 | 4/4 |
| PERF-ROAD | 5 | 5/5 |
| REGRESS-ROAD (P02 static + full P03) | 8 | 8/8 |
| **total** | **98** | **98/98** |

STATIC recomputes from the export (length/grade/coast/works), never trusts
summaries. CROSS runs the in-engine verifier: lengths agree 5.7e-12
(tol 1e-9), node elevations rel 3.5e-15 (tol 1e-9), grades 2.2e-13
(tol 1e-9), checksum exact, routes 12/12 exact. Integration evidence =
CROSS `X-run` (engine loads terrain twin + roads jointly) + `S-versions`
pins; no separate suite needed.

## §4 CHECKSUM (the identity of this network)

`roads.json` checksum: `0e28622c1bb2185b` (FNV-1a 64 over canonical parts:
meta, nodes, edges, samples, fillets, bridges; pinned by
`R-checksum-stable` and `G-checksum-pinned`).

Quantization rule (learned the hard way, §7): half-AWAY-from-zero
millimeter/centimeter integers. Python `round()` is half-even and diverges
from GDScript `roundf()` on exact .5 ties — interpolated midpoints HIT
these (10 found). Never use `round()` in canonical identity strings.

## §5 NETWORK STATS

- Length 23.14 km (plan estimate 21.5 km was explicitly non-binding).
- Residual curvature open ≤ 6.67° (cap 15°); works-disc residual
  122.15° attributed to P04 earthworks, excluded from the open cap.
- Pinches: open 193 m on `E_ring_hw_04` (R≈65, < 15% allowance),
  works-disc pinch 52.8 m flagged for P04; junction pinches uncapped.
- Beach samples: resort 16/20 allowance, single coast-end span, terminal
  floor holds (allowance scales with 10 m sample spacing).
- Ring cycle closes via the tunnel; 9 graph dead ends recorded; 9
  articulation points identified (`hub_city` + 8 junctions).
- Runway exclusion: zero samples inside RW09_27 strip+60 m rect.
- Coast clearance: all edges satisfy class minima; resort waterfront
  approaches to ~30 m by design.

## §6 JUNCTIONS + ROUNDABOUT (closed)

- `hub_city` is a 6-arm roundabout (the forgotten `rd_urban_south` arm made
  5 wrong). Contract carries a roundabout-specific cap 6
  (`intersection_rules.roundabout_max`), all other types cap 5
  (`N-degree-caps` enforces both).
- Junction-disc corners are never filleted (in-disc skip + pinch record);
  junction-pinches are exempt from the length cap.
- Turn-connector surfacing geometry is DEFERRED to P04 (construction owns
  junction meshes); P03 hands off split topology, approach bearings,
  and pinch records — sufficient for P04 and for smoke routing.

## §7 KEY ENGINEERING RESULTS (for the record)

1. **Export rounding broke exactness.** 4-decimal export rounding broke 4
   STATIC recompute checks and would have forked GDScript cross-checksums.
   Machine data exports at full precision; rounding lives in reports only.
2. **Route-full profiling or nothing.** Slicing edges before smoothing
   truncates the window at junctions and disagrees with P02 corridor
   grades. Generator, STATIC, and the GDScript verifier all profile
   route-full, then slice maxima. Same rule bit all three sides.
3. **Works-zone attribution.** The unfilletable 122° idx46 kink (62 m from
   the W portal, locked P02 geometry) polluted open residual + pinch caps.
   Residuals and pinches now carry works flags; open caps exclude works
   zones; `V-works-pinches` records 52.8 m for P04 coordination.
4. **Half-away quantization.** See §4. Three-way digest split
   (Python round vs floor-half-up vs GDScript roundf) bisected to S-parts,
   root-caused to 10 exact .5 ties, fixed on the Python side to match
   `roundf` bit-for-bit. Cross-engine checksum parity now exact.
5. **Failure hardening from INJECT.** Unknown split nodes raised bare
   `StopIteration` (now `RoadError: unknown node`); off-disc nodes
   silently clamped in `Field.height` (now `off-terrain` refusal at
   r_world 2000). Grade caps live in the validator, and `I-grade-gate`
   proves the gate fires.

## §8 SMOKE (gameplay-traversal evidence)

`tools/road_smoke.py`: 12 fixed queries + 19.25 km grand tour, accel 2.0 /
brake 3.5 m/s², curve limit v=√(2.5·R), junction 30 / roundabout 20 km/h
slow-downs, rest-to-rest. All 13 trips complete; tour avg 49.3 km/h;
max lateral 2.50 m/s² (limit binds, as designed). Raw sample-to-sample
grades reach 21.8% on trail/rural (contract caps apply to smoothed P02
grades, which hold — noted, not a violation). Evidence:
`docs/evidence/p03_plan.png`, `p03_tour_elev.png`, `p03_tour_speed.png`.

## §9 PERFORMANCE MATRIX (real execution, no projections)

Build 0.9 s (< 30), STATIC 2.4 s (< 60), smoke 0.7 s (< 60), route query
≈0.0 ms (< 500 ms), export 523 KB (< 2 MB). Budgets carry 10–30× margin.

## §10 LOCK TABLE

| # | condition | holds |
|---|---|---|
| 1 | inputs pinned (§1), stale refused | ✓ |
| 2 | 98/98 checks green across 7 suites | ✓ |
| 3 | checksum `0e28622c1bb2` pinned + cross-engine exact | ✓ |
| 4 | all open grades within caps; works attributed | ✓ |
| 5 | bridges real crossings; tunnel gates pass | ✓ |
| 6 | roundabout 6-arm justified + capped | ✓ |
| 7 | smoke 13/13 + evidence plots | ✓ |
| 8 | perf within budget | ✓ |
| 9 | P02 suites still green (untouched) | ✓ |
| 10 | byte-identical reproduce | ✓ |
| 11 | INJECT failures all loud + named | ✓ |
| 12 | connector surfacing deferred to P04, recorded | ✓ |

## §11 FILES

- `tools/road_model.py` — authoritative generator.
- `tools/validate_roads.py` — 7 suites.
- `tools/road_smoke.py` — kinematic smoke + evidence.
- `tests/godot/tools/road_check.gd` — in-engine verifier.
- `data/world/road_contract.json`, `data/roads/authoring.json` — inputs.
- `data/derived/roads.json` — the network (523 KB).

## §12 REPRODUCE

```
python3 tools/road_model.py            # checksum 0e28622c1bb2185b
python3 tools/validate_roads.py static # 62/62
python3 tools/validate_roads.py cross  # 7/7 (needs tools/.godot/godot)
python3 tools/validate_roads.py inject # 8/8
python3 tools/validate_roads.py reproduce  # 4/4
python3 tools/validate_roads.py smoke  # 4/4
python3 tools/validate_roads.py perf   # 5/5
python3 tools/validate_roads.py regress  # 8/8
```
