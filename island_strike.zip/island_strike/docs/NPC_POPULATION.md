# NPC POPULATION (P09) — LOCKED

Manifests: `data/derived/npc_population_manifest.json`
(`npc_population_checksum = fd1f5bdeeb7e95e7`,
`npc_policy_checksum = 5b59d290bb0de76b`)
+ `data/derived/npc_spawn_zones.json`.
Census: 26 zones · 1263 target population · 9 archetypes.

## 1. Zones

One zone per district/arrival site (18 classes: CITY_CORE … WATERFRONT,
ARRIVAL, RESTRICTED). Each zone: areas, buildings, target + peak
population, archetype weights, schedule profile, restrictions.
Area-less zones (PZ-D-air-ops, PZ-D-farmA, PZ-D-farmB) spawn at building
ENTRY nodes (principled: occupants exit buildings) — never in the void.

## 2. Archetypes (9)

CIVILIAN, COMMUTER, RESIDENT, SHOPPER, TOURIST, WORKER (full) +
EMERGENCY_HOOK, SECURITY_HOOK, SERVICE_HOOK (typed hooks: spawnable,
counted, interactable; their P10+ role logic is out of scope).
Each archetype: walk/run speeds, radius, perception envelope
(los/fov/proximity/reaction/traffic-awareness), class weights.

## 3. Spawning (all §10 checks)

Candidate attempts 8, point step 4 m, min NPC spacing 1.0 m, min player
clearance 5.0 m, defer 30 ticks when blocked. Every placement validates:
walkable area, not in water/road/building/restricted, sector READY,
no NPC overlap, player clearance. Rejections carry reasons and are
counted (`spawn_rejects`); duplicate semantic placements are refused
at `acquire`. No teleport, no infinite-despawn recovery (§63 upheld:
every invalid spawn in the inject suite is rejected with its reason).

## 4. Despawning

Rules: outside relevance (600 m), over zone peak, recovery-exhausted
(4 strikes → FAILED → safe despawn). `despawn_safe` gates removal;
despawns emit events with reasons. Pins: sector pins carry owner +
expiry; `check_leaks` proves none outlive their release (all suites).

## 5. Scheduling

Four schedules (MORNING/DAY/EVENING/NIGHT) multiply destination weights
(work ×2 mornings, home ×3 nights, …). Streams are seeded per-domain
(`npc` namespace: spawn/destination/path/behavior/perception/schedule),
so schedule changes never perturb pathing or perception draws.
