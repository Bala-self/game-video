# ISLAND STRIKE — WORLD MASTER CONTRACT

| Field | Value |
|---|---|
| Document | `WORLD_MASTER_CONTRACT.md` |
| Status | **LOCKED (Prompt 00)** — revision `1.0.0` |
| Date locked | 2026-09-20 |
| Engine target | Godot 4.x (4.3+ recommended; re-verify at Prompt 01) |
| Authority | Single authoritative world definition. All Prompts 01–10 inherit this contract. Any change requires a new lock revision per §26. |
| Validation | `tools/validate_world_contract.py` — 53/53 checks passing (pure-math scope) |
| Related docs | `01_WORLD_CLARIFICATION_REPORT.md`, `AAA_OPEN_WORLD_REFERENCE_DATABASE.md`, `ISLAND_STRIKE_WORLD_DESIGN_RULES.md`, `WORLD_REFERENCE_MATRIX.md`, `WORLD_AREA_BUDGET.md` |

> **Originality notice.** This is an original world specification. AAA titles are referenced
> only for systemic patterns (density, hierarchy, traversal, streaming concepts). No
> proprietary map data, coordinates, assets, or code are reproduced here.

---

## 1. WORLD IDENTITY (§4.1)

```text
Project:      ISLAND STRIKE
World:        Original 2 km-radius circular island ("Strike Island" working name)
World type:   Open-world action island, single landmass, ocean-surrounded
Engine:       Godot 4.x
Primary unit: meters (m). All distances, speeds, heights in meters / m/s unless stated.
Time unit:    seconds. Speeds in m/s; travel times derived, not assumed.
```

---

## 2. MATHEMATICAL DIMENSIONS — LOCKED (§4.2)

```text
RADIUS (R_world):        2,000 m            (EXACT)
DIAMETER:                4,000 m            (EXACT, = 2R)
AREA (land disc):        π × 2000² = 12,566,370.61 m² ≈ 12.566371 km²
CIRCUMFERENCE:           2π × 2000 = 12,566.37 m ≈ 12.566 km
```

Verification: `GEO-01…GEO-06` in `tools/validate_world_contract.py` — **PASS**.

**Anti-confusion rule (locked):** `2 km` = RADIUS, `4 km` = DIAMETER. Any document,
variable, or comment that equates "2 km" with diameter or "4 km" with radius is a
contract violation. Canonical constant names:

```gdscript
const R_WORLD := 2000.0   # meters, island boundary radius from ISLAND_CENTER
const D_WORLD := 4000.0   # meters, island diameter
const ISLAND_CENTER := Vector3.ZERO
const OCEAN_LEVEL := 0.0  # meters on Y axis
```

---

## 3. COORDINATE CONTRACT — LOCKED (§4.3, §5)

### 3.1 Engine basis (verified against Godot documentation)

Godot 4.x uses a **right-handed, Y-up** coordinate system with **`−Z` as forward**
(`Vector3.FORWARD == (0,0,-1)`), `+X` right, `+Y` up — the OpenGL convention
(see clarification report §C for sources). Therefore:

```text
World X:   East–West axis.  +X = EAST,  −X = WEST
World Y:   Up axis.         +Y = UP (terrain height, elevation, altitude)
World Z:   North–South axis. −Z = NORTH, +Z = SOUTH
Forward:   −Z (engine convention; cameras, Vector3.FORWARD, look_at)
Terrain height axis: Y (heightmap value displaces +Y)
Ocean plane:  y = 0.0 (X–Z plane)
Beach elevation reference: y ≈ +0.4 m (wet sand) → +1.5 m (dry beach); see §6
World origin:        (0, 0, 0)
Island center:       (0, 0, 0)  — IDENTICAL to world origin (locked, §5)
Boundary center:     (0, 0, 0)  — radial boundary measured on the X–Z plane
North direction:     −Z (locked). Compass heading 0° = −Z, 90° = +X (East).
```

### 3.2 Canonical mappings (all deterministic, §5)

Let world position be `P = (x, y, z)`. Radial distance from center:

```text
r(P) = sqrt(x² + z²)            # Y is excluded: boundary is a vertical cylinder
inside_world(P)  ⟺  r(P) <= 2000.0
```

| Domain | Mapping (locked) |
|---|---|
| World → radial | `r = sqrt(x²+z²)`, `θ = atan2(x, −z)` (0 = North, clockwise) |
| World → GPS/map | `gx = x + 2000 ∈ [0,4000]`, `gz = z + 2000 ∈ [0,4000]`; map pixel = `gx/4000×W`, `gz/4000×H` |
| World → sector (256 m) | `sx = floor((x+2048)/256)`, `sz = floor((z+2048)/256)`, grid `16×16` over `4096 m` span |
| World → terrain UV | `u = (x+2000)/4000`, `v = (z+2000)/4000` (heightmap spans `[-2000,2000]`², ocean apron beyond) |
| World → nav/road/AI/NPC/vehicle | identity transform; all subsystems consume world `Vector3` directly — no secondary origin |
| Heading | `heading = atan2(x_dir, −z_dir)` in radians, 0 = North |

Rules:

1. **One origin.** No subsystem may define a competing origin. Legacy offsets, if any
   are discovered in Prompt 01, must be migrated to this contract, never wrapped silently.
2. **Y is never part of boundary tests.** Boundary is cylindrical on X–Z.
3. **GPS ≠ local offsets.** Minimap/world-map always derive from the mapping above.
4. All conversions are pure functions of `(x, z)` + constants — reproducible, testable.

---

## 4. WORLD BOUNDARY CONTRACT — LOCKED (§6)

Conceptual rule: `r <= 2000 m` is the island domain; `r > 2000 m` is ocean.
The visible/technical boundary is a **controlled 4-band coastal termination**
(derived per §6 criteria: traversal readability, road setback, streaming margin,
camera visibility at 2 km sightlines, slope feasibility):

```text
Band                         Radial range        Width    Character
─────────────────────────────────────────────────────────────────────────
B0  Interior land            0 → 1,700 m         1,700 m  Full gameplay landmass
B1  Coastal transition       1,700 → 1,850 m     150 m    Vegetation/soil shift, shore roads end,
                                                          slope eases toward sea
B2  Beach / shoreline        1,850 → 1,950 m     100 m    Sand/rock/dune per beach class (§9),
                                                          water-depth ramp begins
B3  Outer termination        1,950 → 2,000 m     50 m     Final landfall below waves; no roads,
                                                          no buildings, no spawns
B4  Ocean domain             > 2,000 m           ∞        Water plane + seabed apron to ≥ 6,000 m
                                                          (visual horizon), hard turn-back at 4,000 m
```

Locked radii:

```text
R_world  = 2000.0   # island domain edge; ocean begins beyond
R_land   = 1950.0   # last dry-land guarantee (mean waterline ≈ 1960–1975 by class)
R_shore  = 1975.0   # nominal waterline crossing (class-dependent ±15 m, see §9)
R_beach0 = 1850.0   # beach-band inner edge
R_coast0 = 1700.0   # coastal-transition inner edge
R_ocean_visual = 6000.0   # water/seabed apron extent (rendering horizon)
R_play_limit   = 4000.0   # absolute player containment (boat/air), soft warning from 2600 m
```

Ring-area check: the four bands sum exactly to the `πR²` disc (`BND-11` PASS).

Hard guarantees:

- Ocean completely surrounds land: **no land bridge, no second continent, no square
  terrain edge visible as boundary.** Terrain mesh skirt extends to ≥ 6,000 m as
  seabed falling to `−25 m`.
- No gameplay-critical object (road node, building, POI, spawn, mission target)
  may be authored with `r > 1950`. Validation must reject it (`VAL-WORLD-01`).
- The **visual boundary = technical boundary**: waterline rendered where heightfield
  crosses `y = 0`, not at an arbitrary radius.

---

## 5. COASTLINE SYSTEM CONTRACT — LOCKED (§7)

The coastline is a **first-class spatial system**, ordered landward→seaward:

```text
COASTLINE (r ≈ 1700–2000, class spine)
  → SHORELINE (waterline crossing, y=0 contour)
    → BEACH / ROCK (material + width by class)
      → COASTAL VEGETATION (salt-tolerant fringe)
        → INLAND TERRAIN (B1 blend)
          → REGIONAL BIOME
```

The coastline generator (Prompt 03) must expose, per ~25 m arc-length sample:

```text
arc position s (0 → C), world pos, class id, waterline r, beach width,
berm height, seabed slope, material weights (sand/rock/vegetation),
navigation flag (walkable), vehicle flag, swim/boat flag, audio zone id
```

Continuity requirement: waterline contour must be a **single closed loop**
(genus-0 island). Validation: contour-tracing test must find exactly 1 loop and
0 dangling ends (`VAL-COAST-01`). Circumference of the loop will exceed 12,566 m
due to coves/inlets; budgeted at **≤ 18 km** (tortuosity ≤ ~1.43).

---

## 6. TERRAIN HEIGHT CONTRACT — LOCKED (§8)

Meters on +Y, relative to `OCEAN_LEVEL = 0.0`:

```text
Datum                  Height (m)     Notes
──────────────────────────────────────────────────────────────────
Ocean floor (min)      −25.0          Seabed apron; never above −2 m for r > 2100
Ocean level              0.0          Water plane (locked)
Wet sand                +0.2…+0.6     Wave-wash band
Dry beach               +0.8…+2.0     Berm crest ≤ +2.5 (dunes ≤ +6 local)
Coastal lowland         +2…+12        B0 fringe; ports/airport pads here
Interior average        +25…+45       Rolling gameplay terrain
Highlands               +90…+160      Named massifs; overlooks, trails
Peak maximum (cap)      +220          ABSOLUTE CAP 250 m (validation rejects above)
```

Slope/grade limits (locked for Prompt 02 terrain synthesis + Prompt 04 roads):

```text
Primary/arterial road grade:   ≤ 6% sustained, ≤ 8% short (<150 m)
Secondary/collector:           ≤ 9% sustained, ≤ 12% short
Local/rural:                   ≤ 12%, dirt/trail ≤ 18% short
Pedestrian comfort:            ≤ 15% (≈8.5°); scramble above, blocked ≥ 70° rock
General vehicle passability:   ≤ 20° slope; 4×4-only ≥ 20° (signed trails)
Urban pad flattening:          ≤ 2% within building pads
Runway strip (if airfield):    ≤ 1% over ≥ 800 m straight — MANDATORY flat site, §13
Drainage: no closed inland basin deeper than −1 m below its outlet (no accidental lakes
          except authored water bodies in the inland-water budget, 0.25 km²)
```

Average coast-to-peak grade check: `220/1500 ≈ 14.7% < 15%` (`HGT-05` PASS) —
terrain synthesis must respect this envelope.

---

## 7. REGIONAL STRUCTURE — LOCKED STRATEGY (§9, §34–35)

Final region taxonomy (11 regions; each owns gameplay purpose per §34):

| # | Region id | Share¹ | Gameplay purpose |
|---|---|---|---|
| R1 | `urban_core` (Portside City) | 4% / 0.50 km² | Mission hub, commerce, police HQ, rooftops, alleys |
| R2 | `suburban_ring` | 7% / 0.88 km² | Residential cover, safehouses, local crime loops |
| R3 | `industrial_flats` | 3% / 0.38 km² | Warehouses, stealth/combat yards, truck gameplay |
| R4 | `port_airfield` (coastal E + flat S) | 3% / 0.38 km² | Boat/air entry points, smuggling missions |
| R5 | `rural_agri` (central-south plains) | 16% / 2.01 km² | Farms, villages, road ambushes, harvest cover |
| R6 | `forest` (central-west + north) | 20% / 2.51 km² | Hunting/stealth, off-road, hiding, lumber camp |
| R7 | `hills_highland` (north massif) | 18% / 2.26 km² | Overlook, trails, radio tower, low-density chase |
| R8 | `coastal_beach` (B1–B3 ring) | 12% / 1.51 km² | Beach loops, docks, coves, tourist + smuggler POIs |
| R9 | `wetland_inland_water` | 2% / 0.25 km² | River/lake, fishing dock, slow-vehicle hazard |
| R10 | `infra_corridors` | 5% / 0.63 km² | Highway ring + arterials + power/trail easements |
| R11 | `special_restricted` (tourist + military) | 4% / 0.50 km² | Resort strip + restricted compound (escalation zone) |
| — | `reserve_buffer` (unassigned) | 6% / 0.75 km² | Breathing space / Prompt 06+ overflow — NOT filler sprawl |

¹ Shares of the 12.566 km² disc; see `WORLD_AREA_BUDGET.md` (sums to 100%, `BUD-01` PASS).

Placement principles (locked):

- **City on the east coast** (port adjacency, sunrise skyline readability from spawn
  waters), suburbs wrapping its landward side, industrial downwind/south of city.
- **Highlands north**, forest west/central, agriculture on southern flats (drainage +
  runway flatness coincide), resort strip on sheltered south-west beaches, restricted
  compound inland-north with single guarded access road.
- Deliberate transition corridors (locked experiences): `CITY→SUBURB→RURAL→FOREST→
  HILLS→COAST` (north loop), `INDUSTRIAL→PORT→BEACH→COASTAL ROAD→RESIDENTIAL`
  (east loop), `URBAN→HIGHWAY→AGRICULTURE→VILLAGE→HILLS` (south–north spine).
- Every region answers the §34 ten-question gameplay test or is reclassified as
  corridor/buffer/transition with a written justification.

---

## 8. WATER CONTRACT — LOCKED (§19)

```text
ocean_level:            0.0 m (Y), single global plane + shore-blend shader
shallow-water region:   depth 0 → −6 m,  r ≈ 1975 → 2300 m (class-dependent)
deep-water region:      depth < −6 m beyond; seabed to −25 m at apron edge
water collision:        swim/boat volume for r > R_shore where depth > −1.2 m
player containment:     soft warning r > 2600 m, hard turn-back r = 4000 m
rendering:              shore foam band keyed to depth texture + wave phase;
                        day/night + weather uniforms shared with sky system
audio:                  surf loop keyed to depth<−3 m & r<2300 m; open-sea loop beyond
 boats:                 if implemented, navmesh = water polygon r ∈ (1990, 4000)
 swimming:              if implemented, entry where depth > −1.2 m; stamina + wave push
```

Integration rule: water level, collision, audio, navigation, streaming, and minimap
shore rendering all derive from the **same heightfield + OCEAN_LEVEL** — no duplicate
waterline constants anywhere.

---

## 9. BEACH CLASS CONTRACT — LOCKED (§20)

Nine authored coastal classes tile the 360° coastline. Each class locks terrain,
material, width, depth ramp, and access flags:

| Class | Share of coast | Width (B2) | Berm | Seabed ramp | Walk | Drive | Boat | Notes |
|---|---|---|---|---|---|---|---|---|
| `sandy_wide` (tourist) | 22% | 80–100 m | +1.5 | gentle 0→−6 m over 250 m | ✓ | ✗ | ✓ | SW resort strip, umbrellas, lifeguard |
| `sandy_narrow` | 20% | 30–60 m | +1.2 | medium | ✓ | ✗ | ✓ | Default east/south shore |
| `rocky_shore` | 16% | 20–50 m | +2.0 | steep | ✓-rough | ✗ | limited | Tidepools, clifflets |
| `cliff` | 10% | 0–15 m | +8…+40 | very steep/vertical | ✗ | ✗ | ✗ | North headlands, overlooks |
| `dune` | 8% | 60–100 m | +2.5…+6 | gentle | ✓ | ✗ | ✓ | Grass-capped, wind audio |
| `urban_waterfront` | 6% | 0–30 m (seawall) | +2.0 | dredged −4 | ✓ | service | ✓ | City east edge, promenade |
| `industrial_port` | 5% | 0 m (quay) | +2.5 | dredged −8 | restricted | ✓-yard | ✓ | Cranes, containers |
| `marina_cove` | 5% | 20–40 m | +1.2 | sheltered −3 | ✓ | ✗ | ✓✓ | Docks, fuel, boat spawn |
| `hidden_cove` | 8% | 15–35 m | +1.0 | medium | trail-only | ✗ | ✓ | Smuggler POIs, 2–3 total |

Rules: class changes only at authored headland/cove nodes (no per-meter noise
flicker); minimum class run-length **150 m**; cliffs never adjacent to port classes;
every `sandy_wide` segment gets 1 lifeguard/toilet/services micro-POI; every `marina_cove`
gets boat spawn + fuel. Shares sum to 100%.

---

## 10. DENSITY CONTRACT — LOCKED RANGES (§16)

Targets per km² **by region** (not global averages). Values are authoring budgets;
Prompt 05+ population passes must land inside them:

| Region | Road km/km² | Buildings/km² | POI/km² | Veg instances/km² | Ped cap (active) | Vehicle cap (active) |
|---|---|---|---|---|---|---|
| urban_core | 18–24 | 350–600 | 25–40 | 2k–5k (planters) | 60–120 | 25–45 |
| suburban | 10–14 | 150–280 | 10–18 | 8k–15k | 25–50 | 15–30 |
| industrial | 8–12 | 60–120 | 8–14 | 1k–3k | 10–25 | 20–40 (trucks) |
| rural_agri | 3–5 | 8–20 | 3–6 | 15k–30k (crops) | 5–12 | 5–12 |
| forest | 1–2 (trails) | 0–2 | 2–4 | 40k–80k (LOD) | 2–6 | 0–4 |
| hills | 1–3 | 0–3 | 3–6 | 10k–25k | 2–6 | 2–6 |
| coastal_beach | 2–4 | 5–15 | 6–12 | 5k–12k | 15–40 | 3–8 |
| special | 4–8 | 40–120 | 10–20 | 4k–10k | 10–40¹ | 5–20 |

¹ Restricted compound uses guard AI, not ambient peds.

Global active caps (streaming-bounded, re-budgeted after Prompt 07 benchmarks):
**peds ≤ 220, road vehicles ≤ 90, parked/prop vehicles ≤ 400, visible veg instances
≤ 60k** (MultiMesh, LOD-chunked). These are ceilings, not spawn goals.

---

## 11. TRAVEL-TIME CONTRACT — LOCKED MODEL (§17)

Reference distances: center→coast `2000 m`, edge→edge `4000 m`.
Reference speeds: walk `1.4`, run `6.0`, city car `13.9` (50 km/h),
highway car `27.8` (100 km/h), boat `12.0`, aircraft `60.0` m/s.
(Validation `TRV-01…05` PASS; full matrix in clarification report §P.)

```text
Route                  Walk      Run     City car   Hwy car   Boat¹   Aircraft¹
center → coast (2 km)  23.8 min  5.6 min  2.4 min   1.2 min   2.8 min  0.6 min
N → S / E → W (4 km)   47.6 min  11.1 min 4.8 min   2.4 min   5.6 min  1.1 min
city → north peak²     ~35 min   ~8 min   ~5 min    ~3 min    —       ~1 min
city → airfield²       ~20 min   ~5 min   ~2.5 min  ~1.5 min  —       —
```

¹ Where water/air path exists. ² Winding-factor 1.3× applied. Design intent: no two
major destinations farther than **~3 min highway drive** apart; the island must feel
traversable, not tedious — density (§10) compensates for modest area.

---

## 12. LANDMARK CONTRACT — LOCKED (§18)

| Level | Count (locked range) | Examples (authored, original) |
|---|---|---|
| L1 world (visible island-wide) | 3–5 | North Peak + radio mast, City tower cluster, Grand Bridge (city↔port causeway), Lighthouse Point headland |
| L2 regional (district-visible) | 12–18 | Airport tower, port cranes, stadium, cathedral/plaza, dam/waterworks, mill/factory chimney, resort pier |
| L3 local (neighborhood) | 40–70 | Churches, markets, fuel stations, trailheads, beaches' named rocks |
| L4 micro (block/POI) | 150–300 | Murals, plaques, wrecks, viewpoints, odd trees, mission doors |

Rules: every L1/L2 landmark is a **navigation reference** (visible in fog-of-war
silhouette tests); every region owns ≥1 L2; no region without an L3 within 400 m
of any spawn point; landmarks double as mission anchors (Prompt 09).

---

## 13. WORLD GRID / SECTOR CONTRACT — LOCKED (§21)

```text
Sector size:        256 × 256 m (candidate LOCKED pending Prompt 07 benchmark
                    against 128 m and 512 m alternatives)
Grid span:          4096 × 4096 m centered on origin → 16 × 16 = 256 sectors
Sector id:          (sx, sz), sx = floor((x+2048)/256), sz = floor((z+2048)/256)
Loading radius:     3 sectors (768 m) full; 5 sectors (1280 m) impostor/LOD
Unloading radius:   6 sectors + hysteresis (no thrash within 60 s revisit)
Priority:           player sector > mission sector > vehicle-heading cone >
                    AI-active > render-far > prefetch-ring
Physics:            only sectors within 2 (512 m) simulate rigid bodies;
                    beyond = kinematic/cached
```

Benchmark rule: Prompt 07 must measure load/unload time, hitch ms, and memory for
128/256/512 m candidates on target hardware and either confirm 256 m or escalate a
contract revision with data. No silent change.

---

## 14. PERFORMANCE CONTRACT — LOCKED METHOD (§22)

No fabricated budgets. Two-stage rule:

**Stage A (Prompt 00–01): measurement scaffolding.** Instrument from day one:

```text
CPU frame, GPU frame (or UNAVAILABLE w/ reason), physics step, render draw calls,
visible instance count, NPC/vehicle active counts, streaming ms + queue depth,
sector load/unload ms, terrain gen ms, shader compile stalls, memory (RSS + VRAM if exposed)
```

**Stage B (Prompt 07): locked budgets.** After benchmarks on declared target hardware,
lock `baseline / target / warning / failure` per metric. Until then, provisional
engineering targets (NOT pass/fail gates): 60 fps @1080p desktop-class, 30 fps
floor on min-spec; streaming hitch ≤ 8 ms p95; sector load ≤ 250 ms; cold
world-build ≤ 60 s; save/load ≤ 5 s.

Any report claiming GPU/CPU numbers without a measured run is a contract violation.

---

## 15. DATA OWNERSHIP CONTRACT — LOCKED (§25)

| System | Data owner | Logic owner | Runtime owner | Save owner | Test owner |
|---|---|---|---|---|---|
| World/regions | `WorldRegistry` (resource) | world gen | streaming | save system | world tests |
| Terrain | heightfield data asset | terrain synth | terrain renderer | seed+edits only | terrain tests |
| Coast/beach | coastline data (arc table) | coast gen | terrain+water | seed+edits | coast tests |
| Roads | road graph resource | road gen | traffic + nav | seed+edits | road tests |
| Navmesh | nav bake config + tiles | nav builder | AI + traffic | derived (rebuild) | nav tests |
| Buildings/POIs | placement tables | district gen | streaming | seed+edits | placement tests |
| NPC/traffic | population profiles | spawner | AI director | dynamic state | sim tests |
| Missions | mission registry | mission logic | mission mgr | progress | mission tests |
| Economy/police | balance tables | system logic | directors | state | system tests |

Conflict rule: exactly one DATA owner per datum. Duplicates found in audit →
`FLAG → TRACE → DECIDE → MIGRATE → TEST → DOCUMENT`. Forbidden: `*_new/_v2/_final`
shadow owners without a revision record.

---

## 16. DETERMINISM CONTRACT — LOCKED (§26)

```text
MASTER_WORLD_SEED (u64, locked default: 0x1SLAND → numeric 13371337; change = revision)
  ├─ REGION_SEED     = hash(master, "region", region_id)
  ├─ SECTOR_SEED     = hash(master, "sector", sx, sz)
  │    ├─ TERRAIN     = hash(sector, "terrain")
  │    ├─ VEGETATION  = hash(sector, "vegetation")
  │    ├─ BUILDINGS   = hash(sector, "buildings")
  │    ├─ PROPS       = hash(sector, "props")
  │    └─ COAST       = hash(sector, "coast")
  ├─ ROAD_SEED       = hash(master, "roads")        # global: graph spans sectors
  ├─ TRAFFIC_SEED    = hash(master, "traffic", day)
  ├─ WEATHER_SEED    = hash(master, "weather", day)
  └─ MISSION_SEED    = hash(master, "mission", mission_id)
```

Guarantee: `same inputs + same version + same seed = same generated world`.
Runtime-only randomness (ambient AI jitter, particles) must use non-persisted streams.
Regression: Prompt 02+ ships a `world_checksum` test — regenerating the island with
the locked seed must reproduce the committed checksum or fail loudly.

---

## 17. VALIDATION & TEST CONTRACT — LOCKED STRATEGY (§44–45)

Validation layers (all automated; visual inspection is supplementary, never sole):

```text
L0 data validation (JSON/resource schema, ID uniqueness, reference integrity)
L1 geometry (radius, center, rings, heights, waterline loop, sector tiling)
L2 topology (road connectivity, nav connectivity, region non-overlap, POI-in-region)
L3 simulation (spawn safety, collision coverage, streaming load/unload, save/load)
L4 gameplay (travel-time spot checks, mission reachability, landmark visibility)
L5 performance (budgets from §14-B; fail on regression >10% vs locked baseline)
L6 regression (world checksum, golden screenshots of L1 landmarks, API locks)
```

`tools/validate_world_contract.py` is the L1 seed (53 checks, passing). Each prompt
extends it; **no prompt locks with a failing or skipped contract test.**

---

## 18. FAILURE & QUALITY RULES — LOCKED (§27, §46–48)

- **No silent failure:** every listed failure class surfaces as assertion / validation
  error / test failure / debug overlay entry. Undocumented fallbacks are violations.
- **No fake pass:** tests, thresholds, and labels (`prototype` vs `production-ready`)
  change only via documented revision with rationale.
- **Issue protocol:** REPRODUCE → ISOLATE → CLASSIFY → TRACE → ROOT CAUSE → SOLVE →
  IMPLEMENT → VALIDATE → TEST → REGRESSION → DOCUMENT → CONTINUE, with category
  from the fixed taxonomy (CODE/DATA/ARCHITECTURE/INTEGRATION/ENGINE/PERFORMANCE/
  ASSET/DESIGN/RESEARCH/TOOLING/TEST DEFECT).
- **Never-incomplete:** no prompt ends with open TODO/blocker claimed as done; every
  blocker ships with `exact blocker / evidence / options / chosen path / impact / next action`.

---

## 19. PIPELINE & DEPENDENCY ORDER — LOCKED (§30–32)

Every system follows: Requirements → Architecture → Data → Core Logic → Components →
Gameplay → AI/Player Integration → World Integration → Validation → Failure Handling →
Testing → Gameplay Testing → Performance → Integration → Regression → Documentation → LOCK.

Dependency order (violations blocked at review):

```text
terrain + region contract  →  coast/water  →  road graph + nav  →  districts/buildings
→  population/traffic profiles  →  missions/economy/police  →  micro-optimization
```

Research pipeline: RESEARCH → EVIDENCE VALIDATION → ABSTRACTION → DESIGN RULE →
REQUIREMENT → ARCHITECTURE → IMPLEMENTATION → TEST. Never `GAME → COPY`.

---

## 20. ART-DIRECTION & DATA-DRIVEN RULES — LOCKED (§42–43)

- Original visual language only: no copied palettes, skylines, signage, or landmark
  designs from any reference title. Regional identity via authored material/vegetation/
  architecture families (defined Prompt 05).
- Data-driven world: zero hardcoded `Vector3` spawn/placement constants in gameplay
  scripts. Regions, sectors, roads, POIs, buildings, biomes, coast sections, landmarks,
  spawn/mission zones live in versioned data (Godot Resources + JSON interchange);
  scripts consume data through registries (§15).

---

## 21. SCOPE EXCLUSIONS (locked for Prompts 01–10)

Out of scope unless a revision re-admits with budget: multiplayer/netcode, interiors
beyond mission shells, full underground/metro, aircraft flyable fleet (AI + 1 player
prop plane max), modding SDK, console ports, localization beyond EN+1.

---

## 22. REVISION RECORD

| Rev | Date | Change | Reason |
|---|---|---|---|
| 1.0.0 | 2026-09-20 | Initial lock (Prompt 00) | Genesis contract |

*End of WORLD MASTER CONTRACT v1.0.0.*
