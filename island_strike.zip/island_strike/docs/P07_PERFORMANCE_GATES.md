# P07 PERFORMANCE GATES

Environment: CURRENT_ENVIRONMENT (2 vCPU, ~1 GB, Python 3.13,
Godot 4.7.2 headless, no GPU). Production: PROVISIONAL.

## Locked gates (measured, p07bench1 + perf suite)

| metric | gate | tolerance (regression) |
|--------|------|------------------------|
| steady frame p95 | 5.240 ms | ×2.0 |
| traversal frame p95 | 4.467 ms | ×2.0 |
| worst frame | 61.347 ms | ×2.0 |
| sector load p95 | 15.383 ms | ×2.0 |
| sector activation p95 | 0.369 ms | ×2.0 |
| manifest query p95 | 0.805 ms | ×3.0 |
| LOD eval p95 | 2.792 ms | ×2.0 |
| mem peak (traversal) | 5.475 MB | ×1.2 |
| cache peak | 4.169 MB | ×1.5 |
| city resident | 2.011 MB | ×1.2 |
| hotspot resident (46 bld) | 2.168 MB | ×1.2 |
| active peak | 23 | ×1.5 |
| queue peak | 11 | ×2.0 |
| spikes / traversal | 1 | ×3.0 |
| empty-sector objects | ≤12 | absolute |
| empty-sector mem | 6.421 KB | ×2.0 |
| hotspot buildings cap | 64 | absolute |
| revisit cache hit floor | 0.15 | absolute |

## Method

Every number ships with its test context (suite, path, repeats,
commit, CPU, engine) in `reports/p07_size_compare.json` and
`reports/p07/performance evidence`. Spikes are first-class: the
50 ms threshold counts genuine sim frames only (memory sampler
runs outside the frame clock — see P07-D4). GPU/VRAM: NULL
(headless; no GPU context) — never approximated from CPU metrics.
