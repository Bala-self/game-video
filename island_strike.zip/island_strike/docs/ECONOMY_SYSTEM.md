# ECONOMY_SYSTEM (P10)

## Ledger (owner: P10, currency ISC)

Ops: CREDIT, DEBIT, HOLD, RELEASE, REFUND. Every record carries
`transaction_id, actor, op, amount, reason, source, balance_before/after,
tick`. Validation rejects: `invalid_amount` (negative/zero), `overflow`,
`insufficient_funds`, `invalid_source`, `unknown_op`, `unknown_hold`,
`release_needs_hold_ref`, bad refund origin. Balance starts at 500 ISC
(sim default; engine verifier links records instead of assuming it).

- Idempotency: re-submitted IDs return `DUPLICATE_NOOP` with no mutation
  (also across save/load restore — txns re-seeded by ID).
- Holds reserve funds (debits that would breach reserve are rejected);
  RELEASE references the hold via `source="hold:<id>"`; holds expire after
  600 ticks.
- Fine overdraft is explicit (`allow_overdraft`, police fines only);
  everything else cannot overdraw.

## Prices and shops (measured)

80 shops / 162 prices, economy checksum `5e54fd5503902fcf`. Buy requires
shop proximity (too-far rejected, unknown shop rejected); sell pays 50%.
Reward `rew:<mid>:<iid>` credits mission money exactly once.

## Evidence

- ECONOMY-GAMEPLAY 18/18 (ops, rejects, idempotency, buy/sell, overdraft,
  hold expiry, refund origin).
- Final smoke s20 (reward `rew:M-TRAVEL-01:MI-0001`), s31
  (`buy:SHOP-BLD-D-farmB-1:2`); long-run buy+sell ×3 rounds; probe ledger:
  2 txns (reward + arrest fine) over the instrumented session.
- Section cost: 0.002 ms/tick mean.
