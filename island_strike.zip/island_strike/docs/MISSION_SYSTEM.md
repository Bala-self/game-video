# MISSION_SYSTEM (P10)

## Corpus (measured)

16 missions / 36 objectives / 80 shops feed the system; mission checksum
`45f35814de3728ea`, objective-graph checksum `4c3a9e86734e6aa5` (acyclic,
verified by STATIC). Templates: 14 + 2 chain seconds (M-TRAVEL-02 behind
M-TRAVEL-01, M-DELIVERY-02 behind M-DELIVERY-01). All 16 start (smoke
completes chain predecessors first).

## Lifecycle machine (contract-owned)

AVAILABLE → OFFERED → ACCEPTED → STARTING → ACTIVE ⇄ CHECKPOINT →
SUCCEEDED / FAILED / ABORTED → COOLDOWN → AVAILABLE (retry path).
Every transition validated against the machine; illegal attempts rejected
and logged (suites assert zero).

- Single-active (P10-D1): second accept/start returns
  `second_active_rejected`.
- Start conditions: player_at radius, wanted_max, sector_ready,
  prev_mission, cooldown — `start_reasons()` reports all unmet causes.
- Checkpoints: approved snapshots (pos, vehicle, objectives, progress,
  timer, flags) after configured objectives; retry restores the latest and
  increments the per-mission attempt counter. Abort also stashes (§15).
- Failure reasons: TIMEOUT, OBJECTIVE_FAILED, NPC_LOST (P09-locked rule:
  role-NPC despawn fails the mission), role_spawn_failed:*.
- Rewards: exactly-once `mission_reward` txn per completion
  (`rew:<mid>:<iid>`), sealed flag + idempotent ledger; verified across
  save/load (save-edge 15/15).

## Roles and pins

- NPC roles: P09 `spawn_check` + `acquire` on a 16-slot ring anchored at
  the walkable origin node (P10-D2); tagged `mission_role` /
  `mission_instance`; lawful `despawn` on cleanup.
- Vehicle roles: P08 `try_spawn` + `pin` (persistent while owned);
  `unpin` + retire on cleanup.
- Mission sector pin (`mission:<iid>`, 36000 ticks) released on cleanup.
  Long-run holds pins_npc at 0 between rounds; stress ≤ 2 owned pins.

## Evidence

- MISSION-GAMEPLAY 16/16, INTEGRATION 5/5, final-smoke steps 05/09/10/11/
  18/19/24/25/26, long-run failure→retry cycles ×3, save-edge mission
  identity + digest-stable load (`e2bb71c87c3180cf` across save/load).
