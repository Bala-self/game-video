# ISLAND STRIKE — PROMPT 05 REPORT (transport infrastructure)

Physicalized bridges, tunnel, retaining, barriers, markings, and
reservations over the LOCKED P03 graph + P04 surfaces. Nothing upstream
rebuilt, re-authored, or moved: P03 `0e28622c1bb2185b`, P04 geometry
`69ca624214ee76fe` (analytic `289dc64a92df86fc`, mesh `6996a47d274da230`)
verified stable at lock, P01–P04 suites re-green.

## §1 INPUTS (pinned versions)

| input | version | checksum |
|---|---|---|
| P03 roads | 0.1.0 | `0e28622c1bb2185b` |
| P04 geometry | 0.1.0 | `69ca624214ee76fe` |
| terrain / coast / world | 0.1.0 | via contracts |
| structure / marking / reservation | 0.1.0 (new) | stale-refusal gated |

Generator preflight refuses to run unless pinned versions + checksums
match. Source values consumed, not recomputed: BC-01
E_radial_west_01 wet d50.13–100.25 deck_floor 21.405; BC-02 E_ring_hw_02
wet d1426.67–1479.47 deck_floor 5.070 clearance 4.259; tunnel
E_ring_hw_north_tunnel_00 bore d60.0–2079.8; 18 P04 cuts; 121
connectors (UTURN47/RIGHT18/LEFT16/STRAIGHT16/RB_ENTRY6/RB_EXIT6/
TUNNEL_TRANS6/BRIDGE_TRANS4/MERGE2).

## §2 OUTPUTS

| file | content | size | checksum |
|---|---|---|---|
| data/derived/transport_structures.json | bridges/tunnel/walls/barriers/dressing | 1.15 MB | `656214306d5855e4` |
| data/derived/transport_markings.json | 323 markings + skips | 2.38 MB | `76fb0434620d9f22` |
| data/derived/transport_reservations.json | 13 layers + 442-cell index | 0.13 MB | `4d1c21f427bc3d4c` |
| data/derived/transport_handoff_ext.json | nav/traffic/collision pins + semantics | 0.002 MB | sha-pinned |
| reports/p05_safety.json | independent safety measurements | — | — |
| reports/p05_transport_golden.json | regress snapshot | — | — |
| reports/p05_transport_infrastructure_summary.json | machine summary | — | — |

Mesh: 43 structure parts (8506v/7586t) + 52 marking parts
(24379v/22279t, all up-facing in engine recompute).

## §3 BRIDGES (BC-01/BC-02 physicalized)

Parapets + fascia follow P04 ribbon edge verts over the FULL wet span
(interpolated wet ends; validator mirrors the lerp bitwise): measured
50.13/50.13 m and 52.79/52.79 m per side. Abutment boxes under both deck
ends, buried (min 0.5 m stem, never inverted — D-12). Piers: none, by
policy without source bathymetry (D-03), gated count == 0. Water
clearance 2.50 m both crossings. Concrete/steel material IDs, LOD +
streaming metadata per component.

## §4 TUNNEL (bore + portals)

Lining over bore d60–2079.8 (2244 verts), apex clearance exactly 6.00;
traveled-way min 5.88 vs 5.0 required (lane geometry from the profile
registry); walkway headroom min 4.21 vs 2.5 gate (D-08). Two headwalls +
four wingwalls at the portal planes; portal hazard markers flank the
headwall at road level; walkway bollards just inside the bore, off lanes
(D-09). 40 mount zones, maintenance + pulloff staging reservations.

## §5 RETAINING (18 cuts, none dropped)

28 dispositions: 10 retaining_wall, 8 natural_slope, 8 mixed, 2
portal_treatment. 10 walls face the road by terrain majority vote with
uniform winding (D-04). Lip treatments recorded; every wall has a
retaining_footprint reservation with a sane bbox.

## §6 BARRIERS (measured need)

12 runs (9 guardrail, 1 concrete, 2 curb) from per-station-pair
cliff/embankment/curve risk; all outside junction discs; none blocks a
legal connector (cross-gated). 204 delineators (curves/highland/
approaches only), 16 hazard markers, 8 bollards. Residual: 6 short segs
(38 m, min-run rule), 0 long unprotected gaps (D-05). Concrete/curb
sections run on travel-perp frames with flat caps; guardrail is
single-sided with local outward hints.

## §7 MARKINGS (movement-faithful paint)

323 records: guidance 112, turn_arrow 81, edge 80, lane 28, centerline 9,
yield 6, hatch 5, stop 1, island ring 1. Connector coverage 121/121:
111 marked, 10 explicitly skipped (6 junction-None transitions, 4
bridge/tunnel continuity), 0 missing, 0 disallowed, arrows never on
STRAIGHT, yields only on roundabout entries (D-06). Contact two-tier:
verts ≤ 0.035, centroids ≤ 0.08 (D-07). Strips use unflipped propagated
frames (no twist through curls); closed rings wrap.

## §8 RESERVATIONS + QUERY API

13 layers, 426 reservations, every id indexed (442 cells). Strips per
edge (safety/veg/setback), junction discs, 38 class-derived sight
triangles, bridge/tunnel exclusions, wall footprints, 65 sign anchors,
195 street lights, utility strips, maintenance/pulloff areas. Spatial
query API: tools/reservation_index.py (ReservationIndex), self-tested;
validator exercises it (is_reserved/types_at/nearest/veg/building/
junction-excluded).

## §9 VISIBILITY / LIGHTS / SIGNS

38 sight triangles from class sight distances. Signs nudge out of ALL
triangles by compass search preserving own-edge clearance: 0 conflicts
(D-10). Lights by regional policy (urban 35 m / infra-primary 70 m /
dark zones none): 195 lights, 0 in forest/highland. No sign or light on
the traveled way (3D off-road gates).

## §10 DRESSING + HANDOFFS

888 skirt-dressing segments (soil/rock/grass/mixed) at half+2 m —
classification only, never hides lips or defects. Handoff extensions in
the NEW transport_handoff_ext.json: nav/traffic/collision sha-pins,
barrier runs, bridge clearances, tunnel interior, marking semantics,
access restrictions. No locked P04 artifact modified (D-11, D-01).

## §11 MESH DOCTRINES

Flat caps use dedicated verts (never shared with walls); boxes are
per-face (flat normals); strips propagate unflipped frames; wall
winding is majority-vote uniform; q6 chainage meets 1e-6 validator
tolerances (D-13). Zero unused verts, zero degenerate tris, zero
non-finite values across 95 parts / 29865 tris (engine-verified index
ranges + min area 3.9e-03).

## §12 SUITES (all green)

| suite | result | notes |
|---|---|---|
| STATIC-STRUCTURE | 456/456 | versions/mesh/bridges/tunnel/walls/barriers/marks/resv/trace/safety/hairpin |
| CROSS-STRUCTURE | 23/23 | P03/P04 identity + engine metrics agreement |
| INJECT-STRUCTURE | 6/6 | flip/stale/drop/phantom/move/drop all refused |
| REPRODUCE-STRUCTURE | 7/7 | 3 checksums + 4 file shas stable |
| SMOKE-STRUCTURE | 13/13 | rebuild + inventory gates |
| PERF-STRUCTURE | 3/3 | build 2.6 s, static 4.5 s, 3.7 MB |
| REGRESS-STRUCTURE | 1/1 | golden match |
| IMPACT-STRUCTURE | 7/7 | upstream untouched |
| SAFETY-STRUCTURE | 1/1 | reports/p05_safety.json written |
| engine structure_check.gd | STRUCTURE_OK | 43/7586 + 52/22279, all marks up |

Upstream re-green at lock: P01 78/78, P02 146/146, P03 62/62 + 7/7,
P04 150/150 + 13/13 + 1/1 + 8/8.

## §13 PORT NOTES (Godot side)

tests/godot/tools/structure_check.gd mirrors geometry_check.gd:
`--verify/--marks/--resv/--metrics`, STRUCTURE_OK/FAIL, exit 0/2.
Scalar floats only; JSON parses in-engine (proves Godot-readable).
Bounds per part in metrics for streaming bounds. Marking parts are
pure up-facing paint (lift 0.02); structure parts are outward-wound
classified walls.

## §14 DEFERRED (recorded, not dropped)

- Piers: need source bathymetry + a pier prompt (D-03).
- bus_stop / bench_bin layers: no transit/pedestrian data in P03/P04
  (recorded in not_applicable with future owners).
- Collision/nav/traffic final systems consume the handoff pins; P05
  ships inputs, not the systems.
- Chunked LOD/streaming meshes: bounds + order metadata shipped; mesh
  chunking stays with the world-streaming prompt.

## §15 LOCK STATEMENT

P05 is COMPLETE and green: 9/9 suites, engine check, upstream re-green,
golden + safety + summary written, decisions logged, repo contains only
intended new files plus pre-existing P02–P04 dirt. P03 graph and P04
surfaces provably untouched. Ready to LOCK — STOP, wait for NEXT.
