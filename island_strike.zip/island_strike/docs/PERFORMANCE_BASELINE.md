# ISLAND STRIKE — PERFORMANCE BASELINE (Prompt 01)

```text
GATING: NON-GATING. This is Stage-A instrumentation + first measurements.
Final budgets lock at Prompt 07 (DR-20). Nothing here gates any test.
```

## What was measured (all values real, 2026-09-20, HEADLESS_DUMMY)

Environment: Godot 4.7.2-stable, Linux x86_64, 2 CPU, ~2 GB RAM.
Artifacts: `reports/performance/{environment,foundation_baseline,bootstrap_baseline,runtime_baseline}.json`.

### Process / bootstrap (macro, cold starts)

| Metric | n | min | mean | median | max |
|---|---:|---:|---:|---:|---:|
| process wall (engine start → quit after 30 frames) | 5 | 0.437 s | 0.440 s | 0.440 s | 0.442 s |
| in-engine bootstrap (BOOT→READY, 41/41 checks + shell) | 5 | 8.19 ms | 8.91 ms | 8.83 ms | 9.86 ms |

### In-engine micro-benchmarks

| Metric | n | min | mean | median | max | p95 |
|---|---:|---:|---:|---:|---:|---:|
| A shell build (17 nodes + free) | 5 | 1.85 ms | 2.88 ms | 1.89 ms | 6.87 ms | — |
| B script resource load (warm) | 21 | 1 µs | 3 µs | 2 µs | 11 µs | 10 µs |
| B icon load (one-shot) | 1 | 0.36 ms | — | — | — | — |
| C JSON contract load+parse | 21 | 32 µs | 35 µs | 33 µs | 56 µs | 41 µs |
| D registry init | 21 | 7 µs | 9 µs | 8 µs | 26 µs | 17 µs |
| E sector census (256 sectors) | 11 | 0.61 ms | 0.68 ms | 0.66 ms | 0.78 ms | — |
| E sector batch (5000 conversions) | 1 | 1.11 ms | — (≈0.22 µs/op) | — | — | — |
| F seed derive (single) | 21 | 6 µs | 7 µs | 7 µs | 17 µs | 9 µs |
| F seed batch (1000 derivations) | 1 | 6.93 ms | — (≈6.9 µs/op) | — | — | — |
| G full validation run (V1+V2+V3) | 11 | 0.41 ms | 0.44 ms | 0.42 ms | 0.53 ms | — |
| H diagnostics (100 log lines) | 11 | 0.52 ms | 0.55 ms | 0.54 ms | 0.59 ms | — |

### Steady-state frame (dummy driver — process-loop signal only, NOT render signal)

60 frames/run × 3 runs: mean-of-means **7.75 ms** (~130 fps equivalent);
per-run means 7.66 / 7.90 / 7.70 ms; medians 6.67 ms; p95 ≤ 8.33 ms.
Mode label `HEADLESS_DUMMY` on every record. This measures script/process cost
with zero render work — useful ONLY as a later regression tripwire.

### Memory (OS.get_static_memory_*, bytes)

Static ≈ 25.9 MB before → 26.8 MB after micro-suite; peak 29.6 MB.
VRAM: UNAVAILABLE (no counters under dummy driver).

### Explicitly unavailable (§22)

`gpu_frame_time`, `render_draw_calls` (and all VRAM/thermal/GPU numbers):
`value=null, status=unavailable` with reason in the baseline JSON. Final frame
budgets are impossible before real rendering exists — that is Prompt 07's job.

## Provisional observations (NOT budgets, NOT gates)

- Foundation overhead is ~9 ms boot + sub-ms validation: negligible headroom cost.
- Seed derivation (~7 µs) and sector mapping (~0.2 µs) are cheap enough for
  per-frame use if ever needed; census (0.66 ms) is a load-time/LOD operation.
- Shell build first-sample cost (6.87 ms max vs 1.89 ms median) shows normal
  first-touch allocation warmup — recorded, not chased.

## Regression hook

`python3 tools/benchmark/compare_baseline.py BASE CURRENT` classifies mean
deltas: <25% informational, 25–100% warning, >100% critical. Informational-only
in Prompt 01; gates belong to Prompt 07.
