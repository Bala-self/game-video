# SAVE_LOAD_SYSTEM (P10)

## Format (schema checksum `73a48ceeb5e98ac9`)

`reports/p10/saves/<slot>.json`: `{schema:"p10save", save_version:1,
gameplay_world_state_version, player, wallet, transactions_tail,
missions_completed, active_mission, wanted, unlocks, world_flags,
seed/version metadata, checksum}`. Checksum = fnv1a64 over canonical
core; mismatch → `bad_checksum`, live state untouched. Unknown versions
→ `unsupported_version`. v0 migrates (defaults wallet 0, wanted NONE).

## Restore semantics (measured, save-edge 15/15)

- Active mission: silent teardown of same-mid runtime (no cooldown side
  effects), machine placed at ACCEPTED (restore is not a gameplay
  transition), `_restore` start (volatile checks skipped — legality was
  proven at save time), then objectives/progress/checkpoints/attempt/
  timer/npc_pos reapplied. Loads never increment attempts.
- Role-NPC positions persisted (`npc_pos`) — digest identical across
  save/load (`e2bb71c87c3180cf`).
- Mission identity: same mid + attempt + restored objectives; no duplicate
  NPCs (1→1), reward still exactly-once after completion + reload.
- Wanted: level restored exactly; pursuit units transient by design
  (stand down on load; fresh crime re-dispatches).
- Economy: `transactions_tail` re-seeded by ID; re-submission returns
  `DUPLICATE_NOOP` — no double-spend across save/load.
- Holds are not persisted (volatile reservations); wallet balance exact.

## Edge stress (§90, 15/15)

save→load→save, abort→save→load→retry, complete→save→load (reward-once),
wanted→save→load (level-consistent)→fresh-pursuit→escape, economy
idempotency across loads; pins 0, subs 0, zero leaks/illegals, clean
shutdown. Final smoke s21–s23: save 245 ISC → dirty → reload → exact.
