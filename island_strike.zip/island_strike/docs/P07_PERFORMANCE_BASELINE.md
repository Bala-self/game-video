# P07 PERFORMANCE BASELINE

Canonical data: `reports/p07_performance_baseline.json`.
Baseline id: `6586663644bed80f`.

## Identity

- world checksum: P00 contract (see baseline JSON)
- P06 aggregate: `a808c338fc8ae499`
- sector version 1.0.0, size 256 m
- LOD checksum: `b8df59a10ec1f39d`
- bench suite p07bench1, engine 4.7.2.stable.official.ed1daf0bf
- CPU: measured host (see JSON context); renderer headless/none
- status: CURRENT_ENVIRONMENT; production TARGET_ENVIRONMENT_PENDING

## Results (clean run, 2 reps, deterministic)

See `reports/p07_size_compare.json` matrix + `reports/p07/perf_measure.json`:

- steady frame p95 5.240 ms; traversal p95 4.467 ms; worst 61.347 ms
- sector load p95 15.383 ms; activation p95 0.369 ms
- manifest query p95 0.805 ms; LOD eval p95 2.792 ms
- mem peak 5.475 MB; cache peak 4.169 MB; city 2.011 MB
- active peak 23; queue peak 11; spikes 2/traversal
- hotspot SX12Z07: 46 buildings, 516 objects, 2.168 MB
- empty sector: 4 objects (terrain base), 6.4 KB
- revisit cache hit 0.214–0.228 (pressured); linear paths ~0 by design

## Regression use

Future phases compare against these gates with the tolerances in
`docs/P07_PERFORMANCE_GATES.md`. Any gate breach blocks lock until
PROFILE → LOCATE → CLASSIFY → FIX → MEASURE → REGRESSION.
