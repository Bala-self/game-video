# P06 HANDOFF — AI

Consumer file: `data/derived/p06_handoff_ai.json` (403 rows, no orphans).

Every building maps to exactly one activity role:

| occupancy | activity |
|-----------|----------|
| residential | reside |
| commercial | shop_work |
| civic | civic_visit |
| industrial | work_logistics |

Rows also carry class + building id for schedule/behavior lookup.
Restricted-district buildings keep industrial/civic occupancy; treat
`D-res-secure` + `standoff_open` space as access-controlled in AI
director logic (see audit `restricted_58` in `places.json`).

Future work (not P06): crowd density by district profile, day/night
schedules, port/airfield shift logic.
