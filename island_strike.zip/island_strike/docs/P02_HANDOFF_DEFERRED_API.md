# P02 HANDOFF — DEFERRED WORK + CONSUMER API

## Deferred (not in P02 scope)

1. COLLISION (geometry + physics baking) — future contract: REPORT §10.
   Entry criteria for the owning prompt: preview mesh vertex order +
   authoring corridors as source; height queries via terrain_field twin;
   CROSS-TERRAIN re-proof; §6 seam bounds on every chunk edge.
2. P07 mesh pipeline proper (LOD, streaming, chunking) — accepts
   preview/terrain_preview.obj + terrain_preview.json as the meshability
   proof (build_preview_mesh.py --selftest is the gate).
3. P05 pad search consumes data/derived/urban_zones.json (checksum
   f25c6037e5edab15, 7 components): schema {rule, cell_m, extent,
   min_component_m2, versions, components[{id, n_cells, area_m2, bbox,
   cells}]}.

## Consumer API (stable within 0.1.0)

GDScript: scripts/terrain/terrain_field.gd — initialize(tc,cc,au,wc) →
height(x,z) / height_raw(x,z,with_noise) / slope_grade(x,z) /
region_at(x,z) / lut[] / coast_length / lut_n. CLI:
tests/godot/tools/terrain_check.gd -- --dump|--validate|--bench N.

Python: tools/terrain_model.py Field (same surface + fnv1a_hex);
tools/terrain_cli.py generate|validate|checksum|report;
tools/terrain_cache.py cached_grid (versioned derived-grid cache);
tools/derive_zones.py; tools/build_preview_mesh.py;
tools/render_terrain_maps.py.

## Breaking-change rule

Any field-math change MUST bump terrain_version/coast_version/
authoring_version (S-ver:* pins fail otherwise) and re-prove CROSS +
all 27 lock criteria before the next lock.
