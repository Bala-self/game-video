# Prompt 10 — Gameplay Final Report (Missions / Wanted / Economy / Lock)

Date: 2026-09-22. Engine: Godot 4.7.2-stable headless. Environment: sandbox
2 vCPU, Python 3.13. Production perf certification: PROVISIONAL.

## Verdict

P10 FINAL LOCK. 14/14 suites, 134/134 checks, 0 FAIL. Final smoke 36/36.
Completion matrix: 54 VALIDATED, 3 MEASURED, 2 DEFERRED, 1 NOT_APPLICABLE,
0 unresolved / 0 unknown-owner / 0 TODO / 0 broken.

## Final checksums (logical, fnv1a64)

| artifact | checksum |
|---|---|
| gameplay | `e5e9700a8291bd53` |
| mission | `45f35814de3728ea` |
| objective graph | `4c3a9e86734e6aa5` |
| economy | `5e54fd5503902fcf` |
| wanted | `f0b2d78281535f5c` |
| events | `161c1ae765d32666` |
| save schema | `73a48ceeb5e98ac9` |

Corpus: 16 missions, 36 objectives, 80 shops, 162 prices, 6 world events,
18 upstream source pins (all verified, zero drift).

## Validation results (measured)

| gate | result | evidence |
|---|---|---|
| 14 GAMEPLAY suites | 134/134 PASS | reports/p10/gameplay_report.txt |
| final smoke (§86, 35 steps) | 36/36 in 304.4 s, 5705 ticks | reports/p10/final_smoke.json |
| world coverage (§87) | 12/12 districts READY | reports/p10/coverage.json |
| full-stack stress (§88) | STRESS_OK, 1200 ticks | reports/p10/stress.json |
| long-run (§89) | LONGRUN_OK, 3 rounds, 4743 ticks | reports/p10/longrun.json |
| save/load edge (§90) | 15/15 | reports/p10/save_edge.json |
| impact (§83) | 16/16, all restored byte-identical | reports/p10/impact.json |
| clean rebuild ×2 (§82) | byte-identical + GREEN ×2 | reports/p10/rebuild.json |
| engine data-only | GAMEPLAY_OK, 18 pins | reports/p10/gameplay_check.out |
| engine runtime parity | GAMEPLAY_OK on live dump | reports/p10/gameplay_runtime.json |
| completion matrix (§84) | zeros verified, 60 reqs | reports/p10_completion_matrix.json |
| machine summary (§95) | written, no nulls | reports/p10_gameplay_summary.json |

## Performance (measured, process_time_ns)

- Full-stack dense-city tick: mean 31.586 ms, p95 61.115 ms (~500 NPC, ~220 veh).
- P10 sections combined: 0.135 ms/tick mean (mission 0.013, wanted 0.098,
  events 0.007, economy 0.002, triggers 0.002, player 0.013).
- Peak RSS (stress): 65652 KB. Long-run RSS growth: +13516 KB / 4743 ticks.
- All 6 §91 gates PASS; production PROVISIONAL (no target hardware).

## Key decisions

- P10-D1: single active mission, enforced (second start rejected).
- P10-D2: objective/start points snap to walkable nav nodes (raw POI sat
  inside building footprints and failed role spawns).
- Pursuit units are transient across save/load (level persists, units stand
  down); fresh witnessed crime while wanted re-dispatches.
- Units lost beyond relevance with a cold trail (>300 unseen) complete as
  ESCAPED, never silently ABORTED.
- Save persists role-NPC positions, per-mission attempt counters, and the
  latest approved checkpoints; loads never count as attempts.
- Digest v2 excludes append-only bus length (telemetry, not state).

## Bugs found and fixed in-prompt (§94)

1. RELEASE could never address a hold (txn-id namespace clash) → holds now
   referenced via `source="hold:<id>"`.
2. load_game dropped the active mission (abort-then-restore deadlock) →
   silent teardown + direct ACCEPTED placement + `_restore` start path.
3. APPROACH had no lost-sight edge → fleeing before contact soft-locked the
   pursuit; added APPROACH→SEARCH (contract already allowed it).
4. act_abort didn't stash checkpoints → retry-after-abort restores them now.
5. _escalate mixed order-index with level-number (repeat crime always +1) →
   level-number comparison + re-dispatch rule.
6. Role-NPC respawn drift across save/load → npc_pos persisted in saves.

No P01–P09 file was modified for P10 (impact test proves containment).
No P11. Future work follows docs/P10_FINAL_HANDOFF.md ownership.
