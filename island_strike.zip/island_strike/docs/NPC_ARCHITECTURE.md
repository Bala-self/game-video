# NPC / PEDESTRIAN / NAVIGATION / AI RUNTIME ARCHITECTURE (P09) — LOCKED

Upstream P00–P08 LOCKED. Pins: nav `3f9a234fcffe672a` · pop
`fd1f5bdeeb7e95e7` · pol `5b59d290bb0de76b` · beh `0f3fde2cdb1da2c8` ·
perc `71e6e20d666e14df`.

## 1. Representation (P09-D1)

Derived hybrid (no engine nav stack in-repo to extend):

- **AREAS** (127): walkable polygons from P06 open spaces with
  `navigation_policy == walkable`, arrival envelopes, beach access.
- **GRAPH** (1087 nodes / 2348 edges): ENTRY (403 P06 nav-handoff
  rows), AREA_CENTROID (126), AREA_MID (450), LANDMARK (33 attached
  of 34 `at` rows; 1 dropped, recorded), ARRIVAL (7), CROSSING_END
  (68). Edges are explicit typed links: AREA_ADJACENCY,
  BUILDING_ENTRY, CROSSING, SECTOR_PORTAL (+ scaffolding). Roads are
  blockers except through CROSSING links (§23).
- Movement: A* + straight-line-in-area + corridor follow + validated
  local avoidance. One navigation truth shared by sim + engine check.

## 2. Structures (P09-D2)

No P05 walkway evidence for BC-01/BC-02/tunnel bore → zero ped links
emitted there; rejection tested (navigation, smoke steps 14/16).

## 3. Services (single owners, all in `tools/npc_sim.py`)

NPCRegistry (semantic `NPC-%06d` identity, no duplicate actives) ·
PopulationService (targets/peaks/abstract counts) · Spawn/Despawn
(§10 checks, defer/reduce, §47 safety) · NavigationService (manifest
queries, READY gating) · PathService (A*, versioned cache, 8/tick
budget, recovery order) · MovementController (corridor, crossing
WAIT/COMMIT/CANCEL) · PerceptionService (64/tick, 512-ray law,
hearing, witness) · BehaviorService (8-state machine) ·
TrafficAwareness (read-only P08 TTA) · StreamingService (P07 states,
expiring pins) · SimulationScheduler (T0–T3 + budgets) ·
Diagnostics/Profiler/Validator (counters, CPU, 12 suites).

## 4. Data flow

Locked P02/P04/P05/P06/P07/P08 → `npc_gen` → navigation + population
manifests + spawn zones + behavior/perception policies → `npc_sim`
runtime → engine `npc_check.gd` (NPC_OK) + `validate_npc.py` 12 suites
→ summary / goldens / completion matrix.

## 5. Tiers

T3 full (<60 m) · T2 simplified (<150 m) · T1 proxy (<400 m) ·
T0 abstract (beyond). Non-READY sector ⇒ T1 max. Transitions preserve
identity/position/sector/destination/progress/seed (§44).

## 6. Determinism

Fixed-step 10 Hz. All RNG from `npc:` namespace streams
(spawn/destination/path/behavior/perception/schedule). Canonical
sorted records. Replay: same tag + pins ⇒ identical event stream
(reproduce suite: identical, wall-timing-independent, seed-sensitive).

## 7. Budgets

8 path queries/tick · 64 perception queries/tick · ≤512 LOS rays/tick
(8/scan cap) · 16 hearing events/tick · P08-D12 CPU-time gates
(ai 4.0 / nav 0.5 / perc 0.5 ms @100, 256 MB @1000).

## 8. Subsystem docs

`NPC_NAVIGATION.md` · `NPC_POPULATION.md` · `NPC_BEHAVIOR.md` ·
`NPC_PERCEPTION.md` · `NPC_PERFORMANCE.md` · `P09_HANDOFF_MISSIONS.md`
· decisions in `P09_DECISIONS.md` · completion in
`PROMPT_09_NPC_REPORT.md`.
