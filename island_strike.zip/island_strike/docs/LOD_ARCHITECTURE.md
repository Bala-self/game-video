# LOD ARCHITECTURE (P07)

Policy: `data/derived/lod_policy.json` (checksum `b8df59a10ec1f39d`).

## Levels

FULL → SIMPLIFIED → PROXY → UNLOADED (valid subsets per category).

| category | FULL ≤ | SIMPLIFIED ≤ | PROXY ≤ | proxy |
|----------|--------|--------------|---------|-------|
| buildings | 150 m | 400 m | 900 m | shared mass proxy by height band |
| landmarks | 600 m | 1500 m | 4000 m | shared silhouette per kind |
| roads (local) | 250 m | — | 600 m | ribbon centerline proxy |
| roads (primary+) | 800 m | — | 2000 m | same |
| structures | 500 m | — | 1500 m | shared span/box proxy |
| detail | 200 m | — | — | none (near-field only) |

## Hysteresis

Exit = enter × 1.15 at every threshold; upgrades immediate,
degrades only beyond exit. Oscillation fixture (40 probes around
150/172.5 m) yields ≤1 change. Importance shifts levels
(CRITICAL +2 … BACKGROUND -2); route-pinned roads pin CRITICAL so
the driven road never drops first; semantic correctness is never
overridden.

## Streaming interaction

Object LOD is UNLOADED unless its sector is ACTIVE (STRUCT
components: unit ACTIVE + ACTIVE user). LOD eval is budgeted
(2000/tick) and measured (p95 2.2 ms city). Landmark identity is
stable across LOD; no 403 unique far meshes — shared proxies.
