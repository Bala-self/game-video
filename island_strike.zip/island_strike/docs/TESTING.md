# ISLAND STRIKE — TESTING (Prompt 01, §33–35)

## Layers

| Layer | What | Runner | Count (locked) |
|---|---|---|---|
| L1 pure data | Prompt 00 math (geometry/boundary/height/budget/travel/sector/coordinate) | validate_world_contract.py | 53/53 |
| L1 pure data | foundation static (schema, locked consts, AAA schemas, golden) | validate_foundation.py static | 78/78 |
| L2 pure logic | seeds/coords/sectors/loader/checksum/diag/bench | in-engine test_runner | part of 207 |
| L3 integration | boot chain, shell nodes, disk==registry, census goldens | in-engine test_runner | part of 207 |
| L3 cross-impl | GDScript↔Python agreement (canonical, checksum, seeds, census) | cross | 31/31 |
| L4 runtime | main-scene smoke 30f + log audit | --quit-after + audit-log | 2/2 |
| L5 performance | micro + macro benches | bench scripts | 10/10 macro |
| L6 regression | inject (13 mutants) + reproduce (2-run stability) | validate_foundation.py | 13/13 + 7/7 |

In-engine total: **207/207** across 8 suites (6 unit + 2 integration).

## Commands (CI path = run_all_tests.sh, 12 steps)

```bash
export GODOT_BIN=<path>            # or: python3 tools/fetch_godot.py (pinned 4.7.2)
bash tools/run_all_tests.sh        # everything, set -euo pipefail, exit 0/≠0

# Granular:
python3 tools/validate_world_contract.py
python3 tools/validate_foundation.py static
godot --headless --path . --import
godot --headless --path . --check-only --script <file.gd>
godot --headless --path . --script res://tests/godot/test_runner.gd
godot --headless --path . --script res://tests/godot/tools/contract_check.gd -- --dump /tmp/d.json
python3 tools/validate_foundation.py cross /tmp/d.json
python3 tools/validate_foundation.py inject
python3 tools/validate_foundation.py reproduce
godot --headless --path . --quit-after 30
python3 tools/validate_foundation.py audit-log <log> [errlog]
python3 tools/validate_foundation.py bench-macro
python3 tools/benchmark/compare_baseline.py BASE CURRENT
```

## Exit-code contract (verified)

| Code | Meaning | Source |
|---|---|---|
| 0 | all pass / CONTRACT_OK / BENCH_OK | runner, contract_check, benches, python tools, CI script |
| 1 | test failure | test_runner (any FAIL), python tools (any FAIL) |
| 2 | contract/tool failure | contract_check (load/locked/consistency/checksum/dump), missing binary |
| 3 | bootstrap abort | application bootstrap fail-fast (contract corruption at boot) |

## Log-audit allowlist (exact-match only)

The diagnostics suite DELIBERATELY emits two error-level lines to test counters:

```text
[ERROR][TEST] e1
[FATAL][TEST] f1
```

`audit-log` allowlists exactly these two strings. Every other `ERROR|FATAL|
SCRIPT ERROR|Parse Error|Failed to|CONTRACT_FAIL|TEST_RUN FAILED|...` line is
an unexpected error and fails the audit. WARNINGs are listed, never blocking.

## Flakiness controls

- No wall-clock assertions (timing is measured, never gated).
- Suppression test uses 200 rapid logs (robust to msec-window rollover).
- Float32-backed assertions use 1 mm (derived quantum policy), doubles use 1e-9.
- Sector exact-boundary assertions use scalar-double APIs; float32 paths use
  ±0.01 offsets (≈50× the local quantum).
- Reproducibility strips `generated_at`/engine-version before comparison.

## What is NOT tested here (owned by later prompts)

Terrain synthesis (P02), coast/water (P03), roads/nav (P04), districts (P05),
POIs (P06), streaming + perf lock (P07), population/traffic (P08),
missions/economy (P09), full-game regression (P10). Graphical window smoke is
ENVIRONMENT-LIMITED in this sandbox (no display/GPU) — structural scene-tree
verification substitutes, honestly labeled.
