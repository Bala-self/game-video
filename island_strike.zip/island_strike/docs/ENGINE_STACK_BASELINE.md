# ISLAND STRIKE — ENGINE STACK BASELINE (Prompt 01, §6)

All values below were QUERIED from the live environment on 2026-09-20.
Nothing here is assumed or transcribed from memory.

## Engine

```text
ENGINE_VERSION = 4.7.2.stable.official.ed1daf0bf  (VERIFIED via --version)
major/minor/patch = 4 / 7 / 2, status = stable, build = official, rev = ed1daf0bf
source = official godotengine/godot release asset:
  Godot_v4.7.2-stable_linux.x86_64.zip (74 MB)
  URL = https://github.com/godotengine/godot/releases/download/4.7.2-stable/Godot_v4.7.2-stable_linux.x86_64.zip
  SHA-256 (zip) = cadd3204e728a35d3f13adb7fd0d7902636b79f6b95c40c265eb73b6c35329e4
  latest 4.x stable as of 2026-09-20 (4.7.2 published 2026-08-18; verified via
  api.github.com/repos/godotengine/godot/releases, non-prerelease, 4.* filter)
re-fetch = python3 tools/fetch_godot.py  (pins URL + SHA-256, verifies, installs)
```

## Runtime environment

```text
OS = Linux (e2b.local, kernel 6.1.158+)          arch = x86_64
CPU = 2 cores                                    RAM = ~2 GB (1507 MB available)
DISPLAY = <unset>                                xvfb = NOT INSTALLED
x11 attempt = FAILS: "X11 Display is not available" (exit 1) + missing
              libxkbcommon.so.0 — graphical window tests are ENVIRONMENT-LIMITED
ldd = all linked libraries present               python = 3.13.14 (tooling)
git = 2.47.3
```

## Render / audio / display backends

```text
project rendering_method = forward_plus (engine default, explicitly pinned)
headless run = --display-driver headless (dummy) + --audio-driver Dummy
DisplayServer.get_name() under headless = "headless"
GPU counters = UNAVAILABLE under dummy driver (recorded as null+reason, §22)
```

## CLI flags used for automation (verified in --help output)

```text
--headless --path . --import                       resource import
--headless --path . --check-only --script <f>      static parse check
--headless --path . --script <SceneTree gd> [-- args...]  tests / tools / benches
--headless --path . --quit-after N                 smoke / frame runs
OS.get_cmdline_user_args()                         args after `--` (verified working)
SceneTree.quit(code)                               exit codes 0/1/2/3 (verified)
```

## Scripting / runtime assumptions (verified by execution, not docs alone)

- GDScript static typing + `preload`-as-type + static funcs: used, all parse.
- `JSON.new().parse()` error capture, `FileAccess`, `DirAccess` statics,
  `Time.get_ticks_usec/msec`, `OS.get_static_memory_*`, `Engine.get_version_info`,
  `OS.has_feature("x86_64")`, `ProjectSettings.get_setting`, `DisplayServer.get_name`:
  all exercised by passing code paths.
- Global `log()` name is TAKEN (built-in 1-arg): diagnostics method named
  `record()` instead (found by real parse error, fixed, re-verified).
- `String.join()` requires PackedStringArray (found by review, fixed pre-run).
- SceneTree `-script` tests run in first `_process` (root guaranteed).
- Test suites must use path-`extends`, never bare cross-file `class_name` refs
  (cache-independent by construction; verified by clean `.godot` re-import run).

## Test / benchmark execution methods

- Engine tests: `--script res://tests/godot/test_runner.gd` → TEST_SUMMARY, exit 0/1.
- Static checks: `tools/validate_world_contract.py` + `validate_foundation.py static`.
- Cross-layer: `contract_check.gd -- --dump X` + `validate_foundation.py cross X`.
- Injection/reproduce/audit/bench-macro: `validate_foundation.py <subcommand>`.
- Full path: `bash tools/run_all_tests.sh` (12 steps, `set -euo pipefail`).
- CI: `.github/workflows/ci.yml` (checkout → python → fetch_godot → run_all_tests).

## Known environment limitations

1. No display server / GPU → graphical window smoke ENVIRONMENT-LIMITED (§43);
   structural substitute (scene-tree node verification) executed and passing.
2. 2 GB RAM / 2 CPU — fine for foundation; later-phase budgets must declare
   their own target hardware (Prompt 07), not inherit this sandbox.
3. Engine binary lives OUTSIDE the repo (`tools/.godot/`, gitignored, or $GODOT_BIN);
   re-fetch is one pinned, hash-verified command (above).
