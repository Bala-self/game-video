# ISLAND STRIKE — WORLD DESIGN RULES

| Field | Value |
|---|---|
| Document | `ISLAND_STRIKE_WORLD_DESIGN_RULES.md` |
| Status | **LOCKED (Prompt 00)** — revision `1.0.0` |
| Date | 2026-09-20 |
| Source | Abstracted from `AAA_OPEN_WORLD_REFERENCE_DATABASE.md` (18 records) |
| Rule | Each rule is an original engineering principle. No copied layouts, coastlines, road networks, or landmark arrangements. |

How to read: `PRINCIPLE` (normative) → `RATIONALE` (evidence) → `STRIKE RULE`
(concrete requirement with ID). IDs `DR-01…` are cited by Prompts 01–10 and tests.

---

## DR-01 — DENSITY BEATS AREA

**PRINCIPLE.** Playable richness is a function of density-per-km², not total km².
**RATIONALE.** Sleeping Dogs (~8 km²) sustains a full AAA urban action game; Just
Cause (~1000 km²) is criticized for emptiness at the opposite extreme.
**STRIKE RULE.** At 12.566 km², Strike Island budgets density per region per the
Master Contract §10 ranges. Any region below its POI/road minimum at review is a
defect, not "minimalism" — unless formally reclassified as corridor/buffer.

## DR-02 — ONE ISLAND, SEAMLESS

**PRINCIPLE.** A single continuous landmass with one perimeter coastline is easier to
stream, navigate, and mentally map than multi-map or mainland-edge worlds.
**RATIONALE.** GTA V, Far Cry 6, Tsushima, Altis all use islands; Witcher 3's map-split
fast travel is explicitly rejected for this project.
**STRIKE RULE.** Exactly one landmass (genus-0 waterline loop); ocean to horizon;
no map-split fast-travel masking; boats/aircraft traverse real space.

## DR-03 — RING + RADIAL ROAD SKELETON

**PRINCIPLE.** Primary settlements connect via few high-capacity corridors; secondary
roads give regional access; local streets give fine-grained navigation.
**RATIONALE.** GTA V freeway ring + arterials; Forza Horizon's hub-ring-connector grammar.
**STRIKE RULE.** Locked skeleton: 1 coastal ring highway (B1 band, r≈1750) + 3 radial
arterials (city→N highlands, city→S airfield, city→W forest) + rural collectors; dirt/trail
capillaries last. No road is drawn without two named endpoints it connects.

## DR-04 — CITY-ON-WATER, HILLS-INLAND

**PRINCIPLE.** Place the dense urban core on navigable water (port fantasy, skyline
readability from approach vectors) and relief inland (vista + containment).
**RATIONALE.** Los Santos/coastal capitals; Esperanza; Night City bay; Tsushima's
mountain spine; Altis airfield-on-flats.
**STRIKE RULE.** Portside City on the east coast with port + marina; highlands north;
airfield on southern flats (runway flatness ≤1% over 800 m is a terrain hard constraint).

## DR-05 — REGION CONTRAST COMMUTES

**PRINCIPLE.** Every 60–90 seconds of highway travel must change the visible biome.
**RATIONALE.** RDR2 snow→swamp rides; San Andreas city→desert→forest; Tsushima's
three-prefecture acts.
**STRIKE RULE.** The three locked transition loops (Contract §7) are acceptance-tested
by drive-through: reviewer logs biome changes against timestamps; gaps >90 s of
monotony are defects.

## DR-06 — BEACHES ARE SYSTEMS, NOT TEXTURES

**PRINCIPLE.** Shoreline segments need width, berm, material, depth ramp, access flags,
audio, and gameplay role — per segment, not per material.
**RATIONALE.** Odyssey's cliffs/ports/beaches; GTA V's beach→cliff→marina variety.
**STRIKE RULE.** Nine locked beach classes (Contract §9) tile the full 360° with
≥150 m run-lengths; each segment carries the full attribute row; waterline = y=0
contour crossing, never a painted ring.

## DR-07 — EVERY REGION HAS AN OWNER AND AN ARC

**PRINCIPLE.** Regions are gameplay containers with a faction/owner, an outpost, and a
progression arc — not wallpaper.
**RATIONALE.** Wildlands' 21 province-bosses; Odyssey conquest; Far Cry checkpoints.
**STRIKE RULE.** Each of the 11 regions answers the ten gameplay questions (Contract
§7); regions R1–R9, R11 each own ≥1 L2 landmark and ≥1 mission-capable site.

## DR-08 — OUTPOST GRAMMAR (OVERLOOK + WALLS + PATROL RINGS)

**PRINCIPLE.** Hostile/controlled sites follow a legible grammar: approach cover →
perimeter → watchtower sightline → core objective → exfil route.
**RATIONALE.** MGSV guard posts; Odyssey forts; Far Cry outposts.
**STRIKE RULE.** Restricted compound, port yard, and all checkpoints implement the
grammar; sightlines validated by automated viewshed test from tower positions.

## DR-09 — LANDMARKS ARE NAVIGATION INFRASTRUCTURE

**PRINCIPLE.** Landmarks exist to orient, not decorate: L1 island-wide → L2 district →
L3 neighborhood → L4 micro.
**RATIONALE.** Tsushima's composed vistas; Chiliad; London/Night City skylines.
**STRIKE RULE.** Locked counts (Contract §12); every spawn point within 400 m of an
L3; L1 silhouettes golden-screenshot regression-tested.

## DR-10 — WATER IS A TRAVERSAL MODE, NOT A WALL

**PRINCIPLE.** Ocean/lakes are navigable space with entry points, vehicles, and
missions — bounded by stamina/fuel and soft containment, not invisible walls.
**RATIONALE.** GTA V/Just Cause/AC naval play; Death Stranding rivers-as-puzzles.
**STRIKE RULE.** Swim + boat rules per Contract §8; ≥3 boat-accessible POIs (marina,
hidden coves ×2); soft warning at 2600 m, hard turn-back at 4000 m — both diegetic.

## DR-11 — TERRAIN DIFFICULTY IS GAMEPLAY

**PRINCIPLE.** Slope, surface, and drainage meaningfully change traversal cost and
route choice.
**RATIONALE.** Death Stranding; Days Gone bike/fuel routing; MGSV climb routes.
**STRIKE RULE.** Locked grade limits (Contract §6); off-grade shortcuts cost
stamina/damage/time — validated by route-cost tests, not vibes.

## DR-12 — VERTICALITY MULTIPLIES AREA

**PRINCIPLE.** Rooftops, multi-floor shells, bridges, underpasses, cliffs, and towers
multiply effective gameplay area without new land.
**RATIONALE.** Cyberpunk verticality; Sleeping Dogs alley stacks; Guanajuato tunnels.
**STRIKE RULE.** Urban core: ≥30% of mission-capable buildings with accessible
rooftop; ≥2 bridge/underpass structures; North Peak mast climbable to overlook.

## DR-13 — POPULATION FOLLOWS REGION, TRAFFIC FOLLOWS ROADS

**PRINCIPLE.** Ambient life is a function of (region profile × time × weather), and
vehicles exist on the road graph — never random scatter.
**RATIONALE.** GTA/RDR ambient systems; WD crowd density by borough.
**STRIKE RULE.** Region→population→pedestrian→traffic→AI chain (Contract §15);
spawn-effectiveness audited: zero off-graph vehicle spawns, zero water/rock ped spawns.

## DR-14 — STREAMING IS ARCHITECTURE, NOT OPTIMIZATION

**PRINCIPLE.** Sector streaming, LOD, and instancing are designed before content, or
content will never fit.
**RATIONALE.** Godot has no built-in world streamer (verified docs-absence); every AAA
ships one; community 20×20 km Godot worlds require chunking.
**STRIKE RULE.** 256 m sectors (benchmark 128/512 in Prompt 07), LOD-by-distance,
MultiMesh vegetation, physics only within 512 m — all before district authoring.

## DR-15 — DETERMINISM IS A FEATURE

**PRINCIPLE.** Same seed + version = same world. Reproducibility enables testing,
multiplayer-future, and bug reports with coordinates.
**RATIONALE.** Standard procedural-generation practice; ARMA grid-coordinate precedent.
**STRIKE RULE.** Master→region→sector→system seed hierarchy (Contract §16) with a
committed `world_checksum` regression test from Prompt 02 onward.

## DR-16 — SMALL MAP, SHORT LOOPS, FAST FANTASY

**PRINCIPLE.** On a 4 km island, loops must be short and readable: 1–3 minute drives
between content beats; couriers, patrols, deliveries, and chases tuned to the scale.
**RATIONALE.** Death Stranding delivery loops; Days Gone fuel-stop routing; FH5's
2-minute race cadence.
**STRIKE RULE.** Travel-time contract (Contract §11) is a design input: mission legs
sized so highway legs ≤3 min; walking-only errands ≤400 m.

## DR-17 — ESCALATION GEOGRAPHY

**PRINCIPLE.** Security response scales with zone sensitivity: tourist beach ≠ downtown ≠
restricted compound, and the player can read the difference before acting.
**RATIONALE.** GTA wanted levels; Far Cry restricted zones; MGSV alert phases.
**STRIKE RULE.** Every region declares a security tier (0 open → 3 restricted) in data;
tier changes are signposted in-world (fences, signage, guards) and on the map.

## DR-18 — GATE WITH TERRAIN, NOT WALLS

**PRINCIPLE.** Progression gating should read as geography (bridges out, passes,
checkpoints, patrol density), not UI locks.
**RATIONALE.** Tsushima's act-gated prefectures; San Andreas' early bridge closures.
**STRIKE RULE.** North highlands + restricted compound gate via checkpoint/bridge
fiction; no arbitrary "locked region" UI without a physical counterpart.

## DR-19 — ORIGINALITY IS BINARY

**PRINCIPLE.** Patterns transfer; content doesn't. No copied coastlines, road graphs,
skylines, palettes, names, or placements.
**RATIONALE.** Legal + creative necessity (Prompt 00 §14/§32).
**STRIKE RULE.** Every authored asset passes the "shelf test": placed beside its
reference, it shares no recognizable layout element. Reviews sample 10% of POIs
against references each prompt.

## DR-20 — MEASURE, THEN BUDGET, THEN LOCK

**PRINCIPLE.** Performance budgets come from measurements on target hardware, never
from aspiration.
**RATIONALE.** Every shipped AAA performance postmortem; Godot community large-world
reports vary 10× by content choices.
**STRIKE RULE.** Contract §14 two-stage rule: instrument in Prompt 01, lock budgets
in Prompt 07. Unmeasured numbers are labeled targets, never gates.

---

*End of design rules v1.0.0 — 20 rules, all traceable to dated evidence records.*
