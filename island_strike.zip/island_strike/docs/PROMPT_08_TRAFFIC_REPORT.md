# PROMPT 08 TRAFFIC REPORT

PROMPT: 08
TITLE: DETERMINISTIC RUNTIME TRAFFIC OVER LOCKED ROADS
STATUS: LOCKED
UPSTREAM: P00 / P01 / P02 / P03 / P04 / P05 / P06 / P07 (all PASS, checksums pinned)

## GRAPH

`data/derived/traffic_graph.json` = `dda8657c55ae8b47`
(derived; locked roads win disagreements).

Census: 77 lanes / 223 movements / 22 junctions / 10 signals /
49 spawn zones. Ingest normalizes the mixed point convention of the
locked road inputs (P08-D1); seeds live in the `traffic` namespace
(P08-D2); signals use the P08-derived CONTROL MODEL (P08-D3);
spatial index reuses the P07 SectorGrid (P08-D4).

## ROUTER

A* over lanes with deterministic tie-breaks; route cache keyed on
(origin, dest, class, escape-flag). Escape mode (P08-D5): RESTRICTED
lanes are traversable at +500 penalty ONLY when the start lane is
RESTRICTED (spur-gate U-turn escape); entering RESTRICTED from PUBLIC
stays barred. All-pairs audit: 5929 pairs, only 152 fails, all
restricted-destination by design. Fallback destinations skip
RESTRICTED lanes. `th_highland` contributes 8 derived TRAILHEAD
movements (P03-route evidenced); wetland route-legality negative test
pins the exclusion.

## RUNTIME

Fixed-step sim (10 Hz): car-following + queues + signal/yield/merge
controls + lane changes + 4-tier fidelity (FULL/SIMPLIFIED/PROXY/
ABSTRACT) + spawn/despawn + player coexistence. Pool assigns a FRESH
vehicle id per generation — never recycled (P08-D6). Trail segments
run under single-track shuttle-lock. Despawn grace is 60 ticks so the
slowest tier (ABSTRACT, 50-tick cadence) always updates before any
relevance retirement (P08-D8).

## VALIDATOR

`tools/validate_traffic.py` — 11 suites, 132 checks, ALL PASS:

| suite | checks | headline |
|---|---|---|
| static | 35/35 | schema, census, geometry, connector, policy pins |
| cross | 7/7 | engine TRAFFIC_OK + digest parity (lanes/moves) |
| inject | 11/11 | mutants fail loudly |
| reproduce | 6/6 | two runs, identical deterministic core |
| smoke | 11/11 | scenario retirements, pin balance per vehicle |
| perf | 15/15 | N=10…1000 ×300 ticks; contract budgets enforced |
| regress | 13/13 | 11 goldens, 0 route failures, 0 leaks |
| stress | 4/4 | dense soak, queue flush, focus jumps, pin shuttle |
| route | 16/16 | 12 O/D pairs + legality/determinism/alt/restricted |
| junction | 6/6 | 210-movement matrix + conflicts + 10/10 signals + roundabout 36 + rush 6/6 + struct end-to-end |
| vehicle | 8/8 | pool ids/reset/balance + state legality + LC + spawn + tiers + player |

Junction matrix covers all 210 routable movements empty plus sampled
2-vehicle conflicts per junction; 13 structure-continuity self-loop
markers are documented, router-inert, and covered by bridge/tunnel
end-to-end runs (P08-D7). Matrix tags are md5-derived (deterministic;
no `hash()` seed flakiness).

## PERF BUDGETS (contract-enforced, ~2× envelope-measured, CPU time)

per-vehicle p95 0.035 ms (measured ≤0.0170) · tick@100 1.5 ms
(measured ≤0.742) · tick@1000 12.0 ms (measured ≤4.544 CPU;
≤6.1 wall in slow windows). Gate metric is process CPU time
(deschedule-robust); wall kept as diagnostic. Budgets follow the
envelope rule (P08-D12): identical deterministic work measures
1.6–2.8× slower CPU seconds on this host class vs the fast-host
calibration, so budgets are ~2× max-observed here. 10 Hz step =
100 ms: 12 ms @1000veh = 12% of step. Evidence:
reports/p08/perf.json.

## GOLDENS

`reports/p08_goldens.json` — 11 scenarios (city/port/highland/resort/
coast/roundabout/bridge/tunnel/low-density/dense/player-traffic),
accepted 4–224, retired converges, 0 route failures, 0 leaks.

## ENGINE CROSS-CHECK

`tests/godot/tools/traffic_check.gd` → TRAFFIC_OK on
`dda8657c55ae8b47`; digests lanes `3f48baf5d3c7fdfd`, moves
`3d64ed035345ebe0`; census + checksum parity asserted by the cross
suite on every run. Metrics: reports/logs/p08_traffic_metrics.json.

## KNOWN LIMITATIONS

- CPU-sim budgets; engine runtime must re-verify on target hardware.
- ABSTRACT tier ignores signal phases (relevance retirement covers).
- Yield/merge waits are gap-driven; signal waits unbounded by design
  (phases guarantee service; matrix asserts 10/10 within 2 cycles).
- No collision damage model; pin/shuttle locks only.

## DEFERRED (owner: future prompt)

Pedestrians/NPC/nav-AI/economy/missions/weather/day-night;
final save/load; full collision; interior shells; mission logic.

## FILES

Created: traffic_contract(+schema), traffic_graph/graph/sim/pool
tools, validate_traffic (11 suites), traffic_check.gd,
traffic_graph.json, reports/p08/*.json, p08_goldens.json,
engine metrics, 2 docs, clean-rebuild script.
Modified: none outside P08 ownership.

## GIT

Baseline `6583393` (P00–P07 file truth re-established; post-P01
objects lost to snapshot cap — ENV EVENT per reports/p08_audit.json)
+ P08 `c98532a` + lock (see log). Clean rebuild ×2, both exit 0,
graph sha `17390149…5d33ae7` + goldens sha `62d6faeb…27e67d`
identical before/after. Worktree clean at lock.

## NEXT

09.
