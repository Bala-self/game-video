# SECTOR ARCHITECTURE (P07)

## Grid (locked)

- size 256 m, grid_min -2048, span 4096 → 16×16 = 256 sectors
- formula: sx = floor((x+2048)/256), sz = floor((z+2048)/256),
  left-closed (exact boundary → higher sector), exact math
- id: SX%02dZ%02d (P05/P06 continuity)
- world: 2 km radius circle; census 164 inside / 60 partial /
  32 outside (matches P01 X-census exactly)

## Manifest

`data/derived/world_stream_manifest.json` (`3970e8e7e96b4e17`):
derived index, references only. Per sector: bounds, world_state,
regions, districts, blocks/parcels/buildings (+primaries),
landmarks, open spaces, road fragments, structures, reservations,
coast fragments, terrain dep, LOD groups, static priority, counts,
source pins.

- streaming_graph_checksum: `fd1574c71d359143` (size+topology+
  1269 dep edges+refs+policy)
- semantic_checksum32: `e5f12b8d` (engine parity)
- 251 STRUCT units; hotspot SX12Z07 (46 buildings, 62 parcels)

## Dependencies

Per-sector layer chain over present layers + STRUCT-unit edges
(sector TERRAIN → unit → sector STRUCTURE). Acyclic (proven by
validator + engine Kahn check). STRUCT units: bridges, tunnel,
retaining walls, barriers, parts. Failure policy per edge
(FAIL_DEPENDENT, PROXY_ALLOWED for structure detail only).

## Source-of-truth rule

Manifest disagrees with source → source wins; fix producer,
regenerate. Ownership: buildings 403/403, parcels 579/579, blocks
161/161, landmarks 34/34 exactly-once; outside-world sectors hold
no primaries. Controlled-mutation test proves manifest sensitivity
+ P02–P05 stability.
