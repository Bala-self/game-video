# GAMEPLAY_EVENT_MODEL (P10)

## One bus

Single append-only bus (`GameWorld.bus`), sequence-numbered, owned
producers (P10 / P09 for OFFENSE_WITNESSED). Subscription registry with
explicit `unsubscribe`; mission instances subscribe on start and release
on cleanup. Duplicate defense: idempotent consumers (ledger IDs, reward
seals, spawn duplicate guards).

Event families (measured in sessions): MISSION_OFFERED/ACCEPTED/STARTED/
OBJECTIVE_COMPLETED/CHECKPOINT_SAVED/SUCCEEDED/FAILED, OFFENSE_COMMITTED/
OFFENSE_WITNESSED/WANTED_CHANGED/POLICE_DISPATCHED/PURSUIT_STARTED/
PURSUIT_ENDED/ARREST_STARTED/ARRESTED/ESCAPED, TRANSACTION_COMPLETED,
EVENT (triggers), WORLD_STATE_CHANGED, CHECKPOINT_SAVED.

## World events (6, checksum `161c1ae765d32666`)

EVT-port-activity / EVT-festival (AREA_ENTER r600), EVT-market-day /
EVT-harbor-patrol / EVT-quiet-night (TIMER 600), EVT-heightened-alert
(WANTED_STATE). Machine: DORMANT → ARMED → TRIGGERED → ACTIVE →
COMPLETED; effects apply as world flags and bump `world_state_version`
(smoke final wsv=2, flags=1 in long-run).

## Triggers

Owner-typed one-shot triggers (AREA_ENTER / TIMER / WANTED_STATE /
MISSION_STATE) evaluated per tick; smoke + integration arm TIMER events
and verify COMPLETED.

## Evidence

- REPRODUCE 3/3 (all public mutators, zero illegals/leaks),
  INTEGRATION 5/5 (mission×wanted×economy×events combined loop),
  INJECT determinism (identical digests across reruns).
- Bus is telemetry, not state: digest v2 excludes bus length because
  restore paths legitimately publish (documented in-prompt fix).
- Section cost: events 0.007 + triggers 0.002 ms/tick mean.
- Stress holds subs ≤ 4 across teleports/saves; long-run returns subs
  to 0 every round.
