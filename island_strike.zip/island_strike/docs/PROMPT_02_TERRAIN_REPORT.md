# ISLAND STRIKE — PROMPT 02 REPORT (master terrain + coastline)

PROMPT:
02

TITLE:
MASTER TERRAIN + COASTLINE (data-defined field, GDScript↔Python twin, validated)

STATUS:
LOCKED (see 27-AND table §12; lock commit recorded at close)

PROJECT STATE:
Data-defined island terrain + closed-loop coastline generated from contracts +
authoring, validated by 170 automated checks across 4 suites (STATIC 146/146,
CROSS 6/6, INJECT 11/11, REPRODUCE 7/7), proven bit-stable across engines
(GDScript↔Python LUT digest f96dfd72725cd647 on both sides) and across clean
rebuilds (mesh sha256 + zones checksum byte-identical). Deterministic preview
mesh (12256 verts / 24018 tris, 0 meshability fails) hands off to P07 mesh
pipeline. Collision is DEFERRED with a written future contract (see §10).

ENGINE:
4.7.2.stable.official (pinned at tools/.godot/godot; re-fetch:
python3 tools/fetch_godot.py)

RUNTIME ENVIRONMENT:
OS: Linux x86_64 / execution: headless CLI (--script SceneTree runners).
Graphical window: ENVIRONMENT-LIMITED (no display/GPU) — same standing
limitation as P01; all P02 evidence is headless-executable and re-runnable.

## §1 INPUTS (pinned versions)

| artifact | version | path |
|---|---|---|
| world_contract | 0.1.0 (world_id pinned, radius, caps) | data/world/world_contract.json |
| terrain_contract | 0.1.0 | data/world/terrain_contract.json |
| coast_contract | 0.1.0 | data/world/coast_contract.json |
| authoring | 0.1.0 | data/terrain/authoring.json |

Schemas peer each JSON (S-schema:* green). Version pins are enforced by
S-ver:* checks — a terrain↔coast↔world version skew fails validation
(change-impact ownership guard, with I-loop-bad-region as the live probe).

## §2 FIELD DEFINITION (what "terrain" is)

Analytic height field h(x,z) + region field, both pure functions of the
inputs above:

- Coast: closed star-shaped loop, 1220-tap LUT (10 m spacing over
  12201.7 m), 17 segments in 9 beach classes, curvature-adaptive width with
  meso-scale smoothing, berm + seabed ramps, cliff_safety caps.
- Relief: 14 landforms + micro coast noise (seeded lattice, salt Micro) +
  800 m runway platform + summit pad + 15 lakes (11 kettlearths, 0 ditches —
  every trap is a lake by construction) + 2 cliff bands + river carve.
- Regions: 12 authored regions + open_water; P00 §9 formal ids in data,
  SHORT beach keys only where the contract uses them.
- Corridors: 6 (ring_hw polyline + north tunnel + 3 radials + restricted
  spur), 17.31 km surface length — see S-05 note §7.

Twin implementation: tools/terrain_model.py (reference) and
scripts/terrain/*.gd (engine). Both scalar-float64 end to end.

## §3 VALIDATION SUITES (all green, real execution)

| suite | result | notes |
|---|---|---|
| STATIC-TERRAIN | 146/146 | schema, versions, coast, regions, heights, field, grades, exclusions, lakes, beaches, drainage grid, zones, sector seams, §83, area stats, cache |
| CROSS-TERRAIN | 6/6 | X-lut 0/1220, X-heights 0/221, X-noisefree 0/221, X-seams 0/2992, X-seam-continuity 0/1496 |
| INJECT-TERRAIN | 11/11 | 10 mutants detected (exit=2) + repo-clean guard |
| REPRODUCE-TERRAIN | 7/7 | re-run stability incl. lut_digest, lut, samples, census |
| TOTAL | 170/170 | |

Injection targets (10): nodes-truncated, share-negative, spacing-zero,
cliff-missing, width-zero, tunnel-no-portals, pad-no-target, lake-unenclosed,
runway-neg-blend, loop-bad-region.

## §4 CHECKSUMS (the identity of this terrain)

| checksum | value | stability |
|---|---|---|
| LUT digest (FNV64, both engines) | f96dfd72725cd647 | cross-engine + rebuild |
| sample digest (Python, 300 m grid + sites) | 8ce693c4555d8a78 | engine-free tripwire |
| urban zones | f25c6037e5edab15 | clean rebuild identical |
| preview mesh sha256 | ac109b68f9c3…2ab0c3d | byte-identical rebuild |
| bench accumulator (2000 pts, both engines) | 83200.4796 | cross-engine |

`python3 tools/terrain_cli.py checksum` recomputes the first two without Godot.

## §5 AREA / RADIAL / SPACING STATS

- Land area 11.68 km². Region shares (got vs tgt): forest 14.9/20.0,
  hills 17.5/18.0, rural 16.4/16.0, beach 11.5/12.0, suburban 6.8/7.0,
  reserve 6.3/6.0, infra 4.2/5.0, urban 3.3/4.0, restricted 4.2/4.0,
  industrial 1.8/3.0, port/airfield 3.7/3.0, wetland 2.4/2.0.
- Inland water 0.244 km² of 0.25 budget (15 lakes; harbor-complex counts
  under the exception rule, see §8).
- Feature spacing min 1165 m (A-spacing). Radial approximation worst 5.5 m.
- Coast: 12201.7 m; waterline + boundary steps within caps
  (non-cliff and cliff gates green).

## §6 SECTOR ±ε CONTINUITY (closed)

- Field level: E-sector-seams probes ±1 m across every 256 m grid line
  (grade-aware bound + node-ray step caps) — 0 bad.
- Cross-engine: X-seams replays 2992 Godot seam heights in Python — 0 bad;
  X-seam-continuity re-checks 1496 pairs against the same bound — 0 discont.
- Mesh level: the preview builder triangulates one global grid (single
  chunk), so there are no internal chunk seams by construction; the 8-ray
  carve and zone overlays never split triangles across sectors.

## §7 S-05 NOTE (surfaced, not buried)

Measured surface-corridor length is 17.31 km against the 21.5 km planning
estimate (A-S05-total: surface=17.3km vs est 21.5). The gap is AUTHORING
choice, not field error: corridors were routed for grade compliance
(≤9% short / ≤6.6% sustained, all G-grade green) rather than for length.
No action; estimate owners adjust downstream if length is load-bearing.

## §8 §79 FIXES + HARBOR EXCEPTION (applied, verified)

- Restricted-zone relocate: applied; G-excl:restricted green.
- Urban node 100→102: class-rule node moved; B-urban-core:102 green,
  nodes-sorted-unique green.
- Wide split 230/240: sandy_wide 196–230 + 230–240 split; B-resort:230/234/
  238/240 green, min-run green.
- Harbor-complex exception: port + marina + urban_waterfront adjacency and
  water budget counted under the harbor rule (C-adjacency-cliff-port green;
  industrial_port 228416 m²; sill masked; tarn rim 48.19 / level 46.7).

## §9 §83 RADIAL-SECTION GATE (closed)

X-radial-sections: worst step 4.26 m < 5 m gate — PASS. Five 3–5 m
half-bench flags, all on spur_restricted_access steps near (882..985,
-1370..-1490): pre-classified restricted-spur benching, no action.
Gate thresholds live in terrain_contract validation
(radial_section_gate_m / radial_bench_flag_m), not in code.

## §10 COLLISION: DEFERRED + FUTURE CONTRACT

Collision is DEFERRED (no collider authoring, no physics baking in P02).
Future contract for the prompt that owns it:

1. Consume preview/terrain_preview.obj vertex order + data/terrain/
   authoring.json corridor polylines as the collision source of truth.
2. Height queries MUST route through the terrain_field twin
   (scripts/terrain/terrain_field.gd), never a re-implementation.
3. Re-run CROSS-TERRAIN after any field change; a digest change without a
   version bump is a lock violation.
4. Water plane = terrain_contract constants; beach d<50 m pile rule and
   cliff_safety caps transfer unchanged.
5. Sector seams: any chunked collider must re-prove §6 bounds per chunk edge.

## §11 PERFORMANCE MATRIX (real execution, no projections)

| op | Godot 4.7.2 | Python 3 |
|---|---|---|
| field build (LUT 1220) | 99 ms | 94 ms |
| height() per call (2000-pt bench) | 63.9 µs | 49.5 µs |
| region_at() per call | 54.7 µs | 50.4 µs |
| full dump wall (startup+LUT+221+2992) | 0.65 s | — |
| STATIC 146 | — | 39.2 s |
| CROSS 6 | — | 0.6 s |
| INJECT 11 | — | 2.6 s |
| REPRODUCE 7 | — | 1.3 s |
| preview mesh 32 m | — | 0.7 s |

Godot bench: `--bench N` in tests/godot/tools/terrain_check.gd (LCG points,
checksum accumulator). Python bench mirrors the same point stream.

## §12 27-AND LOCK TABLE (all must hold; all do)

Suites: (1) STATIC 146/146 · (2) CROSS 6/6 · (3) INJECT 11/11 ·
(4) REPRODUCE 7/7.
Determinism: (5) LUT digest equal both engines · (6) zones checksum stable
across rebuild · (7) mesh bytes identical across rebuild · (8) bench
accumulator cross-engine · (9) clean-rebuild regression green.
Design: (10) water 0.244≤0.25 · (11) peak 207.0 in band at pad ·
(12) §83 worst 4.26<5 m · (13) sector seams 0 discont (static + cross) ·
(14) S-05 note surfaced · (15) §79 fixes applied+verified.
Artifacts: (16) preview mesh 0 fails · (17) 3 evidence maps rendered ·
(18) REPORT + machine summary written · (19) originality record ·
(20) §89 decisions · (21) deferred/API handoff.
Process: (22) terrain_cli 4 subcommands work · (23) perf matrix real-only ·
(24) cache hit/corrupt/version tests pass · (25) change-impact guards pass ·
(26) smoke green (fresh dump + suites + mesh + checksum) ·
(27) tracked tree clean vs P01 lock.

## §13 FILES

CREATED (P02): data/world/{terrain_contract,coast_contract}{,.schema}.json,
data/terrain/{authoring.json,authoring.schema.json},
data/derived/urban_zones.json, scripts/terrain/{terrain_noise,coast_loop,
terrain_regions,terrain_field}.gd, tests/godot/tools/terrain_check.gd,
tools/{terrain_model,validate_terrain,terrain_cache,terrain_cli,
derive_zones,build_preview_mesh,render_terrain_maps,tune_terrain}.py,
preview/{terrain_preview.obj,terrain_preview.json,map_height,map_slope,
map_regions.png}, reports/p02_terrain_summary.json,
docs/{PROMPT_02_TERRAIN_REPORT,P02_ORIGINALITY_RECORD,P02_DECISIONS_S89,
P02_HANDOFF_DEFERRED_API}.md.
MODIFIED: none (P01-locked bytes restored; verified via git status).

## §14 REPRODUCE

1. `python3 tools/fetch_godot.py` (pins 4.7.2).
2. `python3 tools/terrain_cli.py generate` (zones + mesh + Godot dump).
3. `python3 tools/terrain_cli.py validate all --dump <dump>`.
4. `python3 tools/terrain_cli.py checksum` →
   f96dfd72725cd647 / 8ce693c4555d8a78.
5. `python3 tools/render_terrain_maps.py` (visual evidence).

## §15 KEY ENGINEERING RESULT (root cause, for the record)

Mid-prompt the twin diverged (X-lut 451→932/1220 after a wrong fix): root
cause was Godot Vector2 storing float32, injecting ~1e-7 curvature noise
amplified ×300–600 by width modulation. Fix: full scalar-float64 rewrite of
the GDScript twin (no Vector2 in any numeric path — documented in
coast_loop.gd header). Lesson recorded in P02_DECISIONS_S89.

LOCK: e69a7c5aa1a2cb631af609fa495b9e4b673542ad (Prompt 02 LOCKED; re-committed
2026-09-21 after a sandbox snapshot dropped the original lock commit da360cd —
content re-verified 170/170 before recommitting, no P02 bytes changed)
