# P02 ORIGINALITY RECORD

All P02 geometry is AUTHOR-FROM-SCRATCH for ISLAND STRIKE. No heightmap,
mesh, coastline, texture, or layout was imported from any external game,
asset pack, scan, or dataset.

- Coast loop, beach segmentation, landform placement, lake kettles, corridor
  polylines, runway/pad siting, region shapes: hand-authored numbers in
  data/terrain/authoring.json + data/world/{terrain,coast}_contract.json.
- Micro-relief noise: seeded lattice function (tools + GDScript twin), not
  sampled data; salt "Micro" under world master seed.
- Reference database (docs/AAA_OPEN_WORLD_REFERENCE_DATABASE.md) informed
  SCALE judgments only (island extents vs. published open-world sizes); no
  reference geometry, heights, or layouts were copied or traced.
- Preview mesh + evidence maps are DERIVED renders of the authored field
  (deterministic builders), not third-party content.

Checksums binding this record to the artifact: LUT f96dfd72725cd647,
zones f25c6037e5edab15, mesh sha256 ac109b68f9c3…2ab0c3d.
