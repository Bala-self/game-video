# ISLAND STRIKE — 01 WORLD CLARIFICATION REPORT (PROMPT 00)

| Field | Value |
|---|---|
| Prompt | 00 / PRE-EXECUTION GATE |
| Status | **READY — contract LOCKED, see §51verdict** |
| Date | 2026-09-20 |
| Workspace | `/home/user/island_strike/` (greenfield — audit §A) |
| Validation | `tools/validate_world_contract.py` — **53/53 PASS** |

This report is the §50 deliverable. Sections A–AD map 1:1 to the prompt's required
outline. Normative values live in `WORLD_MASTER_CONTRACT.md`; this report records the
audit, evidence, reasoning, assumptions, and readiness verdict.

---

## A. Project state summary

**Workspace audit result: EMPTY / GREENFIELD.** On 2026-09-20 the workspace
`/home/user` contained zero files and zero directories (verified by filesystem
enumeration at execution start). There is therefore:

- no legacy Godot project (`project.godot` absent),
- no scenes, scripts, resources, data, shaders, audio, or docs to migrate,
- no competing coordinate systems, registries, or managers,
- no tests, CI, or generated files,
- no technical debt and no hidden dependencies.

**Consequence:** all §23 "legacy vs placeholder" classifications collapse to a single
state — **MISSING (greenfield)**. No migration, wrapping, or deconfliction work is
required. The "existing project" sections B–E below therefore record *verified absence*
plus the engine-ground-truth that replaces inference (per §4.3 "do not infer from
variable names"). The origin decision (§5) is made free of legacy constraints, and the
"no second source of truth" rule (§24) is satisfied trivially: the registries created
from Prompt 01 onward are first sources, and this report's §W table pre-assigns their
ownership so duplicates can never arise unnoticed.

Risk note: greenfield removes migration risk but concentrates risk on *first-authoring
correctness* — hence the contract-first approach, the 53-check validation seed, and the
measure-then-lock performance strategy are load-bearing. See §Z.

## B. Existing world architecture

**None exists.** No world scene, terrain, sector system, or biome registry was found
(workspace empty). Architectural decisions for Prompts 01–10 are therefore greenfield
choices recorded in the Master Contract (§7 regions, §13 sectors, §15 ownership) and
the execution order §AD — not migrations. The first Godot project scaffold
(`project.godot`, folder layout, autoloads, registries) is scheduled as Prompt 01's
opening task so that terrain work (Prompt 02) inherits a stable skeleton.

## C. Existing coordinate system

**None exists in-project.** Engine ground truth (used instead of inference, per §4.3):

- Godot 4.x: **right-handed, Y-up; −Z forward** (`Vector3.FORWARD == (0,0,−1)`),
  `+X` right — the OpenGL convention. Sources: official Godot documentation
  "Using 3D transforms" (X Right / Y Up / Z Forward; "keep in mind that −Z is
  forward") and "Importing 3D scenes" ("Godot uses a right-handed, Y-is-up
  coordinate system, with the −Z axis as the camera's forward direction").
  Confidence: **VERIFIED** (first-party docs).
- 2D/minimap note: `Vector2.UP == (0,−1)` (Y-down in 2D) — minimap code must not
  reuse 3D sign conventions blindly.

**Locked mapping derived from this truth:** `+X`=East, `−X`=West, `+Y`=Up (height),
`−Z`=North, `+Z`=South; origin = island center = boundary center = `(0,0,0)`;
boundary tested on X–Z (`r=√(x²+z²)`); GPS `(gx,gz)=(x+2000,z+2000)`.
Full table: Master Contract §3. Validation `COO-01…COO-10` PASS.

## D. Existing terrain system

**None exists.** No heightmap, mesh, material, or terrain script was found. Terrain
strategy is therefore fully specified (not reverse-engineered) in Master Contract §6:
ocean floor −25 m → peak cap 220 m (absolute 250 m), locked grade limits per road
class, drainage rule, and the south-flats runway reserve. Engine capability context:
Godot 4.x ships **no built-in AAA terrain streamer** (verified by documentation
absence + community consensus: Terrain3D ≤65.5×65.5 km claimed, Voxel Tools, or
custom heightmap clipmaps are the available paths — all REPORTED/community). At
4×4 km the island is well inside Godot's comfortable range (community 20×20 km
worlds reported workable with chunking — REPORTED). Prompt 01 benchmarks the
terrain-stack choice; Prompt 02 synthesizes terrain inside the §6 envelope.

## E. Existing streaming system

**None exists.** Streaming strategy is specified greenfield in Master Contract §13:
256 m sectors, 16×16 grid over a 4096 m span, load/unload radii with hysteresis,
priority ladder (player > mission > heading-cone > AI > render-far > prefetch),
physics only within 512 m — with Prompt 07 benchmarking 128/256/512 m candidates
before the sector size is finally confirmed. Godot primitives to build on (all
VERIFIED in official docs): `ResourceLoader` background loading,
`MultiMeshInstance3D`, per-node visibility ranges/LOD. No Unity-style world
streamer exists in-engine (VERIFIED-by-docs-absence) — it must be authored.

## F. Target world geometry

Circular island, single landmass, ocean-surrounded, continuous coastline,
beach-terminated perimeter. Geometry is cylindrical on X–Z (boundary excludes Y).
Terrain mesh extends past the play boundary as a seabed skirt to ≥6000 m so the
visible horizon is water, never a mesh edge. All values §G–I.

## G. Island radius — `R_world = 2,000 m` (EXACT, locked)

Anti-confusion rule locked: "2 km" is ALWAYS the radius. Canonical constant
`R_WORLD`. Validation `GEO-01` PASS.

## H. Island diameter — `D_world = 4,000 m` (EXACT, locked)

`D = 2R` enforced by test (`GEO-06` PASS) so radius/diameter can never be silently
swapped in code or docs.

## I. World area — `π × 2000² = 12,566,370.61 m² ≈ 12.566371 km²` (locked)

Circumference `2π × 2000 = 12,566.37 m ≈ 12.566 km`. Validation `GEO-03…GEO-05`
PASS. Comparative context: 1.57× Sleeping Dogs (~8 km², full AAA urban game),
0.45× Ghost of Tsushima (~28 km², full AAA island game) — the scale bracket that
validates the density-first strategy (DR-01).

## J. Coastline contract

First-class spatial system (Master Contract §5): coastline spine → shoreline (y=0
contour) → beach/rock → coastal vegetation → inland → biome. Waterline must be a
**single closed loop** (genus-0; contour-tracing test mandated); tortuosity budget
≤1.43× (≤18 km actual waterline). Ring highway set back to r≈1750 (B1), never on
the beach. No land bridges, second continents, or square-edge boundaries — visual
and technical boundaries agree by construction (waterline = heightfield crossing).

## K. Beach contract

Nine locked classes tiling 360° (`sandy_wide/narrow`, `rocky_shore`, `cliff`,
`dune`, `urban_waterfront`, `industrial_port`, `marina_cove`, `hidden_cove`) with
per-class width/berm/ramp/access/role rows (Contract §9), minimum 150 m run-length,
class changes only at authored nodes. Beaches carry physical meaning (collision,
navigation, audio, missions) — never texture-only.

## L. Ocean contract

Single plane y=0 + seabed apron to ≥6000 m / −25 m; shallow (0→−6 m) and deep
(<−6 m) regions; swim/boat volume gating; soft warning at 2600 m, hard turn-back
at 4000 m; foam/depth rendering, surf audio, weather + day/night response all
derived from the same heightfield + `OCEAN_LEVEL` (Contract §8).

## M. Terrain contract

Height ladder −25 m → +220 m cap (absolute 250), monotonic coast→peak, grade
limits per road class (6%–12% + 18% trails), pad flattening ≤2%, runway ≤1%/800 m,
drainage (no accidental closed basins), south-flats runway reserve, north massif
placement (Contract §6). Avg coast→peak grade 14.7% < 15% (`HGT-05` PASS).

## N. Region contract

11 regions + reserve buffer, each with gameplay purpose, locked shares summing to
100% (Contract §7, `WORLD_AREA_BUDGET.md`): urban core (E coast) → suburban ring →
industrial → port/airfield → rural plains (S) → forest (W/central) → highlands (N) →
coastal ring → wetlands → infra corridors → special (SW resort + N restricted) →
6% reserve. Placement principles + 3 locked transition loops specified.

## O. World density model

Per-region (never global-average) budgets for roads, buildings, POIs, vegetation,
active peds/vehicles (Contract §10); global active ceilings (peds ≤220, road
vehicles ≤90, parked ≤400, visible veg ≤60k) pending Prompt 07 re-budget. Urban
core 350–600 bldg/km² (Sleeping-Dogs-class); forest 40–80k instanced veg/km².

## P. Travel-time model

Reference speeds walk 1.4 / run 6.0 / city car 13.9 / highway 27.8 / boat 12.0 /
aircraft 60.0 m/s. Locked matrix (winding 1.3× on named routes):

```text
center→coast 2 km:  walk 23.8 min | run 5.6 | city car 2.4 | hwy 1.2 | boat 2.8 | air 0.6
N→S / E→W 4 km:     walk 47.6 min | run 11.1| city car 4.8 | hwy 2.4 | boat 5.6 | air 1.1
city→north peak:    ~35 / ~8 / ~5 / ~3 / — / ~1 min
city→airfield:      ~20 / ~5 / ~2.5 / ~1.5 / — / — min
```

Validation `TRV-01…TRV-05` PASS. Design read: big on foot, fast by car — correct.

## Q. Landmark hierarchy

L1 world (3–5: peak+mast, city towers, causeway bridge, lighthouse headland) →
L2 regional (12–18) → L3 local (40–70, ≤400 m from any spawn) → L4 micro
(150–300); L1 silhouettes golden-tested (Contract §12).

## R. World grid / sector proposal

256 m sectors (candidate-locked), 16×16 over 4096 m span, load-3/impostor-5/
unload-6+hysteresis, priority ladder, physics ≤512 m; 128/512 alternatives
benchmarked in Prompt 07 before final confirmation (Contract §13). Tiling checks
`SEC-01…SEC-03` PASS.

## S. AAA research categories

12 categories × 38 questions in `WORLD_REFERENCE_MATRIX.md` (terrain, coast, roads,
urban, rural, NPC, vehicles, water, law/security, weather/day-night,
streaming/performance, missions/economy) fed by 18 title records + Godot engine
note in `AAA_OPEN_WORLD_REFERENCE_DATABASE.md` (+ 18 JSON files). Scale bracketing:
8 km² (Sleeping Dogs) … 28 km² (Tsushima) … 75–88 km² (GTA V/RDR2/FC6) … 270 km²
land (Altis, VERIFIED) … ~1000 km² (Just Cause, incl. sea).

## T. AAA source/evidence rules

Three-state evidence (`VERIFIED` / `REPORTED` / `UNKNOWN`) enforced per-record;
numeric scale claims record method + confidence; engine internals default UNKNOWN
unless first-party documented; Godot facts VERIFIED against official docs only.
Full matrices in the database doc; machine-readable confidences in JSON.

## U. Originality rules

Patterns-transfer/content-doesn't (DR-19); no copied coastlines, road graphs,
skylines, palettes, names, placements; "shelf test" at each review; research→design→
implementation pipeline (never game→copy); scope exclusions locked (Contract §21).

## V. Performance measurement strategy

Two-stage (Contract §14): Prompt 01 instruments CPU/GPU-or-UNAVAILABLE/physics/draws/
instances/AI/streaming/sector/shader/memory from day one; Prompt 07 locks
baseline/target/warning/failure per metric on declared target hardware. Provisional
targets (60 fps @1080p desktop, 30 floor; hitch ≤8 ms p95; sector ≤250 ms) are
explicitly NOT gates until measured. No unmeasured number may be reported as a result.

## W. Data ownership model

One DATA owner per datum (Contract §15 table: WorldRegistry, heightfield, coastline
arc table, road graph, nav tiles, placement tables, population profiles, mission
registry, balance tables); conflict protocol FLAG→TRACE→DECIDE→MIGRATE→TEST→
DOCUMENT; `*_v2/_final` shadow owners forbidden without revision record. Greenfield
means first authors are owners by default — recorded now so drift is detectable.

## X. Deterministic generation strategy

Master→region→sector→system u64 seed hierarchy, default master `13371337`
(Contract §16); guarantee same-inputs+version+seed = same world; runtime-only
streams non-persisted; `world_checksum` regression test mandated from Prompt 02.

## Y. Validation strategy

Six layers L0–L6 (data → geometry → topology → simulation → gameplay → performance →
regression); `tools/validate_world_contract.py` is the L1 seed (53/53 PASS, run
2026-09-20); each prompt extends it; no prompt locks with failing/skipped contract
tests; visual inspection supplementary only; failure taxonomy + no-silent-failure +
no-fake-pass rules locked (Contract §17–18).

## Z. Major risks

| # | Risk | Severity | Mitigation (locked) |
|---|---|---|---|
| 1 | Greenfield first-authoring errors (no legacy to check against) | HIGH | Contract-first + validation seed + checksums + reviews |
| 2 | Godot terrain/streamer authored custom (no built-in) | HIGH | Prompt 01 stack benchmark; 4 km well inside engine comfort |
| 3 | 12.6 km² feeling empty/thin | MEDIUM | DR-01 density budgets; Sleeping Dogs precedent; drive-through tests |
| 4 | Coastline loop breaks (2nd loop / gap / bridge) | MEDIUM | Genus-0 contour test; tortuosity budget; B3 no-build rule |
| 5 | Road↔terrain grade conflicts | MEDIUM | Grade caps lock terrain AND roads; route-cost tests |
| 6 | Performance unknowns until Prompt 07 | MEDIUM | Instrument-first; provisional targets labeled, not gated |
| 7 | Scope creep (2nd city, snow biome, multiplayer…) | MEDIUM | §21 exclusions + area-change control + reserve buffer |
| 8 | Research figures imprecise (REPORTED methods vary) | LOW | Confidence labels; no exact requirement rests on REPORTED data |
| 9 | Runway flat vs terrain interest conflict | LOW | South-flats reserve pre-locked; terrain must yield to strip |
| 10 | Seed/version drift breaking determinism | LOW | Checksum regression test; version in hash inputs |

## AA. Required assumptions

| # | Assumption | Rationale | Risk | Reversibility | Validation |
|---|---|---|---|---|---|
| 1 | Island center = world origin | Simplifies radial math; no legacy conflict (empty WS) | None found | High | COO tests PASS |
| 2 | North = −Z | Matches Godot forward convention | Low | High | Engine docs VERIFIED |
| 3 | Godot 4.3+ target | Current stable 4.x lineage | Low | High | Prompt 01 pins exact version |
| 4 | 256 m sectors | 16×16 tidy grid; mid-point of community practice | Medium | High | Prompt 07 benchmark 128/512 |
| 5 | 24-min day cycle | Common action-game pacing | Low | Trivial (data) | Playtest tuning |
| 6 | REPORTED scale figures adequate for bracketing | Exact AAA sizes unknowable; only brackets drive rules | Low | N/A | No exact req. depends on them |
| 7 | Single-player baseline; no netcode | Scope control for 10-prompt budget | Medium | Medium (determinism helps) | §21 exclusion; revisit post-10 |
| 8 | Desktop-class primary target | Godot open-world reports center on PC | Medium | Medium | Prompt 01 declares min-spec HW |

## AB. Questions resolved through evidence

1. Godot axes/forward/up? → **Resolved VERIFIED** via official docs (−Z fwd, Y up, RH).
2. Godot built-in world streamer? → **Resolved**: none (docs-absence + community) — must author.
3. Is 12.566 km² enough for AAA-like depth? → **Resolved**: yes at density (Sleeping
   Dogs 8 km² / Tsushima 28 km² bracket — REPORTED but convergent).
4. Radius vs diameter? → **Resolved**: 2000 R / 4000 D, test-enforced.
5. Beach-everywhere reading? → **Resolved**: continuous coastal *system* with 9 varied
   classes, not uniform sand (Contract §9).
6. Multi-map vs seamless? → **Resolved**: seamless single island (DR-02).
7. Area budget closure? → **Resolved**: 100.0% exact, test-enforced.
8. Travel feel? → **Resolved**: computed matrix; big-on-foot/fast-by-car.

## AC. Genuinely unresolved (deferred with owner + prompt)

| # | Question | Owner prompt | Why deferred |
|---|---|---|---|
| 1 | Exact Godot version + render API (GL/Fwd+/Mobile) | Prompt 01 | Needs target-HW declaration first |
| 2 | Terrain stack (Terrain3D vs Voxel vs custom clipmap) | Prompt 01 | Needs benchmark on target HW |
| 3 | Heightfield resolution (1/2/4 m pitch) | Prompt 02 | Needs terrain-stack + perf data |
| 4 | Final sector size (128/256/512) | Prompt 07 | Needs streaming benchmark |
| 5 | Locked perf budgets | Prompt 07 | Measurement must precede budget (DR-20) |
| 6 | Exact ped/vehicle/AI tick architecture | Prompt 08 | Needs nav + streaming + crowd tests |
| 7 | Swim/boat/aircraft final feature cut | Prompt 03/09 | Needs water + mission-scope pass |
| 8 | Art-style final look-dev | Prompt 05 | Needs district blockout first |

None blocks Prompt 01 (scaffold + benchmark prompt by design).

## AD. Recommended execution order (Prompts 01–10)

```text
P01  SCAFFOLD + STACK BENCHMARKS — project.godot, folders, autoloads, registries,
     instrumentation; terrain-stack + sector-size + import-pipeline benchmarks; pin
     Godot version + target HW. (Unlocks everything; resolves AC-1/2.)
P02  TERRAIN SYNTHESIS — heightfield in §6 envelope + runway reserve + drainage;
     world_checksum test born here. (Resolves AC-3.)
P03  COAST + WATER — 9-class coastline loop, y=0 waterline, foam/depth shader,
     swim/boat volumes, audio zones. (Resolves AC-7 water half.)
P04  ROADS + NAVIGATION — ring+radials graph, grade validation, nav tiles,
     bridges/underpasses, route-cost tests.
P05  DISTRICTS + BUILDINGS + VEGETATION — urban/suburban/industrial/rural authoring,
     look-dev, instancing, HLOD; density audits vs §10.
P06  POIs + LANDMARKS + WATER BODIES — L1–L4 placement, inland river/lake, docks,
     contract boards, viewshed + visibility tests.
P07  STREAMING + PERFORMANCE LOCK — sector streamer, LOD, budgets locked on target
     HW; 128/256/512 decision. (Resolves AC-4/5.)
P08  POPULATION + TRAFFIC + SECURITY — region profiles, crowd/traffic sim, wanted/
     escalation, checkpoints. (Resolves AC-6.)
P09  MISSIONS + ECONOMY + GAMEPLAY LOOPS — hubs, arcs, courier/cargo, airfield/boat
     gameplay, travel-cadence acceptance. (Resolves AC-7 fully.)
P10  INTEGRATION + REGRESSION + SHIP-READINESS — full pass, L0–L6 suite green,
     golden screenshots, docs, lock.
```

Dependency order follows Contract §19; each prompt runs the §30 pipeline
(Requirements…LOCK) and extends the validation suite.

---

## §51 READINESS VERDICT

```text
WORLD CONTRACT:            READY (LOCKED v1.0.0)
RESEARCH CONTRACT:         READY (18 records + 38-question matrix + 20 design rules)
PROJECT TRUTH:             READY (greenfield verified; engine ground-truth VERIFIED)
IMPLEMENTATION PREREQUISITES: READY (Prompt 01 scaffold+benchmark unblocked;
                             8 deferred items all owned by later prompts, none critical)
```

## §54 LOCK CRITERIA CHECKLIST

```text
project inspected ............................ YES (empty workspace, enumerated)
world target mathematically defined .......... YES (GEO-01…06 PASS)
coordinate contract defined .................. YES (COO-01…10 PASS)
boundary contract defined .................... YES (BND-01…11 PASS)
coastline contract defined ................... YES (§J + §5 + tests specified)
beach contract defined ....................... YES (§K + 9 classes)
ocean contract defined ....................... YES (§L + §8)
terrain contract defined ..................... YES (§M + HGT-01…05 PASS)
regional strategy defined .................... YES (§N + budget 100%)
AAA research methodology defined ............. YES (evidence states + 18 records)
AAA evidence methodology defined ............. YES (§T confidences + JSON)
originality rules defined .................... YES (DR-19 + pipeline)
data ownership strategy defined .............. YES (§W table)
determinism strategy defined ................. YES (§X hierarchy + checksum)
validation strategy defined .................. YES (§Y L0–L6 + 53-test seed)
performance strategy defined ................. YES (§V two-stage + DR-20)
documentation created ........................ YES (6 docs + 18 JSON + 1 tool)
no critical unknown blocks Prompt 01 ......... YES (§AC all deferred-with-owner)
```

**Prompt 00 status: LOCKED.** Awaiting explicit `NEXT` before Prompt 01, per §56.

*End of clarification report — Prompt 00.*
