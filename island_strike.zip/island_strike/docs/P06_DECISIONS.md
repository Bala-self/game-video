# P06 DECISIONS (P06-D1 …)

Record of every material design decision taken during Prompt 06
settlement + district + building reconstruction. Newest last.

## P06-D1 — Convex-quad road-band blocks instead of full planar polygonization

The road network is sparse (25 edges, ~2.3k stations over a 6×6 km
island). Full planar polygonization of road bands yields mostly
unbounded faces and slivers — unusable as allocation units. Gen-C
therefore emits convex-quad OBB blocks marching along road runs:

- frames derive ONLY from road centerline stations (centroid + chord
  tangent); never from district bounds;
- runs split at junction discs (R+4 m), the runway (+20 m), tangent
  breaks > 12°, and a 120 m allocation cap;
- the road band is treated as a barrier: the block edge clears the
  measured per-window chord deviation + half width + 1 m;
- ends inset 3 m each (inter-block alley gap; adjacent windows share a
  station with different tangents, which otherwise wedges overlaps).

All §6 validations still enforced (exactness, ±2° edge alignment,
road/junction/runway clearance, district intersection, no subdivision).

## P06-D2 — Priority partition for district membership

District bounds are authored policy zones (discs/sectors/rings) that
intentionally overlap (gradient rings carved by special districts,
cross-settlement fringe). Membership is a global deterministic
partition: highest `district_priority` wins; the contract table is
verified tie-free and area-closure sampling asserts zero ties.
Transitions between winning districts are classified against an
explicit gradient/sharp table; anything else fails the build.

## P06-D3 — Parcel modes: urban rows, campus zones, rural direct

One subdivision algorithm cannot serve towers, ports, and farms:

- URBAN: road-fronting rows, recursive binary split along frontage
  with §46 acceptance (area/frontage/buildability/access/reservation),
  alternate seeded positions, remainder merged into neighbor (no
  slivers), back rows behind `access_lane` parcels.
- CAMPUS (port/industrial/airfield/restricted/civic/resort/utility):
  functional zones along the long axis, never force-split; whole-block
  fallback, then open ground.
- RURAL/DIRECT: seeded placement with driveway corridors for farms,
  block-less campus districts (port industry), and terrain-driven
  pockets (highland cabins cluster-share one driveway).
- Beach access parcels are placed directly on `coastal_beach` land.

## P06-D4 — Hillside grade limits follow measured terrain (contract patch)

Parcel grades were measured per district (restricted ~0.30, highland
0.21–0.30, bluff-top waterfront/resort 0.16–0.19). Class
`terrain_grade_limit` values were raised to real hillside practice
(terrace/stilt construction recorded per building via §50
foundations): restricted_facility → 0.30, farmhouse/rural_service →
0.30, detached_lowrise → 0.18, coastal classes → 0.15–0.20. Urban
classes unchanged. Note stored in
`building_contract.validation.grade_limit_note`.

## P06-D5 — Gen-D building-viability probe

A parcel can clear hard layers yet sit 70% inside P05
building-setback/utility zones and never host a footprint. Gen-D
requires ≥10/25 samples clear of FULL building exclusion, else the
lot merges or the row becomes OPEN green (utility-corridor greens).
Gen-E keeps the exact per-footprint test as authoritative.

## P06-D6 — Bounded placement search, no retry loops

Gen-E tries at most 2 sizes × 4 depth-spanning positions per class
(fixed order, seeded aspects fitted to the envelope). Commercial
starts at the street wall and falls back deeper; residential starts
mid-yard. Overlap tolerance 0.5 m (eaves). No unbounded loops anywhere.

## P06-D7 — View-corridor repair: height change, else prune

Gen-E runs before corridors exist, so §49's corridor rule is enforced
as a deterministic Gen-F repair on REQUIRED corridors only: lower the
building to the worst sightline (if ≥ class minimum), else prune the
building and mark the parcel OPEN_SPACE. Roads and terrain are never
touched. This run: 0 intrusions on REQUIRED corridors, 0 repairs.

## P06-D8 — Engine parity is semantic, not float-identical

Python authors data; Godot verifies. `tests/godot/tools/
buildings_check.gd` checks counts, IDs, bounds, heights (±0.05 m),
footprints (±0.01 m), sectors (exact, same GRID_MIN/SIZE), mesh
validity, and a cross-language-safe fnv1a32 semantic checksum over
`id|class|h3|sector` lines. This run: `0f77e981` on both sides.

## P06-D9 — Rectangle footprints (rect_union model)

All parcels are rectangles by construction; all footprints are
rectangles in the parcel frame (CCW, closed). Variety comes from
size/aspect/height/roof/facade/position/style — not from L/U shapes.
Sufficient for massing + LOD + gameplay metadata; documented
limitation, not a defect.

## P06-D10 — Open-space connectivity is constructional

Every OPEN parcel carries road access by construction (DIRECT / LANE /
DRIVEWAY / CAMPUS / BEACH_PATH); the §62 analysis verifies the
special chains (resort→beach, core→plaza, waterfront→access) rather
than discovering a network. Operational/restricted open space is
explicitly excluded from the public network.
