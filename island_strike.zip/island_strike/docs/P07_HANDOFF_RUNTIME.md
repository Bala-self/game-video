# P07 HANDOFF — RUNTIME (for P08+)

## What later prompts inherit

- Sector grid (256 m, locked): `data/world/sector_contract.json`,
  math in `tools/sector_math.py` + `scripts/core/sector_service.gd`.
- Stream manifest: `data/derived/world_stream_manifest.json`
  (`3970e8e7e96b4e17`, graph `fd1574c71d359143`).
- LOD policy: `data/derived/lod_policy.json` (`b8df59a10ec1f39d`).
- Runtime reference: `tools/streaming_sim.py` (deterministic model
  of the scheduler/loader/activator/cache/LOD behavior the engine
  runtime must reproduce).
- Budgets: `docs/P07_PERFORMANCE_GATES.md` (CURRENT_ENVIRONMENT;
  production PROVISIONAL).

## Future-ready interfaces (NOT YET APPLICABLE, owner = future prompt)

- `pin_sector(owner, reason, ttl)` — mission/route/collision pins;
  lifecycle validated, no mission logic implemented.
- Arrival zones (P06 places.json) — spawn/drive-in contexts.
- Save/load hook: sector_version + persistent content ids exposed;
  transient loading state is never serialized.
- Collision policy classes (CRITICAL/NEAR/ROUTE/MISSION/BACKGROUND)
  defined as handoff only; full collision stays a later prompt.
- loaded vs active vs processing separation is modeled; per-frame
  script/AI processing of buildings is a later prompt.

## Invariants future work must preserve

- Manifest is derived; sources win disagreements; regenerate, never
  hand-edit. Sector size changes are versioned + re-benchmarked.
- FAILED → ACTIVE impossible; no duplicate runtime objects; no
  unresolved pins at rest; dependency graph stays acyclic.
- Performance regressions compare against
  `reports/p07_performance_baseline.json` (`performance_baseline_id`
  in `reports/p07_streaming_summary.json`).
