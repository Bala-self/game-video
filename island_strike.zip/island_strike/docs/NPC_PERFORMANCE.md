# NPC PERFORMANCE (P09) — LOCKED

Method (P08-D12 comparability): CPU time via `process_time_ns` (wall
time excluded), 300 measured ticks after 30 warmup ticks, fixed seeds,
gated figures are median-of-3 repeats (same seed/scenario, paired
full/ablated runs), env + pins recorded in `reports/p09/perf.json`
evidence. Reference implementation is Python; engine figures will
differ — comparability comes from the documented method, not from
matching numbers.

## 1. Load curve (realistic placement, retirement on, N held)

| NPCs | ms/tick | arrivals/300t |
|------|---------|---------------|
| 25   | 0.20    | 2             |
| 50   | 0.51    | 4             |
| 100  | 1.89    | 18            |
| 200  | 5.84    | 27            |
| 500  | 24.37   | 40            |
| 1000 | 86.71   | 96            |

Superlinear past ~200 (neighbor + LOS candidate density); every level
holds N exactly with zero illegals and live arrivals (real AI load,
not idle spin — verified after catching a first draft that measured
stuck NPCs).

## 2. Gates (contract, ~2× headroom per P08-D9)

- `ai_cpu_ms_100` = 4.0 (measured 1.79–1.89)
- `nav_cpu_ms_100` = 0.5 (measured 0.19, ablation)
- `perception_cpu_ms_100` = 0.5 (measured 0.12, ablation)
- `memory_mb_1000` = 256 (measured 71 MB process peak, flat)

Subsystem split by ablation (`enable_paths`/`enable_perc` flags, always
true in production): full − without-paths = nav; full − without-perc =
perception. Perf suite enforces all four gates on every run.

## 3. Worst case

250-NPC all-T3 crowd in 40 m: 39.17 ms/tick, 250/250 T3, 80 arrivals.
Urban hotspot (city at peak + traffic + loud event): see
`reports/p09/stress.json`. Nav hotspot (mass repath every 20 ticks):
p50/p99 tick latency recorded, cache invalidations counted. Streaming
hotspot (5-stop island sweep): tier churn counted, zero stale refs,
zero leaks, RSS delta recorded.

## 4. Long run (§90)

2000 uninterrupted ticks, city focus: population stable (sampled every
200 ticks), arrivals ongoing, zero illegals, zero leaks, hub within
peak + 5. Evidence in `reports/p09/stress.json` (`long`).
