# P05 DECISION LOG (transport infrastructure)

D-01 P03 topology and P04 surfaces are read-only inputs. All structure
geometry derives from ribbon verts / station frames; nothing re-authors
the graph, the mesh, or any locked artifact. Proven by IMPACT-STRUCTURE
(pinned P03/P04 checksums) plus full upstream re-green at lock.

D-02 Parapets run the full wet span, not just BRIDGE stations. P04 marks
~30 m of each crossing BRIDGE while the wet span is ~50 m; parapet base
verts follow ribbon edge verts with interpolated wet ends (validator
mirrors the lerp bitwise). Measured cover: 50.13/50.13 and 52.79/52.79.

D-03 No piers without source data. Both crossings are short single spans;
the generator records piers: none with reason, and the validator gates
count == 0. A future bathymetry prompt may add piers with provenance.

D-04 Retaining walls face the road by terrain vote, wound uniformly.
Per-segment terrain probes vote; majority wins; all quads share one
winding (no flip-flop on noisy segments). 10 walls, 28 dispositions,
zero dropped cuts; portal cuts get portal_treatment, shallow cuts stay
natural_slope, split cuts are mixed.

D-05 Barriers are measured need, never decoration. Guardrail/concrete/
curb from cliff/embankment/curve risk per station pair; 12 runs, all
outside junction discs, none blocking a legal connector (cross-gated).
Short risky stubs (< 8 m) are intentionally unprotected (delineators
instead); 6 short segs / 38 m remain, 0 long gaps.

D-06 Markings follow P03 movements exactly: 111 connectors marked, 10
explicitly skipped with reasons (6 junction-None transitions, 4
bridge/tunnel continuity), 0 missing, 0 disallowed movements marked,
arrows never on STRAIGHT, yields only on roundabout entries.

D-07 Paint contact is two-tier: every strip vert within 0.035 of its
station frame + lift (grade-proof), tri centroids within 0.08 (gross
float net). Centroid-only comparison smears 5 cm on steep grades and
was rejected as a tight gate after measurement.

D-08 Tunnel clearance is gated over the traveled way (lane geometry
from the profile registry: 5.88 min vs 5.0 required), with a separate
2.5 m walkway-headroom gate over shoulders (4.21 min). Arch springline
at |lat| 14.6 clears 4.21 over the shoulder — by design, not a defect.

D-09 Portal furniture: hazard markers flank the headwall at road level;
walkway bollards live just inside the bore (off lanes, against the
lining). Off-road checks are 3D: grade-separated roads within 30 m plan
do not count (the hairpin passes 4 m under the east portal furniture).

D-10 Signs nudge out of sight triangles by compass search that preserves
own-edge clearance. Thin poles stay out of sight lines; 0 conflicts.
Lights follow the regional policy (urban 35 m, infra-primary 70 m,
else none): 195 lights, none in forest/highland dark zones.

D-11 Reservations index every id (442 cells, 100% cover) and the
authoritative query API is tools/reservation_index.py (ReservationIndex:
is_reserved / types_at / nearest / veg / building / junction-excluded).
Vegetation/building/nav/traffic/collision consumers extend via the NEW
transport_handoff_ext.json (sha-pinned, never edited in place).

D-12 Abutments never invert: base = min(terrain - burial, top - 0.5 m).
BC-01-B sits in approach fill (ground above deck underside); it keeps a
buried 0.5 m stub rather than a zero/negative box.

D-13 q6 chainage rounds to nearest; validator tolerances are 1e-6 where
they meet rounded records. Six 10 m phantom barrier gaps and one range
failure were rounding slivers (<= 5e-7), proven by station-pair audit,
not coverage defects.

D-14 HAIRPIN_BULB is a synthetic fixture only: validator proves the real
E_ring_hw_02 bulb needs no escalation (2 proper fillets stand) while the
fixture correctly escalates (legs too short for R17). No real geometry
changed for the test.
