# WANTED_POLICE_SYSTEM (P10)

## Model (wanted checksum `f0b2d78281535f5c`)

Levels: NONE, SUSPECTED, WANTED_1..5. Enabled offenses: TRESPASS
(severity 2) and VEHICLE_THEFT (severity 3); five hook classes
(THEFT/ASSAULT/COLLISION/PROPERTY/WEAPON) are contract-reserved and
rejected without a producer system (DEFERRED, matrix P10-HOOKS).

## Witness (P09 consumption)

`_witness_scan` consumes live P09 facts: NPCs within 60 m, LOS check,
+0.2 if the observer's `perceived` includes PLAYER (gated by P09 `los_m`),
+0.15 for SECURITY/WORKER archetypes; threshold 0.5, top-3 reporters.
No witnesses → SUSPECTED at most, no dispatch. Impact t2 proves
sensitivity: CIVILIAN `los_m` 40→5 m drops the 30 m-ring probe from 3
reporters to 1, and STATIC flags exactly the `npc_perception_policy` pin.

## Escalation / dispatch / pursuit

- Escalation compares level numbers (fixed §94 index bug); fresh witnessed
  crime while wanted with no pursuit re-dispatches (units re-engage).
- Dispatch tables: W1 {1,0}, W2 {2,0}, W3 {2,1}, W4 {3,1}, W5 {3,2}
  (npc, vehicle). NPC units via P09 acquire near the scene; vehicle units
  via P08 `try_spawn` + `pin`.
- Pursuit machine: DISPATCH → APPROACH ⇄ PURSUIT ⇄ SEARCH → LOST →
  COMPLETE (+ARREST→COMPLETE, ABORTED). APPROACH→SEARCH lost-sight edge
  added in-prompt (contract allowed it).
- Arrest: intercept within 6 m + slow/surrendering 20 ticks → ARRESTED,
  fine txn (TRESPASS 150), respawn at ARRIVAL node.
- Escape (multi-factor: unseen>300 ticks + distance + coverage ≥ 0.7):
  SEARCH→LOST→COMPLETE, level NONE. Units lost beyond relevance with a
  cold trail also complete as ESCAPED (never silent ABORTED).
- Quiet decay steps the level down every 900 ticks without a pursuit.

## Persistence

Save stores the wanted level (restored exactly); pursuit units are
transient by design and stand down on load (matrix note, save-edge
`pursuit-transient-by-design`).

## Evidence (measured)

- WANTED-GAMEPLAY 11/11: hooks rejected, witness cap, no-witness,
  dispatch, arrest+fine (500→350), escape, theft-on-entry, surrender.
- Final smoke s12–s17 (OFF-0002, 3 witnesses, WANTED_3, P08 vehicle unit,
  outcome ESCAPED); probe session: 19 wanted events, 2 dispatches,
  2 pursuits, 1 arrest.
- Section cost: 0.098 ms/tick mean.
