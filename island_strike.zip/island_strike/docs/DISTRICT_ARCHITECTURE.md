# DISTRICT ARCHITECTURE (P06 Gen-B/C/D)

## Layers

```
terrain / regions (P01/P02, locked)
road network + geometry (P03/P04, locked)
reservations + structures (P05, locked)
  → settlements (11, authored anchors on locked nodes)
    → districts (19, policy zones: disc / sector / ring)
      → membership partition (global, priority-ordered)
        → blocks (161 convex-quad OBBs along road runs)
          → parcels (579: urban lots / campus zones / rural direct)
```

## Settlements

| id | class | anchor | districts |
|----|-------|--------|-----------|
| SET-hub | MAJOR_CITY | hub_city | core, mixed, civic, commercial, resin, resout, water |
| SET-port | PORT_COMPLEX | port_gate | ops, ind (hub-facing arc excluded) |
| SET-air | AIRFIELD_COMPLEX | air_gate | ops (runway rect avoided) |
| SET-sub | SECONDARY_TOWN | sub_center | mixed, sub |
| SET-village | VILLAGE | village_center | core |
| SET-resort | RESORT_CLUSTER | resort_waterfront | main, secure |
| SET-restricted | RESTRICTED_COMPLEX | (spur gate) | secure |
| SET-forest | RURAL_CLUSTER | forest_depot | svc |
| SET-highland | RURAL_CLUSTER | ridge_end | look (shoulder disc, peak avoided) |
| SET-farmA/B | (agri) | — | farmA, farmB |

Routine notes: farmC's authored site was wetland → replaced by probed
pasture site farmC2 (500,700). Highland disc moved off the 47% peak
onto the buildable shoulder (still contains the ridge node).

## Membership & area closure

`data/derived/districts.json`: `area_closure` proves per settlement
`districts + water + infrastructure + natural` with zero priority
ties (8 m grid). `transitions` classifies every district adjacency
(12 VALID_GRADIENT + 5 VALID_SHARP_TRANSITION, buffers recorded).

## Blocks

`data/derived/blocks.json`: 161 kept, 361 dropped-with-reason
(345 outside districts = rural frontage, 8 junction, 3 runway, plus
degenerate windows). Fields: frame, corners, area, frontage,
junction relation, access, buildability, campus flag, seed.

## Parcels

`data/derived/parcels.json`: 579 parcels + skips + 180 rejections
(all reasoned). Roles per §47 policy; setbacks from district
profiles + road-class minima + junction adders; access
DIRECT/LANE/LANE_VIA/CAMPUS/DRIVEWAY/BEACH_PATH. Landlocked public
parcels: none (verified by construction + validators).
