# P07 DECISIONS (P07-D1 …)

## P07-D1 — Sector size 256 m SELECTED FOR THIS PROJECT

Benchmarked 128/256/512 on identical world state + paths (p07bench1,
clean run, 2 reps each, deterministic):

| size | crossing mem | fmax | load p95 | churn | reqs |
|------|-----|------|----------|-------|------|
| 128 | 2.9 MB | 46 ms | 3.5 ms | 169 | 198 |
| 256 | 5.5 MB | 69 ms | 8.3 ms | 71 | 101 |
| 512 | 6.3 MB | 121 ms | 22.2 ms | 27 | 51 |

- 128 REJECTED: 2.8× churn / 2× requests vs 256; equal-coverage
  R=2 confirmation run cost 331 requests + 5.2 MB + 46 active —
  worse than 256 on every axis except per-sector load.
- 512 REJECTED: hotspot 102 buildings/sector, load p95 34 ms,
  frame max 193 ms, 2× resident objects (286 vs 152 end-count).
- 256 SELECTED: balanced on all axes AND 1:1 alignment with the
  P05/P06 256 m batch/sector grid (180 mesh batches map directly to
  stream sectors; 128/512 would orphan that alignment).

Evidence: reports/p07_size_compare.json. First (instrumented) run
agreed on ordering; clean run is canonical.

## P07-D2 — Radii R=1 / U=3 / P=2 locked for 256 m

Streaming radius 1 (768 m active span), unload radius 3 (hysteresis
band absorbs boundary dither), prefetch radius 2 with budgeted
ahead-cone issue (2/tick, cap 8 sectors). Verified by oracle
agreement (cross suite) and teleport boundedness.

## P07-D3 — DISTANCE-aware cache eviction selected by measurement

Pressured revisit benchmark (cap 16 entries, EW-return path):
DISTANCE hit 0.228 > LRU 0.214 > PRIORITY 0.124. Static priority
does not predict revisits; distance does. Cap stays 64 entries
(generous, bounded). Linear one-way paths show ~0 hits by design;
cache value is proven in long-run revisit runs.

## P07-D4 — Memory sampler moved out of the frame clock

Spike attribution proved 131/132 crossing spikes were the deep-size
memory sampler (up to 458 ms), not sim work. Fix per §70: frame
clock stops before sampling; cadence 500 ticks. Genuine worst frame
after fix: 61.3 ms (multi-sector activation; locked gate). Both the
instrumented finding and the genuine numbers are reported honestly;
gates use genuine frames.

## P07-D5 — Primary-sector ownership with geometric fallback

Every owned object (block/parcel/building) has exactly one primary
sector: centroid sector when covered, else first overlapped sector.
Fallback exists because 2 P06 blocks have frame-centers outside
their corner quads (upstream quirk, locked, not repaired). Districts
are zones (listed in all overlapped sectors, never owned). Roads
stream as per-(edge,sector) fragments; cross-sector structures share
one STRUCT unit that activates once.

## P07-D6 — LOD gating rule incl. shared units

No distance-LOD object may claim non-UNLOADED unless its sector is
ACTIVE; shared STRUCT components are live iff their UNIT is ACTIVE
with an ACTIVE user (cross-suite enforced). Terrain objects follow
sector state. Hysteresis exit = enter × 1.15; oscillation fixture
allows ≤1 change at every boundary.

## P07-D7 — Semantic (not float-identical) engine parity

Python sim authors behavior; Godot re-verifies math, bounds,
world-state, LOD sanity, dependency acyclicity, the state table, and
a cross-language fnv1a32 semantic checksum. This run: `e5f12b8d`
both sides; 6 static golden contexts replayed in-engine.

## P07-D9 — Determinism scope is world state, not wall-clock

Reproduce flaked once: a genuine frame crossed the 50 ms spike
threshold in one repeat but not the other (timing noise, not state
divergence). Spike counts are excluded from snapshot-core and
golden comparisons; timing stays covered by the perf suite with
tolerances. Golden lod_sample is stored as JSON-native lists
(tuple/list mismatch made first-compare fail spuriously — fixed,
goldens regenerated, engine replay re-verified).

## P07-D8 — Budgets are CURRENT_ENVIRONMENT; production PROVISIONAL

All gates measured on this CPU-only headless host (2 vCPU, ~1 GB).
No GPU/VRAM exists here (recorded NULL + reason). Production
hardware certification is explicitly PROVISIONAL, never claimed.
