# ISLAND STRIKE — PROMPT 04 REPORT (physical road geometry)

Date: 2026-09-21. Status: COMPLETE, all suites green, ready to LOCK.
Scope: locked P03 graph (22 nodes / 25 edges / 23.14 km, checksum
`0e28622c1bb2185b`) turned into physical road geometry — cross-section
profiles, crown/crossfall, station chainage, terrain contact, junction
surfacing (21 junctions + 1 butt joint), turn connectors, 6-arm
roundabout ring + island, BC-01/BC-02 deck profiles, tunnel portal
chain, 2 ruled hairpin fillets, 248 sector fragments, 179 reservations,
collision/navigation/traffic handoffs. Python-authoritative generator
(`tools/road_geometry.py`) + lightweight GDScript mesh verifier
(`tests/godot/tools/geometry_check.gd`). Mesh: 53 parts, 31226 verts,
52838 tris, every tri up-facing, checksum `69ca624214ee76fe`.

## §1 INPUTS (pinned versions)

| input | version | path |
|---|---|---|
| geometry contract | 0.1.0 | `data/world/road_geometry_contract.json` |
| contract schema | 1.0.0 | `data/world/road_geometry_contract.schema.json` |
| profile version | 0.1.0 | (contract `profile_version`) |
| P03 roads (LOCKED) | `0e28622c1bb2185b` | `data/derived/roads.json` |
| terrain (P02 LOCKED) | 0.1.0 | Field API only (`tools/terrain_model.py`) |
| coast (P02 LOCKED) | 0.1.0 | via Field API |
| world (P01 LOCKED) | 0.1.0 | `data/world/world_contract.json` |

Generator refuses stale/mismatched inputs (INJECT stale-version mutant
proves it). All height/grade/region/coast math is consumed from the P02
Field API only; no duplication. P03 graph untouched: same 22 nodes / 25
edges, same routes/widths/classes/access/tunnel flags (STATIC
graph-edge checks prove field-by-field identity).

## §2 OUTPUTS

| output | path | content |
|---|---|---|
| road geometry | `data/derived/road_geometry.json` | analytic + 53 mesh parts (9.2 MB) |
| nav handoff | `data/derived/road_nav_handoff.json` | routes |
| traffic handoff | `data/derived/road_traffic_handoff.json` | flows |
| collision handoff | `data/derived/road_collision.json` | barriers |
| golden | `reports/p04_geometry_golden.json` | regression snapshot |
| summary | `reports/p04_road_geometry_summary.json` | machine-readable P04 record |
| validator | `tools/validate_road_geometry.py` | 6 suites |
| smoke | `tools/road_geometry_smoke.py` | rebuild + gates |
| engine verifier | `tests/godot/tools/geometry_check.gd` | cross-layer mesh check |

## §3 CROSS-SECTIONS (profiles, crown, crossfall)

Per-class band stacks from the contract sum EXACTLY to the locked P03
edge width (unknown widths refused). Column layouts: primary w30 →
11 cols, secondary w30 → 11, w20 → 9 (?), w14 → 7, narrow → 5.
Crown apex rule + crossfall percent per class; surface lift
(`surface_lift_m`) raises the drivable surface above the reference
profile. Station columns carry analytic normals (crown/crossfall
slopes); mesh verts store them for direct Godot import.

## §4 STATIONS (chainage, structures, grades)

2283 stations, edge-local chainage (P03 route chainage normalized).
Marks win within 1 mm (exact inserts for trims, bridge wet spans,
portal transitions; P03 samples under marks dropped — no cm-slivers).
Structure classes: ORDINARY_TERRAIN_CONTACT (elev == terrain to 1e-6,
drift-checked), BRIDGE (wet spans), SPECIAL_STRUCTURE (bridge
approaches + tunnel portals), TUNNEL (bore), SPECIAL (approach
embankments, skirted). Grades re-computed on road_elev (decks differ
from terrain profile); max |grade| 0.2% on open alignment (tunnel bore
0.03%, P03 value preserved).

## §5 HAIRPIN FILLETS (proven P03 defect, ruled correction)

Two P03 polyline vertices carry impossible instant turns (R=0 <
class turn minimum): E_ring_hw_04 d=1550 δ=122.1° (legs 10.7/10.3 m),
E_tr_highland_00 d=54 δ=48.4°. Rule (`hairpin_fillet`, contract):
δ > 45° → corner arc, R = max(half_width + 2, min(class
junction_turn_min, walkable_straight/tan(δ/2))), tangent points by
polyline arc-length walk (legs must continue within 10°), arc sampled
at 2 m, elevations = terrain (terrain-following, drift-check exact),
stations between tangents consumed (recorded). Results: ring R=17.0 m
(class exception: exceeds primary turn_min 15, fit-driven), arc
36.2 m, 20 samples, consumed idx 160–166; trail R=3.5 m, arc 3.0 m,
3 samples. Post-fillet max step deflection 6.4° / 24.2° (gate 45°).
If legs are too short/curved the builder raises HAIRPIN_BULB
(turnaround-junction escalation — not triggered; both fit). The
pre-fillet ribbon folded past vertical (ny≈0); post-fillet the ribbon
is uniformly up-facing.

## §6 JUNCTION SURFACING (21 junctions + 1 butt)

Per junction: envelope disc R (contract rule + margin, min/max
clamped), chord trim per arm, mouth frames (bearing/pos/E/grade-out/
width/class/access), road-following rim (rim y = mouth chord lerp
inside spans, never plaza-flat — plaza-inside-spans pitched strips
past vertical, proven by failure), radial strip triangulation mouth↔rim
(uniform chirality: fixed order + strict emit; straddling rim-dip
quads orient by per-tri exhaustion), platform fan, skirts on non-mouth
rim spans (embankment to terrain, toe tucked).

Contested arcs (5 sites: hub_city, jn_W_portal, jn_air, jn_ring_N,
jn_ring_S): strict-interior span overlap by 2 mouths. ALL FIVE are
merge crossings (chord pairs cross — probed, not assumed). Rules:
arc-level stripping (arc-inner strips the whole closed arc, outer
skips; rim y follows arc-inner — per-edge/per-angle splitting twisted
cm-slivers past vertical, proven by failure); ruled chord↔chord
extensions (per-tri exhaustion on the fixed diagonal — the per-quad
radius family was falsified: hub quad0 needs F1, quad2 needs F1′);
bowtie quads (proper crossing strictly inside, 1 per site) emit 2 road
lobes (platform part) + 2 nose caps (separate `gore-{nid}-{k}` parts,
junction access) while gore quadrants past the noses stay open
terrain. Nose edges ≤ 3.5 m (measured max 3.25), nose-terrain lips
gated (gore ≤ 1.0 / retained ≤ 5.0; measured max 0.42 / 1.50).
X-spoke edges pair lobe↔nose across parts (coincident verts, bitwise).

Butt joint (th_highland, pass-through + trail stub): 49° wedge over a
shared centerpoint, per-tri exhaustion (saddle sides + pinched
center); stub caps close the trail ribbon. P03 node sits ~10–11 m off
the polyline ends — the butt spans the gap (bridge-span rule, not
coincidence). Ribbon↔butt T-seams bitwise.

## §7 ROUNDABOUT (hub_city, 6 arms)

Ring platform (adaptive rim subdivision, `mesh_fill_deg`), 36 sector
arcs (6 arms × 6), entry/exit connectors per leg, 121 connectors
total across all junctions (types: STRAIGHT/LEFT/RIGHT/SHARP/
UTURN/MERGE/SPLIT/ROUNDABOUT_ENTRY/EXIT/BRIDGE_TRANSITION/
TUNNEL_TRANSITION), 145 movements with legality (access + turn radius
vs class minima; straight turn_radius = null, never Infinity —
JSON-safe). Central island: surveyed disc (elev = max terrain + lift,
never buried), curb-lifted, access NONE.

## §8 BRIDGES + TUNNEL

BC-01 (E_radial_west_01), BC-02 (E_ring_hw_02): wet spans + 60 m-class
approach transitions, deck_floor profiles, BRIDGE structure spans;
ribbon surfaces the deck; deck edges recorded (`deck_edges`, P05
parapet/fascia scope); no skirts over wet spans (nothing to stand on).
Tunnel E_ring_hw_north_tunnel_00: bore span + portal transition spans
both ends; portal_E cutting to 10.5 m, portal_W to 6.3 m (cutting
records, P05 retaining scope); bore ribbon excluded from burial rules
(lining scope). 2 deck-edge records, 18 cutting records.

## §9 TERRAIN CONTACT (skirts, lips, cuts)

Skirts: ribbon approach embankments (SPECIAL→SPECIAL pairs) + platform
non-mouth rim spans. Every skirt toe surveyed: 0 toes inside junction
discs (suppression rule holds vacuously), all toes within 0.35 m of
terrain. Cut inventory: 18 records (edges: station ranges with
terrain−road > 0.3 m; junctions: disc max depth; deepest jn_E_portal
9.5 m). Buried-face census: 10434 faces > 10 cm under terrain =
4200 tunnel bore (by design) + cut trenches (open, visible from
above) + 0 defects.

LIP DOCTRINE (enforced): steep road faces (ny < 0.2) are classified
curb (h ≤ 0.05 m), gore (h ≤ 1.0, contested site), retained (h ≤ 5.0,
tunnel-adjacent junction); anything else fails the build. Measured:
6 lips exactly — 1 curb (jn_ring_S microlift step 0.035 m), 1 gore
(jn_air merge step 0.170 m), 4 retained (jn_W_portal wing-wall steps
1.63–1.72 m). No unlisted steep faces, no phantom lips (STATIC
cross-checks both directions). Min emitted tri area 1.65e-05 m²
(flat lens remnant, ny≈1) vs skip threshold 1e-9: separation ×1.6e4
(threshold validated: pinch residue ~1e-11 ≪ 1e-9 ≪ real).

## §10 MESH DOCTRINES (orientation / edge-use / coverage)

- Uniform-chirality surfaces (ribbons, strips, fans, skirts): FIXED
  emission orders + strict `_emit` (deviation = defect, fails loud).
- Label-dependent patches (bowtie lobes/noses, straddling strips,
  butt wedge, non-bowtie ruled extensions): orient by exhaustion
  (exactly one order faces up; degenerate → skip; neither up → loud).
- Edge use: 1 = classified boundary, 2 = interior (any directions;
  same-direction pairs allowed and counted), 3+ = defect (0 found).
- Coincident verts across parts validated to 1e-9 (no shared index
  space; T-seams, X-spokes, nose coincidence all bitwise or gated).
- Coverage: strip double-cover scan over every junction platform —
  max lip 0.096 m (jn_air sub-edge overlap, gore-gated); platform
  grade max 6.2% (jn_E_portal, gate 25%).

## §11 SUITES (all green)

| suite | command | tally |
|---|---|---|
| STATIC-GEOMETRY | `validate_road_geometry.py static` | 150/150 |
| CROSS-GEOMETRY | engine `geometry_check.gd` + `cross <metrics>` | 8/8 |
| INJECT-GEOMETRY | `validate_road_geometry.py inject` | 6/6 mutants fail loud |
| REPRODUCE-GEOMETRY | `validate_road_geometry.py reproduce` | 4/4 (`69ca624214ee76fe` ×2) |
| SMOKE-GEOMETRY | `tools/road_geometry_smoke.py` | 13/13 |
| PERF-GEOMETRY | `validate_road_geometry.py bench` | 3/3 (build 3.0 s / static 4.5 s / 9.2 MB) |
| REGRESS-GEOMETRY | `validate_road_geometry.py regress` | 1/1 vs golden |

Checksums: analytic `289dc64a92df86fc`, mesh `6996a47d274da230`,
geometry `69ca624214ee76fe`. Golden: `reports/p04_geometry_golden.json`.
Engine independently recomputes 52838/52838 tris up-facing (Godot
4.7.2-stable). NOTE: `tools/.godot/godot` (146 MB) does not survive
workspace snapshots (128 MB cap) — re-fetch with
`python3 tools/fetch_godot.py` before CROSS/engine runs.

## §12 PORT NOTES (Godot side)

- Mesh parts import directly: verts [x,y,z,nx,ny,nz], tris index-local
  per part, semantic block per part (edge/node/material/access/class).
- Up-facing guaranteed (engine-verified); normals analytic on ribbons,
  (0,1,0) on flatwork — recompute in-engine only if smoothing wanted.
- `turn_radius: null` = straight (no Infinity anywhere in JSON).
- Island/disc/ring access flags drive AI/physics layers (island NONE).
- Cuttings (`cuts`), deck edges (`deck_edges`), lips (`lips`) and
  retained steps are P05 structure placement inputs (see §13).

## §13 DEFERRED TO P05 (recorded, not dropped)

- Bridge parapets/fascia/piers/abutments (`deck_edges`: 2 records).
- Tunnel lining + portal headwalls/wing walls (bore + portal spans).
- Retaining walls at cuttings (`cuts`: 18 records, max 10.5 m) and
  retained lips (4 records, ≤ 1.72 m).
- Connector paint/markings (121 analytic paths with pts).
- Island planting/furniture; skirt rock/vegetation dressing.
- HAIRPIN_BULB escalation path (coded, untriggered).

## §14 LOCK STATEMENT

P04 is COMPLETE and ready to LOCK: generator, 7 suites, smoke,
evidence, docs all green; P03 graph provably untouched; determinism
proven (identical file hash across rebuilds); regression golden
written. Junction-connector surfacing was P04's deferred-in item from
P03 and is delivered (§6: strips, extensions, lobes, noses, butt).
