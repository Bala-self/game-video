# P10_FINAL_HANDOFF (§97) — ownership for all future work

P00–P09 are LOCKED; P10 is FINAL LOCK. No parallel subsystems. Every
change below goes to its existing owner, then affected derived data is
regenerated and the gates re-run (validate + smoke + gates scripts).

| future work | owner → action |
|---|---|
| new mission | mission framework → add template row in gameplay_gen plan, regen, STATIC + MISSION suites |
| new objective type | objective eval (`_eval_objective`) + contract otype list + graph checks |
| new vehicle behavior | P08 (traffic_sim) → P10 consumes via request/pin interfaces only |
| new NPC behavior | P09 (npc_sim) → P10 consumes via acquire/perception interfaces only |
| new streaming rule | P07 → P10 keeps pin discipline (pin while owned, release on cleanup) |
| new economy op/price | P10 economy owner → contract op set + `apply_txn` + idempotency tests |
| new wanted rule/level | P10 wanted owner → wanted_contract + machines + WANTED suite |
| new offense class | enable in contract `offenses.enabled` + severity + witness evidence; hook classes stay DEFERRED until a producer exists |
| new world event | events table + trigger types + machine; effects as world flags |
| new save field | increment `save_version` + write migration + SAVE suite cases (never break v1 loads silently) |
| new world data | change the authoritative producer, regen affected derived data, update contract source pins deliberately |
| perf regression | §91 gates (reports/p10/perf_gates.json) are the tripwire; profile per-section `perf` before optimizing |

## Standing rules (from P10)

- P10-D1 single-active mission; P10-D2 nav-snapped points.
- Never teleport mission NPCs / police as behavior; test fast-travel is
  player-harness only and must be logged (smoke logged 8).
- Never weaken REGRESS goldens without root-cause evidence (the one golden
  update in P10 documents digest v2).
- Never claim production perf without target hardware (PROVISIONAL).
- No P11: the 10-prompt sequence ends here; everything after is
  maintenance under this table.
