# P09 DECISIONS REGISTER — LOCKED

## P09-D1 — Derived hybrid navigation

No engine nav stack exists in-repo, so P09 derives areas + waypoint
graph + typed links from P06/P05/P04/P02 evidence. One navigation truth
shared by the Python sim and the engine check (`npc_check.gd`
recomputes all checksums). See `NPC_NAVIGATION.md`.

## P09-D2 — Structures rejected without evidence

P05 carries no walkway/sidewalk evidence for BC-01, BC-02, or the
tunnel bore: zero pedestrian links emitted there, rejection tested
in navigation + smoke (§88 steps 14/16 document the rejection because
no valid route exists to traverse).

## P09-D3 — ENTRY fallback for area-less zones

PZ-D-air-ops, PZ-D-farmA, PZ-D-farmB have buildings but no walkable
areas. They spawn at building ENTRY nodes (occupants exit buildings),
recorded in `npc_spawn_zones.json` — never in the void, never skipped.

## P09-D4 — Crossing dedupe key (edge, station)

Parallel lanes produced 72 duplicate crossings at identical stations.
Dedupe key is (edge, station-km); 34 survive, 13 bad-endpoint + 88
unattached candidates recorded in stats, not silently dropped.

## P09-D5 — Perception budget law

rays/tick ≤ queries × per-scan-cap = 512 by construction. Overflow
candidates counted (`perc_skipped_los`), whole scans deferred
(`perc_deferred`). No silent drops anywhere in perception.

## P09-D6 — Per-domain seed streams

`npc` namespace, six streams (spawn/destination/path/behavior/
perception/schedule). Crowd size never perturbs pathing; schedule
never perturbs perception. Replay = same tag → identical event stream.

## P09-D7 — Tier radii + non-READY rule

T3 < 60 m < T2 < 150 m < T1 < 400 m < T0; any NPC in a non-READY sector
is T1-proxy maximum (never full-AI on unloaded data).

## P09-D8 — Crossing TTA rule, P08 never bypassed

Commit iff min vehicle TTA over the corridor > width/1.2 + 2.0 s, read
from live P08 snapshots; where a P08 signal governs, conflicting
movements must be RED. WAIT/COMMIT/CANCEL only; timeouts recover.

## P09-D9 — Fixed step + CPU-time discipline

0.5 s fixed step; all measurement in CPU time (`process_time_ns`),
wall time excluded, warmup excluded, env+pins recorded (adopts
P08-D12 comparability for the ref impl vs engine).

## P09-D10 — Retire rules

Outside 600 m relevance, over zone peak, or 4-strike recovery
exhaustion → FAILED → safe despawn. `despawn_safe` gates every removal.

## P09-D11 — Perf gates at ~2× measured

ai 4.0 / nav 0.5 / perc 0.5 ms @100 NPCs, 256 MB @1000 (measured 1.79/
0.19/0.12/71). Subsystem split by ablation flags (always true in prod).

## P09-D12 — Upstream locked-state pins

`data/derived/upstream_pins.json` freezes the 8 P00–P08 inputs at P09
start (sha256[:16]); regress suite fails on any drift. P09 writes
`npc_*` only.

## P09-D13 — Machines are policy data

Movement/behavior transition tables live in `npc_behavior_policy.json`;
sim loads them, fails fast on corruption; static suite proves
sim.tables == policy.tables. Engine port uses the same tables.

## P09-D14 — Stale paths void at request

A (re)route request clears the old path immediately; a deferred repath
holds position instead of executing a stale route (killed a real
IDLE→CROSSING illegal found by the 28-step gameplay).

## P09-D15 — Hearing delivered on next executed scan

Events persist across the 10-tick window, delivered once per observer
(deduped), never same-tick-only (which starved under budget pressure).

## P09-D16 — Arrival confirms idle; dead legs recover

Arrival never self-transitions behavior; a chained leg with no
destination recovers (retry → fail safe) instead of stranding NPCs.

## Rejected alternatives

- Engine NavigationServer: nothing in-repo to extend; twin-pattern
  consistency (P08) won.
- Same-tick hearing: starved under load (proven by gameplay step 23).
- Clearing repath via state hacks: root-caused to stale paths (D14).
- Weakening tests to pass: never; every red suite exposed a real bug
  or a real test bug, fixed at the source (see main report §7).
