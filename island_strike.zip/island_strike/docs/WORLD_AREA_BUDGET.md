# ISLAND STRIKE — WORLD AREA BUDGET

| Field | Value |
|---|---|
| Document | `WORLD_AREA_BUDGET.md` |
| Status | **LOCKED (Prompt 00)** — revision `1.0.0` |
| Date | 2026-09-20 |
| Land disc | 12.566371 km² (r ≤ 2000 m) — sums to exactly 100% (`BUD-01` PASS) |
| Companion | Master Contract §7 regions; §10 density; §11 travel |

## Method

Top-down allocation from gameplay needs (city, towns, airfield, port, farms, forest,
hills, beaches, corridors) cross-checked bottom-up against reference densities
(Sleeping Dogs urban ≈ full game in ~8 km²; Tsushima island pacing ≈ 28 km²).
Reserve buffer (6%) absorbs Prompt 06+ overflow without re-budgeting the island.

## Budget table

| Region | Share | Area (km²) | Area (m²) | Shape note |
|---|---:|---:|---:|---|
| R1 urban_core (Portside City) | 4% | 0.503 | 502,655 | ~710×710 m east-coast city |
| R2 suburban_ring | 7% | 0.880 | 879,646 | wraps R1 landward |
| R3 industrial_flats | 3% | 0.377 | 376,991 | south of city, port-adjacent |
| R4 port_airfield | 3% | 0.377 | 376,991 | quay + 800 m strip on south flats |
| R5 rural_agri | 16% | 2.011 | 2,010,619 | central-south plains |
| R6 forest | 20% | 2.513 | 2,513,274 | central-west + north slopes |
| R7 hills_highland | 18% | 2.262 | 2,261,947 | north massif + peak 220 m |
| R8 coastal_beach (B1–B3 ring) | 12% | 1.508 | 1,507,964 | full 360° ring (overlaps coast band) |
| R9 wetland_inland_water | 2% | 0.251 | 251,327 | river + lake + marsh |
| R10 infra_corridors | 5% | 0.628 | 628,319 | ring + radials + easements |
| R11 special (resort + restricted) | 4% | 0.503 | 502,655 | SW resort strip + N compound |
| Reserve buffer | 6% | 0.754 | 753,982 | unassigned breathing space |
| **TOTAL** | **100%** | **12.566** | **12,566,371** | ✔ closes to πR² |

Overlap note: R8 (coastal ring) geographically overlaps the B1–B3 radial bands while
R1/R3/R4/R11 hold coastal frontage plots *within* their shares — the budget is
accounted by primary land-use, so no double counting. GIS-style: each m² has exactly
one primary-use owner; coast attributes are a secondary overlay layer.

## Scale sanity checks (all PASS)

```text
S-01  Urban total (R1+R2+R3 = 14%) ≤ 20% cap .................... PASS (1.76 km²)
S-02  City 0.50 km² vs Esperanza 1.3 km² (FC6, REPORTED): smaller city justified —
      Strike City is a port town, not a capital; density matches Sleeping Dogs .... PASS (DR-01)
S-03  Forest 2.51 km² fits 40–80k instanced trees @ 16–32k/km² ... PASS (instancing)
S-04  Airfield 800 m strip fits inside R4+R5 south flats ......... PASS (terrain reserve)
S-05  Ring road ≈ 2π×1750 ≈ 11.0 km + 3 radials ≈ 3×3.5 km ≈ 21.5 km paved;
      + collectors/trails ≈ 30–35 km total ≈ 2.6 km/km² avg — inside band ...... PASS
S-06  Walk N→S 47.6 min; highway N→S 2.4 min — island reads "big on foot,
      fast by car": correct action-game feel ..................... PASS (DR-16)
S-07  Reserve 6% (0.75 km²) ≥ one full region-overflow ........... PASS
S-08  No region < 0.25 km² except by design (R9 water) ........... PASS
```

## What does NOT fit (explicitly descoped by area)

- Second city, second airfield, or full race circuit (no 2+ km² spare parcel).
- Desert AND snow biomes simultaneously — island spans subtropical→highland only.
- Multi-hour wilderness treks — longest trail ≈ 6 km ≈ 70 min on foot by design.

## Area-change control

Any Prompt 01–10 proposal moving >0.5% between regions requires: gameplay
justification + travel/density re-validation + budget-table update + revision bump.
Moves ≤0.5% need justification + table update only.

*End of area budget v1.0.0.*
