# P06 HANDOFF — MISSIONS

Consumer file: `data/derived/p06_handoff_missions.json` (9 zones).

A mission zone exists for every building whose interior state is
INTERIOR_REQUIRED or MISSION_INTERIOR_CANDIDATE. Each zone points
to a valid building with entrance + floor count + floor height +
core reservation + grid hint (see `interior` block in
`buildings.json`). No interiors are built — readiness metadata
only, per §14.

Landmarks (`places.json`, 34, tiered WORLD/REGIONAL/DISTRICT/LOCAL
with roles: civic, hotel/resort, port, airport, industrial,
restricted, bridge-view, city identity, anchors) are the
recommended mission-anchor pool; each carries score breakdown,
visibility ratio, and access metadata.

Future work (not P06): interior shell generation, mission scripting
against zones MZ-*.
