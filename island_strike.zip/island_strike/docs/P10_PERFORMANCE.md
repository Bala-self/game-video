# P10_PERFORMANCE (§91)

Method: `process_time_ns` CPU per tick + `ru_maxrss`/VmRSS (established
P08-D12 discipline). Environment: sandbox 2 vCPU, Python 3.13, headless.
Production certification: PROVISIONAL — no target hardware was available
and no target numbers are claimed.

## Measured (1200-tick dense-city stress, reports/p10/stress.json)

| metric | value |
|---|---|
| full-stack tick mean (CPU) | 31.586 ms |
| full-stack tick p95 (CPU) | 61.115 ms |
| wall mean (proxy only, not a gate) | 31.595 ms |
| peak RSS | 65652 KB |
| RSS growth over run | +5860 KB |
| NPC range / vehicle range | 8–715 / 23–228 |

Per-section CPU means: world (P08+P09) 32.277 ms; wanted 0.098; mission
0.013; player 0.013; events 0.007; economy 0.002; triggers 0.002.
P10 combined: 0.135 ms/tick (~0.4% of tick). P10 adds no density of its
own; upstream budgets untouched.

Long-run (3 rounds, 4743 ticks): RSS +13516 KB end-start, pins 0, subs 0,
NPCs < 1200, flags 1, txns linear (+2.3/round). No unbounded growth.

## §91 gates (reports/p10/perf_gates.json) — all PASS

| metric | owner | baseline | threshold | tolerance | severity |
|---|---|---|---|---|---|
| p10_section_cpu_mean_ms | P10 | 0.135 | 1.0 | ×2.0 | MAJOR |
| fullstack_tick_p95_ms | P10 | 61.115 | 150.0 | ×1.5 | MINOR |
| fullstack_tick_mean_ms | P10 | 31.586 | 80.0 | ×1.5 | MINOR |
| stress_peak_rss_kb | P10 | 65652 | 262144 | ×1.2 | MAJOR |
| longrun_rss_growth_kb | P10 | 13516 | 150000 | absolute | MINOR |
| p10_pin_leak | P10 | 0 | 0 | absolute | CRITICAL |

Wall clock is reported as proxy only; no gate uses it (§91 metrology
rule). Combined P07+P08+P09+P10 workload measured as one tick above;
no approved envelope existed, so P10 defines these gates as the baseline
for future regression.
