# NPC BEHAVIOR (P09) — LOCKED

Policy: `data/derived/npc_behavior_policy.json`
(`npc_behavior_checksum = 0f3fde2cdb1da2c8`).

## 1. Machines are data (P09-D13)

Movement (17 states) and behavior (8 states) transition tables live in
the policy file; the sim loads them at startup and fails fast on a
corrupt policy. No hardcoded transitions in runtimes; the engine port
uses the same tables. Static suite proves `sim.tables == policy.tables`.

Movement highlights: SPAWNED→INITIALIZING→IDLE→{WALKING,WAITING,…};
WAITING→CROSSING (gap accepted after a wait); CROSSING→IDLE (cancelled
crossing stands down); STUCK→RECOVERING→{IDLE,WALKING,…};
FAILED→{RECOVERING,DESPAWNING}; DESPAWNED terminal. Every illegal
attempt is rejected AND recorded (`illegal` event + counter); all
suites assert zero illegals in every passing run.

Behavior highlights: IDLE→TRAVEL→…→IDLE per leg; REACT on loud events
(no self-loop, no INTERACT edge — repeat deliveries are deduped and the
machine forbids re-trigger); RECOVER→DESPAWN terminal path.

## 2. Destinations

10 categories (HOME/WORK/SHOP/PARK/OPEN_SPACE/LANDMARK/ARRIVAL/RETURN/
RANDOM_WALK/TRANSIT_HOOK) weighted per class-group × schedule
(8 groups × 4 schedules = 32 weight rows + default). Resolution order:
category node → RANDOM_WALK fallback → recover (never teleport, never
null-route). Landmark/arrival/transit rows exist in data; TRANSIT_HOOK
resolves through arrival nodes until P10 transit lands.

## 3. Movement execution

Fixed-step (0.1 s, 10 Hz) corridor follow with walk/run speeds per archetype,
crossing speed 1.2 m/s on CROSSING edges, personal radius 0.6 m /
preferred spacing 1.2 m separation validated to ≤ 2 m corridor
deviation, stuck detection (50 ticks) → STUCK → recover. Arrival chains
the next leg; a leg with no destination recovers (retry, then fail safe)
per P09-D16 — arrival confirms idle and never self-transitions.

## 4. Schedules

DAY default; MORNING/EVENING/NIGHT reweight per §5 of population doc.
Behavior draws come from the `behavior` seed stream only.
