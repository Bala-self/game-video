# P09 → P10+ HANDOFF: NPC HOOKS — LOCKED

P09 scope excludes final missions, economy, police-wanted, combat, and
social life. Each ships as a **typed, tested hook**, never a TODO:

| Hook | Tap point (data/code) | Status |
|------|----------------------|--------|
| Transit | `TRANSIT_HOOK` destination category; arrival nodes; `ARRIVAL` zones | resolves via arrivals today |
| Police-wanted | `witness()` observation tuples; `SECURITY_HOOK` archetype | recorded + tested, no consumers |
| Emergency | `EMERGENCY_HOOK` archetype; hearing `alarm_hook`/`shout_hook` events | spawnable, audible |
| Services/economy | `SERVICE_HOOK` archetype; SHOP/WORK destinations + schedules | counted in population |
| Combat | `FLEEING_HOOK` movement state; REACT behavior; `RUNNING`/`AVOIDING` | machine-complete, untriggered by combat (no combat yet) |
| Social | `INTERACTING`/`INTERACT` states; proximity sense; witness tuples | reachable, no social logic |
| Signals | crossing `signal_hook`: P08 RED requirement where governed | enforced where signals exist |

Rules for P10+: consume these hooks, do not fork them. New behavior
must come through policy weights/machines (P09-D13), new senses through
the perception budget law (§2 of perception doc). Anything that needs a
new movement state requires a machine version bump + regen + re-lock.
