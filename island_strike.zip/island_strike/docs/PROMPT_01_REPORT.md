# ISLAND STRIKE — PROMPT 01 REPORT (§64, exact structure)

PROMPT:
01

TITLE:
SCAFFOLD + STACK BENCHMARKS

STATUS:
LOCKED

PROJECT STATE:
Clean Godot 4.x project scaffolded on verified-greenfield repo. Foundation boots
headless (exit 0), validates the locked world contract at startup (41/41), builds
a diagnostic world shell proving engine-side contract truth, and measures real
performance baselines. 425 automated checks green across 6 layers; 13/13 injected
mutants detected; determinism proven across runs and across implementations
(GDScript↔Python byte agreement).

ENGINE:
4.7.2.stable.official.ed1daf0bf (pinned; re-fetch: python3 tools/fetch_godot.py)

RUNTIME ENVIRONMENT:
OS: Linux x86_64 (2 CPU, ~2 GB RAM) / renderer: forward_plus (pinned default) /
display: headless dummy + Dummy audio / execution: headless CLI (import, check-only,
--script SceneTree runners, --quit-after smoke). Graphical window: ENVIRONMENT-LIMITED
(no display/GPU; x11 attempt exits 1 with evidence).

FILES CREATED:
project.godot, icon.svg, README.md, .gitignore, .gitattributes,
.github/workflows/ci.yml,
data/world/world_contract.json, data/world/world_contract.schema.json,
data/world/contract_checksum.txt,
scripts/core/{units,world_contract_data,world_registry,coordinate_service,sector_service,seed_service,world_checksum,validation_service,diagnostics_service,benchmark_service}.gd,
scripts/bootstrap/application_bootstrap.gd, scripts/world/world_shell.gd,
scenes/bootstrap/bootstrap.tscn,
tests/godot/test_suite.gd, tests/godot/test_runner.gd,
tests/godot/unit/{test_seed_vectors,test_coordinates,test_sectors,test_contract_loader,test_checksum,test_diag_bench}.gd,
tests/godot/integration/{test_bootstrap_integration,test_cross_layer}.gd,
tests/godot/tools/contract_check.gd, tests/godot/benchmarks/foundation_benchmark.gd,
tools/{validate_foundation.py,fetch_godot.py,run_all_tests.sh},
tools/benchmark/compare_baseline.py,
docs/{ARCHITECTURE,ENGINE_STACK_BASELINE,PERFORMANCE_BASELINE,TESTING,PROMPT_01_BENCHMARK_REPORT,PROMPT_01_TEST_REPORT,PROMPT_01_REPORT}.md,
reports/performance/{environment,foundation_baseline,bootstrap_baseline,runtime_baseline}.json

FILES MODIFIED:
None (greenfield; Prompt 00 docs RELOCATED docs/*.md unchanged in content).

FOUNDATION SYSTEMS:
ApplicationBootstrap, WorldContractData, WorldRegistry, CoordinateService,
SectorService (candidate), SeedService, WorldChecksum, ValidationService,
DiagnosticsService, BenchmarkService, WorldShell, Units policy, 4 Python tools,
CI workflow.

ARCHITECTURE:
BOOT→PRELOAD→VALIDATE→INITIALIZE→READY→RUNTIME→SHUTDOWN; single frozen registry;
preload-only cross-refs (no class-cache dependence); shape-vs-value validation
split; fail-fast contract handling (exits 3/2); full table in ARCHITECTURE.md.

WORLD CONTRACT INTEGRATION:
JSON (schema-validated) → normalized dict → frozen registry → V1/V2/V3 at every
boot + CLI + CI. Disk==registry proven field-by-field; checksum golden
ad20e1fde64f051e committed after dual-implementation byte agreement.

COORDINATE CONTRACT:
+X=E,-X=W,+Y=UP,-Z=N,+Z=S,origin=(0,0,0),r=√(x²+z²) cylindrical; game-grid GPS
(x+2000,z+2000) via map_gps APIs; 1 mm boundary eps (derived from float32
quantum); 66 coordinate checks green; §27 movement verified on live nodes.

SECTOR CONTRACT:
sx=floor((x+2048)/256), 16×16 over [-2048,2048), left-closed, status CANDIDATE
(never promoted; Prompt 07 decides). Census 164/60/32/224 independently
cross-validated (Python precompute == GDScript runtime).

SEED CONTRACT:
IS-SEED/1 FNV-1a-64 over version|master|domain|key; spec vectors in both
implementations; reproducibility + 16-sample separation + per-dimension
sensitivity proven; 64-bit collision analysis documented.

VALIDATION:
53/53 Prompt-00 math + 78/78 static + 207/207 engine + 31/31 cross-layer +
41/41 boot-time + 24/24 parse + clean log audits. Total 425+ automated checks,
zero failures, zero skips.

TESTS:
passed 425+ / failed 0 / skipped 0 (207 engine + 53 math + 78 static + 31 cross +
13 inject + 7 reproduce + 10 bench-macro + audits/parses; see TEST REPORT).

RUNTIME SMOKE:
Main scene 30 frames headless: exit 0, full lifecycle logged, empty stderr,
boot 8.19–9.86 ms. Graphical window: ENVIRONMENT-LIMITED with evidence.

HEADLESS:
All execution headless; 30+ invocations zero flakes; exit codes 0/1/2 verified
live (3 reviewed, healthy-contract path never triggers it).

BENCHMARKS:
Cold wall 0.44 s; boot 8.9 ms; validation 0.42 ms; census 0.66 ms; seed 7 µs;
sector 0.22 µs; frame (dummy) 7.75 ms; static mem ~26 MB. GPU metrics
null+unavailable (honest). NON-GATING. Full tables in BENCHMARK REPORT.

MEMORY:
Static 25.9→26.8 MB, peak 29.6 MB (OS.get_static_memory_*). VRAM unavailable
(dummy driver) — recorded, not estimated.

DETERMINISM:
Two-run stability 7/7; GDScript↔Python canonical/checksum/seed byte agreement;
FNV spec vectors both sides; timestamps isolated from checksummed cores.

FAILURE INJECTION:
13/13 mutants fail loudly (exit 2 + CONTRACT_FAIL); repo untouched (/tmp only);
recovery probes loud-and-clear (exit 2) or explicitly degraded (NOTE + exit 0).

ISSUES FOUND:
1. log() name collision (parse error). 2. Five test-code bugs (all fixed, services
correct). 3. CI pipe exit-masking (fixed). 4. Parallel-edit race (process lesson).

ISSUES FIXED:
All four above; re-verified end to end (full CI script exit 0). Zero outstanding.

KNOWN LIMITATIONS:
1. No graphical window verification (ENVIRONMENT-LIMITED, evidenced).
2. GPU/VRAM metrics unavailable (dummy driver) — Prompt 07 territory.
3. Sandbox hardware ≠ target hardware — numbers are relative signals.
4. Bootstrap exit-3 path reviewed, not live-triggered (healthy contract).
5. Engine binary external to repo (pinned one-command re-fetch).
6. Sector size candidate-pending Prompt 07 benchmark decision.

DEFERRED OWNERS:
P02 terrain+regions | P03 coast+water | P04 roads+nav | P05 districts+look-dev |
P06 POIs+landmarks | P07 streaming+sector decision+perf lock | P08 population |
P09 missions+economy | P10 integration+ship. Folder/data ownership documented
in ARCHITECTURE.md §7.

DOCUMENTATION:
ARCHITECTURE, ENGINE_STACK_BASELINE, PERFORMANCE_BASELINE, TESTING,
PROMPT_01_BENCHMARK_REPORT, PROMPT_01_TEST_REPORT, PROMPT_01_REPORT (+ this file),
README, schema JSON, 6 relocated Prompt-00 docs (content-unchanged).

GIT:
48d1bb7 "Prompt 01 LOCKED: scaffold + stack benchmarks + runtime foundation"
(repo-local identity island-strike@local; .godot/ + reports/logs/ gitignored)

WORKTREE:
clean after commit (only gitignored .godot/ + reports/logs/ untracked-by-design)

DELIVERABLE:
COMPLETE — scaffold boots, contract integrated+validated, coordinates/sectors/
seeds executable+tested, benchmarks real, regression path live, docs synced,
no blocking defect.

NEXT PROMPT:
02 (awaiting explicit NEXT per §66 — terrain synthesis; DO NOT auto-advance)
