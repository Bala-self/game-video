# P06 HANDOFF — ECONOMY

Consumer file: `data/derived/p06_handoff_economy.json` (80 rows).

Every business/economic class maps to a valid building role:

shop, dine, lodge, work, mixed_trade, service_trade, freight,
manufacture, craft, aviation_svc, marine_svc, farmstead, farm_ops.

Coverage: 80 business buildings across ≥6 roles (smoke-verified).
Farmsteads/barns/silos carry farm roles; port/airfield support
carries freight/aviation roles; resort + waterfront carry
lodge/mixed_trade. Parking metadata (type + stalls) rides with each
building for customer-capacity modeling.

Future work (not P06): supply/demand simulation, shop inventory,
rent/value model by district profile.
