# ISLAND STRIKE — ARCHITECTURE (Prompt 01)

| Field | Value |
|---|---|
| Status | Foundation scaffold — 2026-09-20 |
| Engine | Godot 4.7.2-stable (pinned; see ENGINE_STACK_BASELINE.md) |
| Contract | WORLD_MASTER_CONTRACT.md v1.0.0 (LOCKED, Prompt 00) |

## 1. Boot chain

```text
BOOT (project.godot -> scenes/bootstrap/bootstrap.tscn -> ISAppBootstrap._ready)
  -> PRELOAD:    ISWorldContractData.load_from_path(data/world/world_contract.json)
  -> INITIALIZE: ISWorldRegistry (freeze) + ISCoordinateService + ISSectorService
                 + ISValidationService + ISBenchmark (+ ISDiagnostics first)
  -> VALIDATE:   V1 locked values + V2 disk-vs-registry + V3 checksum-vs-golden
  -> READY:      ISWorldShell.build() (diagnostic nodes only)
  -> RUNTIME:    _process (idle) or --benchmark-frames collector
  -> SHUTDOWN:   _exit_tree log
```

Contract corruption at any stage FAILS FAST (exit 3 from bootstrap, exit 2 from
contract_check CLI). No silent fallbacks anywhere (Rule 4).

## 2. Service ownership (§9)

| Service | File | Owns | Inputs | Outputs | Deps | Test owner |
|---|---|---|---|---|---|---|
| ISAppBootstrap | bootstrap/application_bootstrap.gd | startup lifecycle only | project settings, CLI args | wired services, shell | all below | integration suite |
| ISWorldContractData | core/world_contract_data.gd | contract SHAPE validation | JSON file/text | normalized Dictionary | none | contract_loader suite |
| ISWorldRegistry | core/world_registry.gd | runtime world truth (frozen) | normalized Dictionary | typed getters, dump, AABB | ContractData (load-time) | cross_layer suite |
| ISCoordinateService | core/coordinate_service.gd | ALL coordinate conversion | registry | r, GPS, boundary, heading | Registry, ISUnits | coordinates suite |
| ISSectorService | core/sector_service.gd | sector mapping (CANDIDATE) | registry | sector ids, bounds, census | Registry | sectors suite |
| ISSeedService | core/seed_service.gd | ALL seed derivation | version+master+domain+key | seed_i64 + hex | none | seed_vectors suite |
| ISWorldChecksum | core/world_checksum.gd | change detection (FNV-1a/64) | registry | canonical + hex | Seed, Registry | checksum suite |
| ISValidationService | core/validation_service.gd | V1+V2+V3 consistency | registry, disk, golden | check list | ContractData, Registry, Checksum | integration suite |
| ISDiagnostics | core/diagnostics_service.gd | logging (5 levels, 10 cats) | log calls | stdout/stderr, counts | none | diag_bench suite |
| ISBenchmark | core/benchmark_service.gd | measurement (NON-GATING) | Callables | stats dicts, JSON reports | Diagnostics (optional) | diag_bench suite |
| ISWorldShell | world/world_shell.gd | diagnostic 3D shell | registry | marker/ring/grid nodes | Registry, Diagnostics | integration suite |
| ISUnits | core/units.gd | unit + tolerance policy | — | constants, approx fns | none | coordinates suite |

Dependency direction is strictly downward (bootstrap at top). No cycles:
Diagnostics takes no service deps (constructor-injected where needed);
services never reference the bootstrap. Cross-file references use `preload`
exclusively — never bare `class_name` ids — so headless runs never depend on
the editor's global class cache.

## 3. Authority hierarchy (§49, as implemented)

1. Verified runtime behavior (207 engine checks + smoke + benchmarks).
2. `data/world/world_contract.json` (machine-readable; schema beside it).
3. `docs/WORLD_MASTER_CONTRACT.md` (design authority, locked v1.0.0).
4. `docs/01_WORLD_CLARIFICATION_REPORT.md` (Prompt 00 evidence).
5. This document + TESTING.md + ENGINE_STACK_BASELINE.md.
6. Assumptions (recorded in PROMPT_01_REPORT.md; none load-bearing).

Shape validation (loader) and locked-value enforcement (V1 + golden checksum +
Python locked-constants) are DELIBERATELY separate layers: "malformed" and
"revised" are different failures with different fixes.

## 4. Determinism (§16, as implemented)

- Seeds: `IS-SEED/1|v=...|m=...|d=...|k=...` → FNV-1a-64. Pure integer math;
  identical on any CPU/OS/Godot version. Spec vectors (`""`, `"a"`, `"foobar"`)
  asserted in BOTH GDScript and Python.
- Checksum core: ASCII strings + integer millimeters only — no floats, no
  timestamps, no locale. Canonical bytes proven IDENTICAL across GDScript and
  Python implementations (X-canonical-identical).
- Timestamps (`generated_at`) and engine strings live ONLY in report envelopes,
  never in checksummed cores; reproducibility tests strip them explicitly.
- Golden: `data/world/contract_checksum.txt` = `ad20e1fde64f051e` (committed
  after dual-implementation agreement; changing the contract requires a
  documented re-goldening, never a silent edit).

## 5. Tolerance policy (derived, §12)

- `DOUBLE_EPS = 1e-9`: double-precision scalar math (|v| ≤ 4096).
- `BOUNDARY_EPS_M = 1e-3` (1 mm): boundary classification + float32-backed
  API assertions. Derived: float32 quantum at 2000 m ≈ 2.4e-4 m, ×4 safety.
- Sector mapping: EXACT `floor()` — no epsilon in the formula; tolerances live
  in tests (scalar-double for exactness, ±0.01 offsets for float32 paths).

## 6. project.godot rationale (§7 — every non-default setting)

| Setting | Value | Reason |
|---|---|---|
| `application/run/main_scene` | bootstrap.tscn | single authoritative entry (§8) |
| `application/config/features` | 4.7 + Forward Plus | editor-written version stamp (import-settled) |
| `display/window/size/*` | 1280×720 | legible diagnostic overlay default |
| `rendering/renderer/rendering_method` | forward_plus | explicit pin of the ENGINE DEFAULT (no evidence to deviate; revisit at Prompt 07) |

Everything else is engine default. Physics: default GodotPhysics3D @ 60 Hz
(assumption recorded; no physics bodies exist yet to measure).

## 7. Deferred (created only with documented reason, §5)

- `data/regions/`, `data/sectors/`: Prompt 02+ (region data, terrain).
- `resources/`: no `.tres` needed — JSON is the machine contract (§11).
- `addons/`: none (zero dependencies by design).
- `scripts/gameplay|ai|player|...`: future prompts own their folders.
- Streaming interfaces (§46): sector id/bounds/neighbors/census APIs ARE the
  anti-dead-end surface; lifecycle (load/activate/unload) is Prompt 07 — no fake
  streaming exists, and no dictionary is called "streamed".
- Debug player controller (§59): NOT created — static debug camera suffices;
  avoids a placeholder mistaken for the final controller.

## 8. Failure taxonomy in force (§20)

- DEVELOPMENT ASSERTION: `assert()` on internal invariants (registry freeze,
  benchmark preconditions). Never the sole production diagnostic.
- TEST FAILURE: every contract violation (V1/V2/V3, 207 engine checks, 78+31
  Python checks, 13 injection mutants) fails automated suites with exit ≠ 0.
- RUNTIME RECOVERY: only for non-contract failures (unwritable report path →
  loud `{ok:false}` + exit 2; missing golden + explicit flag → documented NOTE).
  Mandatory contract corruption ALWAYS fails fast — no degraded mode.
