# ISLAND STRIKE

Original 2 km-radius / 4 km-diameter open-world action island (Godot 4.x).
Single landmass, ocean-surrounded, continuous coastline. Contract-first,
deterministic, tested.

- World authority: `docs/WORLD_MASTER_CONTRACT.md` (v1.0.0, LOCKED)
- Architecture: `docs/ARCHITECTURE.md` · Engine: `docs/ENGINE_STACK_BASELINE.md`
- Testing: `docs/TESTING.md` · Perf: `docs/PERFORMANCE_BASELINE.md`

## Quick start

```bash
python3 tools/fetch_godot.py     # pinned Godot 4.7.2 (hash-verified) -> tools/.godot/
export GODOT_BIN=$PWD/tools/.godot/godot
bash tools/run_all_tests.sh      # 12-step validation: contract, tests, smoke, benches
```

Run the diagnostic shell (headless): `godot --headless --path . --quit-after 60`

## Layout

```text
project.godot  scenes/  scripts/{core,bootstrap,world}/  tests/godot/  tools/
data/world/ (machine contract + schema + golden)  data/aaa_reference/ (research)
docs/ (contract, reports, architecture)  reports/performance/ (measured baselines)
```

## Rules (non-negotiable)

1. The locked contract wins over convenience — migrate, never silently edit.
2. One owner per datum; services via `preload`, no ad-hoc globals.
3. Same seed + version = same world. Timestamps never enter checksummed data.
4. No silent failure; no fake pass; every number measured or marked unavailable.
5. `NEXT` prompt waits for the explicit command. Current state: **Prompt 01 LOCKED**.
