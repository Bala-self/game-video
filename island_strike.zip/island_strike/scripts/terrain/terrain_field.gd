class_name ISTerrainField
extends RefCounted
## Full terrain/coast field twin (tools/terrain_model.py Field).
## Owns the beach-class LUT and height(x, z). Numeric port: same algorithms,
## same order, same control flow; cross-checked to 1e-6 relative.
## FLOAT64 DISCIPLINE (see coast_loop.gd): scalar floats only, no Vector2.

const TN = preload("res://scripts/terrain/terrain_noise.gd")
const Seed = preload("res://scripts/core/seed_service.gd")
const CoastLoop = preload("res://scripts/terrain/coast_loop.gd")
const Rgn = preload("res://scripts/terrain/terrain_regions.gd")

var tc: Dictionary = {}
var cc: Dictionary = {}
var au: Dictionary = {}
var wc: Dictionary = {}
var loop = null
var regions = null
var lut_n: int = 0
var salt_micro: int = 0
var salt_meso: int = 0
var classes: Dictionary = {}
var lut: Array = []
var coast_length: float = 0.0
var arc_pts: Array = []


func initialize(p_tc: Dictionary, p_cc: Dictionary, p_au: Dictionary, p_wc: Dictionary) -> Dictionary:
	tc = p_tc
	cc = p_cc
	au = p_au
	wc = p_wc
	var wv: String = str(wc["world_version"])
	var master: int = int(wc["master_seed"])
	loop = CoastLoop.new()
	var lr: Dictionary = loop.initialize(cc, wv, master)
	if not lr["ok"]:
		return lr
	# LUT size from the contracted sample spacing (emergent but deterministic).
	var pre: Array = []
	pre.resize(1440)
	for i in range(1440):
		var th: float = float(i) * TAU / 1440.0
		pre[i] = CoastLoop.point(loop.rs(th), th)
	var prelen: float = 0.0
	for i in range(1440):
		var a: Array = pre[i]
		var b: Array = pre[TN.pos_imod(i + 1, 1440)]
		var ex: float = float(b[0]) - float(a[0])
		var ez: float = float(b[1]) - float(a[1])
		prelen += sqrt(ex * ex + ez * ez)
	lut_n = maxi(360, TN.py_round(prelen / float(cc["sample_spacing_m"])))
	regions = Rgn.new()
	regions.initialize(au, loop, lut_n)
	var dm: Dictionary = Seed.derive(wv, master, "terrain", "micro")
	var ds: Dictionary = Seed.derive(wv, master, "terrain", "meso")
	if not dm["ok"] or not ds["ok"]:
		return {"ok": false, "error": "seed derive failed"}
	salt_micro = int(dm["seed_i64"])
	salt_meso = int(ds["seed_i64"])
	classes.clear()
	for c in cc["beach_classes"]:
		classes[c["key"]] = c
	lut = build_lut()
	return {"ok": true, "error": ""}


func width_for(cls: String, curv: float) -> float:
	var conc: float = clampf(-curv * 300.0, -0.5, 1.0)
	var row: Dictionary = classes[cls]
	var k: float = float(cc["authoring"]["width_modulation"]["meso_strength"])
	var w: float = float(row["base_width_m"]) * (1.0 + k * conc)
	return clampf(w, float(row["width_min_m"]), float(row["width_max_m"]))


static func seg_class(ths_rad: float, segments: Array) -> String:
	for seg in segments:
		var a: float = float(seg[0])
		var b: float = float(seg[1])
		if a <= b:
			if a <= ths_rad and ths_rad < b:
				return str(seg[2])
		elif ths_rad >= a or ths_rad < b:
			return str(seg[2])
	push_error("theta outside segments")
	return ""


func build_lut() -> Array:
	var n: int = lut_n
	var ths: Array = []
	var rss: Array = []
	ths.resize(n)
	rss.resize(n)
	for i in range(n):
		ths[i] = float(i) * TAU / float(n)
		rss[i] = loop.rs(float(ths[i]))
	var pts: Array = []
	pts.resize(n)
	for i in range(n):
		pts[i] = CoastLoop.point(float(rss[i]), float(ths[i]))
	var arc: Array = [0.0]
	for i in range(1, n + 1):
		var a: Array = pts[i - 1]
		var b: Array = pts[TN.pos_imod(i, n)]
		var ex: float = float(b[0]) - float(a[0])
		var ez: float = float(b[1]) - float(a[1])
		arc.append(float(arc[i - 1]) + sqrt(ex * ex + ez * ez))
	var total: float = float(arc[n])
	var curv: Array = []
	curv.resize(n)
	for i in range(n):
		var p0: Array = pts[TN.pos_imod(i - 1, n)]
		var p1: Array = pts[i]
		var p2: Array = pts[TN.pos_imod(i + 1, n)]
		var t1x: float = float(p1[0]) - float(p0[0])
		var t1z: float = float(p1[1]) - float(p0[1])
		var t2x: float = float(p2[0]) - float(p1[0])
		var t2z: float = float(p2[1]) - float(p1[1])
		var cross: float = t1x * t2z - t1z * t2x
		var dot: float = t1x * t2x + t1z * t2z
		var turn: float = atan2(cross, dot)
		var ds: float = (sqrt(t1x * t1x + t1z * t1z) + sqrt(t2x * t2x + t2z * t2z)) / 2.0
		curv[i] = turn / maxf(ds, 1e-6)
	var wc_: int = maxi(2, TN.py_round(35.0 / (total / float(n))))
	var curv_s: Array = []
	curv_s.resize(n)
	for i in range(n):
		var s: float = 0.0
		for j in range(-wc_, wc_ + 1):
			s += float(curv[TN.pos_imod(i + j, n)])
		curv_s[i] = s / float(2 * wc_ + 1)
	var mpts: Array = []
	mpts.resize(n)
	for i in range(n):
		mpts[i] = CoastLoop.point(loop.rs_meso(float(ths[i])), float(ths[i]))
	var mcurv: Array = []
	mcurv.resize(n)
	for i in range(n):
		var p0: Array = mpts[TN.pos_imod(i - 1, n)]
		var p1: Array = mpts[i]
		var p2: Array = mpts[TN.pos_imod(i + 1, n)]
		var t1x: float = float(p1[0]) - float(p0[0])
		var t1z: float = float(p1[1]) - float(p0[1])
		var t2x: float = float(p2[0]) - float(p1[0])
		var t2z: float = float(p2[1]) - float(p1[1])
		var cross: float = t1x * t2z - t1z * t2x
		var dot: float = t1x * t2x + t1z * t2z
		var turn: float = atan2(cross, dot)
		var ds: float = (sqrt(t1x * t1x + t1z * t1z) + sqrt(t2x * t2x + t2z * t2z)) / 2.0
		mcurv[i] = turn / maxf(ds, 1e-6)
	var mcurv_s: Array = []
	mcurv_s.resize(n)
	for i in range(n):
		var s: float = 0.0
		for j in range(-wc_, wc_ + 1):
			s += float(mcurv[TN.pos_imod(i + j, n)])
		mcurv_s[i] = s / float(2 * wc_ + 1)
	var segments: Array = []
	for s in cc["class_rules"]["segments"]:
		segments.append([deg_to_rad(float(s["from_deg"])), deg_to_rad(float(s["to_deg"])), s["class"]])
	var out: Array = []
	var probe_d: float = float(cc["validation"]["normal_probe_m"])
	for i in range(n):
		var a: float = float(arc[i])
		var cls: String = seg_class(float(ths[i]), segments)
		var width: float = width_for(cls, float(mcurv_s[i]))
		var xi: Array = CoastLoop.point(float(rss[i]) - probe_d, float(ths[i]))
		var owner: String = str(regions.classify(float(xi[0]), float(xi[1]))[0])
		out.append({"theta": float(ths[i]), "rs": float(rss[i]), "arc": a, "class": cls,
			"width": width, "berm": float((classes[cls] as Dictionary)["berm_m"]),
			"curv": float(curv_s[i]), "curv_meso": float(mcurv_s[i]), "region": owner})
	# run-length enforcement: merge runs < 150 m
	var runs: Array = runs_of(out, total)
	for run in runs:
		var s: int = int(run[0])
		var e: int = int(run[1])
		var cl: String = str(run[2])
		var ln: float = float(run[3])
		if ln >= 150.0:
			continue
		var ri: int = -1
		for k in range(runs.size()):
			if int(runs[k][0]) == s and int(runs[k][1]) == e and str(runs[k][2]) == cl and float(runs[k][3]) == ln:
				ri = k
				break
		var prev: Array = runs[TN.pos_imod(ri - 1, runs.size())]
		var nxt: Array = runs[TN.pos_imod(ri + 1, runs.size())]
		var winner: String
		if float(prev[3]) > float(nxt[3]) or (float(prev[3]) == float(nxt[3]) and int((classes[str(prev[2])] as Dictionary)["id"]) < int((classes[str(nxt[2])] as Dictionary)["id"])):
			winner = str(prev[2])
		else:
			winner = str(nxt[2])
		var j: int = s
		while true:
			(out[j] as Dictionary)["class"] = winner
			(out[j] as Dictionary)["width"] = width_for(winner, float((out[j] as Dictionary)["curv_meso"]))
			(out[j] as Dictionary)["berm"] = float((classes[winner] as Dictionary)["berm_m"])
			if j == e:
				break
			j = TN.pos_imod(j + 1, n)
	# Width smoothing (+-5 cells) AFTER run-merge; LUT keeps BOTH the
	# authored clamped "width" and the unclamped render "rwidth" (see twin).
	var sm_w: Array = []
	sm_w.resize(n)
	for i in range(n):
		var t: float = 0.0
		for j in range(-5, 6):
			t += float((out[TN.pos_imod(i + j, n)] as Dictionary)["width"])
		sm_w[i] = t / 11.0
	for i in range(n):
		var row: Dictionary = classes[str((out[i] as Dictionary)["class"])]
		(out[i] as Dictionary)["width"] = clampf(float(sm_w[i]), float(row["width_min_m"]), float(row["width_max_m"]))
		(out[i] as Dictionary)["rwidth"] = float(sm_w[i])
	coast_length = total
	arc_pts = pts
	return out


static func runs_of(p_lut: Array, total: float) -> Array:
	var n: int = p_lut.size()
	var runs: Array = []
	var i: int = 0
	while str((p_lut[i] as Dictionary)["class"]) == str((p_lut[TN.pos_imod(i - 1, n)] as Dictionary)["class"]):
		i = TN.pos_imod(i + 1, n)
		if i == 0:
			break
	var start: int = i
	while true:
		var j: int = start
		while str((p_lut[TN.pos_imod(j + 1, n)] as Dictionary)["class"]) == str((p_lut[start] as Dictionary)["class"]):
			j = TN.pos_imod(j + 1, n)
			if j == start:
				break
		var a0: float = float((p_lut[start] as Dictionary)["arc"])
		var a1: float = float((p_lut[j] as Dictionary)["arc"])
		var ln: float = TN.pos_fmod(a1 - a0, total)
		var step: float = total / float(n)
		ln += step
		runs.append([start, j, str((p_lut[start] as Dictionary)["class"]), ln])
		start = TN.pos_imod(j + 1, n)
		if start == i:
			break
	return runs


func lut_at_theta(th: float) -> Dictionary:
	# Round-half-up to nearest sample (identical rule to the Python twin).
	var n: int = lut.size()
	return lut[TN.pos_imod(int(TN.pos_fmod(th, TAU) / TAU * float(n) + 0.5), n)]


static func seabed(s: float, prof: Array) -> float:
	if s <= 0.0:
		return 0.0
	for i in range(prof.size() - 1):
		var s0: float = float(prof[i][0])
		var h0: float = float(prof[i][1])
		var s1: float = float(prof[i + 1][0])
		var h1: float = float(prof[i + 1][1])
		if s <= s1:
			return h0 + (h1 - h0) * TN.sstep(s0, s1, s)
	return float(prof[prof.size() - 1][1])


func play_masks(x: float, z: float) -> Array:
	# Returns [wstrip, lakes] where lakes = [[w, floor], ...].
	var rw: Dictionary = au["runway"]
	var hd: float = deg_to_rad(float(rw["heading_deg"]))
	var ax: float = sin(hd)
	var az: float = -cos(hd)
	var dx: float = x - float(rw["center"][0])
	var dz: float = z - float(rw["center"][1])
	var u: float = dx * ax + dz * az
	var v: float = -dx * az + dz * ax
	var wstrip: float = (1.0 - TN.sstep(float(rw["length_m"]) / 2.0, float(rw["length_m"]) / 2.0 + float(rw["blend_m"]), absf(u))) * (1.0 - TN.sstep(float(rw["width_m"]) / 2.0, float(rw["width_m"]) / 2.0 + float(rw["blend_m"]), absf(v)))
	var lakes: Array = []
	for lk in au["drainage"].get("lakes", []):
		var ndx: float = (x - float(lk["cx"])) / float(lk["rx"])
		var ndz: float = (z - float(lk["cz"])) / float(lk["rz"])
		var nd: float = sqrt(ndx * ndx + ndz * ndz)
		var edge: float = 1.0 + float(lk["blend_m"]) / ((float(lk["rx"]) + float(lk["rz"])) / 2.0)
		lakes.append([1.0 - TN.sstep(1.0, edge, nd), float(lk["floor_m"])])
	return [wstrip, lakes]


func height_raw(x: float, z: float, noise: bool = true) -> float:
	var r: float = sqrt(x * x + z * z)
	var th: float = CoastLoop.theta(x, z)
	var rs: float = loop.rs(th)
	var d: float = rs - r
	var cell: Dictionary = lut_at_theta(th)
	if d < 0.0:
		return seabed(-d, (classes[str(cell["class"])] as Dictionary)["seabed_profile"])
	var bl: Array = regions.blend(x, z)
	var h: float = float(bl[0])
	var mic_amp: float = float(bl[1])
	var mes_amp: float = float(bl[2])
	for lf in au["landforms"]:
		var dx: float = (x - float(lf["cx"])) / float(lf["sx"])
		var dz: float = (z - float(lf["cz"])) / float(lf["sz"])
		h += float(lf["amp_m"]) * exp(-0.5 * (dx * dx + dz * dz))
	var pm: Array = play_masks(x, z)
	var wstrip: float = float(pm[0])
	var lakes: Array = pm[1]
	var mic: Dictionary = au["micro"]
	var n1: float = TN.vnoise(x, z, float(mic["lambda1_m"]), salt_micro) - 0.5
	var n2: float = TN.vnoise(x, z, float(mic["lambda2_m"]), salt_micro ^ 0x9E3779B9) - 0.5
	var nm: float = TN.vnoise(x, z, float(mic["meso_lambda_m"]), salt_meso) - 0.5
	var wmax: float = wstrip
	for e in lakes:
		wmax = maxf(wmax, float(e[0]))
	for rv in au["drainage"]["rivers"]:
		var dd: float = TN.poly_dist(x, z, rv["points"])
		wmax = maxf(wmax, 1.0 - TN.sstep(float(rv["width_m"]) / 2.0, float(rv["width_m"]) / 2.0 + 20.0, dd))
	if noise:
		var micro: float = (n1 + float(mic["oct2_ratio"]) * n2) * 2.0 * mic_amp * (1.0 - 0.9 * wmax)
		var meso: float = nm * 2.0 * mes_amp * (1.0 - 0.9 * wmax)
		h += meso + micro
	var carve: float = 0.0
	for rv in au["drainage"]["rivers"]:
		var dd: float = TN.poly_dist(x, z, rv["points"])
		carve += float(rv["depth_m"]) * (1.0 - TN.sstep(0.0, float(rv["width_m"]) / 2.0, dd))
	for b in au["drainage"]["bowls"]:
		var dx: float = (x - float(b["cx"])) / float(b["sx"])
		var dz: float = (z - float(b["cz"])) / float(b["sz"])
		carve += float(b["depth_m"]) * exp(-0.5 * (dx * dx + dz * dz))
	h -= carve
	var bw: float = float(cell["rwidth"])
	var berm: float = float(cell["berm"])
	var prof: float = berm * TN.sstep(0.0, maxf(bw, 6.0), d)
	if d > bw:
		h = prof * (1.0 - TN.sstep(bw, 150.0, d)) + h * TN.sstep(bw, 150.0, d)
	else:
		h = prof
	if wstrip > 0.0:
		h = h * (1.0 - wstrip) + float(au["runway"]["target_m"]) * wstrip
	for e in lakes:
		var w: float = float(e[0])
		if w > 0.0:
			h = h * (1.0 - w) + float(e[1]) * w
	for pd in au.get("pads", []):
		var ndx: float = (x - float(pd["cx"])) / float(pd["r_m"])
		var ndz: float = (z - float(pd["cz"])) / float(pd["r_m"])
		var nd: float = sqrt(ndx * ndx + ndz * ndz)
		var w: float = 1.0 - TN.sstep(1.0, 1.0 + float(pd["blend_m"]) / float(pd["r_m"]), nd)
		if w > 0.0:
			h = h * (1.0 - w) + float(pd["target_m"]) * w
	return h


func height(x: float, z: float) -> float:
	return clampf(height_raw(x, z), -25.0, 250.0)


func slope_grade(x: float, z: float, eps: float = 2.0) -> Array:
	var gx: float = (height(x + eps, z) - height(x - eps, z)) / (2.0 * eps)
	var gz: float = (height(x, z + eps) - height(x, z - eps)) / (2.0 * eps)
	var g: float = sqrt(gx * gx + gz * gz)
	return [rad_to_deg(atan(g)), g * 100.0]


func is_land(x: float, z: float) -> bool:
	var r: float = sqrt(x * x + z * z)
	if r > 2000.0 + 0.001:
		return false
	return loop.rs(CoastLoop.theta(x, z)) - r > 0.0


func is_coast_band(x: float, z: float) -> bool:
	var r: float = sqrt(x * x + z * z)
	var d: float = loop.rs(CoastLoop.theta(x, z)) - r
	return absf(d) <= 150.0


func region_at(x: float, z: float) -> String:
	return str(regions.classify(x, z)[0])
