class_name ISTerrainCoastLoop
extends RefCounted
## Star-shaped coast loop twin (tools/terrain_model.py CoastLoop).
## Fourier terms (seeded phases) + gaussian bays + envelope normalization.
## FLOAT64 DISCIPLINE: all math uses scalar floats. Godot's Vector2 stores
## float32, which injects ~1e-7 curvature errors that the 300x width
## modulation amplifies past the 1e-6 cross tolerance (found in cross-check).

const TN = preload("res://scripts/terrain/terrain_noise.gd")
const Seed = preload("res://scripts/core/seed_service.gd")

var base: float = 0.0
var terms: Array = []  # [k, amp, phase]
var bays: Array = []
var env_max: float = 0.0
var env_min: float = 0.0
var pos_scale: float = 1.0
var neg_scale: float = 1.0


func initialize(coast: Dictionary, world_version: String, master: int) -> Dictionary:
	var au: Dictionary = coast["authoring"]
	base = float(au["radial_base_m"])
	terms.clear()
	for f in au["fourier_terms"]:
		var d: Dictionary = Seed.derive(world_version, master, "coast", "phase:%d" % int(f["k"]))
		if not d["ok"]:
			return {"ok": false, "error": str(d["error"])}
		terms.append([int(f["k"]), float(f["amp_m"]), TN.phase_of(int(d["seed_i64"]))])
	bays = au["bays"]
	env_max = float(au["envelope"]["max_m"])
	env_min = float(au["envelope"]["min_m"])
	# Envelope normalization: measure raw deviation densely, scale DOWN only.
	var mx: float = -1e18
	var mn: float = 1e18
	for i in range(1440):
		var dv: float = raw_dev(float(i) * TAU / 1440.0)
		mx = maxf(mx, dv)
		mn = minf(mn, dv)
	pos_scale = 1.0
	neg_scale = 1.0
	if mx > 0.0:
		pos_scale = minf(1.0, (env_max - base) / mx)
	if mn < 0.0:
		neg_scale = minf(1.0, (base - env_min) / (-mn))
	return {"ok": true, "error": ""}


func raw_dev(th: float) -> float:
	var d: float = 0.0
	for t in terms:
		d += float(t[1]) * sin(float(t[0]) * th + float(t[2]))
	for b in bays:
		var thc: float = deg_to_rad(float(b["theta_deg"]))
		var dt: float = TN.pos_fmod(th - thc + PI, TAU) - PI
		var arc: float = dt * base
		var sig: float = float(b["width_m"])
		var q: float = arc / sig
		d += float(b["depth_m"]) * exp(-0.5 * q * q)
	return d


func dev(th: float) -> float:
	var d: float = raw_dev(th)
	return d * (pos_scale if d >= 0.0 else neg_scale)


func rs(th: float) -> float:
	return base + dev(th)


func rs_meso(th: float) -> float:
	# Loop without micro terms (k>=50): meso trend for width modulation.
	var d: float = 0.0
	for t in terms:
		if int(t[0]) < 50:
			d += float(t[1]) * sin(float(t[0]) * th + float(t[2]))
	for b in bays:
		var thc: float = deg_to_rad(float(b["theta_deg"]))
		var dt: float = TN.pos_fmod(th - thc + PI, TAU) - PI
		var arc: float = dt * base
		var sig: float = float(b["width_m"])
		var q: float = arc / sig
		d += float(b["depth_m"]) * exp(-0.5 * q * q)
	return base + d * (pos_scale if d >= 0.0 else neg_scale)


static func theta(x: float, z: float) -> float:
	return TN.pos_fmod(atan2(x, -z), TAU)


static func point(rs_m: float, th: float) -> Array:
	return [rs_m * sin(th), -rs_m * cos(th)]
