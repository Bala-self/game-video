class_name ISTerrainRegions
extends RefCounted
## Region ownership + height-blend twin (tools/terrain_model.py Regions).
## Ownership: R10 corridor mask > lakes (R12 water) > R8 band/frontage >
## ellipse weights > reserve fallback. Height BLEND uses hinterland
## ellipses (+reserve fallback) ONLY.
## FLOAT64 DISCIPLINE (see coast_loop.gd): scalar floats only, no Vector2.

const TN = preload("res://scripts/terrain/terrain_noise.gd")
const CoastLoop = preload("res://scripts/terrain/coast_loop.gd")

var regs: Array = []
var lakes: Array = []
var loop = null
var lut_n: int = 0
var fb_threshold: float = 0.15
var r8: Dictionary = {}
var r10: Dictionary = {}
var corridors: Dictionary = {}
var r10_ids: Array = []
var r8_depth: float = 150.0
var frontage: Array = []  # [a_rad, b_rad, region_id]


func initialize(authoring: Dictionary, coast_loop, p_lut_n: int) -> void:
	regs = authoring["regions"]
	lakes = authoring["drainage"].get("lakes", [])
	loop = coast_loop
	lut_n = p_lut_n
	for r in regs:
		if r["id"] == "coastal_beach":
			r8 = r
		if r["id"] == "infra_corridors":
			r10 = r
	for c in authoring["corridors"]:
		corridors[c["id"]] = c
	r10_ids = r10["rule"]["corridors"]
	r8_depth = float(r8["rule"]["depth_m"])
	frontage.clear()
	for s in r8["rule"]["frontage_segments"]:
		frontage.append([deg_to_rad(float(s["from_deg"])), deg_to_rad(float(s["to_deg"])), s["region"]])


static func in_arc(th: float, a: float, b: float) -> bool:
	if a <= b:
		return a <= th and th < b
	return th >= a or th < b


func corridor_dist(x: float, z: float) -> float:
	var best: float = 1e18
	for cid in r10_ids:
		var c: Dictionary = corridors[cid]
		var dd: float
		if c["type"] == "ring":
			dd = TN.ring_dist(x, z, float(c["r_m"]))
		elif c["type"] == "tunnel":
			# A tunnel bore reserves no surface; only portal works are masked.
			var dd2: float = 1e18
			var portals: Array = c["portals"]
			var radii: Array = c["portal_works_r_m"]
			for pi in range(portals.size()):
				var qx: float = x - float(portals[pi][0])
				var qz: float = z - float(portals[pi][1])
				dd2 = minf(dd2, sqrt(qx * qx + qz * qz) - float(radii[pi]))
			best = minf(best, dd2)
			continue
		else:
			dd = TN.poly_dist(x, z, c["points"])
		dd -= float(c["width_m"]) / 2.0
		best = minf(best, dd)
	return best


func weights(x: float, z: float) -> Array:
	var out: Array = []
	var idx: int = 0
	for r in regs:
		if r.has("rule") or (r["shapes"] as Array).is_empty():
			idx += 1
			continue
		var wmax: float = 0.0
		var base: float = float(r["base_m"])
		var tmax: String = ""
		for s in r["shapes"]:
			var dx: float = (x - float(s["cx"])) / float(s["rx"])
			var dz: float = (z - float(s["cz"])) / float(s["rz"])
			var nd: float = sqrt(dx * dx + dz * dz)
			var w: float = 1.0 - TN.sstep(0.70, 1.0, nd)
			if w > wmax:
				wmax = w
				base = float(s.get("base_m", float(r["base_m"])))
				tmax = str(s.get("tag", ""))
		if wmax > 0.0:
			out.append({"id": r["id"], "w": wmax, "base": base,
				"micro": float(r["micro_m"]), "meso": float(r["meso_m"]),
				"pri": int(r["priority"]), "tag": tmax, "_i": idx})
		idx += 1
	return out


## Python sorted(key=(-w, -pri)) is STABLE (file order breaks ties);
## the explicit _i tiebreak reproduces that exactly.
static func _wcmp(a: Dictionary, b: Dictionary) -> bool:
	if float(a["w"]) != float(b["w"]):
		return float(a["w"]) > float(b["w"])
	if int(a["pri"]) != int(b["pri"]):
		return int(a["pri"]) > int(b["pri"])
	return int(a["_i"]) < int(b["_i"])


func classify(x: float, z: float) -> Array:
	# Returns [id, tag, w] like the Python twin.
	var r: float = sqrt(x * x + z * z)
	var th: float = CoastLoop.theta(x, z)
	var d: float = loop.rs(th) - r
	if d < 0.0 or r > 2000.0:
		return ["open_water", "", 0.0]
	if corridor_dist(x, z) < 0.0:
		return ["infra_corridors", "", 1.0]
	for lk in lakes:
		var ndx: float = (x - float(lk["cx"])) / float(lk["rx"])
		var ndz: float = (z - float(lk["cz"])) / float(lk["rz"])
		if sqrt(ndx * ndx + ndz * ndz) < 1.0:
			return ["wetland_inland_water", "", 1.0]
	if d < r8_depth:
		var idx: int = TN.pos_imod(int(th / TAU * float(lut_n) + 0.5), lut_n)
		var th_q: float = float(idx) / float(lut_n) * TAU
		for seg in frontage:
			if in_arc(th_q, float(seg[0]), float(seg[1])):
				return [seg[2], "", 1.0]
		return ["coastal_beach", "", 1.0]
	var ws: Array = weights(x, z)
	if ws.is_empty():
		return ["reserve_buffer", "", 0.0]
	ws.sort_custom(_wcmp)
	if float(ws[0]["w"]) < fb_threshold:
		return ["reserve_buffer", "", float(ws[0]["w"])]
	return [ws[0]["id"], ws[0]["tag"], float(ws[0]["w"])]


func blend(x: float, z: float) -> Array:
	# Returns [base, micro_amp, meso_amp].
	var ws: Array = weights(x, z)
	var tot: float = 0.0
	for e in ws:
		tot += float(e["w"])
	var wres: float = pow(1.0 - minf(tot, 1.0), 2.0)
	var tot2: float = tot + wres
	var base: float = 0.0
	var mic: float = 0.0
	var mes: float = 0.0
	for e in ws:
		base += float(e["w"]) * float(e["base"])
		mic += float(e["w"]) * float(e["micro"])
		mes += float(e["w"]) * float(e["meso"])
	base = (base + wres * 20.0) / tot2
	mic = (mic + wres * 2.0) / tot2
	mes = (mes + wres * 5.0) / tot2
	return [base, mic, mes]
