class_name ISTerrainNoise
extends RefCounted
## Scalar math twins for Prompt 02 (exact ports of tools/terrain_model.py).
## Every function here MUST match its Python twin bit-for-bit where the
## operation is exact (integer hash, comparisons, control flow) and to 1e-6
## relative where libm is involved. Known traps, all handled:
## - GDScript %/fmod truncate; Python % floors -> use pos_fmod/pos_imod.
## - round() differs at .5 (banker's vs half-away) -> use py_round.
## - int() truncates in both. float division is IEEE754 double in both.

const TAU_F: float = 6.283185307179586


static func pos_fmod(x: float, y: float) -> float:
	# Python x % y for y > 0 (floored, always in [0, y)).
	return x - floorf(x / y) * y


static func pos_imod(x: int, y: int) -> int:
	# Python x % y for y > 0 (floored).
	var r: int = x % y
	if r < 0:
		r += y
	return r


static func py_round(x: float) -> int:
	# Python round(): banker's rounding (half to even), returned as int.
	var f: float = floorf(x)
	var frac: float = x - f
	if frac < 0.5 or frac > 0.5:
		return int(f + (1.0 if frac > 0.5 else 0.0))
	var i: int = int(f)
	return i if pos_imod(i, 2) == 0 else i + 1


static func sstep(a: float, b: float, t: float) -> float:
	if t <= a:
		return 0.0
	if t >= b:
		return 1.0
	var u: float = (t - a) / (b - a)
	return u * u * (3.0 - 2.0 * u)


static func lattice(ix: int, iz: int, salt_i64: int) -> float:
	# Bit-exact twin: GDScript ints wrap mod 2^64 like the Python & MASK64,
	# and >> on ints is arithmetic like Python's _arith_shift.
	var salt: int = salt_i64
	var h: int = salt ^ (ix * 374761393) ^ (iz * 668265263)
	h = (h ^ (h >> 13)) * 1274126177
	h = h ^ (h >> 16)
	return float(h & 0x7FFFFFFF) / 2147483648.0


static func vnoise(x: float, z: float, lam: float, salt: int) -> float:
	var gx: float = x / lam
	var gz: float = z / lam
	var ix0: int = int(floorf(gx))
	var iz0: int = int(floorf(gz))
	var fx: float = gx - float(ix0)
	var fz: float = gz - float(iz0)
	var ux: float = fx * fx * (3.0 - 2.0 * fx)
	var uz: float = fz * fz * (3.0 - 2.0 * fz)
	var a: float = lattice(ix0, iz0, salt)
	var b: float = lattice(ix0 + 1, iz0, salt)
	var c: float = lattice(ix0, iz0 + 1, salt)
	var d: float = lattice(ix0 + 1, iz0 + 1, salt)
	return (a * (1.0 - ux) + b * ux) * (1.0 - uz) + (c * (1.0 - ux) + d * ux) * uz


static func poly_dist(x: float, z: float, pts: Array) -> float:
	var best: float = 1e18
	for i in range(pts.size() - 1):
		var ax: float = float(pts[i][0])
		var az: float = float(pts[i][1])
		var bx: float = float(pts[i + 1][0])
		var bz: float = float(pts[i + 1][1])
		var abx: float = bx - ax
		var abz: float = bz - az
		var denom: float = abx * abx + abz * abz
		var t: float = 0.0
		if denom > 0.0:
			t = clampf(((x - ax) * abx + (z - az) * abz) / denom, 0.0, 1.0)
		var qx: float = x - (ax + t * abx)
		var qz: float = z - (az + t * abz)
		best = minf(best, sqrt(qx * qx + qz * qz))
	return best


static func ring_dist(x: float, z: float, r_m: float) -> float:
	return absf(sqrt(x * x + z * z) - r_m)


static func phase_of(seed_i64: int) -> float:
	var u: float = float(seed_i64 & 0x7FFFFFFFFFFFFFFF) / 9223372036854775808.0
	return u * 2.0 * PI
