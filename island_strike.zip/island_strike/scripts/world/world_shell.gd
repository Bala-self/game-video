class_name ISWorldShell
extends Node3D
## Minimal diagnostic runtime world (Prompt 01, §24–27). NOT final terrain/coast/roads.
##
## Proves the engine interprets the locked contract: origin/north/east markers,
## exact boundary rings (1700/1850/1950/1975/2000 m from the REGISTRY — never
## hardcoded), sector debug grid, ocean placeholder plane, config overlay.
## build() must be called after the shell enters the tree (camera look_at needs it).

const WorldRegistry = preload("res://scripts/core/world_registry.gd")
const Diagnostics = preload("res://scripts/core/diagnostics_service.gd")

const MARKER_DIST_M := 300.0
const RING_SEGMENTS := 256
const RING_Y := 0.5
const GRID_Y := 0.4

var nodes: Dictionary = {}


## Build all diagnostic children. Returns {ok, errors, nodes}.
func build(registry: WorldRegistry, diag: Diagnostics) -> Dictionary:
	if not is_inside_tree():
		return {"ok": false, "errors": ["shell must be inside tree before build()"], "nodes": {}}
	var errors: Array = []
	_add_light()
	_add_camera()
	_add_origin_marker()
	_add_axis_markers()
	_add_boundary_rings(registry)
	_add_sector_grid(registry)
	_add_ocean_plane()
	_add_overlay(registry)
	if diag != null:
		diag.info(Diagnostics.CAT_WORLD, "world shell built", {"children": get_child_count()})
	return {"ok": true, "errors": errors, "nodes": nodes}


func _add_light() -> void:
	var sun := DirectionalLight3D.new()
	sun.name = "DebugSun"
	sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
	sun.shadow_enabled = false
	add_child(sun)
	nodes["sun"] = sun


func _add_camera() -> void:
	var cam := Camera3D.new()
	cam.name = "DebugCamera"
	cam.position = Vector3(0.0, 2600.0, 2600.0)
	cam.far = 20000.0
	add_child(cam)
	cam.look_at(Vector3.ZERO, Vector3.UP)
	cam.current = true
	nodes["camera"] = cam


func _add_origin_marker() -> void:
	var mesh := SphereMesh.new()
	mesh.radius = 6.0
	mesh.height = 12.0
	var mi := MeshInstance3D.new()
	mi.name = "OriginMarker"
	mi.mesh = mesh
	mi.material_override = _unshaded(Color.WHITE)
	add_child(mi)
	nodes["origin_marker"] = mi


func _add_axis_markers() -> void:
	var defs := [
		{"name": "NorthMarker", "dir": Vector3(0, 0, -1), "color": Color(0.3, 0.5, 1.0), "label": "NORTH -Z"},
		{"name": "EastMarker", "dir": Vector3(1, 0, 0), "color": Color(1.0, 0.35, 0.3), "label": "EAST +X"},
		{"name": "UpMarker", "dir": Vector3(0, 1, 0), "color": Color(0.35, 1.0, 0.4), "label": "UP +Y"},
	]
	for d in defs:
		var tip: Vector3 = (d["dir"] as Vector3) * MARKER_DIST_M
		var line := _line_node([Vector3.ZERO, tip], d["color"])
		line.name = "%sLine" % d["name"]
		add_child(line)
		var tag := Label3D.new()
		tag.name = "%sLabel" % d["name"]
		tag.text = d["label"]
		tag.position = tip + Vector3(0, 30, 0)
		tag.modulate = d["color"]
		tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		add_child(tag)
		nodes[d["name"]] = {"tip": tip, "line": line, "label": tag}


func _add_boundary_rings(registry: WorldRegistry) -> void:
	var rings := [
		{"key": "coast0", "r": registry.r_coast0_m(), "color": Color(1.0, 0.9, 0.3)},
		{"key": "beach0", "r": registry.r_beach0_m(), "color": Color(1.0, 0.65, 0.2)},
		{"key": "land", "r": registry.r_land_m(), "color": Color(1.0, 0.45, 0.15)},
		{"key": "shore", "r": registry.r_shore_m(), "color": Color(1.0, 0.25, 0.25)},
		{"key": "world", "r": registry.r_world_m(), "color": Color(1.0, 0.1, 0.1)},
	]
	for ring in rings:
		var pts: Array[Vector3] = []
		var rr: float = ring["r"]
		for i in range(RING_SEGMENTS + 1):
			var a: float = TAU * float(i) / float(RING_SEGMENTS)
			pts.append(Vector3(cos(a) * rr, RING_Y, sin(a) * rr))
		var node := _line_strip_node(pts, ring["color"])
		node.name = "Ring_%s" % ring["key"]
		add_child(node)
		nodes[node.name] = {"r": rr, "node": node}


func _add_sector_grid(registry: WorldRegistry) -> void:
	var size: float = float(registry.sector_size_m())
	var gmin: float = registry.sector_grid_min_m()
	var n: int = registry.sector_grid_count()
	var gmax: float = gmin + size * float(n)
	var lines: Array[Vector3] = []
	var c: float = gmin
	while c <= gmax + 0.001:
		lines.append(Vector3(c, GRID_Y, gmin))
		lines.append(Vector3(c, GRID_Y, gmax))
		lines.append(Vector3(gmin, GRID_Y, c))
		lines.append(Vector3(gmax, GRID_Y, c))
		c += size
	var node := _line_node(lines, Color(0.45, 0.6, 0.8, 0.6))
	node.name = "SectorGrid"
	add_child(node)
	nodes["sector_grid"] = node


func _add_ocean_plane() -> void:
	var plane := PlaneMesh.new()
	plane.size = Vector2(12000.0, 12000.0)
	var mi := MeshInstance3D.new()
	mi.name = "OceanPlaceholder"
	mi.mesh = plane
	mi.position = Vector3(0, 0, 0)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.1, 0.3, 0.6, 0.55)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	add_child(mi)
	nodes["ocean"] = mi


func _add_overlay(registry: WorldRegistry) -> void:
	var layer := CanvasLayer.new()
	layer.name = "OverlayLayer"
	add_child(layer)
	var label := Label.new()
	label.name = "OverlayLabel"
	label.position = Vector2(16, 16)
	label.size = Vector2(640, 400)
	label.text = _overlay_text(registry)
	layer.add_child(label)
	nodes["overlay"] = label


func _overlay_text(registry: WorldRegistry) -> String:
	var lines: PackedStringArray = [
		"ISLAND STRIKE — foundation shell (diagnostic, NOT gameplay)",
		"world: %s  contract: %s  world_ver: %s" % [registry.world_id(), registry.contract_version(), registry.world_version()],
		"R=%.1f m  D=%.1f m  area=%.2f m2  C=%.2f m" % [registry.radius_m(), registry.diameter_m(), registry.area_m2(), registry.circumference_m()],
		"origin=(0,0,0)  NORTH=-Z  EAST=+X  UP=+Y  ocean_y=%.1f" % registry.ocean_level_m(),
		"seed=%d (%s)  sector=%d m (%s)" % [registry.master_seed(), registry.seed_scheme(), registry.sector_size_m(), registry.sector_status()],
		"rings: coast0=%.0f beach0=%.0f land=%.0f shore=%.0f world=%.0f" % [
			registry.r_coast0_m(), registry.r_beach0_m(), registry.r_land_m(),
			registry.r_shore_m(), registry.r_world_m()],
	]
	return "\n".join(lines)


func _unshaded(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	return mat


func _line_node(points: Array, color: Color) -> MeshInstance3D:
	var im := ImmediateMesh.new()
	im.surface_begin(Mesh.PRIMITIVE_LINES)
	for p in points:
		im.surface_add_vertex(p)
	im.surface_end()
	var mi := MeshInstance3D.new()
	mi.mesh = im
	mi.material_override = _unshaded(color)
	return mi


func _line_strip_node(points: Array[Vector3], color: Color) -> MeshInstance3D:
	var im := ImmediateMesh.new()
	im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
	for p in points:
		im.surface_add_vertex(p)
	im.surface_end()
	var mi := MeshInstance3D.new()
	mi.mesh = im
	mi.material_override = _unshaded(color)
	return mi
