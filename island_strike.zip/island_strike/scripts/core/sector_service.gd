class_name ISSectorService
extends RefCounted
## Candidate sector system (Prompt 01, §14–15). STATUS: CANDIDATE/BENCHMARK-PENDING.
##
## Formula: sx = floor((x - grid_min) / size), sz = floor((z - grid_min) / size)
## with grid_min=-2048, size=256, count=16 -> indices 0..15, span [-2048,2048).
## Intervals are LEFT-CLOSED: exact boundary values belong to the higher sector
## (e.g. x=-1792 -> sx=1). Mapping is EXACT (no epsilon); tolerances live in tests.
## Sector size must NOT be treated as final until the Prompt 07 benchmark decision.

const WorldRegistry = preload("res://scripts/core/world_registry.gd")

enum SectorVsWorld { FULLY_INSIDE = 0, PARTIAL = 1, FULLY_OUTSIDE = 2 }

var _reg: WorldRegistry


func _init(registry: WorldRegistry) -> void:
	_reg = registry


# ---------------------------------------------------------------- statics (pure)
static func sector_of_xz(x: float, z: float, size_m: int, grid_min_m: float) -> Vector2i:
	var s: float = float(size_m)
	return Vector2i(floori((x - grid_min_m) / s), floori((z - grid_min_m) / s))


static func sector_of_pos(pos: Vector3, size_m: int, grid_min_m: float) -> Vector2i:
	return sector_of_xz(pos.x, pos.z, size_m, grid_min_m)


static func is_in_grid(sector: Vector2i, grid_count: int) -> bool:
	return sector.x >= 0 and sector.y >= 0 and sector.x < grid_count and sector.y < grid_count


## Min-corner (x,z) of a sector in world meters.
static func sector_bounds_min(sector: Vector2i, size_m: int, grid_min_m: float) -> Vector2:
	return Vector2(grid_min_m + float(sector.x * size_m), grid_min_m + float(sector.y * size_m))


## Max-corner (x,z), exclusive upper bound.
static func sector_bounds_max(sector: Vector2i, size_m: int, grid_min_m: float) -> Vector2:
	var mn: Vector2 = sector_bounds_min(sector, size_m, grid_min_m)
	return mn + Vector2(float(size_m), float(size_m))


static func sector_center(sector: Vector2i, size_m: int, grid_min_m: float) -> Vector2:
	return sector_bounds_min(sector, size_m, grid_min_m) + Vector2(float(size_m), float(size_m)) * 0.5


static func sector_id_string(sector: Vector2i) -> String:
	return "%d,%d" % [sector.x, sector.y]


## Parse "sx,sz". Returns {ok, sector}.
static func parse_sector_id(s: String) -> Dictionary:
	var parts: PackedStringArray = s.split(",", false, 2)
	if parts.size() != 2 or not parts[0].is_valid_int() or not parts[1].is_valid_int():
		return {"ok": false, "sector": Vector2i.ZERO}
	return {"ok": true, "sector": Vector2i(parts[0].to_int(), parts[1].to_int())}


static func neighbors_4(sector: Vector2i) -> Array[Vector2i]:
	return [
		sector + Vector2i(1, 0), sector + Vector2i(-1, 0),
		sector + Vector2i(0, 1), sector + Vector2i(0, -1),
	]


static func neighbors_8(sector: Vector2i) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			if dx == 0 and dz == 0:
				continue
			out.append(sector + Vector2i(dx, dz))
	return out


static func sector_chebyshev(a: Vector2i, b: Vector2i) -> int:
	return maxi(absi(a.x - b.x), absi(a.y - b.y))


static func sector_center_distance_m(a: Vector2i, b: Vector2i, size_m: int, grid_min_m: float) -> float:
	var ca: Vector2 = sector_center(a, size_m, grid_min_m)
	var cb: Vector2 = sector_center(b, size_m, grid_min_m)
	return ca.distance_to(cb)


static func sector_contains(sector: Vector2i, x: float, z: float, size_m: int, grid_min_m: float) -> bool:
	var mn: Vector2 = sector_bounds_min(sector, size_m, grid_min_m)
	var mx: Vector2 = sector_bounds_max(sector, size_m, grid_min_m)
	return x >= mn.x and x < mx.x and z >= mn.y and z < mx.y


## Classify sector rect vs island disc (closest/farthest corner test).
static func sector_vs_world(sector: Vector2i, size_m: int, grid_min_m: float, r_world: float) -> int:
	var mn: Vector2 = sector_bounds_min(sector, size_m, grid_min_m)
	var mx: Vector2 = sector_bounds_max(sector, size_m, grid_min_m)
	var cx: float = clampf(0.0, mn.x, mx.x)
	var cz: float = clampf(0.0, mn.y, mx.y)
	var d_min: float = sqrt(cx * cx + cz * cz)
	if d_min > r_world:
		return SectorVsWorld.FULLY_OUTSIDE
	var d_max := 0.0
	for px in [mn.x, mx.x]:
		for pz in [mn.y, mx.y]:
			d_max = maxf(d_max, sqrt(px * px + pz * pz))
	if d_max <= r_world:
		return SectorVsWorld.FULLY_INSIDE
	return SectorVsWorld.PARTIAL


# ---------------------------------------------------------------- instance (registry-bound)
func size_m() -> int: return _reg.sector_size_m()
func grid_min_m() -> float: return _reg.sector_grid_min_m()
func grid_count() -> int: return _reg.sector_grid_count()

func world_position_to_sector(pos: Vector3) -> Vector2i:
	return sector_of_pos(pos, size_m(), grid_min_m())


func sector_to_world_bounds(sector: Vector2i) -> Rect2:
	var mn: Vector2 = sector_bounds_min(sector, size_m(), grid_min_m())
	return Rect2(mn, Vector2(float(size_m()), float(size_m())))


func sector_to_center(sector: Vector2i) -> Vector3:
	var c: Vector2 = sector_center(sector, size_m(), grid_min_m())
	return Vector3(c.x, 0.0, c.y)


func sector_contains_position(sector: Vector2i, pos: Vector3) -> bool:
	return sector_contains(sector, pos.x, pos.z, size_m(), grid_min_m())


func sector_distance(a: Vector2i, b: Vector2i) -> float:
	return sector_center_distance_m(a, b, size_m(), grid_min_m())


func sector_vs_island(sector: Vector2i) -> int:
	return sector_vs_world(sector, size_m(), grid_min_m(), _reg.r_world_m())


## Full-grid census for §15 metadata (computed, not stored).
func grid_census() -> Dictionary:
	var n: int = grid_count()
	var inside := 0
	var partial := 0
	var outside := 0
	for sx in range(n):
		for sz in range(n):
			match sector_vs_island(Vector2i(sx, sz)):
				SectorVsWorld.FULLY_INSIDE:
					inside += 1
				SectorVsWorld.PARTIAL:
					partial += 1
				_:
					outside += 1
	return {
		"grid_count": n, "total": n * n,
		"fully_inside": inside, "partial": partial, "fully_outside": outside,
		"intersecting": inside + partial,
	}
