class_name ISBenchmark
extends RefCounted
## Benchmark harness (Prompt 01, §21–23). Measures; NEVER gates (NON-GATING).
##
## - measure(): run a Callable N times, report min/mean/median/max (+p95 if n>=20).
## - Values in SECONDS (float). Timestamps via Time (system clock, UTC-ish local).
## - Unmeasurable metrics: value=null + status/unavailable + reason (§22).
## - Modes labeled on every record (COLD_START/HEADLESS_DUMMY/etc.), never mixed.

const Diagnostics = preload("res://scripts/core/diagnostics_service.gd")

var diag: Diagnostics


func _init(diagnostics: Diagnostics = null) -> void:
	diag = diagnostics


## Run `fn` `samples` times. Returns stats dict (values in seconds).
func measure(label: String, fn: Callable, samples: int, extra: Dictionary = {}) -> Dictionary:
	var values: Array[float] = []
	values.resize(samples)
	for i in range(samples):
		var t0: int = Time.get_ticks_usec()
		fn.call()
		var t1: int = Time.get_ticks_usec()
		values[i] = float(t1 - t0) / 1000000.0
	return stats_for(label, "s", values, extra)


## Stats for one-shot measurements (single sample, no percentiles).
func measure_once(label: String, fn: Callable, extra: Dictionary = {}) -> Dictionary:
	var t0: int = Time.get_ticks_usec()
	var ret: Variant = fn.call()
	var t1: int = Time.get_ticks_usec()
	var secs: float = float(t1 - t0) / 1000000.0
	var d := stats_for(label, "s", [secs], extra)
	d["one_shot"] = true
	d["return_kept"] = ret != null
	return d


static func stats_for(label: String, unit: String, values: Array, extra: Dictionary = {}) -> Dictionary:
	var vals: Array[float] = []
	for v in values:
		vals.append(float(v))
	vals.sort()
	var n: int = vals.size()
	var total := 0.0
	for v in vals:
		total += v
	var mean: float = total / float(maxi(n, 1))
	var median := 0.0
	if n > 0:
		if n % 2 == 1:
			median = vals[n / 2]
		else:
			median = (vals[n / 2 - 1] + vals[n / 2]) / 2.0
	var p95: Variant = null
	if n >= 20:
		var rank: int = mini(n - 1, int(ceil(0.95 * float(n))) - 1)
		p95 = vals[rank]
	var d := {
		"label": label, "unit": unit, "samples": n,
		"min": vals[0] if n > 0 else null,
		"mean": mean, "median": median,
		"max": vals[n - 1] if n > 0 else null,
		"p95": p95, "status": "measured",
	}
	for k in extra.keys():
		d[k] = extra[k]
	return d


## Record for an UNMEASURABLE metric (§22: null + unavailable + reason).
static func unavailable(label: String, unit: String, reason: String, extra: Dictionary = {}) -> Dictionary:
	var d := {"label": label, "unit": unit, "value": null, "status": "unavailable", "reason": reason}
	for k in extra.keys():
		d[k] = extra[k]
	return d


static func memory_bytes() -> int:
	return OS.get_static_memory_usage()


static func memory_peak_bytes() -> int:
	return OS.get_static_memory_peak_usage()


static func utc_stamp() -> String:
	return Time.get_datetime_string_from_system(true, false)


## Write a JSON report (creates parent dirs; works for res:// and absolute paths).
func write_json(path: String, report: Dictionary) -> Dictionary:
	var dir: String = path.get_base_dir()
	if not DirAccess.dir_exists_absolute(dir):
		var mk: int = DirAccess.make_dir_recursive_absolute(dir)
		if mk != OK:
			return {"ok": false, "error": "cannot create report dir: %s" % dir}
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return {"ok": false, "error": "cannot open report path for write: %s" % path}
	f.store_string(JSON.stringify(report, "  "))
	f.close()
	return {"ok": true, "error": ""}
