class_name ISSeedService
extends RefCounted
## Deterministic seed derivation (Prompt 01, §16). Owner of ALL world seeds.
##
## Scheme "IS-SEED/1": FNV-1a (64-bit) over the canonical input string:
##   "IS-SEED/1|v=<world_version>|m=<master>|d=<domain>|k=<key>"
## Inputs: world_version + master + domain + key. Same inputs => same seed,
## on any machine, any run, any Godot version (pure integer math, no engine RNG).
##
## Collision note: 64-bit space; birthday bound ~4e9 derivations for 50% collision.
## World needs < 1e6 derivations. Practically collision-free; separation is
## additionally asserted by tests over sampled keys.
## Engine caveat: the derived SEED is version-independent, but Godot's
## RandomNumberGenerator STREAM for a given seed may vary across engine versions.
## Gameplay must never depend on cross-version RNG streams, only on seed stability.

const SCHEME := "IS-SEED/1"
const DOMAINS: Array[String] = [
	"region", "sector", "terrain", "vegetation", "buildings",
	"props", "coast", "roads", "traffic", "weather", "mission",
]

## FNV-1a 64-bit offset basis as SIGNED int64 (unsigned 14695981039346656037
## minus 2^64). Bit pattern is identical; GDScript ints wrap mod 2^64.
const _FNV_OFFSET_I64: int = -3750763034362895579
const _FNV_PRIME_I64: int = 1099511628211
const _HEX_DIGITS := "0123456789abcdef"


## FNV-1a 64-bit digest of text (UTF-8 bytes) as signed int64 bit pattern.
static func fnv1a64_i64(text: String) -> int:
	var h: int = _FNV_OFFSET_I64
	var bytes: PackedByteArray = text.to_utf8_buffer()
	for b in bytes:
		h = h ^ b
		h = h * _FNV_PRIME_I64
	return h


## Unsigned 64-bit value rendered as 16 lowercase hex chars (manual nibbles;
## no reliance on %x sign behavior).
static func u64_to_hex(v: int) -> String:
	var out := ""
	for i in range(16):
		var nibble: int = (v >> (60 - i * 4)) & 0xF
		out += _HEX_DIGITS[nibble]
	return out


## FNV-1a 64-bit digest of text as 16-char hex string.
static func fnv1a64_hex(text: String) -> String:
	return u64_to_hex(fnv1a64_i64(text))


## Canonical input string for a derivation (exposed so tests/tools can audit it).
static func canonical_input(world_version: String, master_seed: int, domain: String, key: String) -> String:
	return "%s|v=%s|m=%d|d=%s|k=%s" % [SCHEME, world_version, master_seed, domain, key]


## Derive a seed. Returns {ok, seed_i64, seed_hex, scheme, domain, key, error}.
static func derive(world_version: String, master_seed: int, domain: String, key: String) -> Dictionary:
	if world_version.is_empty():
		return {"ok": false, "error": "world_version is empty"}
	if domain not in DOMAINS:
		return {"ok": false, "error": "unknown domain '%s'" % domain}
	if key.is_empty():
		return {"ok": false, "error": "key is empty"}
	var text: String = canonical_input(world_version, master_seed, domain, key)
	var digest: int = fnv1a64_i64(text)
	return {
		"ok": true,
		"scheme": SCHEME,
		"domain": domain,
		"key": key,
		"seed_i64": digest,
		"seed_hex": u64_to_hex(digest),
		"error": "",
	}


## Convenience: seed a RandomNumberGenerator from a derivation.
## NOTE: engine RNG stream stability across Godot versions is NOT guaranteed;
## only the seed value itself is contract-stable.
static func rng_for_seed(seed_i64: int) -> RandomNumberGenerator:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_i64
	return rng
