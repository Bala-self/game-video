class_name ISUnits
extends RefCounted
## Single unit + tolerance policy for ISLAND STRIKE (Prompt 01, §29).
##
## Units: distance/height meters, time seconds, speed m/s.
## Angles: radians in math APIs, degrees only where the name says `_deg`.
## Naming: prefer `*_m`, `*_mps`, `*_s`, `*_deg`, `*_rad` suffixes.
##
## Tolerance policy (derived, not magic):
## - DOUBLE_EPS (1e-9): double-precision comparisons for |v| <= 4096.
##   Double machine epsilon ~2.2e-16; 1e-9 absorbs chained-op error with margin.
## - BOUNDARY_EPS_M (1e-3 m = 1 mm): boundary classification tolerance.
##   Derived from float32 Vector3 storage quantization at island scale:
##   quantum(2000 m) = 2000 * 2^-23 ~= 2.4e-4 m; x4 safety factor -> 1e-3 m.
##   Gameplay-irrelevant (1 mm on a 4000 m island), kills float flicker at r=2000.
## - Sector mapping uses EXACT floor() with NO epsilon inside the formula;
##   tolerances live in tests, never in the mapping (determinism, §14).

const DOUBLE_EPS: float = 1e-9
const BOUNDARY_EPS_M: float = 0.001

const UNIT_DISTANCE := "m"
const UNIT_TIME := "s"
const UNIT_SPEED := "m/s"


## True if two doubles agree within DOUBLE_EPS (absolute).
static func approx_eq(a: float, b: float) -> bool:
	return absf(a - b) <= DOUBLE_EPS


## True if two meter values agree within 1 mm.
static func approx_eq_m(a_m: float, b_m: float) -> bool:
	return absf(a_m - b_m) <= BOUNDARY_EPS_M


## True if v is a finite number (rejects NaN/inf from malformed data, §51).
static func is_valid_number(v: float) -> bool:
	return is_finite(v)
