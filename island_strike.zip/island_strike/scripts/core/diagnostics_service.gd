class_name ISDiagnostics
extends RefCounted
## Development diagnostics service (Prompt 01, §19). Failures stay visible.
##
## Levels: DEBUG < INFO < WARNING < ERROR < FATAL. Categories per §19.
## Output: stdout via print(); ERROR/FATAL additionally via printerr() so CI
## log audits can separate streams. Repeat suppression: identical
## (level,category,message) bursts are collapsed after 5 repeats/second —
## failures remain visible, floods do not.

enum Level { DEBUG = 0, INFO = 1, WARNING = 2, ERROR = 3, FATAL = 4 }

const LEVEL_NAMES: Array[String] = ["DEBUG", "INFO", "WARNING", "ERROR", "FATAL"]
const CAT_BOOT := "BOOT"
const CAT_WORLD := "WORLD"
const CAT_COORDINATE := "COORDINATE"
const CAT_SECTOR := "SECTOR"
const CAT_SEED := "SEED"
const CAT_VALIDATION := "VALIDATION"
const CAT_PERFORMANCE := "PERFORMANCE"
const CAT_STREAMING := "STREAMING"
const CAT_DATA := "DATA"
const CAT_TEST := "TEST"

const _SUPPRESS_AFTER := 5
const _SUPPRESS_WINDOW_MSEC := 1000

var min_level: int = Level.DEBUG
var _last_key := ""
var _last_window: int = 0
var _repeat_count := 0
var _suppressed_total := 0
var error_count := 0
var warning_count := 0
var fatal_count := 0


func debug(category: String, message: String, context: Dictionary = {}) -> void:
	record(Level.DEBUG, category, message, context)


func info(category: String, message: String, context: Dictionary = {}) -> void:
	record(Level.INFO, category, message, context)


func warning(category: String, message: String, context: Dictionary = {}) -> void:
	warning_count += 1
	record(Level.WARNING, category, message, context)


func error(category: String, message: String, context: Dictionary = {}) -> void:
	error_count += 1
	record(Level.ERROR, category, message, context)


func fatal(category: String, message: String, context: Dictionary = {}) -> void:
	fatal_count += 1
	error_count += 1
	record(Level.FATAL, category, message, context)


func record(level: int, category: String, message: String, context: Dictionary = {}) -> void:
	if level < min_level:
		return
	var key: String = "%d|%s|%s" % [level, category, message]
	var now: int = Time.get_ticks_msec()
	if key == _last_key and now - _last_window < _SUPPRESS_WINDOW_MSEC:
		_repeat_count += 1
		if _repeat_count > _SUPPRESS_AFTER:
			_suppressed_total += 1
			return
	else:
		_last_key = key
		_last_window = now
		_repeat_count = 0
	var line := "[%s][%s] %s" % [LEVEL_NAMES[level], category, message]
	if not context.is_empty():
		line += " " + JSON.stringify(context)
	if level >= Level.ERROR:
		printerr(line)
	else:
		print(line)


func suppressed_total() -> int:
	return _suppressed_total


func reset_counts() -> void:
	error_count = 0
	warning_count = 0
	fatal_count = 0
	_suppressed_total = 0
	_last_key = ""
	_repeat_count = 0
