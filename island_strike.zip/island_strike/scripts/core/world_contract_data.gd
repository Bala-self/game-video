class_name ISWorldContractData
extends RefCounted
## Machine-readable world-contract loader + SHAPE validator (Prompt 01, §11/§51/§52).
##
## Pipeline: WORLD_MASTER_CONTRACT.md (design authority)
##         -> data/world/world_contract.json (this loader's input)
##         -> normalized Dictionary -> ISWorldRegistry (runtime authority).
##
## This loader validates SHAPE (presence, types, finiteness, ranges, relations).
## LOCKED-VALUE enforcement (radius==2000, seed==13371337, ...) is owned by:
##   - ISWorldChecksum vs committed golden (runtime), and
##   - tools/validate_foundation.py locked-constants comparison (CI).
## Rationale: one layer validates structure, another guards locked values; a single
## layer doing both would conflate "malformed" with "revised". See ARCHITECTURE.md.

const REQUIRED_KEYS: Array[String] = [
	"world_id", "world_name", "schema_version", "world_version",
	"contract_version", "engine_target", "radius_m", "diameter_m",
	"origin", "axes", "coordinate_convention", "ocean_level_m",
	"terrain_min_m", "terrain_target_max_m", "terrain_absolute_cap_m",
	"boundary", "gps_origin_offset", "sector_size_m", "sector_grid_min_m",
	"sector_grid_count", "sector_status", "master_seed", "seed_scheme",
]
const REQUIRED_AXES: Array[String] = ["east", "west", "up", "north", "south"]
const REQUIRED_BOUNDS: Array[String] = [
	"r_world_m", "r_land_m", "r_shore_m", "r_beach0_m", "r_coast0_m",
	"r_play_limit_m", "r_ocean_visual_m",
]


## Load + validate a contract file. Returns {ok, data, errors}.
## `data` is the NORMALIZED contract (integral floats converted to ints).
static func load_from_path(path: String) -> Dictionary:
	var errors: Array[String] = []
	if not FileAccess.file_exists(path):
		return {"ok": false, "data": {}, "errors": ["contract file missing: %s" % path]}
	var text: String = FileAccess.get_file_as_string(path)
	if text.is_empty():
		return {"ok": false, "data": {}, "errors": ["contract file empty: %s" % path]}
	var parser := JSON.new()
	var parse_err: int = parser.parse(text)
	if parse_err != OK:
		return {"ok": false, "data": {}, "errors": ["JSON parse error at line %d: %s" % [parser.get_error_line(), parser.get_error_string()]]}
	if not (parser.data is Dictionary):
		return {"ok": false, "data": {}, "errors": ["contract root must be a JSON object"]}
	return validate(parser.data, errors)


## Validate an already-parsed Dictionary. Returns {ok, data, errors}.
static func validate(raw: Variant, errors: Array[String] = []) -> Dictionary:
	var errs: Array[String] = errors.duplicate()
	if not (raw is Dictionary):
		errs.append("contract root must be a Dictionary")
		return {"ok": false, "data": {}, "errors": errs}
	var d: Dictionary = raw
	for key in REQUIRED_KEYS:
		if not d.has(key):
			errs.append("missing required key: %s" % key)
	if not errs.is_empty():
		return {"ok": false, "data": {}, "errors": errs}

	var norm := {}
	# --- string identity fields ---
	for key in ["world_id", "world_name", "schema_version", "world_version",
			"contract_version", "engine_target", "coordinate_convention",
			"sector_status", "seed_scheme"]:
		var sv := _req_string(d, key, errs)
		if sv[0]:
			norm[key] = sv[1]
	# --- meter floats ---
	for key in ["radius_m", "diameter_m", "ocean_level_m", "terrain_min_m",
			"terrain_target_max_m", "terrain_absolute_cap_m", "sector_grid_min_m"]:
		var fv := _req_finite_number(d, key, errs)
		if fv[0]:
			norm[key] = fv[1]
	# --- ints (JSON numbers arrive as float; accept integral only) ---
	for key in ["sector_size_m", "sector_grid_count", "master_seed"]:
		var iv := _req_int(d, key, errs)
		if iv[0]:
			norm[key] = iv[1]
	# --- origin [0,0,0] ---
	if d["origin"] is Array and (d["origin"] as Array).size() == 3:
		var org: Array = []
		for i in range(3):
			var cv := _to_int((d["origin"] as Array)[i])
			if not cv[0]:
				errs.append("origin[%d] must be an integer 0" % i)
			else:
				org.append(cv[1])
		if org == [0, 0, 0]:
			norm["origin"] = [0, 0, 0]
		else:
			errs.append("origin must be exactly [0,0,0]")
	else:
		errs.append("origin must be an array of 3 numbers")
	# --- axes ---
	if d["axes"] is Dictionary:
		var axes: Dictionary = d["axes"]
		var want := {"east": "+X", "west": "-X", "up": "+Y", "north": "-Z", "south": "+Z"}
		for key in REQUIRED_AXES:
			if not axes.has(key):
				errs.append("axes missing key: %s" % key)
			elif str(axes[key]) != str(want[key]):
				errs.append("axes.%s must be '%s', got '%s'" % [key, want[key], axes[key]])
		norm["axes"] = {
			"east": "+X", "west": "-X", "up": "+Y", "north": "-Z", "south": "+Z",
		}
	else:
		errs.append("axes must be an object")
	# --- boundary ---
	if d["boundary"] is Dictionary:
		var bnorm := {}
		var bd: Dictionary = d["boundary"]
		for key in REQUIRED_BOUNDS:
			if not bd.has(key):
				errs.append("boundary missing key: %s" % key)
				continue
			var bv := _to_finite_float(bd[key])
			if not bv[0]:
				errs.append("boundary.%s must be a finite number" % key)
			else:
				bnorm[key] = bv[1]
		norm["boundary"] = bnorm
	else:
		errs.append("boundary must be an object")
	# --- gps offset [2000,2000] ---
	if d["gps_origin_offset"] is Array and (d["gps_origin_offset"] as Array).size() == 2:
		var gp: Array = []
		for i in range(2):
			var gv := _to_int((d["gps_origin_offset"] as Array)[i])
			if gv[0]:
				gp.append(gv[1])
		norm["gps_origin_offset"] = gp
	else:
		errs.append("gps_origin_offset must be an array of 2 numbers")

	if not errs.is_empty():
		return {"ok": false, "data": {}, "errors": errs}

	# --- cross-field relations (§52) ---
	_rel(norm, errs)
	if not errs.is_empty():
		return {"ok": false, "data": {}, "errors": errs}
	return {"ok": true, "data": norm, "errors": []}


## Relation checks on normalized data. Appends to errs.
static func _rel(n: Dictionary, errs: Array[String]) -> void:
	var radius: float = n["radius_m"]
	var diameter: float = n["diameter_m"]
	if radius <= 0.0:
		errs.append("radius_m must be > 0")
	if diameter != 2.0 * radius:
		errs.append("diameter_m (%.6f) must equal 2*radius_m (%.6f)" % [diameter, 2.0 * radius])
	if n["coordinate_convention"] != "right-handed-y-up":
		errs.append("coordinate_convention must be 'right-handed-y-up'")
	if n["sector_status"] != "candidate":
		errs.append("sector_status must be 'candidate' until Prompt 07 decides (got '%s')" % n["sector_status"])
	if int(n["sector_size_m"]) <= 0:
		errs.append("sector_size_m must be > 0")
	if int(n["sector_grid_count"]) <= 0:
		errs.append("sector_grid_count must be > 0")
	if int(n["master_seed"]) < 0:
		errs.append("master_seed must be >= 0")
	if n["seed_scheme"] != "IS-SEED/1":
		errs.append("seed_scheme must be 'IS-SEED/1'")
	if float(n["terrain_min_m"]) >= 0.0:
		errs.append("terrain_min_m must be < 0 (seabed below ocean)")
	if float(n["terrain_target_max_m"]) <= 0.0:
		errs.append("terrain_target_max_m must be > 0")
	if float(n["terrain_target_max_m"]) > float(n["terrain_absolute_cap_m"]):
		errs.append("terrain_target_max_m must be <= terrain_absolute_cap_m")
	var b: Dictionary = n["boundary"]
	if b["r_world_m"] != radius:
		errs.append("boundary.r_world_m must equal radius_m")
	if not (b["r_coast0_m"] < b["r_beach0_m"] and b["r_beach0_m"] < b["r_land_m"] and b["r_land_m"] < b["r_shore_m"] and b["r_shore_m"] <= b["r_world_m"]):
		errs.append("boundary rings must nest: coast0 < beach0 < land < shore <= world")
	if not (b["r_play_limit_m"] > b["r_world_m"]):
		errs.append("boundary.r_play_limit_m must exceed r_world_m")
	if not (b["r_ocean_visual_m"] >= b["r_play_limit_m"]):
		errs.append("boundary.r_ocean_visual_m must cover r_play_limit_m")
	var gp: Array = n["gps_origin_offset"]
	if gp != [2000, 2000]:
		errs.append("gps_origin_offset must be [2000,2000]")


static func _req_string(d: Dictionary, key: String, errs: Array[String]) -> Array:
	if not (d[key] is String) or (d[key] as String).is_empty():
		errs.append("%s must be a non-empty string" % key)
		return [false, ""]
	return [true, d[key]]


static func _req_finite_number(d: Dictionary, key: String, errs: Array[String]) -> Array:
	var r := _to_finite_float(d[key])
	if not r[0]:
		errs.append("%s must be a finite number" % key)
		return [false, 0.0]
	return [true, r[1]]


static func _req_int(d: Dictionary, key: String, errs: Array[String]) -> Array:
	var r := _to_int(d[key])
	if not r[0]:
		errs.append("%s must be an integer" % key)
		return [false, 0]
	return [true, r[1]]


## Accept int or integral float; reject NaN/inf/non-integral. Returns [ok, int].
static func _to_int(v: Variant) -> Array:
	if v is int:
		return [true, v]
	if v is float:
		var f: float = v
		if not is_finite(f):
			return [false, 0]
		if f != floorf(f):
			return [false, 0]
		if f < -9.0e18 or f > 9.0e18:
			return [false, 0]
		return [true, int(f)]
	return [false, 0]


## Accept int/float; reject NaN/inf. Returns [ok, float].
static func _to_finite_float(v: Variant) -> Array:
	if v is float:
		return [is_finite(v), float(v)]
	if v is int:
		return [true, float(v)]
	return [false, 0.0]
