class_name ISValidationService
extends RefCounted
## Cross-layer consistency validation (Prompt 01, §53). Fail-loud, never silent.
##
## Checks:
##  V1 locked values: contract data carries the EXACT locked constants
##     (radius 2000, diameter 4000, seed 13371337, origin, axes, ocean 0, versions).
##  V2 registry consistency: live registry dump == re-loaded contract (drift check).
##  V3 checksum: registry checksum == committed golden file.
## Any mismatch is a FAILURE (contract corruption fails fast, §39).

const ContractData = preload("res://scripts/core/world_contract_data.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")
const WorldChecksum = preload("res://scripts/core/world_checksum.gd")
const Units = preload("res://scripts/core/units.gd")

var _reg: WorldRegistry


func _init(registry: WorldRegistry) -> void:
	_reg = registry


## V1: locked constants. Returns array of {name, pass, detail}.
func check_locked_values() -> Array:
	var out: Array = []
	_chk(out, "V1-radius", _reg.radius_m() == 2000.0, "radius=%s" % _reg.radius_m())
	_chk(out, "V1-diameter", _reg.diameter_m() == 4000.0, "diameter=%s" % _reg.diameter_m())
	_chk(out, "V1-origin", _reg.origin() == Vector3.ZERO, "origin=%s" % _reg.origin())
	_chk(out, "V1-ocean", _reg.ocean_level_m() == 0.0, "ocean=%s" % _reg.ocean_level_m())
	_chk(out, "V1-seed", _reg.master_seed() == 13371337, "seed=%d" % _reg.master_seed())
	_chk(out, "V1-north", _reg.north_axis() == Vector3i(0, 0, -1), "north=%s" % _reg.north_axis())
	_chk(out, "V1-east", _reg.east_axis() == Vector3i(1, 0, 0), "east=%s" % _reg.east_axis())
	_chk(out, "V1-up", _reg.up_axis() == Vector3i(0, 1, 0), "up=%s" % _reg.up_axis())
	_chk(out, "V1-schema", _reg.schema_version() == "1.0.0", "schema=%s" % _reg.schema_version())
	_chk(out, "V1-world-ver", _reg.world_version() == "0.1.0", "world=%s" % _reg.world_version())
	_chk(out, "V1-contract-ver", _reg.contract_version() == "1.0.0", "contract=%s" % _reg.contract_version())
	_chk(out, "V1-sector", _reg.sector_size_m() == 256 and _reg.sector_status() == "candidate",
		"sector=%d/%s" % [_reg.sector_size_m(), _reg.sector_status()])
	_chk(out, "V1-area", Units.approx_eq(_reg.area_m2(), PI * 2000.0 * 2000.0), "area=%.2f" % _reg.area_m2())
	_chk(out, "V1-circ", Units.approx_eq(_reg.circumference_m(), TAU * 2000.0), "circ=%.2f" % _reg.circumference_m())
	return out


## V2: re-load contract from disk, compare field-by-field with live registry.
func check_registry_consistency(contract_path: String) -> Array:
	var out: Array = []
	var loaded: Dictionary = ContractData.load_from_path(contract_path)
	if not loaded["ok"]:
		_chk(out, "V2-reload", false, "reload failed: %s" % "; ".join(loaded["errors"]))
		return out
	_chk(out, "V2-reload", true, "contract re-loaded")
	var disk: Dictionary = loaded["data"]
	var dump: Dictionary = _reg.to_dump()
	for key in disk.keys():
		if not dump.has(key):
			_chk(out, "V2-field:" + key, false, "missing in registry dump")
			continue
		var a: Variant = disk[key]
		var b: Variant = dump[key]
		var same := false
		if a is float and b is float:
			same = Units.approx_eq(float(a), float(b))
		else:
			same = str(a) == str(b)
		_chk(out, "V2-field:" + str(key), same, "disk=%s reg=%s" % [str(a), str(b)])
	return out


## V3: checksum vs golden file.
func check_checksum(golden_path: String) -> Array:
	var out: Array = []
	if not FileAccess.file_exists(golden_path):
		_chk(out, "V3-golden-exists", false, "missing: %s" % golden_path)
		return out
	var golden: String = FileAccess.get_file_as_string(golden_path).strip_edges().to_lower()
	_chk(out, "V3-golden-format", golden.length() == 16, "len=%d" % golden.length())
	var core_r: Dictionary = WorldChecksum.core_from_registry(_reg)
	if not core_r["ok"]:
		_chk(out, "V3-core", false, core_r["error"])
		return out
	_chk(out, "V3-core", true, "core built")
	var v: Dictionary = WorldChecksum.verify_against_golden(core_r["core"], golden)
	_chk(out, "V3-match", v["ok"], "actual=%s expected=%s" % [v.get("actual", "?"), golden])
	return out


## Run V1+V2+V3. Returns {ok, checks}.
func run_all(contract_path: String, golden_path: String) -> Dictionary:
	var checks: Array = []
	checks.append_array(check_locked_values())
	checks.append_array(check_registry_consistency(contract_path))
	checks.append_array(check_checksum(golden_path))
	var ok := true
	for c in checks:
		if not c["pass"]:
			ok = false
	return {"ok": ok, "checks": checks}


static func _chk(out: Array, name: String, passed: bool, detail: String) -> void:
	out.append({"name": name, "pass": passed, "detail": detail})
