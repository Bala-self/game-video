class_name ISWorldRegistry
extends RefCounted
## Authoritative RUNTIME world registry (Prompt 01, §10). Single source of truth.
##
## Owns: world identity, dimensions, origin, axes, ocean level, terrain limits,
## boundary rings, sector layout, master seed. Initialized ONCE from normalized
## ISWorldContractData, then FROZEN (mutation-controlled; re-init is an error).
## All future systems (terrain, roads, streaming, GPS, AI) read from here —
## never from project.godot, never from duplicated constants.

const ContractData = preload("res://scripts/core/world_contract_data.gd")

var _frozen: bool = false
var _d: Dictionary = {}


## Initialize from normalized contract data. Returns {ok, errors}.
func initialize(normalized: Dictionary) -> Dictionary:
	if _frozen:
		return {"ok": false, "errors": ["registry already initialized (frozen)"]}
	if normalized.is_empty():
		return {"ok": false, "errors": ["cannot initialize registry from empty data"]}
	_d = normalized.duplicate(true)
	_frozen = true
	return {"ok": true, "errors": []}


func is_initialized() -> bool:
	return _frozen

# --- identity ---
func world_id() -> String: return _d["world_id"]
func world_name() -> String: return _d["world_name"]
func schema_version() -> String: return _d["schema_version"]
func world_version() -> String: return _d["world_version"]
func contract_version() -> String: return _d["contract_version"]
func engine_target() -> String: return _d["engine_target"]

# --- dimensions (meters) ---
func radius_m() -> float: return _d["radius_m"]
func diameter_m() -> float: return _d["diameter_m"]
func area_m2() -> float:
	var r: float = radius_m()
	return PI * r * r
func circumference_m() -> float:
	return TAU * radius_m()

# --- frame ---
func origin() -> Vector3: return Vector3.ZERO
func north_axis() -> Vector3i: return Vector3i(0, 0, -1)
func east_axis() -> Vector3i: return Vector3i(1, 0, 0)
func up_axis() -> Vector3i: return Vector3i(0, 1, 0)
func ocean_level_m() -> float: return _d["ocean_level_m"]

# --- terrain limits ---
func terrain_min_m() -> float: return _d["terrain_min_m"]
func terrain_target_max_m() -> float: return _d["terrain_target_max_m"]
func terrain_absolute_cap_m() -> float: return _d["terrain_absolute_cap_m"]

# --- boundary rings ---
func boundary() -> Dictionary: return (_d["boundary"] as Dictionary).duplicate()
func r_world_m() -> float: return _d["boundary"]["r_world_m"]
func r_land_m() -> float: return _d["boundary"]["r_land_m"]
func r_shore_m() -> float: return _d["boundary"]["r_shore_m"]
func r_beach0_m() -> float: return _d["boundary"]["r_beach0_m"]
func r_coast0_m() -> float: return _d["boundary"]["r_coast0_m"]
func r_play_limit_m() -> float: return _d["boundary"]["r_play_limit_m"]
func r_ocean_visual_m() -> float: return _d["boundary"]["r_ocean_visual_m"]

# --- gps / sectors / seeds ---
func gps_offset() -> Vector2: return Vector2(2000.0, 2000.0)
func sector_size_m() -> int: return _d["sector_size_m"]
func sector_grid_min_m() -> float: return _d["sector_grid_min_m"]
func sector_grid_count() -> int: return _d["sector_grid_count"]
func sector_status() -> String: return _d["sector_status"]
func master_seed() -> int: return _d["master_seed"]
func seed_scheme() -> String: return _d["seed_scheme"]

## World bounds as AABB: x/z in [-R, +R], y in [terrain_min, terrain_cap].
func world_bounds_aabb() -> AABB:
	var r: float = radius_m()
	var y0: float = terrain_min_m()
	var y1: float = terrain_absolute_cap_m()
	return AABB(Vector3(-r, y0, -r), Vector3(2.0 * r, y1 - y0, 2.0 * r))


## Serializable dump for diagnostics, registry_dump.json, and cross-layer tests.
## NOTE: contains no timestamps (deterministic; see docs/ARCHITECTURE.md).
func to_dump() -> Dictionary:
	return {
		"world_id": world_id(),
		"world_name": world_name(),
		"schema_version": schema_version(),
		"world_version": world_version(),
		"contract_version": contract_version(),
		"engine_target": engine_target(),
		"radius_m": radius_m(),
		"diameter_m": diameter_m(),
		"area_m2": area_m2(),
		"circumference_m": circumference_m(),
		"origin": [0, 0, 0],
		"axes": {"east": "+X", "west": "-X", "up": "+Y", "north": "-Z", "south": "+Z"},
		"coordinate_convention": "right-handed-y-up",
		"ocean_level_m": ocean_level_m(),
		"terrain_min_m": terrain_min_m(),
		"terrain_target_max_m": terrain_target_max_m(),
		"terrain_absolute_cap_m": terrain_absolute_cap_m(),
		"boundary": boundary(),
		"gps_origin_offset": [2000, 2000],
		"sector_size_m": sector_size_m(),
		"sector_grid_min_m": sector_grid_min_m(),
		"sector_grid_count": sector_grid_count(),
		"sector_status": sector_status(),
		"master_seed": master_seed(),
		"seed_scheme": seed_scheme(),
	}
