class_name ISWorldChecksum
extends RefCounted
## Deterministic world-contract checksum (Prompt 01, §17). Change detector, NOT crypto.
##
## Core = flat Dictionary of ASCII strings + ints ONLY (meters as integer
## millimeters — no floats, no locale issues, no float formatting divergence).
## Canonical form: keys sorted ascending, `{"k":v,...}` with minimal escaping.
## This byte stream MUST be identical to Python's
## `json.dumps(core, sort_keys=True, separators=(",",":"), ensure_ascii=True)`,
## verified by tools/validate_foundation.py cross-check (F-CHECKSUM-01).
## Digest: FNV-1a 64-bit hex (see ISSeedService). Non-ASCII in core is a loud
## error, never silently re-encoded.

const SeedService = preload("res://scripts/core/seed_service.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")


## Build the checksum core from a live registry. Returns {ok, core, error}.
static func core_from_registry(reg: WorldRegistry) -> Dictionary:
	var b: Dictionary = reg.boundary()
	var core := {
		"axes": "E:+X,W:-X,U:+Y,N:-Z,S:+Z",
		"b_beach0_mm": _mm(b["r_beach0_m"]),
		"b_coast0_mm": _mm(b["r_coast0_m"]),
		"b_land_mm": _mm(b["r_land_m"]),
		"b_ocean_mm": _mm(b["r_ocean_visual_m"]),
		"b_play_mm": _mm(b["r_play_limit_m"]),
		"b_shore_mm": _mm(b["r_shore_m"]),
		"b_world_mm": _mm(b["r_world_m"]),
		"contract_version": reg.contract_version(),
		"diameter_mm": _mm(reg.diameter_m()),
		"gps": "2000,2000",
		"grid_count": reg.sector_grid_count(),
		"grid_min_mm": _mm(reg.sector_grid_min_m()),
		"master_seed": reg.master_seed(),
		"ocean_mm": _mm(reg.ocean_level_m()),
		"origin": "0,0,0",
		"radius_mm": _mm(reg.radius_m()),
		"schema_version": reg.schema_version(),
		"sector_size": reg.sector_size_m(),
		"terrain_cap_mm": _mm(reg.terrain_absolute_cap_m()),
		"terrain_max_mm": _mm(reg.terrain_target_max_m()),
		"terrain_min_mm": _mm(reg.terrain_min_m()),
		"world_id": reg.world_id(),
		"world_version": reg.world_version(),
	}
	return {"ok": true, "core": core, "error": ""}


## Canonical JSON serialization. Returns {ok, text, error}.
static func canonical_json(core: Dictionary) -> Dictionary:
	var keys: Array = core.keys()
	keys.sort()
	var parts: PackedStringArray = []
	for k in keys:
		if not (k is String):
			return {"ok": false, "text": "", "error": "checksum core keys must be strings"}
		var ks: String = k
		var ev := _escape_ascii(ks)
		if not ev[0]:
			return {"ok": false, "text": "", "error": "non-ASCII in key: %s" % ks}
		var v: Variant = core[k]
		var vs := ""
		if v is int:
			vs = "%d" % v
		elif v is String:
			var e2 := _escape_ascii(v)
			if not e2[0]:
				return {"ok": false, "text": "", "error": "non-ASCII in value of '%s'" % ks}
			vs = "\"%s\"" % e2[1]
		else:
			return {"ok": false, "text": "", "error": "core value '%s' must be int or ASCII string" % ks}
		parts.append("\"%s\":%s" % [ev[1], vs])
	return {"ok": true, "text": "{" + ",".join(parts) + "}", "error": ""}


## Full checksum of a core. Returns {ok, checksum_hex, canonical, error}.
static func checksum_of_core(core: Dictionary) -> Dictionary:
	var c := canonical_json(core)
	if not c["ok"]:
		return {"ok": false, "checksum_hex": "", "canonical": "", "error": c["error"]}
	var digest: String = SeedService.fnv1a64_hex(c["text"])
	return {"ok": true, "checksum_hex": digest, "canonical": c["text"], "error": ""}


## Compare against a golden hex string. Returns {ok, actual, expected}.
static func verify_against_golden(core: Dictionary, golden_hex: String) -> Dictionary:
	var c := checksum_of_core(core)
	if not c["ok"]:
		return {"ok": false, "actual": "", "expected": golden_hex, "error": c["error"]}
	var actual: String = c["checksum_hex"]
	if actual != golden_hex.strip_edges().to_lower():
		return {"ok": false, "actual": actual, "expected": golden_hex, "error": "checksum mismatch"}
	return {"ok": true, "actual": actual, "expected": golden_hex, "error": ""}


static func _mm(v: float) -> int:
	return roundi(v * 1000.0)


## Minimal ASCII escaper matching Python json.dumps(ensure_ascii=True) for the
## ASCII subset. Returns [ok, escaped]. Non-ASCII -> [false, ""] (loud failure).
static func _escape_ascii(s: String) -> Array:
	var out := ""
	for i in range(s.length()):
		var cp: int = s.unicode_at(i)
		if cp == 0x22:
			out += "\\\""
		elif cp == 0x5C:
			out += "\\\\"
		elif cp == 0x0A:
			out += "\\n"
		elif cp == 0x0D:
			out += "\\r"
		elif cp == 0x09:
			out += "\\t"
		elif cp < 0x20 or cp >= 0x7F:
			return [false, ""]
		else:
			out += s[i]
	return [true, out]
