class_name ISCoordinateService
extends RefCounted
## Authoritative coordinate contract (Prompt 01, §12–13). ONLY conversion owner.
##
## Locked: +X=EAST, -X=WEST, +Y=UP/height, -Z=NORTH, +Z=SOUTH, origin=(0,0,0).
## r = sqrt(x^2 + z^2). Boundary is cylindrical (Y excluded).
## "Map GPS" here is the GAME grid mapping (x+2000, z+2000) — NOT geographic
## latitude/longitude. API names say `map_gps` to prevent confusion (§13).
##
## Precision: core math is scalar-double; Vector3 wrappers exist for engine
## interop (Vector3 stores float32 — see ISUnits tolerance policy).

const Units = preload("res://scripts/core/units.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")

enum BoundaryClass { INSIDE = 0, EDGE = 1, OUTSIDE = 2 }

var _reg: WorldRegistry


func _init(registry: WorldRegistry) -> void:
	_reg = registry


# ---------------------------------------------------------------- statics (pure)
static func radius_from_xz(x: float, z: float) -> float:
	return sqrt(x * x + z * z)


static func radius_of(pos: Vector3) -> float:
	return radius_from_xz(pos.x, pos.z)


## Inside test with documented 1 mm fail-open (kills float flicker at r=R).
static func is_inside_world_r(r: float, r_world: float) -> bool:
	return r <= r_world + Units.BOUNDARY_EPS_M


static func boundary_class_of_r(r: float, r_world: float) -> int:
	var eps: float = Units.BOUNDARY_EPS_M
	if r > r_world + eps:
		return BoundaryClass.OUTSIDE
	if r < r_world - eps:
		return BoundaryClass.INSIDE
	return BoundaryClass.EDGE


static func world_to_map_gps_xz(x: float, z: float, gps_offset: Vector2) -> Vector2:
	return Vector2(x + gps_offset.x, z + gps_offset.y)


static func map_gps_to_world_xz(gx: float, gz: float, gps_offset: Vector2) -> Vector2:
	return Vector2(gx - gps_offset.x, gz - gps_offset.y)


## Move semantics: north decreases Z, east increases X (§27 — runtime verified).
static func north_offset(pos: Vector3, dist_m: float) -> Vector3:
	return Vector3(pos.x, pos.y, pos.z - dist_m)


static func east_offset(pos: Vector3, dist_m: float) -> Vector3:
	return Vector3(pos.x + dist_m, pos.y, pos.z)


static func up_offset(pos: Vector3, dist_m: float) -> Vector3:
	return Vector3(pos.x, pos.y + dist_m, pos.z)


## Compass heading in radians: 0 = North(-Z), clockwise. Returns [ok, heading].
static func heading_from_direction(d: Vector3) -> Array:
	if d.x == 0.0 and d.z == 0.0:
		return [false, 0.0]
	return [true, atan2(d.x, -d.z)]


## Explicit boundary gate: inside -> {ok:true, pos}; outside -> {ok:false,
## clamped pos scaled onto r=R}. Callers must branch on ok — never silent.
static func clamp_or_reject(pos: Vector3, r_world: float) -> Dictionary:
	var r: float = radius_of(pos)
	if is_inside_world_r(r, r_world):
		return {"ok": true, "pos": pos, "r": r}
	if r <= 0.0:
		return {"ok": true, "pos": pos, "r": r}
	var s: float = r_world / r
	return {"ok": false, "pos": Vector3(pos.x * s, pos.y, pos.z * s), "r": r}


# ---------------------------------------------------------------- instance (registry-bound)
func radius_of_world_pos(pos: Vector3) -> float:
	return radius_of(pos)


func is_inside_world(pos: Vector3) -> bool:
	return is_inside_world_r(radius_of(pos), _reg.r_world_m())


func is_inside_land_boundary(pos: Vector3) -> bool:
	return is_inside_world_r(radius_of(pos), _reg.r_land_m())


func boundary_class(pos: Vector3) -> int:
	return boundary_class_of_r(radius_of(pos), _reg.r_world_m())


func distance_from_center(pos: Vector3) -> float:
	return radius_of(pos)


func world_to_map_gps(pos: Vector3) -> Vector2:
	return world_to_map_gps_xz(pos.x, pos.z, _reg.gps_offset())


func map_gps_to_world(g: Vector2) -> Vector3:
	var xz: Vector2 = map_gps_to_world_xz(g.x, g.y, _reg.gps_offset())
	return Vector3(xz.x, 0.0, xz.y)


func clamp_or_reject_world(pos: Vector3) -> Dictionary:
	return clamp_or_reject(pos, _reg.r_world_m())
