class_name ISAppBootstrap
extends Node
## Authoritative application entry (Prompt 01, §8). Coordinates startup; OWNS nothing gameplay.
##
## Lifecycle: BOOT -> PRELOAD -> VALIDATE -> INITIALIZE -> READY -> RUNTIME -> SHUTDOWN.
## Order: Diagnostics -> Contract load -> Registry -> Validation -> Coord/Sector ->
## Benchmark env -> WorldShell. Contract corruption FAILS FAST (exit 3).
## Optional benchmark mode: `-- --benchmark-frames N` collects N _process deltas,
## prints `FRAME_STATS_JSON <json>` to stdout, then quits (exit 0).

const ContractData = preload("res://scripts/core/world_contract_data.gd")
const WorldRegistry = preload("res://scripts/core/world_registry.gd")
const CoordService = preload("res://scripts/core/coordinate_service.gd")
const SectorService = preload("res://scripts/core/sector_service.gd")
const SeedService = preload("res://scripts/core/seed_service.gd")
const Validation = preload("res://scripts/core/validation_service.gd")
const Diagnostics = preload("res://scripts/core/diagnostics_service.gd")
const Benchmark = preload("res://scripts/core/benchmark_service.gd")
const WorldShell = preload("res://scripts/world/world_shell.gd")

const CONTRACT_PATH := "res://data/world/world_contract.json"
const GOLDEN_PATH := "res://data/world/contract_checksum.txt"

enum Stage { BOOT, PRELOAD, VALIDATE, INITIALIZE, READY, RUNTIME, SHUTDOWN }

var stage: int = Stage.BOOT
var diag: Diagnostics
var registry: WorldRegistry
var coord: CoordService
var sectors: SectorService
var validation: Validation
var benchmark: Benchmark
var shell: WorldShell
var boot_usec: int = 0

var _bench_frames_target: int = 0
var _bench_deltas: Array[float] = []
var _failed: bool = false


func _ready() -> void:
	run_boot()


func run_boot() -> bool:
	var t0: int = Time.get_ticks_usec()
	diag = Diagnostics.new()
	stage = Stage.BOOT
	diag.info(Diagnostics.CAT_BOOT, "ISLAND STRIKE bootstrap start", {"stage": "BOOT"})

	# PRELOAD: contract from disk.
	stage = Stage.PRELOAD
	var loaded: Dictionary = ContractData.load_from_path(CONTRACT_PATH)
	if not loaded["ok"]:
		return _fail_fast("contract load failed", loaded["errors"])
	diag.info(Diagnostics.CAT_DATA, "world contract loaded", {"path": CONTRACT_PATH})

	# INITIALIZE: registry + services.
	stage = Stage.INITIALIZE
	registry = WorldRegistry.new()
	var init_r: Dictionary = registry.initialize(loaded["data"])
	if not init_r["ok"]:
		return _fail_fast("registry init failed", init_r["errors"])
	coord = CoordService.new(registry)
	sectors = SectorService.new(registry)
	validation = Validation.new(registry)
	benchmark = Benchmark.new(diag)
	diag.info(Diagnostics.CAT_WORLD, "services initialized", {
		"radius_m": registry.radius_m(), "seed": registry.master_seed(),
		"sector": "%d/%s" % [registry.sector_size_m(), registry.sector_status()],
	})

	# VALIDATE: V1+V2+V3 before any world node exists.
	stage = Stage.VALIDATE
	var v: Dictionary = validation.run_all(CONTRACT_PATH, GOLDEN_PATH)
	var passed := 0
	for c in v["checks"]:
		if c["pass"]:
			passed += 1
		else:
			diag.error(Diagnostics.CAT_VALIDATION, "check failed: " + c["name"], {"detail": c["detail"]})
	diag.info(Diagnostics.CAT_VALIDATION, "validation complete",
		{"passed": passed, "total": v["checks"].size()})
	if not v["ok"]:
		return _fail_fast("world validation failed", [])

	# READY: build the diagnostic world shell.
	stage = Stage.READY
	shell = WorldShell.new()
	shell.name = "WorldShell"
	add_child(shell)
	var built: Dictionary = shell.build(registry, diag)
	if not built["ok"]:
		return _fail_fast("world shell build failed", built["errors"])

	boot_usec = Time.get_ticks_usec() - t0
	stage = Stage.RUNTIME
	diag.info(Diagnostics.CAT_BOOT, "bootstrap READY", {
		"boot_ms": float(boot_usec) / 1000.0,
		"world": registry.world_id(), "contract": registry.contract_version(),
	})
	_parse_bench_args()
	return true


func _process(delta: float) -> void:
	if _bench_frames_target > 0:
		_bench_deltas.append(delta)
		if _bench_deltas.size() >= _bench_frames_target:
			_emit_frame_stats()
			get_tree().quit(0)


func _exit_tree() -> void:
	stage = Stage.SHUTDOWN
	if diag != null:
		diag.info(Diagnostics.CAT_BOOT, "shutdown", {"stage": "SHUTDOWN"})


func has_failed() -> bool:
	return _failed


func _fail_fast(message: String, errors: Array) -> bool:
	_failed = true
	stage = Stage.SHUTDOWN
	var ctx := {"errors": errors}
	if diag != null:
		diag.fatal(Diagnostics.CAT_BOOT, message, ctx)
	else:
		printerr("[FATAL][BOOT] %s %s" % [message, JSON.stringify(ctx)])
	push_error("ISLAND STRIKE bootstrap aborted: %s" % message)
	get_tree().quit(3)
	return false


func _parse_bench_args() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	for i in range(args.size()):
		if args[i] == "--benchmark-frames" and i + 1 < args.size() and args[i + 1].is_valid_int():
			_bench_frames_target = maxi(1, args[i + 1].to_int())
			_bench_deltas.clear()
			diag.info(Diagnostics.CAT_PERFORMANCE, "frame benchmark armed",
				{"frames": _bench_frames_target})


func _emit_frame_stats() -> void:
	var vals: Array = []
	for d in _bench_deltas:
		vals.append(d)
	var stats: Dictionary = Benchmark.stats_for("steady_state_frame", "s", vals, {
		"mode": "HEADLESS_DUMMY", "source": "bootstrap --benchmark-frames"})
	stats["fps_mean"] = 1.0 / float(stats["mean"]) if float(stats["mean"]) > 0.0 else null
	print("FRAME_STATS_JSON " + JSON.stringify(stats))
