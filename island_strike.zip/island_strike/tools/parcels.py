#!/usr/bin/env python3
"""P06 Gen-D: parcels inside validated blocks + rural farmsteads.

Reads: district_contract, districts.json, blocks.json, road_geometry.json,
       transport_reservations.json (via P05 ReservationIndex), terrain.
Writes: data/derived/parcels.json {parcels, skips, rejections, checksum}.

Modes per district class:
  URBAN    recursive binary subdivision of road-fronting rows (front row
           + optional back row behind a 6m access_lane parcel).
  CAMPUS   functional zones along the block long axis (never force-split
           into fake urban lots). One parcel per zone.
  RURAL    direct seeded placement (farmstead + barn) with a driveway
           corridor to the nearest road. Fields stay natural.
  NONE     no parcels (open coast / wetland buffer).

Split acceptance (46): both children satisfy min-area, min-frontage,
buildability, access, reservation compliance; on failure try alternate
seeded positions, else retain the larger (merge remainder into neighbor).
No slivers: remainders merge, never emitted as tiny lots.
"""
import json
import math
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from districts import seed_for, q6, polyline_dist, canon, fnv1a_hex  # noqa: E402
from terrain_model import Field  # noqa: E402
from reservation_index import ReservationIndex  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P06D = os.environ.get("P06_OUT_DIR") or os.path.join(ROOT, "data/derived")
BEACH_REGION = "coastal_beach"

HARD_LAYERS = {"road_safety", "junction", "bridge_exclusion",
               "tunnel_exclusion", "retaining_footprint"}

URBAN_CLASSES = {"CITY_CORE", "MIXED_USE", "RESIDENTIAL_INNER",
                 "RESIDENTIAL_OUTER", "SUBURBAN", "RURAL_VILLAGE",
                 "COMMERCIAL", "WATERFRONT", "FOREST_SETTLEMENT",
                 "HIGHLAND_SETTLEMENT"}
CAMPUS_CLASSES = {"CIVIC", "RESORT", "INDUSTRIAL", "PORT", "AIRFIELD",
                  "RESTRICTED", "UTILITY"}
RURAL_CLASSES = {"AGRICULTURAL"}
NONE_CLASSES = {"OPEN_COAST", "WETLAND_BUFFER"}

CAMPUS_GRADE = {"PORT": 0.15, "INDUSTRIAL": 0.20, "AIRFIELD": 0.15,
                "RESTRICTED": 0.30, "CIVIC": 0.20, "RESORT": 0.25,
                "UTILITY": 0.25}

CAMPUS_ZONES = {
    "PORT": [("LOGISTICS", 0.50, "freight_ops"), ("SPECIAL", 0.20, "support"),
             ("OPEN", 0.30, "operational_open")],
    "INDUSTRIAL": [("INDUSTRIAL", 0.55, "plant_pad"),
                   ("LOGISTICS", 0.20, "loading"),
                   ("OPEN", 0.25, "operational_open")],
    "AIRFIELD": [("SERVICE", 0.40, "hangar_support"),
                 ("SPECIAL", 0.25, "ops_support"),
                 ("OPEN", 0.35, "apron_open")],
    "RESTRICTED": [("RESTRICTED", 0.70, "secure_ops"),
                   ("SERVICE", 0.15, "support"),
                   ("OPEN", 0.15, "standoff_open")],
    "CIVIC": [("CIVIC", 0.50, "hall"), ("OPEN", 0.50, "plaza")],
    "RESORT": [("TOURISM", 0.55, "guest"), ("OPEN", 0.45, "grounds")],
    "UTILITY": [("UTILITY", 0.80, "plant"), ("OPEN", 0.20, "buffer_open")],
}

SERVICE_PARKING = {
    "RESIDENTIAL": ("rear_lane_or_driveway", "on_lot"),
    "COMMERCIAL": ("rear_service_court", "rear_lot_or_street"),
    "CIVIC": ("dedicated_service_entry", "plaza_adjacent_lot"),
    "INDUSTRIAL": ("truck_court", "fleet_yard"),
    "LOGISTICS": ("truck_court", "fleet_yard"),
    "TOURISM": ("service_entry", "guest_lot"),
    "SERVICE": ("front_counter_lane", "customer_front"),
    "UTILITY": ("secure_service", "operational_only"),
    "SPECIAL": ("secure_service", "operational_only"),
    "RESTRICTED": ("secure_service", "operational_only"),
    "OPEN": ("maintenance_access", "none_or_trailhead"),
}

# runway protection: rect + 60m safety + 400m approach bands E/W
RW_MARGIN = 60.0
RW_APPROACH_LEN = 400.0
RW_APPROACH_HALF = 80.0

LANE_W = 6.0


class ParcelsError(Exception):
    pass


def shoelace(poly):
    a = 0.0
    for i in range(len(poly)):
        x0, z0 = poly[i]
        x1, z1 = poly[(i + 1) % len(poly)]
        a += x0 * z1 - x1 * z0
    return abs(a) / 2.0


class Registry:
    def __init__(self):
        t0 = time.time()
        self.timers = {}
        self.dc = json.load(open(os.path.join(
            ROOT, "data/world/district_contract.json")))
        self.dist = json.load(open(os.path.join(
            P06D, "districts.json")))
        self.blk = json.load(open(os.path.join(
            P06D, "blocks.json")))
        self.g = json.load(open(os.path.join(
            ROOT, "data/derived/road_geometry.json")))
        self.r = json.load(open(os.path.join(
            ROOT, "data/derived/roads.json")))
        self.f = Field()
        self.ri = ReservationIndex()
        self.runway = self.r["runway_rect"]
        self.cls_of = {d["id"]: d["class"] for d in self.dist["districts"]}
        self.set_of = {d["id"]: d["settlement"]
                       for d in self.dist["districts"]}
        self.parcels = []
        self.skips = []
        self.rejections = []
        self.timers["load"] = time.time() - t0

    def _t(self, name):
        if name is None:
            self.timers[self._cur] = time.time() - self._t0
        else:
            self._cur = name
            self._t0 = time.time()

    # ---------- preflight ----------
    @staticmethod
    def checksum_scope(items):
        lines = sorted(canon(it) for it in items)
        return fnv1a_hex("\n".join(lines))

    def phase_preflight(self):
        self._t("preflight")
        for doc, name in ((self.dist, "districts"), (self.blk, "blocks")):
            key = "settlements" if name == "districts" else "blocks"
            if name == "districts":
                items = doc["settlements"] + doc["districts"] + \
                    doc["area_closure"] + doc["transitions"]
            else:
                items = doc["blocks"]
            if self.checksum_scope(items) != doc["checksum"]:
                raise ParcelsError("stale %s.json (checksum mismatch)" % name)
        assert self.dc["district_version"] == \
            self.dist["meta"]["district_version"]
        assert self.dc["parcel_version"] == self.blk["meta"]["parcel_version"]
        self._t(None)

    # ---------- shared tests ----------
    def hard_reserved(self, x, z):
        return bool(set(self.ri.reservation_types_at(x, z)) & HARD_LAYERS)

    def in_runway_zone(self, x, z):
        x0, z0, x1, z1 = self.runway
        if x0 - RW_MARGIN <= x <= x1 + RW_MARGIN and \
                z0 - RW_MARGIN <= z <= z1 + RW_MARGIN:
            return True
        zc = (z0 + z1) / 2.0
        if abs(z - zc) <= RW_APPROACH_HALF and \
                (x0 - RW_APPROACH_LEN <= x <= x0 or
                 x1 <= x <= x1 + RW_APPROACH_LEN):
            return True
        return False

    def sample_quad(self, corners, nu=3, nv=3):
        (ax, az), (bx, bz), (cx, cz), (dx, dz) = corners
        for i in range(nu):
            s = i / (nu - 1.0) if nu > 1 else 0.0
            for j in range(nv):
                t = j / (nv - 1.0) if nv > 1 else 0.0
                yield (ax * (1 - s) * (1 - t) + bx * s * (1 - t) +
                       cx * s * t + dx * (1 - s) * t,
                       az * (1 - s) * (1 - t) + bz * s * (1 - t) +
                       cz * s * t + dz * (1 - s) * t)

    def quad_world(self, C, T, N, u0, u1, v0, v1):
        out = []
        for (u, v) in ((u0, v0), (u1, v0), (u1, v1), (u0, v1)):
            out.append((C[0] + T[0] * u + N[0] * v,
                        C[1] + T[1] * u + N[1] * v))
        return out

    def buildability(self, corners, grade_max):
        pts = list(self.sample_quad(corners))
        land = 0
        gmax = 0.0
        beach = False
        coast = False
        for (x, z) in pts:
            if not self.f.is_land(x, z):
                continue
            land += 1
            _, pct = self.f.slope_grade(x, z)
            gmax = max(gmax, pct / 100.0)
            rg = self.f.region_at(x, z)
            if rg == BEACH_REGION:
                beach = True
            if self.f.is_coast_band(x, z):
                coast = True
        return {"land_share": land / len(pts), "grade_max": gmax,
                "beach": beach, "coast": coast}

    # ---------- Gen-D urban ----------
    def phase_parcels(self):
        self._t("parcels")
        for b in self.blk["blocks"]:
            if b["buildability"]["verdict"] == "NON_BUILDABLE":
                self.skips.append({"block": b["id"],
                                   "reason": "block_non_buildable"})
                continue
            dcls = self.cls_of[b["district_id"]]
            if dcls in URBAN_CLASSES:
                self._urban_block(b, dcls)
            elif dcls in CAMPUS_CLASSES:
                self._campus_block(b, dcls)
            elif dcls in NONE_CLASSES:
                self.skips.append({"block": b["id"],
                                   "reason": "open_district_no_parcels"})
            else:
                self.skips.append({"block": b["id"],
                                   "reason": "rural_handled_directly"})
        self._rural_districts()
        self._direct_districts()
        self._beach_access()
        self._t(None)

    def _frame_ranges(self, b):
        C = b["frame"]["center"]
        T = b["frame"]["tangent"]
        N = [-T[1], T[0]]
        us, vs = [], []
        for (x, z) in b["corners"]:
            us.append((x - C[0]) * T[0] + (z - C[1]) * T[1])
            vs.append((x - C[0]) * N[0] + (z - C[1]) * N[1])
        # v0 = road side: the edge nearer the road centerline
        return C, T, N, min(us), max(us), min(vs), max(vs)

    def _urban_block(self, b, dcls):
        cls = self.dc["district_classes"][dcls]
        pref_w, pref_d = cls["preferred_lot"]
        C, T, N, u0, u1, v0, v1 = self._frame_ranges(b)
        # road side = v-edge closer to the block's road stations
        E = self.g["edges"][b["edge"]]
        pts = [(p["x"], p["z"]) for p in E["stations"]]
        wa, wb = b["stations"]
        mid_lo = (C[0] + N[0] * v0, C[1] + N[1] * v0)
        mid_hi = (C[0] + N[0] * v1, C[1] + N[1] * v1)
        seg = pts[wa:wb + 1]
        road_v0 = polyline_dist(mid_lo[0], mid_lo[1], seg) < \
            polyline_dist(mid_hi[0], mid_hi[1], seg)
        if not road_v0:
            v0, v1 = v1, v0  # normalize: v0 = road side
        total_d = abs(v1 - v0)
        sgn = 1.0 if v1 > v0 else -1.0
        d_front = min(pref_d, total_d)
        rem = total_d - d_front
        rows = []  # (va, vb, access)
        rows.append((v0, v0 + sgn * d_front, "DIRECT"))
        if rem >= pref_d * 0.7 + LANE_W:
            lane_a = v0 + sgn * d_front
            lane_b = lane_a + sgn * LANE_W
            back_a = lane_b
            rows.append((lane_a, lane_b, "LANE"))
            rows.append((back_a, v1, "LANE_VIA"))
        elif rem >= 200.0 / abs(u1 - u0):
            rows.append((v0 + sgn * d_front, v1, "OPEN_REM"))
        else:
            rows = [(v0, v1, "DIRECT")]  # absorb sliver into front row
        for ri, (va, vb, acc) in enumerate(rows):
            if acc == "LANE":
                self._emit_lane(b, dcls, C, T, N, u0, u1, va, vb)
            elif acc == "OPEN_REM":
                self._emit_open(b, dcls, C, T, N, u0, u1, va, vb,
                                "rear_court")
            else:
                self._subdivide_row(b, dcls, cls, C, T, N, u0, u1, va, vb,
                                    acc, ri, pref_w)

    def _lot_valid(self, corners, cls, front_len, need_front, grade_max,
                   access_ok):
        area = shoelace(corners)
        if area < cls["parcel_area_min_m2"] or \
                area > cls["parcel_area_max_m2"]:
            return False, "area"
        if need_front and front_len < cls["frontage_min_m"]:
            return False, "frontage"
        # sliver: shortest edge under global min width
        emin = min(math.hypot(corners[i][0] - corners[(i + 1) % 4][0],
                              corners[i][1] - corners[(i + 1) % 4][1])
                   for i in range(4))
        if emin < self.dc["parcel_rules"]["min_width_m"]:
            return False, "sliver"
        bb = self.buildability(corners, grade_max)
        if bb["land_share"] < 0.85:
            return False, "water_or_terrain"
        if bb["grade_max"] > grade_max:
            return False, "grade"
        # building viability: enough of the lot must clear FULL building
        # exclusion (setbacks/utility/visibility), else it can never host
        # a footprint (lots failing here become OPEN remainders, not dead
        # parcels).
        clear = 0
        for (x, z) in self.sample_quad(corners, nu=5, nv=5):
            if not self.ri.is_building_excluded(x, z)[0]:
                clear += 1
        if clear < 10:
            return False, "no_building_envelope"
        for (x, z) in self.sample_quad(corners):
            if self.hard_reserved(x, z):
                return False, "reservation"
            if self.in_runway_zone(x, z):
                return False, "runway"
        if not access_ok:
            return False, "access"
        return True, bb

    def _subdivide_row(self, b, dcls, cls, C, T, N, u0, u1, va, vb,
                       access, ri, pref_w):
        depth = abs(vb - va)
        grade_max = 0.30 if dcls in ("FOREST_SETTLEMENT",
                                     "HIGHLAND_SETTLEMENT") else 0.20
        rng = random.Random(b["seed"] + ri * 7919)
        lots = []  # (ua, ub)

        def rec(ua, ub):
            span = ub - ua
            if span <= pref_w * 1.6:
                lots.append((ua, ub))
                return
            fracs = [0.42 + 0.16 * rng.random() for _ in range(3)]
            for f in fracs:
                m = ua + span * f
                a = self.quad_world(C, T, N, ua, m, va, vb)
                c = self.quad_world(C, T, N, m, ub, va, vb)
                oka, _ = self._lot_valid(a, cls, m - ua, True, grade_max,
                                         True)
                okc, _ = self._lot_valid(c, cls, ub - m, True, grade_max,
                                         True)
                if oka and okc:
                    rec(ua, m)
                    rec(m, ub)
                    return
            self.rejections.append({"block": b["id"], "row": ri,
                                    "span": [q6(ua), q6(ub)],
                                    "reason": "split_failed_retain_larger"})
            lots.append((ua, ub))  # retain larger (whole)

        rec(u0, u1)
        # merge invalid lots into neighbor (no slivers emitted)
        valid = []
        for (ua, ub) in lots:
            corn = self.quad_world(C, T, N, ua, ub, va, vb)
            ok, info = self._lot_valid(corn, cls, ub - ua, True, grade_max,
                                       True)
            if ok:
                valid.append((ua, ub))
            elif valid:
                pa, _ = valid[-1]
                valid[-1] = (pa, ub)  # merge into previous
                self.rejections.append({"block": b["id"], "row": ri,
                                        "span": [q6(ua), q6(ub)],
                                        "reason": "merged_into_neighbor"})
            else:
                valid.append((ua, ub))  # first: keep, merge forward later
                self.rejections.append({"block": b["id"], "row": ri,
                                        "span": [q6(ua), q6(ub)],
                                        "reason": "kept_pending_merge"})
        # forward-merge check for a leading invalid lot
        if len(valid) > 1:
            corn = self.quad_world(C, T, N, valid[0][0], valid[0][1],
                                   va, vb)
            ok, _ = self._lot_valid(corn, cls, valid[0][1] - valid[0][0],
                                    True, grade_max, True)
            if not ok:
                valid[1] = (valid[0][0], valid[1][1])
                self.rejections.append({"block": b["id"], "row": ri,
                                        "span": [q6(valid[0][0]),
                                                 q6(valid[0][1])],
                                        "reason": "merged_forward"})
                valid.pop(0)
        for (ua, ub) in valid:
            corn = self.quad_world(C, T, N, ua, ub, va, vb)
            ok, info = self._lot_valid(corn, cls, ub - ua, True, grade_max,
                                       True)
            if not ok:
                self.rejections.append({"block": b["id"], "row": ri,
                                        "span": [q6(ua), q6(ub)],
                                        "reason": "row_unviable_%s"
                                        % info})
                if info in ("area", "grade", "runway", "frontage",
                            "sliver", "access", "no_building_envelope"):
                    kind = ("runway_open" if info == "runway"
                            else "row_remainder")
                    self._emit_open(b, dcls, C, T, N, ua, ub, va, vb,
                                    kind)
                continue
            self._emit_lot(b, dcls, cls, corn, ub - ua, access, info,
                           len(valid))

    def _gap_to_road(self, b, corners):
        E = self.g["edges"][b["edge"]]
        pts = [(p["x"], p["z"]) for p in E["stations"]]
        wa, wb = b["stations"]
        seg = pts[wa:wb + 1]
        (ax, az), (bx, bz) = corners[0], corners[1]
        mx, mz = (ax + bx) / 2.0, (az + bz) / 2.0
        return polyline_dist(mx, mz, seg) - E["width_m"] / 2.0

    def _assign_role(self, b, dcls, area, road_class, coast, idx, n):
        if dcls == "WATERFRONT":
            if coast:
                return "TOURISM", "coast_touch"
            if road_class in ("primary", "secondary"):
                return "COMMERCIAL", "arterial_frontage"
            return "RESIDENTIAL", "quiet_frontage"
        if dcls == "CITY_CORE":
            if idx % 4 == 3:
                return "SERVICE", "service_spacing"
            return "COMMERCIAL", "core_default"
        if dcls == "MIXED_USE":
            if idx % 6 == 5:
                return "SERVICE", "service_spacing"
            if road_class in ("primary", "secondary"):
                return "COMMERCIAL", "arterial_frontage"
            return "RESIDENTIAL", "quiet_frontage"
        if dcls == "COMMERCIAL":
            return "COMMERCIAL", "district_default"
        if dcls in ("RURAL_VILLAGE", "FOREST_SETTLEMENT",
                    "HIGHLAND_SETTLEMENT") and area >= 1500 and idx == 0:
            return "SERVICE", "largest_serves_cluster"
        return "RESIDENTIAL", "district_default"

    def _emit_lot(self, b, dcls, cls, corn, front_len, access, bb, n):
        k = len([p for p in self.parcels if p["block"] == b["id"]])
        pid = "PAR-%s-%d" % (b["id"], k)
        cx = sum(p[0] for p in corn) / 4.0
        cz = sum(p[1] for p in corn) / 4.0
        E = self.g["edges"][b["edge"]]
        if bb["beach"]:
            role, why = "OPEN", "beach_preserved"
            kind = "beach_preserve"
        else:
            role, why = self._assign_role(b, dcls, shoelace(corn),
                                          E["class"], bb["coast"], k, n)
            kind = "lot"
        sb = self.dc["setback_profiles"][cls["setback_profile"]]
        gap = self._gap_to_road(b, corn)
        front_ok = gap <= 12.0
        for (fx, fz) in (corn[0], corn[1]):
            if self.hard_reserved(fx, fz) or not self.f.is_land(fx, fz):
                front_ok = False
        if access == "DIRECT" and not front_ok and role != "OPEN":
            self.rejections.append({"block": b["id"], "parcel": pid,
                                    "reason": "frontage_invalid"})
            return
        svc, park = SERVICE_PARKING[role]
        self.parcels.append({
            "id": pid, "block": b["id"], "district": b["district_id"],
            "settlement": self.set_of[b["district_id"]],
            "region": self.f.region_at(cx, cz),
            "polygon": [[q6(x), q6(z)] for (x, z) in corn],
            "area": q6(shoelace(corn)),
            "frontage": {"edge": b["edge"], "length": q6(front_len),
                         "gap_m": q6(gap), "valid": front_ok},
            "access_edge": b["edge"],
            "access": {"type": access if role != "OPEN" else "OPEN_FRONT",
                       "via": None},
            "buildability": {"verdict": "BUILDABLE",
                             "grade_max": q6(bb["grade_max"]),
                             "land_share": q6(bb["land_share"]),
                             "reservation_clear": True},
            "role": role, "role_reason": why, "kind": kind,
            "setbacks": {"front_m": sb["front_m"], "side_m": sb["side_m"],
                         "rear_m": sb["rear_m"]},
            "service_access": svc, "parking_policy": park,
            "seed": seed_for("p06-parcel", pid)})

    def _emit_lane(self, b, dcls, C, T, N, u0, u1, va, vb):
        corn = self.quad_world(C, T, N, u0, u1, va, vb)
        k = len([p for p in self.parcels if p["block"] == b["id"]])
        pid = "PAR-%s-%d" % (b["id"], k)
        cx = sum(p[0] for p in corn) / 4.0
        cz = sum(p[1] for p in corn) / 4.0
        sb = self.dc["setback_profiles"][
            self.dc["district_classes"][dcls]["setback_profile"]]
        self.parcels.append({
            "id": pid, "block": b["id"], "district": b["district_id"],
            "settlement": self.set_of[b["district_id"]],
            "region": self.f.region_at(cx, cz),
            "polygon": [[q6(x), q6(z)] for (x, z) in corn],
            "area": q6(shoelace(corn)),
            "frontage": {"edge": b["edge"],
                         "length": q6(abs(u1 - u0)), "gap_m": 0.0,
                         "valid": True},
            "access_edge": b["edge"],
            "access": {"type": "LANE", "via": None},
            "buildability": {"verdict": "OPEN_INFRA",
                             "grade_max": 0.0, "land_share": 1.0,
                             "reservation_clear": True},
            "role": "OPEN", "role_reason": "rear_access_lane",
            "kind": "access_lane",
            "setbacks": {"front_m": 0, "side_m": 0, "rear_m": 0},
            "service_access": "maintenance_access",
            "parking_policy": "none_or_trailhead",
            "seed": seed_for("p06-parcel", pid)})

    def _emit_open(self, b, dcls, C, T, N, u0, u1, va, vb, kind):
        corn = self.quad_world(C, T, N, u0, u1, va, vb)
        if any(self.hard_reserved(x, z) for (x, z) in corn):
            self.rejections.append({"block": b["id"], "kind": kind,
                                    "reason": "open_remainder_reserved"})
            return
        k = len([p for p in self.parcels if p["block"] == b["id"]])
        pid = "PAR-%s-%d" % (b["id"], k)
        cx = sum(p[0] for p in corn) / 4.0
        cz = sum(p[1] for p in corn) / 4.0
        self.parcels.append({
            "id": pid, "block": b["id"], "district": b["district_id"],
            "settlement": self.set_of[b["district_id"]],
            "region": self.f.region_at(cx, cz),
            "polygon": [[q6(x), q6(z)] for (x, z) in corn],
            "area": q6(shoelace(corn)),
            "frontage": {"edge": b["edge"],
                         "length": q6(abs(u1 - u0)), "gap_m": 0.0,
                         "valid": True},
            "access_edge": b["edge"],
            "access": {"type": "OPEN_FRONT", "via": None},
            "buildability": {"verdict": "OPEN_INFRA",
                             "grade_max": 0.0, "land_share": 1.0,
                             "reservation_clear": True},
            "role": "OPEN", "role_reason": kind, "kind": kind,
            "setbacks": {"front_m": 0, "side_m": 0, "rear_m": 0},
            "service_access": "maintenance_access",
            "parking_policy": "none_or_trailhead",
            "seed": seed_for("p06-parcel", pid)})

    # ---------- Gen-D campus ----------
    def _campus_block(self, b, dcls):
        zones = CAMPUS_ZONES[dcls]
        C, T, N, u0, u1, v0, v1 = self._frame_ranges(b)
        n0 = len(self.parcels)
        # split along the LONG axis
        if abs(u1 - u0) >= abs(v1 - v0):
            horizontal = True
            total = abs(u1 - u0)
        else:
            horizontal = False
            total = abs(v1 - v0)
        cls = self.dc["district_classes"][dcls]
        acc = 0.0
        for zi, (role, share, kind) in enumerate(zones):
            f0 = acc
            f1 = acc + share
            acc = f1
            if horizontal:
                corn = self.quad_world(C, T, N, u0 + (u1 - u0) * f0,
                                       u0 + (u1 - u0) * f1, v0, v1)
            else:
                corn = self.quad_world(C, T, N, u0, u1,
                                       v0 + (v1 - v0) * f0,
                                       v0 + (v1 - v0) * f1)
            area = shoelace(corn)
            if role != "OPEN" and (area < cls["parcel_area_min_m2"] or
                                   area > cls["parcel_area_max_m2"]):
                self.rejections.append({"block": b["id"], "zone": zi,
                                        "reason": "campus_zone_area"})
                continue
            gmax = CAMPUS_GRADE[dcls]
            bb = self.buildability(corn, gmax)
            if bb["land_share"] < 0.85 or bb["grade_max"] > gmax:
                self.rejections.append({"block": b["id"], "zone": zi,
                                        "reason": "campus_zone_terrain"})
                continue
            bad = any(self.hard_reserved(x, z) or
                      self.in_runway_zone(x, z)
                      for (x, z) in self.sample_quad(corn))
            if bad:
                self.rejections.append({"block": b["id"], "zone": zi,
                                        "reason": "campus_zone_reserved"})
                continue
            self._emit_campus(b, dcls, cls, corn, role, kind, zi)
        if len(self.parcels) == n0:
            # all zones failed: retain the whole block (46) or open ground
            corn = self.quad_world(C, T, N, u0, u1, v0, v1)
            role = zones[0][0]
            area = shoelace(corn)
            gmax = CAMPUS_GRADE[dcls]
            bb = self.buildability(corn, gmax)
            bad = any(self.hard_reserved(x, z) or
                      self.in_runway_zone(x, z)
                      for (x, z) in self.sample_quad(corn))
            if role != "OPEN" and cls["parcel_area_min_m2"] <= area <= \
                    cls["parcel_area_max_m2"] and bb["land_share"] >= 0.85 \
                    and bb["grade_max"] <= gmax and not bad:
                self._emit_campus(b, dcls, cls, corn, role, "whole", -1)
            elif not bad and bb["land_share"] >= 0.5:
                self._emit_open(b, dcls, C, T, N, u0, u1, v0, v1,
                                "campus_open")
            else:
                self.rejections.append({"block": b["id"],
                                        "reason": "campus_block_unviable"})

    def _emit_campus(self, b, dcls, cls, corn, role, kind, zi):
            area = shoelace(corn)
            bb = self.buildability(corn, 0.20)
            k = len([p for p in self.parcels if p["block"] == b["id"]])
            pid = "PAR-%s-%d" % (b["id"], k)
            cx = sum(p[0] for p in corn) / 4.0
            cz = sum(p[1] for p in corn) / 4.0
            sb = self.dc["setback_profiles"][cls["setback_profile"]]
            svc, park = SERVICE_PARKING[role]
            self.parcels.append({
                "id": pid, "block": b["id"], "district": b["district_id"],
                "settlement": self.set_of[b["district_id"]],
                "region": self.f.region_at(cx, cz),
                "polygon": [[q6(x), q6(z)] for (x, z) in corn],
                "area": q6(area),
                "frontage": {"edge": b["edge"], "length": 0.0,
                             "gap_m": 0.0, "valid": False},
                "access_edge": b["edge"],
                "access": {"type": "CAMPUS", "via": "campus_entry"},
                "buildability": {"verdict": "BUILDABLE",
                                 "grade_max": q6(bb["grade_max"]),
                                 "land_share": q6(bb["land_share"]),
                                 "reservation_clear": True},
                "role": role, "role_reason": "campus_zone_" + kind,
                "kind": "campus_" + kind,
                "campus": {"entry_side": "road", "service_side": "rear",
                           "zone": zi},
                "setbacks": {"front_m": sb["front_m"],
                             "side_m": sb["side_m"], "rear_m": sb["rear_m"]},
                "service_access": svc, "parking_policy": park,
                "seed": seed_for("p06-parcel", pid)})

    # ---------- Gen-D rural ----------
    def _nearest_road(self, x, z):
        best = None
        for eid, E in self.g["edges"].items():
            pts = [(p["x"], p["z"]) for p in E["stations"]]
            d = polyline_dist(x, z, pts)
            if best is None or d < best[0]:
                best = (d, eid)
        return best

    def _rural_districts(self):
        for s in self.dist["settlements"]:
            for d in self.dist["districts"]:
                if d["settlement"] != s["id"]:
                    continue
                if d["class"] not in RURAL_CLASSES:
                    continue
                self._farmstead(s, d)

    def _farmstead(self, s, d):
        cls = self.dc["district_classes"][d["class"]]
        bb = d["bounds"]["disc"]
        cx, cz, _ = bb
        rng = random.Random(d["seed"])
        placed = []
        house_corr = None
        for fi, (w, v, kind, role) in enumerate(
                ((60.0, 80.0, "farmhouse", "RESIDENTIAL"),
                 (70.0, 70.0, "barn", "SERVICE"))):
            found = None
            for trial in range(150):
                if fi == 1 and placed:
                    ang = rng.random() * 2 * math.pi
                    rad = 75.0 + rng.random() * 55.0
                    x = placed[0][0] + math.cos(ang) * rad
                    z = placed[0][1] + math.sin(ang) * rad
                else:
                    ang = rng.random() * 2 * math.pi
                    rad = 20.0 + trial * 2.0
                    x = cx + math.cos(ang) * rad
                    z = cz + math.sin(ang) * rad
                corn = [(x - w / 2, z - v / 2), (x + w / 2, z - v / 2),
                        (x + w / 2, z + v / 2), (x - w / 2, z + v / 2)]
                ok, bbinfo = self._lot_valid(
                    corn, cls, w, False, 0.12, True)
                if not ok:
                    continue
                if any(math.hypot(x - px, z - pz) < 60.0
                       for (px, pz) in placed):
                    continue
                if fi == 1 and placed and house_corr is not None and \
                        math.hypot(x - placed[0][0],
                                   z - placed[0][1]) <= 130.0:
                    corr = (house_corr[0], house_corr[1] +
                            math.hypot(x - placed[0][0],
                                       z - placed[0][1]))
                    shared = True
                else:
                    corr = self._driveway(x, z)
                    shared = False
                if corr is None:
                    continue
                found = (x, z, corn, bbinfo, corr, shared)
                break
            if found is None:
                self.rejections.append({"district": d["id"], "kind": kind,
                                        "reason": "no_rural_site"})
                continue
            x, z, corn, bbinfo, corr, shared = found
            placed.append((x, z))
            if fi == 0:
                house_corr = corr
            via = ("shared_farm_driveway" if shared
                   else "driveway_%.0fm" % corr[1])
            pid = "PAR-%s-%d" % (d["id"], fi)
            sb = self.dc["setback_profiles"][cls["setback_profile"]]
            svc, park = SERVICE_PARKING[role]
            self.parcels.append({
                "id": pid, "block": None, "district": d["id"],
                "settlement": d["settlement"],
                "region": self.f.region_at(x, z),
                "polygon": [[q6(px), q6(pz)] for (px, pz) in corn],
                "area": q6(shoelace(corn)),
                "frontage": {"edge": corr[0], "length": 6.0,
                             "gap_m": q6(corr[1]), "valid": True},
                "access_edge": corr[0],
                "access": {"type": "DRIVEWAY", "via": via},
                "buildability": {"verdict": "BUILDABLE",
                                 "grade_max": q6(bbinfo["grade_max"]),
                                 "land_share": q6(bbinfo["land_share"]),
                                 "reservation_clear": True},
                "role": role, "role_reason": "farmstead_" + kind,
                "kind": kind,
                "setbacks": {"front_m": sb["front_m"],
                             "side_m": sb["side_m"],
                             "rear_m": sb["rear_m"]},
                "service_access": svc, "parking_policy": park,
                "seed": seed_for("p06-parcel", pid)})

    def _driveway(self, x, z):
        dist, eid = self._nearest_road(x, z)
        if dist > 400.0:
            return None
        E = self.g["edges"][eid]
        pts = [(p["x"], p["z"]) for p in E["stations"]]
        # nearest centerline point
        best, bd = None, 1e18
        for i in range(len(pts) - 1):
            ax, az = pts[i]
            bx, bz = pts[i + 1]
            abx, abz = bx - ax, bz - az
            L2 = abx * abx + abz * abz
            t = ((x - ax) * abx + (z - az) * abz) / L2 if L2 > 0 else 0
            t = max(0.0, min(1.0, t))
            px, pz = ax + abx * t, az + abz * t
            dd = math.hypot(x - px, z - pz)
            if dd < bd:
                best, bd = (px, pz), dd
        # corridor must be land + unreserved except near the mouth
        n = max(2, int(bd / 5.0))
        for i in range(n + 1):
            s = i / n
            px = x + (best[0] - x) * s
            pz = z + (best[1] - z) * s
            if not self.f.is_land(px, pz):
                return None
            if s < 0.85 and self.hard_reserved(px, pz):
                return None
            if self.in_runway_zone(px, pz):
                return None
        return eid, bd


    # ---------- Gen-D direct placement (under-served districts) ----------
    DIRECT_PLAN = {
        # class: (count, w, d, grade_max, separation, [(role, kind)])
        "PORT": (3, 70.0, 90.0, 0.15, 100.0,
                 [("LOGISTICS", "yard"), ("LOGISTICS", "yard"),
                  ("SPECIAL", "support")]),
        "INDUSTRIAL": (3, 90.0, 110.0, 0.20, 120.0,
                       [("INDUSTRIAL", "plant"), ("INDUSTRIAL", "plant"),
                        ("LOGISTICS", "loading")]),
        "RESTRICTED": (2, 80.0, 100.0, 0.30, 100.0,
                       [("RESTRICTED", "compound"),
                        ("SERVICE", "support")]),
        "AIRFIELD": (2, 70.0, 90.0, 0.12, 100.0,
                     [("SERVICE", "hangar"), ("SPECIAL", "ops")]),
        "CIVIC": (1, 70.0, 90.0, 0.20, 80.0, [("CIVIC", "hall")]),
        "RESORT": (2, 60.0, 80.0, 0.25, 80.0,
                   [("TOURISM", "guest"), ("TOURISM", "guest")]),
        "UTILITY": (1, 60.0, 80.0, 0.25, 80.0, [("UTILITY", "plant")]),
        "HIGHLAND_SETTLEMENT": (3, 35.0, 50.0, 0.30, 50.0,
                                [("RESIDENTIAL", "cabin"),
                                 ("RESIDENTIAL", "cabin"),
                                 ("SERVICE", "lodge")]),
        "FOREST_SETTLEMENT": (3, 40.0, 60.0, 0.30, 60.0,
                              [("RESIDENTIAL", "cabin"),
                               ("RESIDENTIAL", "cabin"),
                               ("SERVICE", "depot")]),
    }

    def _member(self, x, z):
        best, bestp = None, -1
        for d in self.dist["districts"]:
            b = d["bounds"]
            inside = False
            if "disc" in b:
                cx, cz, r = b["disc"]
                inside = (x - cx) ** 2 + (z - cz) ** 2 <= r * r
            else:
                cx, cz, r0, r1, a0, a1 = b["sector"]
                d2 = (x - cx) ** 2 + (z - cz) ** 2
                if r0 * r0 <= d2 <= r1 * r1:
                    if a1 - a0 >= 2 * math.pi - 1e-6:
                        inside = True
                    else:
                        a = math.atan2(z - cz, x - cx)
                        if a < 0:
                            a += 2 * math.pi
                        b0 = a0 % (2 * math.pi)
                        b1 = a1 % (2 * math.pi)
                        if b1 <= b0:
                            inside = a >= b0 or a <= b1
                        else:
                            inside = b0 <= a <= b1
            if inside:
                p = self.dc["district_priority"][d["class"]]
                if p > bestp:
                    best, bestp = d["id"], p
        return best

    def _direct_districts(self):
        built = {}
        for p in self.parcels:
            if p["role"] != "OPEN":
                built[p["district"]] = built.get(p["district"], 0) + 1
        for d in self.dist["districts"]:
            plan = self.DIRECT_PLAN.get(d["class"])
            if plan is None:
                continue
            if built.get(d["id"], 0) >= 2:
                continue
            self._direct_place(d, plan)

    def _direct_place(self, d, plan):
        count, w, v, gmax, sep, roles = plan
        cls = self.dc["district_classes"][d["class"]]
        rng = random.Random(d["seed"] + 4242)
        b = d["bounds"]
        placed = []
        first_corr = None
        for i in range(count):
            role, kind = roles[i]
            found = None
            cluster = (d["class"] in ("HIGHLAND_SETTLEMENT",
                                      "FOREST_SETTLEMENT") and i > 0
                       and placed)
            for trial in range(300):
                if cluster:
                    ang = rng.random() * 2 * math.pi
                    rad = 55.0 + rng.random() * 45.0
                    x = placed[0][0] + math.cos(ang) * rad
                    z = placed[0][1] + math.sin(ang) * rad
                elif "disc" in b:
                    cx, cz, r = b["disc"]
                    ang = rng.random() * 2 * math.pi
                    rad = (0.15 + 0.75 * rng.random()) * r
                    x = cx + math.cos(ang) * rad
                    z = cz + math.sin(ang) * rad
                else:
                    cx, cz, r0, r1, a0, a1 = b["sector"]
                    a = a0 + rng.random() * (a1 - a0)
                    rad = r0 + 10.0 + rng.random() * (r1 - r0 - 20.0)
                    x = cx + math.cos(a) * rad
                    z = cz + math.sin(a) * rad
                if self._member(x, z) != d["id"]:
                    continue
                corn = [(x - w / 2, z - v / 2), (x + w / 2, z - v / 2),
                        (x + w / 2, z + v / 2), (x - w / 2, z + v / 2)]
                ok, bbinfo = self._lot_valid(corn, cls, w, False, gmax,
                                             True)
                if not ok:
                    continue
                if any(math.hypot(x - px, z - pz) < sep
                       for (px, pz) in placed):
                    continue
                if cluster and first_corr is not None and \
                        math.hypot(x - placed[0][0],
                                   z - placed[0][1]) <= 100.0:
                    corr = (first_corr[0], first_corr[1] +
                            math.hypot(x - placed[0][0],
                                       z - placed[0][1]))
                    shared = True
                else:
                    corr = self._driveway(x, z)
                    shared = False
                if corr is None:
                    continue
                found = (x, z, corn, bbinfo, corr, shared)
                break
            if found is None:
                self.rejections.append({"district": d["id"], "kind": kind,
                                        "reason": "no_direct_site"})
                continue
            x, z, corn, bbinfo, corr, shared = found
            placed.append((x, z))
            if i == 0:
                first_corr = corr
            via = ("shared_cluster_driveway" if shared
                   else "driveway_%.0fm" % corr[1])
            pid = "PAR-%s-D%d" % (d["id"], i)
            sb = self.dc["setback_profiles"][cls["setback_profile"]]
            svc, park = SERVICE_PARKING[role]
            self.parcels.append({
                "id": pid, "block": None, "district": d["id"],
                "settlement": d["settlement"],
                "region": self.f.region_at(x, z),
                "polygon": [[q6(px), q6(pz)] for (px, pz) in corn],
                "area": q6(shoelace(corn)),
                "frontage": {"edge": corr[0], "length": 8.0,
                             "gap_m": q6(corr[1]), "valid": True},
                "access_edge": corr[0],
                "access": {"type": "DRIVEWAY", "via": via},
                "buildability": {"verdict": "BUILDABLE",
                                 "grade_max": q6(bbinfo["grade_max"]),
                                 "land_share": q6(bbinfo["land_share"]),
                                 "reservation_clear": True},
                "role": role, "role_reason": "direct_" + kind,
                "kind": "direct_" + kind,
                "setbacks": {"front_m": sb["front_m"],
                             "side_m": sb["side_m"],
                             "rear_m": sb["rear_m"]},
                "service_access": svc, "parking_policy": park,
                "seed": seed_for("p06-parcel", pid)})

    # ---------- Gen-D beach access ----------
    def _beach_access(self):
        for d in self.dist["districts"]:
            if not d.get("coastal"):
                continue
            if any(p["district"] == d["id"] and
                   p["kind"] == "beach_access"
                   for p in self.parcels):
                continue
            b = d["bounds"]
            rng = random.Random(d["seed"] + 9753)
            placed = []
            for bi in range(2):
                found = None
                for trial in range(200):
                    if "disc" in b:
                        cx, cz, r = b["disc"]
                        ang = rng.random() * 2 * math.pi
                        rad = rng.random() * r
                        x = cx + math.cos(ang) * rad
                        z = cz + math.sin(ang) * rad
                    else:
                        continue
                    if not self.f.is_land(x, z):
                        continue
                    if self.f.region_at(x, z) != "coastal_beach":
                        continue
                    if self._member(x, z) != d["id"]:
                        continue
                    if any(math.hypot(x - px, z - pz) < 60.0
                           for (px, pz) in placed):
                        continue
                    corn = [(x - 15, z - 15), (x + 15, z - 15),
                            (x + 15, z + 15), (x - 15, z + 15)]
                    if any(self.hard_reserved(px, pz) or
                           self.in_runway_zone(px, pz)
                           for (px, pz) in
                           self.sample_quad(corn)):
                        continue
                    dist, eid = self._nearest_road(x, z)
                    found = (x, z, corn, eid, dist)
                    break
                if found is None:
                    self.rejections.append(
                        {"district": d["id"],
                         "reason": "no_beach_site"})
                    continue
                x, z, corn, eid, dist = found
                placed.append((x, z))
                pid = "PAR-%s-B%d" % (d["id"], bi)
                self.parcels.append({
                    "id": pid, "block": None, "district": d["id"],
                    "settlement": d["settlement"],
                    "region": "coastal_beach",
                    "polygon": [[q6(px), q6(pz)] for (px, pz) in corn],
                    "area": 900.0,
                    "frontage": {"edge": eid, "length": 6.0,
                                 "gap_m": q6(dist), "valid": True},
                    "access_edge": eid,
                    "access": {"type": "BEACH_PATH",
                               "via": "footpath_%.0fm" % dist},
                    "buildability": {"verdict": "OPEN_INFRA",
                                     "grade_max": 0.0,
                                     "land_share": 1.0,
                                     "reservation_clear": True},
                    "role": "OPEN", "role_reason": "public_beach_access",
                    "kind": "beach_access",
                    "setbacks": {"front_m": 0, "side_m": 0, "rear_m": 0},
                    "service_access": "maintenance_access",
                    "parking_policy": "none_or_trailhead",
                    "seed": seed_for("p06-parcel", pid)})

    # ---------- export ----------
    def phase_export(self):
        self._t("export")
        outdir = os.environ.get("P06_OUT_DIR",
                                P06D)
        doc = {"meta": {"parcel_version": self.dc["parcel_version"],
                        "district_version": self.dc["district_version"],
                        "generator": "parcels.py"},
               "parcels": self.parcels, "skips": self.skips,
               "rejections": self.rejections, "checksum": ""}
        doc["checksum"] = self.checksum_scope(self.parcels)
        json.dump(doc, open(os.path.join(outdir, "parcels.json"), "w"))
        self._t(None)


def main():
    reg = Registry()
    reg.phase_preflight()
    reg.phase_parcels()
    reg.phase_export()
    print("gen-d ok: %d parcels (%d skips, %d rejections)" % (
        len(reg.parcels), len(reg.skips), len(reg.rejections)))
    print("timers: %s" % " ".join("%s=%.2f" % kv for kv in
                                  sorted(reg.timers.items())))


if __name__ == "__main__":
    main()
