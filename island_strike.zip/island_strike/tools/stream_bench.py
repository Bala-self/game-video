#!/usr/bin/env python3
"""P07 sector-size comparison + cache-policy benchmark.

Runs IDENTICAL scenarios on identical world state for each candidate
sector size (128/256/512). Every benchmark records its full test context
(engine/python versions, OS/CPU/RAM, commit, checksums, sample counts).
No performance number is published without context.

Usage:
  python3 tools/stream_bench.py --manifests 128:/tmp/man128.json,... --out reports/p07_size_compare.json
  python3 tools/stream_bench.py --cache-policies --manifest /tmp/man256.json --out reports/p07_cache_compare.json
"""
import json
import os
import platform
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from streaming_sim import (StreamingManager, DEFAULT_CONFIG, node_path,  # noqa: E402
                           run_traversal)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOD = os.path.join(ROOT, "data/derived/lod_policy.json")


def context():
    commit = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                            capture_output=True, text=True).stdout.strip()
    cpu = "unknown"
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    ram = "unknown"
    try:
        with open("/proc/meminfo") as f:
            ram = f.readline().strip()
    except OSError:
        pass
    godot = "absent"
    gb = os.path.join(ROOT, "tools/.godot/godot")
    if os.path.exists(gb):
        godot = subprocess.run([gb, "--version"], capture_output=True,
                               text=True).stdout.strip()
    return {"python": sys.version.split()[0], "os": platform.platform(),
            "cpu": cpu, "ram": ram, "godot": godot, "commit": commit,
            "renderer": "headless/none", "mode": "cpu-sim",
            "suite_version": "p07bench1"}


def summarize(snap):
    c = snap["counters"]
    hits, miss = snap["cache"]["hits"], snap["cache"]["misses"]
    return {
        "active_peak": snap["active_peak"], "objects_end": snap["objects"],
        "mem_peak": snap["mem_peak"], "mem_end": snap["memory"]["total"],
        "cache_end": snap["memory"]["cache"],
        "cache_hit_ratio": (hits / (hits + miss)) if (hits + miss) else 0.0,
        "requests": c["requests"], "duplicates": c["duplicates"],
        "cancelled": c["cancelled"], "stale": c["stale"], "churn": c["churn"],
        "prefetch": [c["prefetch_req"], c["prefetch_used"], c["prefetch_wasted"]],
        "load_fail": c["load_fail"], "activate_fail": c["activate_fail"],
        "spikes": c["spikes"],
        "load_ms": snap["prof"]["load"], "activate_ms": snap["prof"]["activate"],
        "frame_ms": snap["frame"], "ticks": snap["tick"],
    }


def scenario_city_settle(mpath, cfg):
    sim = StreamingManager(mpath, LOD, dict(cfg))
    sim.set_context(1400, 150)
    for _ in range(600):
        sim.tick()
    return sim.snapshot()


def scenario_crossing(mpath, cfg):
    sim = StreamingManager(mpath, LOD, dict(cfg))
    wps = node_path("ridge_end", "jn_ring_N", "hub_city", "jn_ring_S",
                    "jn_sub", "jn_resort", "resort_waterfront")
    run_traversal(sim, wps, 14.0, settle_ticks=60)
    return sim.snapshot()


def scenario_coast(mpath, cfg):
    sim = StreamingManager(mpath, LOD, dict(cfg))
    wps = node_path("waterfront_access", "port_gate", "jn_port_mid",
                    "jn_resort", "resort_waterfront")
    run_traversal(sim, wps, 14.0, settle_ticks=60)
    return sim.snapshot()


SCENARIOS = {"city_settle": scenario_city_settle, "crossing": scenario_crossing,
             "coast": scenario_coast}


def run_compare(manifests, out, repeats=2):
    cfg = dict(DEFAULT_CONFIG)
    res = {"context": context(), "config": cfg, "repeats": repeats, "runs": {},
           "matrix": []}
    for size, mpath in sorted(manifests.items()):
        for name, fn in SCENARIOS.items():
            reps = []
            for r in range(repeats):
                t0 = time.perf_counter()
                snap = fn(mpath, cfg)
                wall = time.perf_counter() - t0
                s = summarize(snap)
                s["wall_s"] = round(wall, 1)
                reps.append(s)
                print("size=%s scenario=%s rep=%d ticks=%d wall=%.0fs "
                      "mem_peak=%.1fMB active_peak=%d frame_max=%.0fms" %
                      (size, name, r, s["ticks"], wall, s["mem_peak"] / 1e6,
                       s["active_peak"], s["frame_ms"].get("max", 0) * 1000),
                      flush=True)
            res["runs"]["%s/%s" % (size, name)] = reps
    # comparison matrix rows
    for size in sorted(manifests):
        row = {"size": size}
        for name in SCENARIOS:
            reps = res["runs"]["%s/%s" % (size, name)]
            row[name] = {
                "mem_peak_MB": round(max(r["mem_peak"] for r in reps) / 1e6, 2),
                "active_peak": max(r["active_peak"] for r in reps),
                "frame_max_ms": round(max(r["frame_ms"].get("max", 0) for r in reps) * 1000, 1),
                "load_p95_ms": round(max(r["load_ms"].get("p95", 0) for r in reps) * 1000, 2),
                "churn": max(r["churn"] for r in reps),
                "requests": max(r["requests"] for r in reps),
                "cache_hit": round(sum(r["cache_hit_ratio"] for r in reps) / len(reps), 3),
                "spikes": max(r["spikes"] for r in reps),
            }
        res["matrix"].append(row)
    with open(out, "w") as f:
        json.dump(res, f, indent=1)
    print("wrote", out)


def scenario_ew_return(mpath, cfg):
    # revisit path: cache policies only differentiate when sectors recur
    sim = StreamingManager(mpath, LOD, dict(cfg))
    wps = node_path("hub_city", "jn_ring_W", "jn_forest", "forest_depot")
    run_traversal(sim, wps + wps[::-1][1:] + wps[1:], 14.0, settle_ticks=60)
    return sim.snapshot()


def run_cache_compare(mpath, out, cache_max=16):
    # small cache forces eviction pressure so policies differentiate
    res = {"context": context(), "scenario": "ew_return_revisit",
           "cache_entries_max": cache_max, "policies": {}}
    for pol in ("LRU", "DISTANCE", "PRIORITY"):
        cfg = dict(DEFAULT_CONFIG)
        cfg["cache_policy"] = pol
        cfg["cache_entries_max"] = cache_max
        t0 = time.perf_counter()
        snap = scenario_ew_return(mpath, cfg)
        wall = time.perf_counter() - t0
        s = summarize(snap)
        s["wall_s"] = round(wall, 1)
        res["policies"][pol] = s
        print("policy=%s hit=%.3f evict=%d mem_peak=%.1fMB wall=%.0fs" %
              (pol, s["cache_hit_ratio"], snap["cache"]["evictions"],
               s["mem_peak"] / 1e6, wall), flush=True)
    with open(out, "w") as f:
        json.dump(res, f, indent=1)
    print("wrote", out)


def main(argv):
    if "--cache-policies" in argv:
        mpath = argv[argv.index("--manifest") + 1]
        out = argv[argv.index("--out") + 1]
        return run_cache_compare(mpath, out) or 0
    man = {}
    for pair in argv[argv.index("--manifests") + 1].split(","):
        size, path = pair.split(":", 1)
        man[int(size)] = path
    out = argv[argv.index("--out") + 1]
    reps = int(argv[argv.index("--repeats") + 1]) if "--repeats" in argv else 2
    run_compare(man, out, reps)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
