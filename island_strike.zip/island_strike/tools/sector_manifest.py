#!/usr/bin/env python3
"""P07 sector manifest generator (size-parameterized).

Builds data/derived/world_stream_manifest.json: a DERIVED index (references
only, never a new source of truth) mapping every sector of a candidate grid
to the world content it touches.

Assignment rules (deterministic, canonical ordering everywhere):
  districts  - every sector overlapped by disc/annular-sector bounds (zones,
               not owned: listed in ALL overlapped sectors)
  blocks     - overlapped sectors; primary = frame-center sector
  parcels    - overlapped sectors; primary = centroid sector
  buildings  - overlapped sectors; primary = footprint-centroid sector
  landmarks  - point sector (single)
  open_space - overlapped sectors; primary = bounds-centroid sector
  roads      - road_ids touch; streamable unit is the per-(edge,sector)
               fragment FRAG-<edge>-<sector> with station index ranges;
               edge primary = sector holding most stations (id tiebreak)
  structures - bridge/tunnel/retaining/barrier/part records mapped via
               absolute verts or edge-station interpolation; cross-sector
               structures share one STRUCT:<id> dependency unit
  reserves   - junction/disc/tri/bbox/pos/edge-range records mapped by shape
  coast      - CF-<sector> iff any region sample hits the coast band
  regions    - dominant/secondary from a KxK region_at sample grid

Usage: python3 tools/sector_manifest.py --size 128|256|512 --out PATH
"""
import bisect
import hashlib
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sector_math import SectorGrid, sector_id, fnv1a32_hex, semantic_lines  # noqa: E402
from terrain_model import Field, load_all  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DD = os.path.join(ROOT, "data/derived")
GENERATION_VERSION = "p07m1"
POLICY_VERSION = "p07pol1"


def load(fn):
    with open(os.path.join(DD, fn)) as f:
        return json.load(f)


def canon(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"))


def sha16(text):
    return hashlib.sha256(text.encode()).hexdigest()[:16]


# ---------------------------------------------------------------- stations
class StationIndex:
    """Edge-station interpolation from P04 road_geometry (authoritative)."""

    def __init__(self, road_geometry):
        self.edges = {}
        for eid, e in road_geometry["edges"].items():
            st = sorted(e["stations"], key=lambda s: s["d"])
            self.edges[eid] = {
                "d": [s["d"] for s in st],
                "x": [s["x"] for s in st],
                "z": [s["z"] for s in st],
                "tx": [s.get("tx", 1.0) for s in st],
                "tz": [s.get("tz", 0.0) for s in st],
            }

    def pos_at(self, eid, d, offset=0.0):
        e = self.edges[eid]
        ds = e["d"]
        i = bisect.bisect_left(ds, d)
        if i <= 0:
            i = 1
        if i >= len(ds):
            i = len(ds) - 1
        d0, d1 = ds[i - 1], ds[i]
        t = 0.0 if d1 == d0 else min(1.0, max(0.0, (d - d0) / (d1 - d0)))
        x = e["x"][i - 1] + (e["x"][i] - e["x"][i - 1]) * t
        z = e["z"][i - 1] + (e["z"][i] - e["z"][i - 1]) * t
        if offset:
            tx = e["tx"][i - 1] + (e["tx"][i] - e["tx"][i - 1]) * t
            tz = e["tz"][i - 1] + (e["tz"][i] - e["tz"][i - 1]) * t
            n = math.hypot(tx, tz) or 1.0
            x += -tz / n * offset
            z += tx / n * offset
        return (x, z)

    def range_points(self, eid, d0, d1, offset=0.0, step=10.0):
        pts = [self.pos_at(eid, d0, offset), self.pos_at(eid, d1, offset)]
        d = d0 + step
        while d < d1:
            pts.append(self.pos_at(eid, d, offset))
            d += step
        for s in self.edges[eid]["d"]:
            if d0 <= s <= d1:
                pts.append(self.pos_at(eid, s, offset))
        return pts


# ------------------------------------------------------------ district test
def bounds_contains(b, x, z):
    if "disc" in b:
        cx, cz, r = b["disc"]
        return (x - cx) ** 2 + (z - cz) ** 2 <= r * r
    cx, cz, r0, r1, a0, a1 = b["sector"]
    d2 = (x - cx) ** 2 + (z - cz) ** 2
    if not (r0 * r0 <= d2 <= r1 * r1):
        return False
    if a1 - a0 >= 2 * math.pi - 1e-6:
        return True
    a = math.atan2(z - cz, x - cx)
    if a < 0:
        a += 2 * math.pi
    b0, b1 = a0 % (2 * math.pi), a1 % (2 * math.pi)
    if b1 <= b0:
        return a >= b0 or a <= b1
    return b0 <= a <= b1


def district_sectors(grid, b):
    if "disc" in b:
        x, z, r = b["disc"]
        return grid.sectors_for_disc(x, z, r)
    cx, cz, r0, r1, a0, a1 = b["sector"]
    full = (a1 - a0) >= 2 * math.pi - 1e-6
    cand = grid.sectors_for_aabb(cx - r1, cz - r1, cx + r1, cz + r1)
    out = []
    for sx, sz in cand:
        mnx, mnz = grid.bounds_min(sx, sz)
        # 5x5 probe: sector kept if any probe inside annular sector
        hit = False
        for ix in range(5):
            for iz in range(5):
                px = mnx + grid.size * (ix + 0.5) / 5.0
                pz = mnz + grid.size * (iz + 0.5) / 5.0
                if bounds_contains(b, px, pz):
                    hit = True
                    break
            if hit:
                break
        if hit:
            out.append((sx, sz))
    return sorted(out)


# ------------------------------------------------------------------ build
SOURCE_FILES = ("roads.json", "road_geometry.json", "transport_structures.json",
                "transport_reservations.json", "districts.json", "blocks.json",
                "parcels.json", "buildings.json", "places.json",
                "urban_mesh.json")


def build_manifest(size_m, sample_k=4):
    grid = SectorGrid(size_m)
    src = {fn: load(fn) for fn in SOURCE_FILES}
    checks = {fn: src[fn]["checksum"] if isinstance(src[fn].get("checksum"), str)
              else src[fn]["checksum"].get("geometry", "?") for fn in SOURCE_FILES}
    # road_geometry checksum is a dict; keep full form
    checks["road_geometry.json"] = src["road_geometry.json"]["checksum"]
    st = StationIndex(src["road_geometry.json"])

    S = {}
    for sx in range(grid.count):
        for sz in range(grid.count):
            sid = sector_id(sx, sz)
            mnx, mnz = grid.bounds_min(sx, sz)
            S[sid] = {
                "sector_id": sid, "bounds": [mnx, mnz, mnx + grid.size, mnz + grid.size],
                "world_state": grid.vs_world(sx, sz),
                "region_ids": [], "district_ids": [],
                "block_ids": [], "block_primary": [],
                "parcel_ids": [], "parcel_primary": [],
                "building_ids": [], "building_primary": [],
                "landmark_ids": [], "open_space_ids": [], "open_primary": [],
                "road_ids": [], "road_fragment_ids": [], "road_primary": [],
                "structure_ids": [], "reservation_ids": [],
                "coast_fragments": [], "terrain_dependencies": ["T-" + sid],
                "lod_groups": {}, "priority": 0.0, "content_counts": {},
            }

    def add(sid, key, val):
        S[sid][key].append(val)

    # -- districts (zones: all overlapped sectors) -------------------------
    for d in src["districts.json"]["districts"]:
        for sx, sz in district_sectors(grid, d["bounds"]):
            add(sector_id(sx, sz), "district_ids", d["id"])

    # -- blocks ------------------------------------------------------------
    for b in src["blocks.json"]["blocks"]:
        secs = grid.sectors_for_poly(b["corners"])
        cx, cz = b["frame"]["center"]
        prim = grid.sector_of(cx, cz)
        if prim not in secs:
            prim = secs[0]
        for sx, sz in secs:
            sid = sector_id(sx, sz)
            add(sid, "block_ids", b["id"])
            if (sx, sz) == prim:
                add(sid, "block_primary", b["id"])

    # -- parcels -----------------------------------------------------------
    for p in src["parcels.json"]["parcels"]:
        secs = grid.sectors_for_poly(p["polygon"])
        cx = sum(q[0] for q in p["polygon"]) / len(p["polygon"])
        cz = sum(q[1] for q in p["polygon"]) / len(p["polygon"])
        prim = grid.sector_of(cx, cz)
        if prim not in secs:
            prim = secs[0]
        for sx, sz in secs:
            sid = sector_id(sx, sz)
            add(sid, "parcel_ids", p["id"])
            if (sx, sz) == prim:
                add(sid, "parcel_primary", p["id"])

    # -- buildings ---------------------------------------------------------
    for b in src["buildings.json"]["buildings"]:
        fp = b["footprint"]
        secs = grid.sectors_for_poly(fp)
        cx = sum(q[0] for q in fp) / len(fp)
        cz = sum(q[1] for q in fp) / len(fp)
        prim = grid.sector_of(cx, cz)
        if prim not in secs:
            prim = secs[0]
        for sx, sz in secs:
            sid = sector_id(sx, sz)
            add(sid, "building_ids", b["id"])
            if (sx, sz) == prim:
                add(sid, "building_primary", b["id"])

    # -- landmarks / open --------------------------------------------------
    for m in src["places.json"]["landmarks"]:
        sx, sz = grid.sector_of(m["at"][0], m["at"][1])
        if grid.in_grid(sx, sz):
            add(sector_id(sx, sz), "landmark_ids", m["id"])
    for o in src["places.json"]["open_spaces"]:
        secs = grid.sectors_for_poly(o["bounds"])
        cx = sum(q[0] for q in o["bounds"]) / len(o["bounds"])
        cz = sum(q[1] for q in o["bounds"]) / len(o["bounds"])
        prim = grid.sector_of(cx, cz)
        if prim not in secs:
            prim = secs[0]
        for sx, sz in secs:
            sid = sector_id(sx, sz)
            add(sid, "open_space_ids", o["id"])
            if (sx, sz) == prim:
                add(sid, "open_primary", o["id"])

    # -- roads: per-(edge,sector) fragments --------------------------------
    for eid, e in src["road_geometry.json"]["edges"].items():
        per = {}
        for i, s in enumerate(e["stations"]):
            k = grid.sector_of(s["x"], s["z"])
            if grid.in_grid(*k):
                per.setdefault(k, []).append(i)
        if not per:
            continue
        prim = sorted(per, key=lambda k: (-len(per[k]), sector_id(*k)))[0]
        for k, idxs in per.items():
            sid = sector_id(*k)
            fid = "FRAG-%s-%s" % (eid, sid)
            add(sid, "road_ids", eid)
            add(sid, "road_fragment_ids", fid)
            if k == prim:
                add(sid, "road_primary", eid)

    # -- structures --------------------------------------------------------
    parts = src["transport_structures.json"]
    struct_units = {}  # STRUCT unit id -> set of sector ids
    struct_edges = {}  # STRUCT unit -> dependency edge list

    def reg_struct(unit, sectors):
        for sx, sz in sectors:
            sid = sector_id(sx, sz)
            add(sid, "structure_ids", unit)
            struct_units.setdefault(unit, set()).add(sid)

    for bid, b in (parts.get("bridges") or {}).items():
        eid = b["edge"]
        d0, d1 = b["station_range"]
        pts = st.range_points(eid, d0, d1)
        secs = set()
        for x, z in pts:
            k = grid.sector_of(x, z)
            if grid.in_grid(*k):
                secs.add(k)
        reg_struct("STRUCT-%s" % b.get("bridge", bid), sorted(secs))
    tun = parts.get("tunnel") or {}
    if tun and tun.get("edge"):
        eid = tun["edge"]
        br = tun.get("bore_range") or [0, 1]
        pts = st.range_points(eid, br[0], br[1])
        secs = set()
        for x, z in pts:
            k = grid.sector_of(x, z)
            if grid.in_grid(*k):
                secs.add(k)
        for pname, pnode in (tun.get("portal_nodes") or {}).items():
            nd = src["roads.json"]["nodes"].get(pnode)
            if nd:
                k = grid.sector_of(nd["x"], nd["z"])
                if grid.in_grid(*k):
                    secs.add(k)
        reg_struct("STRUCT-%s" % tun.get("id", "TN"), sorted(secs))
    for wid, w in (parts.get("retaining") or {}).items():
        recs = w if isinstance(w, list) else [w]
        for r in recs:
            ref = r.get("structure_ref") or r.get("id") or wid
            srcinfo = r.get("source") or {}
            secs = set()
            if "edge" in srcinfo and srcinfo["edge"] in st.edges:
                d = r.get("d", (st.edges[srcinfo["edge"]]["d"][-1]) / 2.0)
                x, z = st.pos_at(srcinfo["edge"], d, r.get("offset", 0.0))
                k = grid.sector_of(x, z)
                if grid.in_grid(*k):
                    secs.add(k)
            elif "node" in srcinfo:
                nd = src["roads.json"]["nodes"].get(srcinfo["node"])
                if nd:
                    k = grid.sector_of(nd["x"], nd["z"])
                    if grid.in_grid(*k):
                        secs.add(k)
            if secs:
                reg_struct("STRUCT-%s" % ref, sorted(secs))
    for gid, gl in (parts.get("barriers") or {}).items():
        recs = gl if isinstance(gl, list) else [gl]
        for r in recs:
            eid = r.get("edge")
            if eid not in st.edges:
                continue
            pts = st.range_points(eid, r.get("d0", 0), r.get("d1", 1), r.get("offset", 0.0))
            secs = set()
            for x, z in pts:
                k = grid.sector_of(x, z)
                if grid.in_grid(*k):
                    secs.add(k)
            reg_struct("STRUCT-%s" % r.get("id", gid), sorted(secs))
    for p in parts.get("parts") or []:
        vs = p.get("verts") or []
        if not vs:
            continue
        xs = [v[0] for v in vs]
        zs = [v[2] for v in vs]
        secs = grid.sectors_for_aabb(min(xs), min(zs), max(xs), max(zs))
        reg_struct("STRUCT-%s" % p.get("id", "part"), secs)

    # -- reservations ------------------------------------------------------
    res = src["transport_reservations.json"]["layers"]
    for layer, recs in res.items():
        if not isinstance(recs, list):
            continue
        for r in recs:
            rid = r.get("id", layer)
            secs = set()
            if "tri" in r:
                secs.update(grid.sectors_for_poly(r["tri"]))
            elif "bbox" in r:
                x0, z0, x1, z1 = r["bbox"]
                secs.update(grid.sectors_for_aabb(x0, z0, x1, z1))
            elif "pos" in r and isinstance(r["pos"], list):
                k = grid.sector_of(r["pos"][0], r["pos"][1])
                if grid.in_grid(*k):
                    secs.add(k)
            elif "x" in r and "z" in r:
                R = r.get("R") or max(r.get("size", [4.0, 4.0])) / 2.0 \
                    if "size" in r else 4.0
                secs.update(grid.sectors_for_disc(r["x"], r["z"], R))
            elif "edge" in r and r["edge"] in st.edges:
                pts = st.range_points(r["edge"], r.get("d0", 0), r.get("d1", 1),
                                      r.get("offset", 0.0))
                for x, z in pts:
                    k = grid.sector_of(x, z)
                    if grid.in_grid(*k):
                        secs.add(k)
            for sx, sz in secs:
                add(sector_id(sx, sz), "reservation_ids", rid)

    # -- regions + coast via authoritative terrain -------------------------
    F = Field()
    step = grid.size / sample_k
    for sx in range(grid.count):
        for sz in range(grid.count):
            sid = sector_id(sx, sz)
            mnx, mnz = grid.bounds_min(sx, sz)
            regs = {}
            coasted = False
            probes = [(mnx + step * (ix + 0.5), mnz + step * (iz + 0.5))
                      for ix in range(sample_k) for iz in range(sample_k)]
            probes.append((mnx + grid.size / 2.0, mnz + grid.size / 2.0))
            for px, pz in probes:
                    try:
                        rg = F.region_at(px, pz)
                    except Exception:
                        rg = "unknown"
                    regs[rg] = regs.get(rg, 0) + 1
                    try:
                        if F.is_coast_band(px, pz):
                            coasted = True
                    except Exception:
                        pass
            order = sorted(regs, key=lambda k: (-regs[k], k))
            S[sid]["region_ids"] = order[:3]
            if coasted:
                S[sid]["coast_fragments"] = ["CF-" + sid]

    # -- LOD groups + static priority + counts ------------------------------
    lm_tier = {m["id"]: m.get("tier", "LOCAL") for m in src["places.json"]["landmarks"]}
    TIER_IMP = {"WORLD": "CRITICAL", "REGIONAL": "HIGH", "DISTRICT": "HIGH", "LOCAL": "NORMAL"}
    edge_class = {eid: e.get("class", "local") for eid, e in src["roads.json"]["edges"].items()}
    for sid, s in S.items():
        crit = [i for i in s["landmark_ids"] if TIER_IMP.get(lm_tier.get(i), "NORMAL") == "CRITICAL"]
        high = ([i for i in s["landmark_ids"] if TIER_IMP.get(lm_tier.get(i), "NORMAL") == "HIGH"] +
                [e for e in s["road_ids"] if edge_class.get(e) in ("primary", "arterial", "highway")])
        s["lod_groups"] = {
            "CRITICAL": sorted(set(crit)),
            "HIGH": sorted(set(high)),
            "NORMAL": sorted(set(s["building_primary"]) | set(s["landmark_ids"]) |
                             set(s["road_ids"]) | set(s["structure_ids"])),
            "LOW": sorted(set(s["parcel_primary"]) | set(s["open_primary"])),
            "BACKGROUND": [],
        }
        s["priority"] = round(min(100.0, 10.0 * len(s["building_primary"]) +
                                  25.0 * len(crit) + 12.0 * len(high) +
                                  2.0 * len(s["road_ids"]) + 1.0 * len(s["structure_ids"])), 2)
        for k in ("region_ids", "district_ids", "block_ids", "block_primary",
                  "parcel_ids", "parcel_primary", "building_ids", "building_primary",
                  "landmark_ids", "open_space_ids", "open_primary", "road_ids",
                  "road_fragment_ids", "road_primary", "structure_ids",
                  "reservation_ids", "coast_fragments", "terrain_dependencies"):
            s[k] = sorted(set(s[k]))
        s["content_counts"] = {
            "districts": len(s["district_ids"]), "blocks": len(s["block_primary"]),
            "parcels": len(s["parcel_primary"]), "buildings": len(s["building_primary"]),
            "landmarks": len(s["landmark_ids"]), "open": len(s["open_primary"]),
            "roads": len(s["road_primary"]), "fragments": len(s["road_fragment_ids"]),
            "structures": len(s["structure_ids"]), "reservations": len(s["reservation_ids"]),
            "coast": len(s["coast_fragments"]),
        }
        s["source_checksums"] = {fn: (c[:8] if isinstance(c, str) else "?")
                                 for fn, c in checks.items()}

    # -- dependency edges ---------------------------------------------------
    dep_edges = []  # (source, target, type, required_state, priority, failure_policy)
    LAYERS = ["TERRAIN", "ROAD", "STRUCTURE", "BUILDING", "DETAIL"]
    for sid, s in S.items():
        present = ["TERRAIN"]
        if s["road_fragment_ids"]:
            present.append("ROAD")
        if s["structure_ids"]:
            present.append("STRUCTURE")
        if s["building_primary"] or s["landmark_ids"]:
            present.append("BUILDING")
        if s["parcel_primary"] or s["open_primary"] or s["reservation_ids"]:
            present.append("DETAIL")
        for a, b in zip(present, present[1:]):
            dep_edges.append(("%s:%s" % (sid, a), "%s:%s" % (sid, b),
                              "LAYER_ORDER", "ACTIVE", 100, "FAIL_DEPENDENT"))
    for unit, sids in sorted(struct_units.items()):
        for sid in sorted(sids):
            dep_edges.append(("%s:TERRAIN" % sid, unit, "STRUCT_BASE",
                              "LOADED", 90, "FAIL_DEPENDENT"))
            dep_edges.append((unit, "%s:STRUCTURE" % sid, "STRUCT_UNIT",
                              "ACTIVE", 90, "PROXY_ALLOWED"))
    dep_edges.sort()

    topo = sorted((sid, s["bounds"], s["world_state"]) for sid, s in S.items())
    refs = sorted((sid, k, tuple(s[k])) for sid, s in S.items()
                  for k in ("district_ids", "block_primary", "parcel_primary",
                            "building_primary", "landmark_ids", "open_primary",
                            "road_fragment_ids", "structure_ids", "reservation_ids"))
    graph_checksum = sha16(canon({"size": size_m, "topology": topo,
                                  "deps": dep_edges, "refs": refs,
                                  "policy": POLICY_VERSION}))
    manifest = {
        "meta": {
            "sector_size_m": size_m, "grid_min": grid.grid_min,
            "grid_count": grid.count, "world_r": grid.world_r,
            "sector_version": "1.0.0", "generation_version": GENERATION_VERSION,
            "policy_version": POLICY_VERSION, "census": grid.census(),
            "source_checksums": checks,
            "dependency_edge_count": len(dep_edges),
            "struct_unit_count": len(struct_units),
            "streaming_graph_checksum": graph_checksum,
            "semantic_checksum32": fnv1a32_hex("\n".join(semantic_lines(
                [S[sector_id(sx, sz)] for sx in range(grid.count)
                 for sz in range(grid.count)]))),
            "generator": "tools/sector_manifest.py",
        },
        "sectors": [S[sector_id(sx, sz)] for sx in range(grid.count)
                    for sz in range(grid.count)],
        "dependency_edges": [
            {"source": a, "target": b, "dependency_type": t,
             "required_state": r, "priority": p, "failure_policy": f}
            for a, b, t, r, p, f in dep_edges],
        "struct_units": sorted(struct_units),
    }
    manifest["checksum"] = sha16(canon({"meta": manifest["meta"],
                                        "sectors": manifest["sectors"],
                                        "deps": manifest["dependency_edges"]}))
    return manifest


def main(argv):
    size = 256
    out = None
    i = 0
    while i < len(argv):
        if argv[i] == "--size":
            size = int(argv[i + 1])
            i += 2
        elif argv[i] == "--out":
            out = argv[i + 1]
            i += 2
        else:
            i += 1
    if out is None:
        print("usage: sector_manifest.py --size N --out PATH")
        return 2
    m = build_manifest(size)
    with open(out, "w") as f:
        json.dump(m, f, indent=1)
    mc = m["meta"]["census"]
    print("size=%d sectors=%d intersecting=%d deps=%d checksum=%s -> %s"
          % (size, mc["total"], mc["intersecting"],
             m["meta"]["dependency_edge_count"], m["checksum"], out))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
