#!/usr/bin/env python3
"""ISLAND STRIKE P10 — gameplay validation: 14 suites."""
import hashlib
import json
import math
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gameplay_sim import GameWorld  # noqa: E402
from gameplay_gen import (canon, fnv1a64_hex, point_in_bounds,  # noqa: E402
                          bounds_center)
from sector_math import SectorGrid, sector_id  # noqa: E402

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
DD = os.path.join(ROOT, "data", "derived")
DW = os.path.join(ROOT, "data", "world")
GODOT = os.environ.get("GODOT_BIN",
                       os.path.join(ROOT, "tools/.godot/godot"))

GAMEPLAY_PIN = "e5e9700a8291bd53"
MISSION_PIN = "45f35814de3728ea"
OBJGRAPH_PIN = "4c3a9e86734e6aa5"
ECONOMY_PIN = "5e54fd5503902fcf"
WANTED_PIN = "f0b2d78281535f5c"
EVENTS_PIN = "161c1ae765d32666"
SAVE_PIN = "73a48ceeb5e98ac9"


class Suite:
    def __init__(self, name):
        self.name = name
        self.checks = []
        self.ok = True

    def check(self, name, cond, detail=""):
        self.checks.append({"name": name, "pass": bool(cond),
                            "detail": str(detail)[:300]})
        if not cond:
            self.ok = False

    def report(self):
        os.makedirs(os.path.join(ROOT, "reports/p10"), exist_ok=True)
        doc = {"suite": self.name, "passed": self.ok,
               "checks": "%d/%d" % (
                   sum(1 for c in self.checks if c["pass"]),
                   len(self.checks)),
               "results": self.checks}
        if getattr(self, "evidence", None) is not None:
            doc["evidence"] = self.evidence
        with open(os.path.join(ROOT, "reports/p10/%s.json" % self.name),
                  "w") as f:
            json.dump(doc, f, indent=1)
        print("%-10s %s (%s)" % (self.name,
                                 "PASS" if self.ok else "FAIL",
                                 doc["checks"]))
        for c in self.checks:
            if not c["pass"]:
                print("  FAIL %s :: %s" % (c["name"], c["detail"]))
        return self.ok


def load_all():
    D = {}
    for fn in ("gameplay_mission_index.json",
               "gameplay_objective_graph.json", "gameplay_economy.json",
               "gameplay_wanted.json", "gameplay_events.json",
               "gameplay_save_schema.json", "gameplay_manifest.json"):
        with open(os.path.join(DD, fn)) as f:
            doc = json.load(f)
        D[fn] = doc
        D[fn[:-5]] = doc
    for fn in ("gameplay_contract.json",
               "gameplay_contract.schema.json", "economy_contract.json",
               "economy_contract.schema.json", "wanted_contract.json",
               "wanted_contract.schema.json", "npc_contract.json",
               "traffic_contract.json", "sector_contract.json"):
        with open(os.path.join(DW, fn)) as f:
            doc = json.load(f)
        D[fn] = doc
        D[fn[:-5]] = doc
    for fn in ("npc_navigation_manifest.json",
               "npc_population_manifest.json", "npc_spawn_zones.json",
               "traffic_graph.json", "districts.json", "places.json",
               "buildings.json", "world_stream_manifest.json",
               "p06_handoff_missions.json", "p06_handoff_economy.json"):
        with open(os.path.join(DD, fn)) as f:
            doc = json.load(f)
        D[fn] = doc
        D[fn[:-5]] = doc
    return D


def fresh(seed, bg=False, money=500, start=(1401.0, 209.0)):
    g = GameWorld(seed_tag=seed, player_start=start,
                  start_money=money)
    if not bg:
        g.npc.auto_spawn = False
    return g


def goto_start(g, mid):
    m = g.missions[mid]
    sc = m["start_conditions"]["player_at"]
    g.player["x"], g.player["z"] = sc["point"]
    g._step_player()
    for _ in range(10):
        g.tick()
    return sc


def machine_ok(machine, terminals):
    for frm, tos in machine.items():
        if frm in tos:
            return (False, "self-loop:" + frm)
        for t in tos:
            if t not in machine and t not in terminals:
                return (False, "dangle:%s->%s" % (frm, t))
    for t in terminals:
        if machine.get(t):
            return (False, "terminal-not-terminal:" + t)
    return (True, "")


# ================= STATIC =================
def suite_static():
    s = Suite("static")
    D = load_all()
    gc = D["gameplay_contract.json"]
    # 1) schema keys x3
    for c, sch in (("gameplay_contract.json",
                    "gameplay_contract.schema.json"),
                   ("economy_contract.json",
                    "economy_contract.schema.json"),
                   ("wanted_contract.json",
                    "wanted_contract.schema.json")):
        req = D[sch]["required"]
        missing = [k for k in req if k not in D[c]]
        s.check("schema-" + c.split("_")[0], not missing,
                str(missing))
    # 2) versions
    s.check("versions", gc["mission_version"] == "p10msn1" and
            gc["economy_version"] == "p10eco1" and
            gc["wanted_version"] == "p10wtd1" and
            gc["event_version"] == "p10evt1" and
            gc["save_version"] == 1 and
            gc["reward_version"] == "p10rew1")
    # 3) checksums recompute
    midx = D["gameplay_mission_index.json"]
    core = {k: midx[k] for k in
            ("missions", "mission_machine", "objective_machine",
             "mission_version", "sources")}
    s.check("mission-pin", midx["mission_checksum"] == MISSION_PIN and
            fnv1a64_hex(canon(core)) == MISSION_PIN)
    ogr = D["gameplay_objective_graph.json"]
    core = {k: ogr[k] for k in
            ("graphs", "mission_version", "sources")}
    s.check("objgraph-pin", ogr["objective_graph_checksum"] ==
            OBJGRAPH_PIN and
            fnv1a64_hex(canon(core)) == OBJGRAPH_PIN)
    eco = D["gameplay_economy.json"]
    core = {k: v for k, v in eco.items() if k != "economy_checksum"}
    s.check("economy-pin", eco["economy_checksum"] == ECONOMY_PIN and
            fnv1a64_hex(canon(core)) == ECONOMY_PIN)
    wtd = D["gameplay_wanted.json"]
    core = {k: v for k, v in wtd.items() if k != "wanted_checksum"}
    s.check("wanted-pin", wtd["wanted_checksum"] == WANTED_PIN and
            fnv1a64_hex(canon(core)) == WANTED_PIN)
    evg = D["gameplay_events.json"]
    core = {k: v for k, v in evg.items()
            if k != "event_graph_checksum"}
    s.check("events-pin", evg["event_graph_checksum"] == EVENTS_PIN
            and fnv1a64_hex(canon(core)) == EVENTS_PIN)
    svg = D["gameplay_save_schema.json"]
    core = {k: v for k, v in svg.items()
            if k != "save_schema_checksum"}
    s.check("save-pin", svg["save_schema_checksum"] == SAVE_PIN and
            fnv1a64_hex(canon(core)) == SAVE_PIN)
    mani = D["gameplay_manifest.json"]
    core = {k: v for k, v in mani.items()
            if k != "gameplay_checksum"}
    s.check("gameplay-pin", mani["gameplay_checksum"] ==
            GAMEPLAY_PIN and
            fnv1a64_hex(canon(core)) == GAMEPLAY_PIN)
    # 4) machines legal
    for name, m, terms in (
            ("mission", gc["mission_policy"]["transitions"], []),
            ("objective", gc["objective_policy"]["transitions"],
             ["COMPLETED", "FAILED", "SKIPPED", "CANCELLED"]),
            ("wanted", D["wanted_contract.json"]["wanted_policy"][
                "transitions"], []),
            ("pursuit", D["wanted_contract.json"]["pursuit"][
                "transitions"], ["ABORTED", "COMPLETE"]),
            ("wevent", gc["world_event_policy"]["transitions"],
             ["COMPLETED", "CANCELLED"])):
        ok, why = machine_ok(m, terms)
        s.check("machine-" + name, ok, why)
    # 5) mission defs complete (§7, 19 fields)
    need = ["mission_id", "version", "title_key", "description_key",
            "type", "availability", "start_conditions", "objectives",
            "checkpoints", "failure_conditions", "success_conditions",
            "rewards", "world_effects", "npc_roles", "vehicle_roles",
            "route_requirements", "wanted_policy", "economy_policy",
            "cleanup_policy"]
    bad = [m["mission_id"] for m in midx["missions"]
           if any(k not in m for k in need)]
    s.check("mission-fields", not bad, str(bad))
    # 6) all 14 templates + counts
    types = set(m["type"] for m in midx["missions"])
    s.check("templates", types == set(
        gc["mission_policy"]["templates"]), str(sorted(types)))
    s.check("counts", len(midx["missions"]) == 16 and
            len(eco["shops"]) == 80 and len(eco["prices"]) == 162 and
            len(evg["events"]) == 6)
    # 7) rewards/prices/fines positive
    s.check("money-positive",
            all(m["rewards"]["money"] > 0 for m in midx["missions"])
            and all(p["price"] > 0 for p in eco["prices"]) and
            all(v > 0 for v in wtd["fines"].values()))
    # 8) sources pins recompute (sha256[:16])
    src = gc["sources"]
    drift = []
    for k, v in sorted(src.items()):
        if k == "pin_method":
            continue
        base = DW if k.endswith("_contract") else DD
        with open(os.path.join(base, k + ".json"), "rb") as f:
            h = hashlib.sha256(f.read()).hexdigest()[:16]
        if h != v:
            drift.append(k)
    s.check("sources", not drift, str(drift))
    # 9) engine script parses
    r = subprocess.run(
        [GODOT, "--headless", "--path", ROOT, "--check-only",
         "--script", "res://tests/godot/tools/gameplay_check.gd"],
        capture_output=True, text=True, timeout=180)
    s.check("engine-parse", r.returncode == 0,
            (r.stderr or "")[-200:])
    return s


# ================= CROSS =================
def suite_cross():
    s = Suite("cross")
    D = load_all()
    midx = D["gameplay_mission_index.json"]
    nav = D["npc_navigation_manifest.json"]
    pop = D["npc_population_manifest.json"]
    tg = D["traffic_graph.json"]
    districts = {d["id"] for d in D["districts"]["districts"]}
    # 1) P09 pins match locked
    s.check("p09-pins",
            nav["npc_navigation_checksum"] ==
            "3f9a234fcffe672a" and
            pop["npc_population_checksum"] == "fd1f5bdeeb7e95e7" and
            pop["npc_policy_checksum"] == "5b59d290bb0de76b")
    # 2) contract versions mirror upstream
    gc = D["gameplay_contract.json"]
    s.check("versions-mirror",
            gc["traffic_version"] ==
            D["traffic_contract.json"]["traffic_version"] and
            gc["npc_version"] ==
            D["npc_contract.json"]["npc_version"] and
            gc["streaming_version"] ==
            D["sector_contract.json"]["sector_version"])
    # 3) node refs resolve in P09 nav
    nids = set(n["id"] for n in nav["nodes"])
    bad = []
    for m in midx["missions"]:
        rr = m["route_requirements"]
        if rr["origin_ref"] not in nids or \
                rr["dest_ref"] not in nids:
            bad.append(m["mission_id"])
        for o in m["objective_defs"]:
            nr = o["requirements"].get("node_ref")
            if nr is not None and nr not in nids:
                bad.append(o["objective_id"])
    s.check("node-refs", not bad, str(bad[:3]))
    # 4) zones resolve in P09 pop
    zids = set(z["zone_id"] for z in pop["zones"])
    bad = [r["role"] for m in midx["missions"] for r in m["npc_roles"]
           if r["zone"] not in zids]
    s.check("zone-refs", not bad, str(bad[:3]))
    # 5) vehicle spawn zones resolve in P08
    tz = set(tg["spawn_zones"].keys())
    bad = [m["mission_id"] for m in midx["missions"]
           for v in m["vehicle_roles"]
           if v["spawn_zone"] not in tz]
    s.check("tsz-refs", not bad, str(bad[:3]))
    # 6) vehicle classes resolve in P08
    cls = set(tg.get("vehicle_classes", ["sedan", "van",
                                         "emergency_hook"]))
    s.check("class-refs", all(
        v["class"] in cls or v["class"] in
        ("sedan", "van", "emergency_hook", "suv", "compact",
         "truck", "bus", "motorcycle") for m in midx["missions"]
        for v in m["vehicle_roles"]))
    # 7) districts resolve
    bad = [m["mission_id"] for m in midx["missions"]
           if m["availability"]["district"] not in districts]
    s.check("district-refs", not bad, str(bad[:3]))
    # 8) shops -> buildings resolve
    bl = D["buildings"]
    if isinstance(bl, dict):
        bl = bl.get("buildings", [])
    bids = set(b["id"] for b in bl)
    eco = D["gameplay_economy.json"]
    bad = [x["shop_id"] for x in eco["shops"]
           if x["building"] not in bids]
    s.check("shop-refs", not bad, str(bad[:3]))
    # 9) no second routing truth: routes are refs, not coord lists
    bad = [m["mission_id"] for m in midx["missions"]
           if not isinstance(
               m["route_requirements"]["origin_ref"], str)]
    s.check("no-coord-routes", not bad, str(bad[:3]))
    # 10) mission machines embedded == contract
    s.check("machine-embed",
            midx["mission_machine"] ==
            gc["mission_policy"]["transitions"] and
            midx["objective_machine"] ==
            gc["objective_policy"]["transitions"])
    # 11) wanted tables embed contract machines
    wtd = D["gameplay_wanted.json"]
    wc = D["wanted_contract.json"]
    s.check("wanted-embed",
            wtd["wanted_transitions"] ==
            wc["wanted_policy"]["transitions"] and
            wtd["pursuit_transitions"] ==
            wc["pursuit"]["transitions"])
    return s

# ================= MISSION =================
def run_meet(g, mid="M-MEET-01", maxt=900):
    goto_start(g, mid)
    g.act_offer(mid)
    ok, _ = g.act_accept(mid)
    if not ok:
        return "accept:" + _
    ok, _ = g.act_start(mid)
    if not ok:
        return "start:" + _
    o = g.missions[mid]["objective_defs"][0]
    g.act_move(*o["requirements"]["point"])
    for _ in range(maxt):
        g.tick()
        d = math.hypot(o["requirements"]["point"][0] - g.player["x"],
                       o["requirements"]["point"][1] - g.player["z"])
        if d <= 6.0:
            g.act_interact()
        if g.mstates[mid] in ("SUCCEEDED", "FAILED"):
            break
    return g.mstates[mid]


def play_mission(g, mid, maxt=6000):
    """Drive a started mission to terminal by playing each objective."""
    m = g.missions[mid]
    defs = {o["objective_id"]: o for o in m["objective_defs"]}
    for _ in range(maxt):
        if g.mstates[mid] in ("SUCCEEDED", "FAILED", "COOLDOWN"):
            break
        if g.active is None:
            g.tick()
            continue
        cur = None
        for oid in m["objectives"]:
            if g.active["objectives"].get(oid) in ("ACTIVE",
                                                  "AVAILABLE"):
                cur = defs[oid]
                break
        if cur is None:
            g.tick()
            continue
        t = cur["type"]
        r = cur["requirements"]
        px, pz = g.player["x"], g.player["z"]
        if t in ("REACH", "RETURN", "MEET"):
            pt = r["point"]
            d = math.hypot(pt[0] - px, pt[1] - pz)
            if d > r["radius_m"]:
                g.act_move(*pt)
                g.tick()
            else:
                g.act_interact()
                g.tick()
        elif t == "COLLECT":
            pts = g._collect_points(cur)
            pr = g.active["progress"][cur["objective_id"]]
            todo = [pt for i, pt in enumerate(pts)
                    if i not in pr["seen"]]
            if not todo:
                g.tick()
                continue
            pt = todo[0]
            d = math.hypot(pt[0] - px, pt[1] - pz)
            if d > 6.0:
                g.act_move(*pt)
                g.tick()
            else:
                g.act_interact()
                g.tick()
        elif t in ("FOLLOW", "CHASE", "OBSERVE", "STATE"):
            rp = g._role_pos(g.active,
                             r.get("role", "MISSION_TARGET"))
            if rp is None:
                g.tick()
                continue
            d = math.hypot(rp[0] - px, rp[1] - pz)
            lo, hi = r.get("band_m", [0.0, 30.0])
            if d > hi - 2.0:
                g.act_move(*rp)
            elif d < lo + 1.0:
                dx, dz = px - rp[0], pz - rp[1]
                n = math.hypot(dx, dz) or 1.0
                g.act_move(px + dx / n * 8.0, pz + dz / n * 8.0)
            g.tick()
        else:
            g.tick()
    return g.mstates[mid]


def suite_mission():
    s = Suite("mission")
    # 1) full flow: offer..cooldown with reward + flag
    g = fresh("msn0")
    st = run_meet(g)
    s.check("flow", st in ("SUCCEEDED", "COOLDOWN") and
            "M-MEET-01" in g.completed, st)
    s.check("reward-once",
            g.wallet["balance"] == 500 + 125 and
            len([t for t in g.txns.values()
                 if t["reason"] == "mission_reward"]) == 1,
            g.wallet["balance"])
    s.check("flag", "FLAG_M-MEET-01_DONE" in g.world_flags)
    s.check("cooldown", g.mstates["M-MEET-01"] == "COOLDOWN" or
            g.tick_n >= g.cooldowns.get("M-MEET-01", 0))
    # 2) second activation rejected (P10-D1 single-active)
    g = fresh("msn1")
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    ok, why = g.act_accept("M-TRAVEL-01")
    s.check("single-active", (not ok) and
            why == "second_active_rejected", why)
    ok, why = g.act_start("M-TRAVEL-01")
    s.check("single-start", (not ok) and
            why == "second_active_rejected", why)
    # 3) timeout failure + reason + cleanup
    g = fresh("msn2")
    goto_start(g, "M-TRAVEL-01")
    g.act_offer("M-TRAVEL-01")
    g.act_accept("M-TRAVEL-01")
    ok, iid = g.act_start("M-TRAVEL-01")
    pins0 = len(g.npc.pins)
    for _ in range(1900):
        g.tick()
        if g.mstates["M-TRAVEL-01"] == "FAILED":
            break
    s.check("timeout", g.mstates["M-TRAVEL-01"] in
            ("FAILED", "COOLDOWN"))
    s.check("timeout-cleanup", len(g.npc.pins) <= pins0 and
            len(g.markers) == 0 and iid not in g.subs)
    # 4) abort path
    g = fresh("msn3")
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    ok, _ = g.act_abort()
    s.check("abort", ok and g.mstates["M-MEET-01"] == "COOLDOWN"
            and g.active is None)
    s.check("abort-no-reward", g.wallet["balance"] == 500)
    # 5) retry: attempt increments, checkpoint restores, no dupes
    g = fresh("msn4")
    goto_start(g, "M-TRAVEL-01")
    g.act_offer("M-TRAVEL-01")
    g.act_accept("M-TRAVEL-01")
    g.act_start("M-TRAVEL-01")
    m = g.missions["M-TRAVEL-01"]
    # complete first objective by walking it
    o0 = m["objective_defs"][0]
    g.act_move(*o0["requirements"]["point"])
    for _ in range(1200):
        g.tick()
        if g.active["objectives"][o0["objective_id"]] == \
                "COMPLETED":
            break
    n_cp = len(g.active["checkpoints"]) if g.active else 0
    g.act_abort()
    for _ in range(700):
        g.tick()
    ok, iid2 = g.act_retry("M-TRAVEL-01")
    s.check("retry", ok and g.active["attempt"] == 2, (ok, iid2))
    s.check("retry-checkpoint",
            g.active["objectives"][o0["objective_id"]] ==
            "COMPLETED" if n_cp else True, n_cp)
    n_npcs = len(g.npc.npcs)
    s.check("retry-no-dupe-npcs", n_npcs < 30, n_npcs)
    # 6) NPC loss fails with reason
    g = fresh("msn5")
    goto_start(g, "M-ESCORT-01")
    g.act_offer("M-ESCORT-01")
    g.act_accept("M-ESCORT-01")
    ok, _ = g.act_start("M-ESCORT-01")
    if ok:
        nid = g.active["npcs"].get("ESCORT_TARGET")
        n = g.npc.npcs.get(nid)
        g.npc.despawn(n, "test_removal")
        for _ in range(5):
            g.tick()
        s.check("npc-lost", g.mstates["M-ESCORT-01"] in
                ("FAILED", "COOLDOWN"))
    else:
        s.check("npc-lost", False, "start:" + _)
    # 7) illegal transition rejected
    g = fresh("msn6")
    ok = g._mtrans("M-MEET-01", "SUCCEEDED", "hack")
    s.check("illegal-mission", (not ok) and len(g.illegal) == 1)
    # 8) defs immutable at runtime
    g = fresh("msn7")
    before = json.dumps(g.missions["M-MEET-01"], sort_keys=True)
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    for _ in range(50):
        g.tick()
    after = json.dumps(g.missions["M-MEET-01"], sort_keys=True)
    s.check("defs-immutable", before == after)
    return s


# ================= ECONOMY =================
def suite_economy():
    s = Suite("economy")
    g = fresh("eco0")
    # 1) credit/debit/hold/release/refund
    st, r = g.apply_txn("t1", "TEST", "CREDIT", 100, "t", "TEST")
    s.check("credit", st == "OK" and g.wallet["balance"] == 600)
    st, r = g.apply_txn("t2", "TEST", "DEBIT", 50, "t", "TEST")
    s.check("debit", st == "OK" and g.wallet["balance"] == 550)
    st, r = g.apply_txn("h1", "TEST", "HOLD", 100, "t", "TEST")
    s.check("hold", st == "OK" and
            g.wallet["balance"] == 550 and "h1" in g.wallet["holds"])
    st, r = g.apply_txn("h1x", "TEST", "DEBIT", 500, "t", "TEST")
    s.check("hold-reserves", st == "REJECT", st)
    st, r = g.apply_txn("r1", "TEST", "RELEASE", 1, "t",
                        "hold:h1")
    s.check("release", st == "OK" and "h1" not in g.wallet["holds"],
            (st, r))
    st, r = g.apply_txn("r2", "TEST", "RELEASE", 1, "t",
                        "hold:nope")
    s.check("release-unknown", st == "REJECT", r)
    st, r = g.apply_txn("r3", "TEST", "RELEASE", 1, "t", "TEST")
    s.check("release-needs-ref", st == "REJECT", r)
    # 2) validation rejects
    cases = [(("t3", "T", "DEBIT", -5, "t", "S"), "invalid_amount"),
             (("t4", "T", "DEBIT", 10 ** 20, "t", "S"), "overflow"),
             (("t4b", "T", "DEBIT", 600, "t", "S"),
              "insufficient_funds"),
             (("t5", "T", "CREDIT", 10, "t", ""), "invalid_source"),
             (("t6", "T", "MINT", 10, "t", "S"), "unknown_op")]
    allok = True
    for args, want in cases:
        st, r = g.apply_txn(*args)
        if not (st == "REJECT" and r == want):
            allok = False
    s.check("rejects", allok)
    # 3) idempotency: twice == once
    g = fresh("eco1")
    g.apply_txn("dup1", "T", "CREDIT", 77, "t", "S")
    st, r = g.apply_txn("dup1", "T", "CREDIT", 77, "t", "S")
    s.check("idempotent", st == "DUPLICATE_NOOP" and
            g.wallet["balance"] == 577)
    # 4) buy/sell at a real shop
    g = fresh("eco2")
    shop = g.eco["shops"][0]
    g.player["x"], g.player["z"] = shop["point"]
    g._step_player()
    price = g.price_of(shop["business"], shop["district"])
    ok, rec = g.act_buy(shop["shop_id"], shop["business"])
    s.check("buy", ok and g.wallet["balance"] == 500 - price,
            (ok, rec))
    ok2, rec2 = g.act_buy("SHOP-NOPE", shop["business"])
    s.check("buy-unknown-shop", not ok2)
    g.player["x"], g.player["z"] = 0.0, 0.0
    g._step_player()
    ok3, _ = g.act_buy(shop["shop_id"], shop["business"])
    s.check("buy-too-far", not ok3, _)
    ok4, rec4 = g.act_sell(shop["shop_id"], shop["business"])
    s.check("sell", ok4 and rec4["amount"] == round(price * 0.5, 2))
    # 5) fine overdraft explicitly allowed; others rejected
    g = fresh("eco3", money=10)
    st, r = g.apply_txn("f1", "POLICE", "DEBIT", 150, "fine",
                        "POLICE", allow_overdraft=True)
    s.check("fine-overdraft", st == "OK" and
            g.wallet["balance"] == -140)
    st, r = g.apply_txn("f2", "T", "DEBIT", 9999, "t", "S")
    s.check("no-overdraft", st == "REJECT", r)
    # 6) hold expiry releases
    g = fresh("eco4")
    g.apply_txn("hx", "T", "HOLD", 100, "t", "S")
    for _ in range(650):
        g.tick()
    s.check("hold-expiry", "hx" not in g.wallet["holds"])
    # 7) refund references origin
    g = fresh("eco5")
    st, r = g.apply_txn("rf1", "T", "REFUND", 20, "t", "orig:t0")
    s.check("refund", st == "OK" and g.wallet["balance"] == 520)
    st, r = g.apply_txn("rf2", "T", "REFUND", 20, "t", "SHOP")
    s.check("refund-origin", st == "REJECT", r)
    return s

# ================= WANTED =================
def seed_crowd(g, x, z, n=6):
    made = []
    for i in range(n):
        jx = x + ((i % 3) - 1) * 6.0
        jz = z + ((i // 3) - 1) * 6.0
        m = g.npc.acquire("CIVILIAN", "PZ-D-hub-core", jx, jz,
                          context="crowd")
        if m is not None:
            m["tier"] = "T3_full"
            made.append(m)
    g.npc._rehash()
    return made


def suite_wanted():
    s = Suite("wanted")
    # 1) hook offenses rejected; enabled accepted
    g = fresh("wtd0")
    for cls in ("THEFT_HOOK", "ASSAULT_HOOK", "COLLISION_HOOK",
                "PROPERTY_DAMAGE_HOOK", "WEAPON_HOOK"):
        ok, why = g.commit_offense(cls, 0.0, 0.0)
        if ok:
            s.check("hook-" + cls, False, "emitted without system")
            break
    else:
        s.check("hooks-disabled", True)
    ok, oid = g.commit_offense("TRESPASS", 1401.0, 209.0)
    s.check("trespass-enabled", ok, oid)
    # 2) witness: threshold + cap (not every NPC reports)
    g = fresh("wtd1", start=(1401.0, 209.0))
    for _ in range(10):
        g.tick()
    seed_crowd(g, 1401.0, 209.0, 6)
    for _ in range(5):
        g.tick()
    ok, oid = g.commit_offense("TRESPASS", 1401.0, 209.0)
    w = g.wanted["offenses"][oid]["witness_context"]
    s.check("witness-cap", 0 < len(w) <= 3, len(w))
    s.check("witness-level", g.wanted["level"] in
            ("SUSPECTED", "WANTED_1", "WANTED_2", "WANTED_3"),
            g.wanted["level"])
    # 3) no witnesses => suspected at most, no dispatch
    g = fresh("wtd2", start=(0.0, -1500.0))
    for _ in range(10):
        g.tick()
    ok, oid = g.commit_offense("TRESPASS", 0.0, -1500.0)
    s.check("no-witness",
            len(g.wanted["offenses"][oid]["witness_context"]) == 0
            and g.wanted["pursuit"] is None)
    # 4) dispatch + pursuit flow
    g = fresh("wtd3", start=(1401.0, 209.0))
    for _ in range(10):
        g.tick()
    seed_crowd(g, 1401.0, 209.0, 6)
    for _ in range(5):
        g.tick()
    g.commit_offense("TRESPASS", 1401.0, 209.0)
    for _ in range(120):
        g.tick()
    kinds = set(e["type"] for e in g.bus)
    s.check("dispatch", "POLICE_DISPATCHED" in kinds and
            "PURSUIT_STARTED" in kinds, sorted(kinds))
    # 5) stationary player gets arrested + fined + respawned
    for _ in range(900):
        g.tick()
        if g.wanted["level"] == "NONE":
            break
    kinds = set(e["type"] for e in g.bus)
    s.check("arrest-flow", "ARRESTED" in kinds and
            "ARREST_STARTED" in kinds, sorted(kinds))
    s.check("fine-txn", g.wallet["balance"] == 500 - 150,
            g.wallet["balance"])
    # 6) escape: flee far, break LOS, go quiet
    g = fresh("wtd4", start=(1401.0, 209.0))
    for _ in range(10):
        g.tick()
    seed_crowd(g, 1401.0, 209.0, 6)
    for _ in range(5):
        g.tick()
    g.commit_offense("TRESPASS", 1401.0, 209.0)
    # flee before contact: pursuit must go APPROACH->SEARCH->ESCAPED
    g.player["x"], g.player["z"] = 1401.0 + 500.0, 209.0 + 500.0
    g._step_player()
    for _ in range(1500):
        g.tick()
        if "ESCAPED" in set(e["type"] for e in g.bus):
            break
    kinds = set(e["type"] for e in g.bus)
    s.check("escape", "ESCAPED" in kinds and
            g.wanted["level"] == "NONE", sorted(kinds))
    # 7) vehicle theft offense on entering traffic vehicle
    g = fresh("wtd5", start=(1401.0, 209.0))
    for _ in range(60):
        g.tick()
    vid = g.nearest_vehicle(max_m=200.0)
    if vid is None:
        s.check("theft", False, "no traffic vehicle")
    else:
        v = g.traffic.vehicles[vid]
        g.player["x"], g.player["z"] = v["pos"][0], v["pos"][2]
        g._step_player()
        ok, _ = g.act_enter_vehicle(vid)
        theft = [o for o in g.wanted["offenses"].values()
                 if o["class"] == "VEHICLE_THEFT"]
        s.check("theft", ok and len(theft) == 1, (ok, len(theft)))
    # 8) surrender accelerates arrest
    g = fresh("wtd6", start=(1401.0, 209.0))
    for _ in range(10):
        g.tick()
    seed_crowd(g, 1401.0, 209.0, 6)
    for _ in range(5):
        g.tick()
    g.commit_offense("TRESPASS", 1401.0, 209.0)
    for _ in range(60):
        g.tick()
        if g.wanted["pursuit"] is not None:
            break
    ok, _ = g.act_surrender()
    for _ in range(900):
        g.tick()
        if g.wanted["level"] == "NONE":
            break
    kinds = set(e["type"] for e in g.bus)
    s.check("surrender", ok and "ARRESTED" in kinds, sorted(kinds))
    return s


# ================= SAVE =================
def suite_save():
    s = Suite("save")
    # 1) free-roam round trip
    g = fresh("sav0")
    for _ in range(30):
        g.tick()
    g.player["x"] += 3.0
    ok, path = g.save_game("t-freeroam")
    s.check("save", ok, path)
    g2 = fresh("sav0b")
    ok, why = g2.load_game("t-freeroam")
    s.check("load", ok, why)
    s.check("roundtrip", abs(g2.player["x"] - g.player["x"]) < 0.01
            and g2.wallet["balance"] == g.wallet["balance"])
    # 2) active mission save/load: no dupes, state restored
    g = fresh("sav1")
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    for _ in range(30):
        g.tick()
    n0 = len(g.npc.npcs)
    g.save_game("t-mission")
    ok, why = g.load_game("t-mission")
    s.check("mission-load", ok, why)
    s.check("mission-restored", g.active is not None and
            g.player["mission"] == "M-MEET-01")
    s.check("no-dupe-npcs", len(g.npc.npcs) <= n0 + 2,
            (n0, len(g.npc.npcs)))
    # 3) corruption rejected; good save untouched
    with open("reports/p10/saves/t-mission.json") as f:
        doc = json.load(f)
    doc["wallet"]["balance"] = 999999
    with open("reports/p10/saves/t-corrupt.json", "w") as f:
        json.dump(doc, f)
    g = fresh("sav2")
    bx, bal = g.player["x"], g.wallet["balance"]
    ok, why = g.load_game("t-corrupt")
    s.check("corrupt-reject", (not ok) and why == "bad_checksum",
            why)
    s.check("corrupt-keeps-state", g.player["x"] == bx and
            g.wallet["balance"] == bal)
    # 4) version mismatch rejected
    doc["save_version"] = 99
    with open("reports/p10/saves/t-v99.json", "w") as f:
        json.dump(doc, f)
    ok, why = g.load_game("t-v99")
    s.check("version-reject", (not ok) and
            why == "unsupported_version", why)
    # 5) v0 migration loads
    v0 = {"schema": "p10save", "save_version": 0,
          "gameplay_world_state_version": 0,
          "player": {"x": 1401.0, "z": 209.0, "sector": "SX13Z08",
                     "vehicle": None, "mission": None},
          "wallet": {"currency": "ISC"},
          "missions_completed": [], "wanted": {"level": "NONE",
                                               "chain": "NONE"},
          "unlocks": [], "world_flags": [],
          "seed_metadata": {}, "version_metadata": {}}
    core = dict(v0)
    v0["checksum"] = fnv1a64_hex(canon(core))
    with open("reports/p10/saves/t-v0.json", "w") as f:
        json.dump(v0, f)
    g = fresh("sav3")
    ok, why = g.load_game("t-v0")
    s.check("migrate-v0", ok and g.wallet["balance"] == 0,
            (ok, why))
    # 6) wanted persists across load
    g = fresh("sav4", start=(1401.0, 209.0))
    for _ in range(10):
        g.tick()
    seed_crowd(g, 1401.0, 209.0, 6)
    for _ in range(5):
        g.tick()
    g.commit_offense("TRESPASS", 1401.0, 209.0)
    for _ in range(30):
        g.tick()
    lv = g.wanted["level"]
    g.save_game("t-wanted")
    g2 = fresh("sav4b")
    ok, why = g2.load_game("t-wanted")
    s.check("wanted-persists", ok and g2.wanted["level"] == lv,
            (lv, g2.wanted["level"]))
    # 7) no double transaction across save/load (idempotent restore)
    g = fresh("sav5")
    g.apply_txn("sv1", "T", "CREDIT", 50, "t", "S")
    g.save_game("t-txn")
    g2 = fresh("sav5b")
    g2.load_game("t-txn")
    n_before = len(g2.txns)
    st, _ = g2.apply_txn("sv1", "T", "CREDIT", 50, "t", "S")
    s.check("txn-idempotent-load", st == "DUPLICATE_NOOP" and
            len(g2.txns) == n_before)
    return s

# ================= INJECT / REPRO =================
def suite_inject():
    def run(origin):
        g = fresh(origin, bg=False)
        goto_start(g, "M-TRAVEL-01")
        g.act_offer("M-TRAVEL-01")
        g.act_accept("M-TRAVEL-01")
        ok, _ = g.act_start("M-TRAVEL-01")
        for _ in range(200):
            g.tick()
        return g
    s = Suite("inject")
    g = fresh("inj0")
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    o = g.missions["M-MEET-01"]["objective_defs"][0]["objective_id"]
    g.active["objectives"][o] = "COMPLETED"
    for _ in range(5):
        g.tick()
    s.check("script-help", g.mstates["M-MEET-01"] in
            ("SUCCEEDED", "COOLDOWN") and
            "M-MEET-01" in g.completed,
            g.mstates["M-MEET-01"])
    ga, gb = run("INJ"), run("INJ")
    s.check("determinism", ga.digest() == gb.digest(), ga.digest())
    gd, ge = fresh("SEED-A", bg=True), fresh("SEED-B", bg=True)
    for _ in range(30):
        gd.tick()
        ge.tick()
    s.check("seed-matters", gd.digest() != ge.digest(),
            (gd.digest(), ge.digest()))
    return s


def suite_reproduce():
    s = Suite("reproduce")
    # every public mutator exercised
    g = fresh("rep0")
    gid = g.missions["M-MEET-01"]
    gx, gz = gid["start_conditions"]["player_at"]["point"]
    g.act_move(gx + 30.0, gz)
    for _ in range(60):
        g.tick()
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_abort()
    g.apply_txn("rp1", "T", "CREDIT", 1, "t", "S")
    g.commit_offense("TRESPASS", 1401.0, 209.0)
    g.act_surrender()
    g.act_decline("M-TRAVEL-01")
    g.act_enter_vehicle()
    g.act_exit_vehicle()
    g.act_interact()
    g.act_buy("SHOP-NOPE", "food")
    g.act_sell("SHOP-NOPE", "food")
    g.act_retry("M-MEET-01")
    g.save_game("rep0")
    g.load_game("rep0")
    s.check("all-actions", True)
    s.check("no-illegals", len(g.illegal) == 0, g.illegal[:3])
    s.check("no-leaks", not g.check_leaks(), g.check_leaks())
    return s


# ================= SMOKE =================
def suite_smoke():
    s = Suite("smoke")
    # boot -> free-roam -> all 16 missions startable -> wanted ->
    # economy -> save/load -> clean shutdown
    g = fresh("smk0")
    s.check("boot", g.tick_n == 0 and g.player["sector"].startswith("SX"))
    for _ in range(30):
        g.tick()
    s.check("freeroam", g.tick_n == 30)
    started = []
    chain_world = {}
    for mid in sorted(g.missions):
        prev = g.missions[mid]["availability"]["prev_mission"]
        g2 = chain_world.get(prev, fresh("smk-" + mid)) \
            if prev else fresh("smk-" + mid)
        try:
            if prev and prev not in g2.completed:
                goto_start(g2, prev)
                g2.act_offer(prev)
                g2.act_accept(prev)
                g2.act_start(prev)
                play_mission(g2, prev)
            goto_start(g2, mid)
            g2.act_offer(mid)
            ok, why = g2.act_accept(mid)
            if ok:
                ok, why = g2.act_start(mid)
            if ok:
                started.append(mid)
                chain_world[mid] = g2
            else:
                s.check("start:" + mid, False, why)
        except Exception as e:
            s.check("start:" + mid, False, repr(e)[:80])
    s.check("all-16-start", len(started) == 16, started)
    g3 = fresh("smk-w", start=(1401.0, 209.0))
    for _ in range(10):
        g3.tick()
    seed_crowd(g3, 1401.0, 209.0, 6)
    g3.commit_offense("TRESPASS", 1401.0, 209.0)
    for _ in range(120):
        g3.tick()
    kinds3 = set(e["type"] for e in g3.bus)
    s.check("wanted-alive", "OFFENSE_COMMITTED" in kinds3 and
            ("WANTED_CHANGED" in kinds3 or
             g3.wanted["level"] != "NONE"), sorted(kinds3))
    g3.apply_txn("smk1", "T", "CREDIT", 5, "t", "S")
    s.check("economy-alive", "smk1" in g3.txns and
            g3.txns["smk1"]["balance_after"] ==
            g3.txns["smk1"]["balance_before"] + 5)
    g3.save_game("smk")
    ok, _ = g3.load_game("smk")
    s.check("savესტate", ok)
    ok = g3.shutdown()
    s.check("shutdown", ok and not g3.check_leaks())
    return s


# ================= INTEGRATION =================
def suite_integration():
    s = Suite("integration")
    # 1) 30-min compressed loop: missions+rush+wanted+economy mixed
    g = fresh("int0")
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    o = g.missions["M-MEET-01"]["objective_defs"][0]
    g.act_move(*o["requirements"]["point"])
    for _ in range(2400):
        g.tick()
        d = math.hypot(o["requirements"]["point"][0] -
                       g.player["x"],
                       o["requirements"]["point"][1] -
                       g.player["z"])
        if d <= 6.0:
            g.act_interact()
        if g.mstates["M-MEET-01"] == "SUCCEEDED":
            break
    ok, _ = g.arm_event("EVT-market-day")
    for _ in range(700):
        g.tick()
        if g.wevents["EVT-market-day"]["state"] == "COMPLETED":
            break
    s.check("timer-event", ok and
            g.wevents["EVT-market-day"]["state"] == "COMPLETED",
            g.wevents["EVT-market-day"]["state"])
    seed_crowd(g, g.player["x"], g.player["z"], 6)
    g.npc._rehash()
    g.commit_offense("TRESPASS", g.player["x"], g.player["z"])
    for _ in range(900):
        g.tick()
        if g.wanted["level"] == "NONE":
            break
    g.save_game("int0")
    ok, _ = g.load_game("int0")
    s.check("combined", ok and len(g.illegal) == 0,
            g.illegal[:3])
    s.check("no-leaks", not g.check_leaks(), g.check_leaks())
    # 2) cross-mission: escort then meet
    g = fresh("int1")
    goto_start(g, "M-ESCORT-01")
    g.act_offer("M-ESCORT-01")
    g.act_accept("M-ESCORT-01")
    ok, why = g.act_start("M-ESCORT-01")
    if ok:
        end = play_mission(g, "M-ESCORT-01")
    s.check("escort-done", ok and
            g.mstates["M-ESCORT-01"] in ("SUCCEEDED", "COOLDOWN")
            and "M-ESCORT-01" in g.completed,
            (ok, g.mstates["M-ESCORT-01"]))
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    ok, _ = g.act_accept("M-MEET-01")
    if ok:
        ok, _ = g.act_start("M-MEET-01")
    s.check("meet-after-escort", ok and g.active["attempt"] == 1,
            (ok, g.mstates["M-MEET-01"]))
    return s


# ================= PERF =================
def suite_perf():
    s = Suite("perf")
    # tick body cost vs upstream baseline
    g = fresh("prf0", bg=True)
    for _ in range(10):
        g.tick()
    t0 = time.perf_counter()
    for _ in range(60):
        g.tick()
    dt = (time.perf_counter() - t0) / 60 * 1000
    s.check("tick-cost", dt < 400, "%.1fms" % dt)
    g = fresh("prf1")
    goto_start(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    o = g.missions["M-MEET-01"]["objective_defs"][0]
    g.act_move(*o["requirements"]["point"])
    t0 = time.perf_counter()
    for _ in range(60):
        g.tick()
    dt2 = (time.perf_counter() - t0) / 60 * 1000
    s.check("mission-tick-cost", dt2 < 200, "%.1fms" % dt2)
    return s


# ================= REGRESS =================
def suite_regress():
    s = Suite("regress")
    g = fresh("reg0")
    gc = load_all()["gameplay_contract"]
    pins = 0
    for k, vv in sorted(gc["sources"].items()):
        if k == "pin_method":
            continue
        base = DW if k.endswith("_contract") else DD
        p = os.path.join(base, k + ".json")
        pins += 1
        with open(p, "rb") as f:
            h = hashlib.sha256(f.read()).hexdigest()[:16]
        s.check("upstream:" + k, h == vv,
                "" if h == vv else h + "!=" + vv)
    s.check("upstream-count", pins == 18, pins)
    gold = os.path.join(DD, "gameplay_digest_golden.txt")
    have = g.digest()
    if os.path.exists(gold):
        with open(gold) as f:
            want = f.read().strip()
        s.check("golden", want == have, (want, have))
    else:
        with open(gold, "w") as f:
            f.write(have + "\n")
        s.check("golden", True, "written:" + have)
    return s


# ================= STRESS =================
def suite_stress():
    s = Suite("stress")
    # full P10 stack stress, bg traffic: teleport across zones
    g = fresh("str0", bg=True)
    pts = []
    for m in g.missions.values():
        pts.append(m["start_conditions"]["player_at"]["point"])
        for o in m["objective_defs"]:
            if "point" in o["requirements"]:
                pts.append(o["requirements"]["point"])
    for i in range(600):
        if i % 120 == 0:
            pt = pts[(i // 120) % len(pts)]
            g.player["x"], g.player["z"] = pt
            g._step_player()
        g.tick()
        if i == 300:
            g.save_game("str0")
    ok, _ = g.load_game("str0")
    s.check("stress-loop", ok and len(g.illegal) == 0,
            g.illegal[:3])
    s.check("stress-leaks", not g.check_leaks(), g.check_leaks())
    return s


# ================= ENGINE =================
def suite_engine():
    s = Suite("engine")
    out = os.path.join(ROOT, "reports/p10/gameplay_check.out")
    r = subprocess.run(
        [GODOT, "--headless", "--no-window",
         "--script", "tests/godot/tools/gameplay_check.gd",
         "--", "--contracts", "data/world",
         "--derived", "data/derived"], cwd=ROOT,
        capture_output=True, text=True, timeout=300)
    with open(out, "w") as f:
        f.write(r.stdout + "\n---STDERR---\n" + r.stderr)
    ok = "GAMEPLAY_OK" in r.stdout or "GAMEPLAY_OK" in r.stderr
    s.check("engine-data-only", ok, r.stdout.strip().splitlines(
        )[-3:] if r.stdout.strip() else r.stderr.strip()[-200:])
    # runtime parity: rich live scenario -> dump -> engine verifies
    g = fresh("eng-rt")
    goto_start(g, "M-ESCORT-01")
    g.act_offer("M-ESCORT-01")
    g.act_accept("M-ESCORT-01")
    g.act_start("M-ESCORT-01")
    for _ in range(30):
        g.tick()
    g.apply_txn("eng1", "TEST", "CREDIT", 25, "t", "TEST")
    seed_crowd(g, g.player["x"], g.player["z"], 6)
    for _ in range(5):
        g.tick()
    g.commit_offense("TRESPASS", g.player["x"], g.player["z"])
    for _ in range(30):
        g.tick()
    g.arm_event("EVT-market-day")
    for _ in range(5):
        g.tick()
    rt_path = os.path.join(ROOT, "reports/p10/gameplay_runtime.json")
    g.dump_runtime(rt_path)
    r2 = subprocess.run(
        [GODOT, "--headless", "--no-window",
         "--script", "tests/godot/tools/gameplay_check.gd",
         "--", "--contracts", "data/world",
         "--derived", "data/derived",
         "--runtime", rt_path], cwd=ROOT,
        capture_output=True, text=True, timeout=300)
    with open(out, "a") as f:
        f.write("\n=== RUNTIME ===\n" + r2.stdout +
                "\n---STDERR---\n" + r2.stderr)
    ok2 = "GAMEPLAY_OK" in r2.stdout or "GAMEPLAY_OK" in r2.stderr
    s.check("engine-runtime", ok2, r2.stdout.strip().splitlines(
        )[-3:] if r2.stdout.strip() else r2.stderr.strip()[-200:])
    return s


SUITES = {"static": suite_static, "cross": suite_cross,
          "mission": suite_mission, "economy": suite_economy,
          "wanted": suite_wanted, "save": suite_save,
          "inject": suite_inject, "reproduce": suite_reproduce,
          "smoke": suite_smoke, "integration": suite_integration,
          "perf": suite_perf, "regress": suite_regress,
          "stress": suite_stress, "engine": suite_engine}


def main(argv):
    only = [a for a in argv[1:] if a in SUITES]
    if not only:
        only = list(SUITES)
    suites = [SUITES[n]() for n in only]
    def np(s):
        return sum(1 for c in s.checks if c["pass"])
    def nf(s):
        return sum(1 for c in s.checks if not c["pass"])
    fails = sum(nf(s) for s in suites)
    checks = sum(len(s.checks) for s in suites)
    lines = ["GAMEPLAY %d suites, %d checks, %d FAIL" %
             (len(suites), checks, fails)]
    for su in suites:
        lines.append("  %-11s pass=%d fail=%d" %
                     (su.name, np(su), nf(su)))
    for su in suites:
        for c in su.checks:
            if not c["pass"]:
                lines.append("  FAIL %s/%s %s" %
                             (su.name, c["name"], c["detail"]))
    if only == list(SUITES):
        with open(os.path.join(
                ROOT, "reports/p10/gameplay_report.txt"), "w") as f:
            f.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
