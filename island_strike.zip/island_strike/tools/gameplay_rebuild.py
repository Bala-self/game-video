"""P10 §82 CLEAN REBUILD x2: delete P10 derived artifacts, rebuild from
P00-P09 twice, canonical outputs must match exactly; complete
validation runs twice. Evidence reports are backed up aside (they are
measurement records, not derived artifacts) and restored after.
Writes reports/p10/rebuild.json. Exit 0 iff identical + GREENx2.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

DD = os.path.join(ROOT, "data", "derived")
RP = os.path.join(ROOT, "reports", "p10")
EVBAK = "/tmp/p10_evidence_bak"
P10F = ["gameplay_mission_index.json", "gameplay_objective_graph.json",
        "gameplay_economy.json", "gameplay_wanted.json",
        "gameplay_events.json", "gameplay_save_schema.json",
        "gameplay_manifest.json"]
CHECKS = []


def check(name, cond, detail=""):
    CHECKS.append({"name": name, "pass": bool(cond),
                   "detail": str(detail)[:200]})
    print("  [%s] %-24s %s" % ("OK" if cond else "FAIL", name,
                               str(detail)[:100]), flush=True)


def snap():
    out = {}
    for fn in P10F:
        with open(os.path.join(DD, fn), "rb") as f:
            out[fn] = hashlib.sha256(f.read()).hexdigest()
    return out


def regen():
    r = subprocess.run([sys.executable, "tools/gameplay_gen.py"],
                       capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, r.stderr[-500:]
    return r.stdout.strip().splitlines()[-1]


def validate(tag):
    r = subprocess.run([sys.executable, "tools/validate_gameplay.py"],
                       capture_output=True, text=True, timeout=1500)
    tail = (r.stdout + r.stderr).strip().splitlines()
    print("  validate#%s exit=%d: %s" % (
        tag, r.returncode,
        tail[-16:] if len(tail) > 16 else tail), flush=True)
    return r.returncode == 0


def main():
    pre = snap()
    # stash evidence reports aside
    shutil.rmtree(EVBAK, ignore_errors=True)
    shutil.copytree(RP, EVBAK)
    # delete P10 derived + saves + reports + caches
    for fn in P10F:
        os.remove(os.path.join(DD, fn))
    shutil.rmtree(os.path.join(RP, "saves"), ignore_errors=True)
    for fn in os.listdir(RP):
        p = os.path.join(RP, fn)
        if os.path.isdir(p):
            shutil.rmtree(p)
        else:
            os.remove(p)
    shutil.rmtree(os.path.join(ROOT, "tools", "__pycache__"),
                  ignore_errors=True)
    check("deleted", all(not os.path.exists(os.path.join(DD, fn))
                         for fn in P10F))
    # rebuild #1 from P00-P09
    out1 = regen()
    b1 = snap()
    check("rebuild1", len(b1) == 7, out1[:90])
    # rebuild #2 from scratch again
    for fn in P10F:
        os.remove(os.path.join(DD, fn))
    out2 = regen()
    b2 = snap()
    check("rebuild2", len(b2) == 7, out2[:90])
    check("identical-1v2", b1 == b2)
    check("identical-vs-pre", b1 == pre)
    # complete validation twice
    v1 = validate(1)
    v2 = validate(2)
    check("validate1", v1)
    check("validate2", v2)
    # restore measurement evidence (not derived artifacts)
    for fn in os.listdir(EVBAK):
        s = os.path.join(EVBAK, fn)
        d = os.path.join(RP, fn)
        if os.path.isdir(s):
            shutil.rmtree(d, ignore_errors=True)
            shutil.copytree(s, d)
        elif not os.path.exists(d):
            shutil.copy2(s, d)
    fails = sum(1 for c in CHECKS if not c["pass"])
    doc = {"result": "REBUILD_OK" if not fails else "REBUILD_FAIL",
           "checks": CHECKS,
           "summary": "%d/%d" % (len(CHECKS) - fails, len(CHECKS))}
    with open(os.path.join(RP, "rebuild.json"), "w") as f:
        json.dump(doc, f, indent=1)
    print(doc["result"], doc["summary"])
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
