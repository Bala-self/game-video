#!/usr/bin/env python3
"""Fetch the PINNED Godot engine binary (reproducible CI / future prompts).

Pinned: 4.7.2-stable, Linux x86_64 (non-mono), official godotengine/godot release.
Verifies SHA-256 of the ZIP before extraction. Installs to tools/.godot/godot
(gitignored) unless --dir is given. Prints the engine --version on success.

Source of pin: docs/ENGINE_STACK_BASELINE.md. Changing the pin requires a
documented revision (engine behavior is a foundation input).
"""
import hashlib, os, sys, urllib.request, zipfile, subprocess

VERSION = "4.7.2-stable"
TAG = "4.7.2-stable"
ASSET = "Godot_v4.7.2-stable_linux.x86_64.zip"
URL = f"https://github.com/godotengine/godot/releases/download/{TAG}/{ASSET}"
SHA256 = "cadd3204e728a35d3f13adb7fd0d7902636b79f6b95c40c265eb73b6c35329e4"
BINARY = "Godot_v4.7.2-stable_linux.x86_64"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def main(argv):
    dest_dir = argv[argv.index("--dir") + 1] if "--dir" in argv else os.path.join(ROOT, "tools/.godot")
    os.makedirs(dest_dir, exist_ok=True)
    zpath = os.path.join(dest_dir, ASSET)
    print(f"fetching {URL}")
    urllib.request.urlretrieve(URL, zpath)
    digest = hashlib.sha256(open(zpath, "rb").read()).hexdigest()
    if digest != SHA256:
        os.remove(zpath)
        print(f"SHA-256 MISMATCH: got {digest} want {SHA256}")
        return 1
    print(f"sha256 OK: {digest}")
    with zipfile.ZipFile(zpath) as z:
        z.extractall(dest_dir)
    os.remove(zpath)
    src = os.path.join(dest_dir, BINARY)
    dst = os.path.join(dest_dir, "godot")
    if src != dst:
        if os.path.exists(dst):
            os.remove(dst)
        os.rename(src, dst)
    os.chmod(dst, 0o755)
    out = subprocess.run([dst, "--version"], capture_output=True, text=True).stdout.strip()
    print(f"installed: {dst}\nversion: {out}")
    if "4.7.2" not in out:
        print("WARNING: version string does not contain pinned 4.7.2")
        return 1
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
