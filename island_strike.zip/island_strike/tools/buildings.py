#!/usr/bin/env python3
"""P06 Gen-E: buildings on validated parcels.

Reads: building_contract, district_contract, parcels.json, districts.json,
       blocks.json, road_geometry.json, roads.json, reservations, terrain.
Writes: data/derived/buildings.json {buildings, parcel_states, rejections,
        stats, checksum}.

Per building parcel: rank compatible classes (48), test in order, commit
the first passing all refusal rules (49). Footprints are rectangles in
the parcel frame (rect_union model); orientation follows road frontage
(51); residential placement varies within the street pattern (52);
commercial fronts high-access roads (53). Foundations follow terrain
(50). View-corridor conflicts are checked after Gen-F defines corridors;
critical conflicts prune here-recorded buildings deterministically.
"""
import json
import math
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from districts import seed_for, q6, polyline_dist, obb_overlap  # noqa: E402
from terrain_model import Field  # noqa: E402
from reservation_index import ReservationIndex  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P06D = os.environ.get("P06_OUT_DIR") or os.path.join(ROOT, "data/derived")

ROLE_OCC = {
    "RESIDENTIAL": {"residential"},
    "COMMERCIAL": {"commercial"},
    "SERVICE": {"commercial", "industrial"},
    "CIVIC": {"civic"},
    "TOURISM": {"commercial", "residential"},
    "INDUSTRIAL": {"industrial"},
    "LOGISTICS": {"industrial"},
    "UTILITY": {"industrial", "civic"},
    "SPECIAL": {"industrial", "civic"},
    "RESTRICTED": {"industrial", "civic"},
}

STYLE_OF = {
    "CITY_CORE": "URBAN_MODERN", "MIXED_USE": "URBAN_MIXED",
    "COMMERCIAL": "URBAN_MIXED", "RESIDENTIAL_INNER": "SUBURBAN",
    "RESIDENTIAL_OUTER": "SUBURBAN", "SUBURBAN": "SUBURBAN",
    "RURAL_VILLAGE": "SUBURBAN", "INDUSTRIAL": "INDUSTRIAL",
    "PORT": "INDUSTRIAL", "AIRFIELD": "INDUSTRIAL", "UTILITY": "INDUSTRIAL",
    "FOREST_SETTLEMENT": "RURAL", "HIGHLAND_SETTLEMENT": "RURAL",
    "AGRICULTURAL": "RURAL", "WATERFRONT": "COASTAL", "RESORT": "RESORT",
    "CIVIC": "CIVIC", "RESTRICTED": "RESTRICTED",
}

RW_MARGIN = 60.0
RW_APPROACH_LEN = 400.0
RW_APPROACH_HALF = 80.0


class BuildingsError(Exception):
    pass


def shoelace(poly):
    a = 0.0
    for i in range(len(poly)):
        x0, z0 = poly[i]
        x1, z1 = poly[(i + 1) % len(poly)]
        a += x0 * z1 - x1 * z0
    return abs(a) / 2.0


class Registry:
    def __init__(self):
        t0 = time.time()
        self.timers = {}
        self.dc = json.load(open(os.path.join(
            ROOT, "data/world/district_contract.json")))
        self.bc = json.load(open(os.path.join(
            ROOT, "data/world/building_contract.json")))
        self.par = json.load(open(os.path.join(
            P06D, "parcels.json")))
        self.dist = json.load(open(os.path.join(
            P06D, "districts.json")))
        self.blk = json.load(open(os.path.join(
            P06D, "blocks.json")))
        self.g = json.load(open(os.path.join(
            ROOT, "data/derived/road_geometry.json")))
        self.r = json.load(open(os.path.join(
            ROOT, "data/derived/roads.json")))
        self.f = Field()
        self.ri = ReservationIndex()
        self.runway = self.r["runway_rect"]
        self.cls_of = {d["id"]: d["class"] for d in self.dist["districts"]}
        self.bounds_of = {d["id"]: d["bounds"]
                           for d in self.dist["districts"]}
        self.block_of = {b["id"]: b for b in self.blk["blocks"]}
        self.centerlines = {}
        for eid, E in self.g["edges"].items():
            self.centerlines[eid] = [(p["x"], p["z"])
                                     for p in E["stations"]]
        self.buildings = []
        self.parcel_states = []
        self.rejections = []
        self.footprints = []  # committed OBBs for overlap tests
        self.timers["load"] = time.time() - t0

    def _t(self, name):
        if name is None:
            self.timers[self._cur] = time.time() - self._t0
        else:
            self._cur = name
            self._t0 = time.time()

    @staticmethod
    def checksum_scope(items):
        from districts import canon, fnv1a_hex
        lines = sorted(canon(it) for it in items)
        return fnv1a_hex("\n".join(lines))

    def phase_preflight(self):
        self._t("preflight")
        if self.checksum_scope(self.par["parcels"]) != self.par["checksum"]:
            raise BuildingsError("stale parcels.json")
        assert self.bc["district_version"] == self.dc["district_version"]
        self._t(None)

    # ---------- geometry helpers ----------
    def in_runway_zone(self, x, z):
        x0, z0, x1, z1 = self.runway
        if x0 - RW_MARGIN <= x <= x1 + RW_MARGIN and \
                z0 - RW_MARGIN <= z <= z1 + RW_MARGIN:
            return True
        zc = (z0 + z1) / 2.0
        if abs(z - zc) <= RW_APPROACH_HALF and \
                (x0 - RW_APPROACH_LEN <= x <= x0 or
                 x1 <= x <= x1 + RW_APPROACH_LEN):
            return True
        return False

    def parcel_frame(self, p):
        """Rectangle parcel -> (origin, F(front dir), G(inward), W, D)."""
        poly = [tuple(v) for v in p["polygon"]]
        A, B, C, D = poly
        e0 = (B[0] - A[0], B[1] - A[1])
        e1 = (D[0] - A[0], D[1] - A[1])
        lu = math.hypot(*e0)
        lv = math.hypot(*e1)
        if lu < 0.5 or lv < 0.5:
            raise BuildingsError("degenerate parcel %s" % p["id"])
        dot = abs(e0[0] * e1[0] + e0[1] * e1[1]) / (lu * lv)
        if dot > 0.02:
            raise BuildingsError("non-rect parcel %s" % p["id"])
        tu = (e0[0] / lu, e0[1] / lu)
        tv = (e1[0] / lv, e1[1] / lv)
        # front edge = nearest to access road centerline
        cl = self.centerlines[p["access_edge"]]
        mids = [((A[0] + B[0]) / 2, (A[1] + B[1]) / 2),
                ((B[0] + C[0]) / 2, (B[1] + C[1]) / 2),
                ((C[0] + D[0]) / 2, (C[1] + D[1]) / 2),
                ((D[0] + A[0]) / 2, (D[1] + A[1]) / 2)]
        fi = min(range(4),
                 key=lambda i: polyline_dist(mids[i][0], mids[i][1], cl))
        if fi == 0:
            return A, tu, tv, lu, lv
        if fi == 2:
            return C, (-tu[0], -tu[1]), (-tv[0], -tv[1]), lu, lv
        if fi == 1:
            return B, tv, (-tu[0], -tu[1]), lv, lu
        return D, (-tv[0], -tv[1]), tu, lv, lu

    def water_within(self, x, z, r):
        if not self.f.is_land(x, z):
            return 0.0
        for rr in (5.0, 10.0, 15.0, 20.0, 30.0):
            if rr > r:
                break
            for k in range(8):
                a = k / 8 * 2 * math.pi
                if not self.f.is_land(x + math.cos(a) * rr,
                                      z + math.sin(a) * rr):
                    return rr
        return 99.0

    def height_cap(self, p):
        dcls = self.cls_of[p["district"]]
        prof = self.dc["height_profiles"][
            self.dc["district_classes"][dcls]["height_profile"]]
        cap = float(prof["max_m"])
        if prof.get("HIGH", 0) > 0:
            b = self.bounds_of[p["district"]]
            if "disc" in b:
                cx, cz, r = b["disc"]
            else:
                cx, cz, _, r1, _, _ = b["sector"]
                r = r1
            poly = p["polygon"]
            px = sum(v[0] for v in poly) / len(poly)
            pz = sum(v[1] for v in poly) / len(poly)
            frac = min(1.0, math.hypot(px - cx, pz - cz) / r)
            cap *= 1.0 - 0.4 * frac
        return cap

    # ---------- ranking (48) ----------
    def candidates(self, p):
        dcls = self.cls_of[p["district"]]
        allowed = self.dc["district_classes"][dcls][
            "allowed_building_classes"]
        occ = ROLE_OCC[p["role"]]
        out = []
        for c in allowed:
            if self.bc["building_classes"][c]["occupancy"] in occ:
                out.append(c)
        return sorted(out)

    def rank(self, p, env_area, rng):
        dcls = self.cls_of[p["district"]]
        cls = self.dc["district_classes"][dcls]
        poly = p["polygon"]
        px = sum(v[0] for v in poly) / len(poly)
        pz = sum(v[1] for v in poly) / len(poly)
        b = self.bounds_of[p["district"]]
        if "disc" in b:
            bx, bz, br = b["disc"]
        else:
            bx, bz, _, br, _, _ = b["sector"]
        centrality = max(0.0, 1.0 - math.hypot(px - bx, pz - bz) / br)
        if not hasattr(self, "_open_pts"):
            self._open_pts = []
            for q in self.par["parcels"]:
                if q["role"] == "OPEN":
                    qp = q["polygon"]
                    self._open_pts.append(
                        (sum(v[0] for v in qp) / len(qp),
                         sum(v[1] for v in qp) / len(qp)))
        near_open = any(math.hypot(px - ox, pz - oz) < 60.0
                        for (ox, oz) in self._open_pts)
        scored = []
        for c in self.candidates(p):
            B = self.bc["building_classes"][c]
            s = 0.0
            fa, fb = B["footprint_range_m2"]
            mid = (fa + fb) / 2.0
            if env_area > 0:
                s += 3.0 * max(0.0, 1.0 - abs(mid - env_area * 0.4) /
                               max(mid, env_area * 0.4))
            if p["frontage"]["length"] >= cls["frontage_min_m"]:
                s += 2.0
            g = p["buildability"]["grade_max"]
            if B["terrain_grade_limit"] >= g * 1.5:
                s += 2.0
            elif B["terrain_grade_limit"] >= g:
                s += 1.0
            if B["height_range_m"][1] <= self.height_cap(p):
                s += 1.0
            if p["frontage"]["valid"]:
                s += 2.0
            elif p["access"]["type"] in ("DRIVEWAY", "CAMPUS"):
                s += 1.0
            if B["service_access"]:
                s += 1.0
            if B["occupancy"] == "civic":  # 54: civic wants center + green
                s += 3.0 * centrality
                if near_open:
                    s += 2.0
            if p["role"] in ("INDUSTRIAL", "LOGISTICS") or \
                    B["occupancy"] == "industrial":  # 55
                if p["_road_class"] in ("service", "secondary", "tertiary",
                                        "rural"):
                    s += 1.5
                if p["setbacks"]["rear_m"] >= 8:
                    s += 1.0
            if B["coast_rule"] != "inland_only":
                s += 0.5
            s += rng.random() * 2.0
            scored.append((s, c))
        scored.sort(key=lambda t: (-t[0], t[1]))
        return [c for _, c in scored]

    # ---------- refusal (49) + commit ----------
    def phase_buildings(self):
        self._t("buildings")
        for p in self.par["parcels"]:
            if p["role"] == "OPEN":
                self.parcel_states.append(
                    {"parcel": p["id"], "state": "OPEN_SPACE",
                     "reason": p["kind"]})
                continue
            self._build_parcel(p)
        self._t(None)

    def _build_parcel(self, p):
        dcls = self.cls_of[p["district"]]
        cls = self.dc["district_classes"][dcls]
        rng = random.Random(p["seed"])
        try:
            O, F, G, W, D = self.parcel_frame(p)
        except BuildingsError as e:
            self.parcel_states.append(
                {"parcel": p["id"], "state": "UNBUILDABLE",
                 "reason": str(e)})
            return
        road_class = self.g["edges"][p["access_edge"]]["class"]
        p["_road_class"] = road_class
        road_min = self.bc["setback_rules"]["by_road_class"].get(
            road_class, 3)
        junc_add = 0
        if p["block"] is not None:
            b = self.block_of[p["block"]]
            if b["junction"]["clear_m"] < 40.0:
                junc_add = self.bc["setback_rules"]["junction_add_m"]
        cands = self.candidates(p)
        if not cands:
            self.parcel_states.append(
                {"parcel": p["id"], "state": "UNBUILDABLE",
                 "reason": "no_compatible_class"})
            return
        # envelope probe for ranking (district setbacks)
        sb = p["setbacks"]
        env_w = W - 2 * sb["side_m"]
        env_d = D - sb["front_m"] - sb["rear_m"]
        ranked = self.rank(p, max(0.0, env_w * env_d), rng)
        road_class = p.pop("_road_class")
        tested = []
        size_fail = False
        for c in ranked:
            B = self.bc["building_classes"][c]
            ok, info = self._try_class(p, dcls, cls, B, c, O, F, G, W, D,
                                       road_min, junc_add, rng)
            if ok:
                self._commit(p, dcls, cls, c, info)
                break
            tested.append({"class": c, "reason": info})
            if info in ("footprint_exceeds", "setback_exceeds"):
                size_fail = True
        else:
            state = "FUTURE_DEVELOPMENT" if size_fail else "UNBUILDABLE"
            self.parcel_states.append(
                {"parcel": p["id"], "state": state,
                 "reason": tested[0]["reason"] if tested else "no_class"})
        if tested:
            self.rejections.append({"parcel": p["id"], "tested": tested,
                                    "untested": len(ranked) - len(tested)})

    def _try_class(self, p, dcls, cls, B, c, O, F, G, W, D, road_min,
                   junc_add, rng):
        sb = p["setbacks"]
        add = B["setback_add_m"]
        front = max(sb["front_m"] + add, road_min) + junc_add
        rear = sb["rear_m"] + add
        side = sb["side_m"] + add
        # coast: rule gate
        coast_parcel = p["buildability"].get("coast", False)
        poly = p["polygon"]
        cx = sum(v[0] for v in poly) / len(poly)
        cz = sum(v[1] for v in poly) / len(poly)
        coast_gap = self.water_within(cx, cz, 30.0)
        is_coast = coast_parcel or coast_gap < 30.0
        rule = B["coast_rule"]
        if rule == "inland_only" and is_coast:
            return False, "coast_conflict"
        if rule == "water_access_required" and not is_coast:
            return False, "coast_conflict"
        if rule == "beach_contract_gated":
            return False, "coast_conflict"  # beach parcels stay OPEN
        if rule == "view_gap_required":
            side = max(side, 6.0)
        env_u0, env_u1 = side, W - side
        env_v0, env_v1 = front, D - rear
        if env_u1 - env_u0 < 4.0 or env_v1 - env_v0 < 4.0:
            return False, "setback_exceeds"
        # height fit
        cap = self.height_cap(p)
        ha, hb = B["height_range_m"]
        lo, hi = max(ha, 3.0), min(hb, cap)
        if hi < lo:
            return False, "height_violation"
        # terrain fit
        if B["terrain_grade_limit"] < p["buildability"]["grade_max"]:
            return False, "terrain_exceeds"
        # footprint size + placement search (bounded: 2 sizes x 4 pos)
        fa, fb = B["footprint_range_m2"]
        cov_cap = cls["coverage_max"] * p["area"]
        env_area = (env_u1 - env_u0) * (env_v1 - env_v0)
        full = min(fa + rng.random() * (fb - fa), cov_cap,
                   env_area * 0.92)
        sizes = [full, min(fa, cov_cap, env_area * 0.92)]
        tried_reasons = []
        win = None
        for area in sizes:
            if area < 20.0:
                tried_reasons.append("footprint_exceeds")
                continue
            if rule == "no_coast_wall" and is_coast and area > 900.0:
                tried_reasons.append("coast_conflict")
                continue
            avail = max(0.0, env_v1 - env_v0)
            ew = env_u1 - env_u0
            for att in range(4):
                # fit aspect to envelope: w in [area/avail, ew]
                lo_w = area / avail if avail > 0 else ew + 1.0
                hi_w = min(ew, area / 4.0)
                if lo_w > hi_w:
                    tried_reasons.append("footprint_exceeds")
                    continue
                w = lo_w + rng.random() * (hi_w - lo_w)
                w = min(max(w, 4.0), ew)
                dd = area / w
                if dd > avail or w > ew:
                    tried_reasons.append("footprint_exceeds")
                    continue
                depth_free = max(0.0, avail - dd)
                if p["role"] in ("COMMERCIAL", "SERVICE", "CIVIC"):
                    fracs = (0.0, 0.35, 0.7, 1.0)  # street-first, fall back
                else:
                    fracs = (0.35, 0.7, 0.1, 1.0)  # yard-first, span depth
                gap_f = fracs[att] * depth_free + rng.random() * 0.5
                gap_f = min(gap_f, depth_free)
                span_u = (env_u1 - env_u0) - w
                u0 = env_u0 + (rng.random() * span_u if span_u > 0
                               else 0.0)
                v0 = env_v0 + gap_f
                ok, reason, data = self._footprint_tests(
                    p, B, O, F, G, u0, v0, w, dd, front, D, W, rng)
                if ok:
                    win = data
                    break
                tried_reasons.append(reason)
            if win is not None:
                break
        if win is None:
            uniq = sorted(set(tried_reasons))
            mode = max(uniq, key=lambda r: (tried_reasons.count(r),
                                            -ord(r[0])))
            return False, mode
        u0, v0, w, dd = win["u0"], win["v0"], win["w"], win["d"]
        world = win["world"]
        ent = win["entrance"]
        svc = win["service"]
        mine = win["obb"]
        # foundation (50)
        hs = []
        for i in range(3):
            for j in range(3):
                u = u0 + w * i / 2.0
                v = v0 + dd * j / 2.0
                hs.append(self.f.height(O[0] + F[0] * u + G[0] * v,
                                       O[1] + F[1] * u + G[1] * v))
        hr = max(hs) - min(hs)
        if hr <= 1.0:
            found = {"method": "flat-base", "base_elev": q6(min(hs))}
        elif hr <= 3.0:
            n = math.ceil(hr / 1.0)
            found = {"method": "terraced", "base_elev": q6(min(hs)),
                     "steps": n, "step_h": q6(hr / n)}
        elif B["terrain_grade_limit"] >= 0.15:
            found = {"method": "raised", "base_elev": q6(min(hs)),
                     "podium_h": q6(round(hr / 2.0, 2))}
        else:
            return False, "terrain_exceeds"
        if rule == "raised_in_wetland" and \
                self.f.region_at(cx, cz) == "wetland_inland_water":
            found = {"method": "raised", "base_elev": q6(min(hs)),
                     "podium_h": 1.5}
        return True, {"footprint": world, "w": w, "d": dd, "obb": mine,
                      "height": (lo, hi), "entrance": ent,
                      "service": svc, "foundation": found,
                      "setbacks_used": {"front": front, "rear": rear,
                                        "side": side},
                      "coast_gap": coast_gap, "rng": rng}

    def _footprint_tests(self, p, B, O, F, G, u0, v0, w, dd,
                             front, D, W, rng):
        corn = [(u0, v0), (u0 + w, v0), (u0 + w, v0 + dd), (u0, v0 + dd)]
        world = [(O[0] + F[0] * u + G[0] * v,
                  O[1] + F[1] * u + G[1] * v) for (u, v) in corn]
        if shoelace(world) < 0:  # keep CCW positive (plan math)
            world = [world[0], world[3], world[2], world[1]]
        for i in range(5):
            for j in range(3):
                u = u0 + w * i / 4.0
                v = v0 + dd * j / 2.0
                x = O[0] + F[0] * u + G[0] * v
                z = O[1] + F[1] * u + G[1] * v
                if self.ri.is_building_excluded(x, z)[0]:
                    return False, "reservation_conflict", None
                if self.in_runway_zone(x, z):
                    return False, "runway_conflict", None
                if not self.f.is_land(x, z):
                    return False, "reservation_conflict", None
        ent = None
        for off_r in (rng.random() - 0.5, 0.25, -0.25):
            eu = u0 + w * (0.5 + off_r * 0.6)
            ex = O[0] + F[0] * eu + G[0] * v0
            ez = O[1] + F[1] * eu + G[1] * v0
            if front >= 1.5 and self.f.is_land(ex, ez) and \
                    not self.ri.is_building_excluded(ex, ez)[0]:
                ent = (ex, ez)
                break
        if ent is None:
            return False, "entrance_blocked", None
        svc = None
        if B["service_access"]:
            rear_yard = D - (v0 + dd)
            side_yard = min(u0, W - (u0 + w))
            if rear_yard >= 4.0:
                svc = ("rear", rear_yard)
            elif side_yard >= 4.0:
                svc = ("side", side_yard)
            else:
                return False, "service_blocked", None
        fx = O[0] + F[0] * (u0 + w / 2) + G[0] * (v0 + dd / 2)
        fz = O[1] + F[1] * (u0 + w / 2) + G[1] * (v0 + dd / 2)
        mine = (fx, fz, F[0], F[1], w / 2, dd / 2)
        for other in self.footprints:
            if obb_overlap(mine, other, tol=0.5):
                return False, "overlap_committed", None
        return True, "", {"u0": u0, "v0": v0, "w": w, "d": dd,
                          "world": world, "entrance": ent,
                          "service": svc, "obb": mine}

    def _commit(self, p, dcls, cls, c, info):
        B = self.bc["building_classes"][c]
        rng = info["rng"]
        lo, hi = info["height"]
        h = lo + rng.random() * (hi - lo)
        fa, fb = B["floor_range"]
        floors = max(fa, min(fb, round(h / 3.2)))
        fp = [[q6(x), q6(z)] for (x, z) in info["footprint"]]
        fp.append(fp[0])  # closure
        poly = p["polygon"]
        cx = sum(v[0] for v in poly) / len(poly)
        cz = sum(v[1] for v in poly) / len(poly)
        occ = B["occupancy"]
        if occ == "residential":
            stalls = 1 + (1 if rng.random() < 0.5 else 0)
        elif occ == "commercial":
            stalls = max(1, round(info["w"] * info["d"] / 40.0))
        elif occ == "civic":
            stalls = max(1, round(info["w"] * info["d"] / 50.0))
        else:
            stalls = max(1, round(info["w"] * info["d"] / 100.0))
        dock = c in self.bc["service_rules"]["dock_classes"]
        readiness = B["interior_readiness"]
        interior = {"state": readiness}
        if readiness in ("INTERIOR_READY", "INTERIOR_REQUIRED",
                         "MISSION_INTERIOR_CANDIDATE"):
            interior.update({"floor_height": 3.2,
                             "core_reservation": [q6(cx), q6(cz)],
                             "grid_hint": "3.2m"})
        bid = "BLD-%s" % p["id"][4:]
        self.footprints.append(info["obb"])
        self.buildings.append({
            "id": bid, "parcel": p["id"],
            "block": p["block"], "district": p["district"],
            "settlement": p["settlement"], "region": p["region"],
            "road": p["access_edge"], "terrain_grade":
                p["buildability"]["grade_max"],
            "reservations": "clear",
            "class": c, "occupancy": occ,
            "style": STYLE_OF[dcls],
            "footprint": fp, "footprint_area": q6(info["w"] * info["d"]),
            "generator": "rectangle",
            "height_m": q6(h), "floors": floors,
            "roof": {"family": B["roof_family"]},
            "facade": {"family": B["facade_family"]},
            "tint_seed": rng.randrange(8),
            "foundation": info["foundation"],
            "entrance": {"at": [q6(info["entrance"][0]),
                                q6(info["entrance"][1])],
                         "faces": "road",
                         "connects_to": p["access_edge"]},
            "service": ({"side": info["service"][0],
                         "yard_m": q6(info["service"][1]),
                         "dock": dock} if info["service"] else None),
            "parking": {"type": B["parking_requirement"],
                        "stalls": stalls,
                        "policy": p["parking_policy"]},
            "interior": interior,
            "setbacks_used": {k: q6(v) for k, v in
                              info["setbacks_used"].items()},
            "view_corridor": "pending_gen_f",
            "seed": seed_for("p06-building", bid)})

    # ---------- export ----------
    def phase_export(self):
        self._t("export")
        outdir = os.environ.get("P06_OUT_DIR",
                                P06D)
        HC = self.bc["height_classes"]
        dist = {"LOW": 0, "MID": 0, "HIGH": 0}
        for b in self.buildings:
            h = b["height_m"]
            if h < HC["MID"]["height_m"][0]:
                dist["LOW"] += 1
            elif h < HC["HIGH"]["height_m"][0]:
                dist["MID"] += 1
            else:
                dist["HIGH"] += 1
        per_class = {}
        for b in self.buildings:
            per_class[b["class"]] = per_class.get(b["class"], 0) + 1
        per_district = {}
        for b in self.buildings:
            per_district[b["district"]] = per_district.get(
                b["district"], 0) + 1
        doc = {"meta": {"building_version": self.bc["building_version"],
                        "parcel_version": self.dc["parcel_version"],
                        "generator": "buildings.py"},
               "buildings": self.buildings,
               "parcel_states": self.parcel_states,
               "rejections": self.rejections,
               "stats": {"count": len(self.buildings),
                         "per_class": per_class,
                         "per_district": per_district,
                         "height_distribution": dist},
               "checksum": ""}
        doc["checksum"] = self.checksum_scope(self.buildings)
        json.dump(doc, open(os.path.join(outdir, "buildings.json"), "w"))
        self._t(None)


def main():
    reg = Registry()
    reg.phase_preflight()
    reg.phase_buildings()
    reg.phase_export()
    print("gen-e ok: %d buildings (%d states, %d rejection records)" % (
        len(reg.buildings), len(reg.parcel_states),
        len(reg.rejections)))
    print("timers: %s" % " ".join("%s=%.2f" % kv for kv in
                                  sorted(reg.timers.items())))


if __name__ == "__main__":
    main()
