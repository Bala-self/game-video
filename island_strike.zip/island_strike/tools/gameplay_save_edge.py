"""P10 §90 SAVE/LOAD EDGE STRESS: repeated save/load/fail/retry/wanted/
escape/economy cycles. Verifies idempotency, identity, consistency,
no dupes, no pin accumulation. Writes reports/p10/save_edge.json.
"""
import json
import math
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
os.chdir(ROOT)

from gameplay_sim import GameWorld  # noqa: E402

CHECKS = []


def check(name, cond, detail=""):
    CHECKS.append({"name": name, "pass": bool(cond),
                   "detail": str(detail)[:200]})
    print("  [%s] %-24s %s" % ("OK" if cond else "FAIL", name,
                               str(detail)[:100]), flush=True)


def goto(g, mid):
    sc = g.missions[mid]["start_conditions"]["player_at"]
    g.player["x"], g.player["z"] = sc["point"]
    g._step_player()
    for _ in range(10):
        g.tick()


def pins(g):
    n = sum(1 for p in g.npc.pins.values()
            if str(p.get("owner", "")).split(":")[0] in (
                "mission", "police"))
    for v in g.traffic.vehicles.values():
        for (_pid, _sid, reason) in v.get("pins", []):
            if str(reason).split(":")[0] in ("mission", "police"):
                n += 1
    return n


def main():
    g = GameWorld(seed_tag="SAVE-EDGE", player_start=(1401.0, 209.0),
                  start_money=500)
    g.npc.auto_spawn = False

    # round 1: save/load/save with active mission + digest stability
    goto(g, "M-MEET-01")
    g.act_offer("M-MEET-01")
    g.act_accept("M-MEET-01")
    g.act_start("M-MEET-01")
    for _ in range(20):
        g.tick()
    d0 = g.digest()
    g.save_game("edge-1")
    g.load_game("edge-1")
    d1 = g.digest()
    check("digest-stable-load", d0 == d1, (d0, d1))
    check("mission-identity", g.active is not None and
          g.player["mission"] == "M-MEET-01" and
          g.active["attempt"] == 1,
          g.active["id"] if g.active else None)
    n0 = len(g.npc.npcs)
    g.save_game("edge-2")
    g.load_game("edge-2")
    check("no-dupe-npcs", len(g.npc.npcs) <= n0 + 1,
          (n0, len(g.npc.npcs)))

    # round 2: fail -> retry -> save (retry restores checkpoint-less)
    g.act_abort()
    for _ in range(700):
        g.tick()
    g.save_game("edge-3")
    g.load_game("edge-3")
    ok, iid = g.act_retry("M-MEET-01")
    check("retry-after-load", ok and g.active["attempt"] == 2,
          (ok, iid if ok else None))
    # complete honestly, reward exactly once across save/load
    o = g.missions["M-MEET-01"]["objective_defs"][0]
    g.act_move(*o["requirements"]["point"])
    for _ in range(1200):
        g.tick()
        dd = math.hypot(o["requirements"]["point"][0] -
                        g.player["x"],
                        o["requirements"]["point"][1] -
                        g.player["z"])
        if dd <= 6.0:
            g.act_interact()
        if g.mstates["M-MEET-01"] in ("SUCCEEDED", "COOLDOWN"):
            break
    g.save_game("edge-4")
    g.load_game("edge-4")
    pay = [t for t in g.txns.values()
           if t["reason"] == "mission_reward"]
    check("reward-once", len(pay) == 1, len(pay))
    check("completed-persists", "M-MEET-01" in g.completed)

    # round 3: wanted -> escape -> save/escape/save
    for i in range(6):
        n = g.npc.acquire(
            "CIVILIAN", "PZ-D-hub-core", g.player["x"] +
            ((i % 3) - 1) * 6.0, g.player["z"] +
            ((i // 3) - 1) * 6.0, context="crowd")
        if n is not None:
            n["tier"] = "T3_full"
    g.npc._rehash()
    for _ in range(5):
        g.tick()
    g.commit_offense("TRESPASS", g.player["x"], g.player["z"])
    for _ in range(10):
        g.tick()
    lv_before = g.wanted["level"]
    g.save_game("edge-5")
    g.load_game("edge-5")
    check("wanted-consistent", g.wanted["level"] == lv_before,
          (lv_before, g.wanted["level"]))
    check("pursuit-transient-by-design",
          g.wanted["pursuit"] is None,
          "level persists; units stand down on load")
    # fresh pursuit after load, then honest escape
    g.commit_offense("TRESPASS", g.player["x"], g.player["z"])
    g.player["x"] += 500.0
    g.player["z"] += 500.0
    g._step_player()
    for _ in range(1500):
        g.tick()
        if g.wanted["level"] == "NONE":
            break
    check("escape-after-load", g.wanted["level"] == "NONE",
          g.wanted["level"])
    g.save_game("edge-6")

    # round 4: economy across save/load (idempotent restore)
    g.apply_txn("edge-t1", "TEST", "CREDIT", 40, "t", "TEST")
    g.save_game("edge-7")
    g.load_game("edge-7")
    st, _ = g.apply_txn("edge-t1", "TEST", "CREDIT", 40, "t",
                        "TEST")
    check("txn-idempotent", st == "DUPLICATE_NOOP", st)
    g.save_game("edge-8")

    # bounds: pins / subs / leaks / illegals
    check("pins-bounded", pins(g) <= 12, pins(g))
    check("subs-clean", len(g.subs) <= 2, len(g.subs))
    check("no-leaks", not g.check_leaks(), g.check_leaks())
    check("no-illegals", not g.illegal, g.illegal[:2])
    ok = g.shutdown()
    check("shutdown", ok and not g.check_leaks())

    fails = sum(1 for c in CHECKS if not c["pass"])
    doc = {"result": "SAVE_EDGE_OK" if not fails else
           "SAVE_EDGE_FAIL", "checks": CHECKS,
           "summary": "%d/%d" % (len(CHECKS) - fails,
                                 len(CHECKS))}
    with open("reports/p10/save_edge.json", "w") as f:
        json.dump(doc, f, indent=1)
    print(doc["result"], doc["summary"])
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
