#!/usr/bin/env python3
"""P07 evidence assembler: reports/p07_streaming_summary.json (§94) +
reports/p07_performance_baseline.json (§68). Measured values only.
Usage: python3 tools/stream_report.py
"""
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sector_manifest import sha16, canon  # noqa: E402
from sector_math import fnv1a32_hex  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DD = os.path.join(ROOT, "data/derived")
DW = os.path.join(ROOT, "data/world")
REP = os.path.join(ROOT, "reports/p07")


def J(path):
    with open(path) as f:
        return json.load(f)


def main():
    man = J(os.path.join(DD, "world_stream_manifest.json"))
    lod = J(os.path.join(DD, "lod_policy.json"))
    sc = J(os.path.join(DW, "sector_contract.json"))
    size = man["meta"]["sector_size_m"]
    lod_checksum = sha16(canon(lod))
    p06 = {fn: J(os.path.join(DD, fn))["checksum"] for fn in
           ("districts.json", "blocks.json", "parcels.json",
            "buildings.json", "places.json", "urban_mesh.json")}
    p06_agg = sha16(canon(p06))
    world_checksum = J(os.path.join(DW, "world_contract.json")).get("checksum", "?")
    cmp_ = J(os.path.join(ROOT, "reports/p07_size_compare.json"))
    cache = J(os.path.join(ROOT, "reports/p07_cache_compare.json"))
    perf = J(os.path.join(REP, "perf_measure.json"))["metrics"]
    ctx = cmp_["context"]
    baseline_id = sha16(canon({
        "world": world_checksum, "p06": p06_agg,
        "sector_version": man["meta"].get("sector_version"),
        "size": size, "lod": lod_checksum, "bench": ctx.get("suite_version"),
        "engine": ctx.get("godot"), "cpu": ctx.get("cpu")}))
    dist = {}
    for k in ("buildings", "parcels", "fragments", "structures", "reservations"):
        v = sorted(x["content_counts"][k] for x in man["sectors"]
                   if x["world_state"] != "FULLY_OUTSIDE")
        dist[k] = {"max": v[-1], "p95": v[int(len(v) * 0.95)],
                   "mean": round(sum(v) / len(v), 2)}
    hot = max(man["sectors"], key=lambda x: x["content_counts"]["buildings"])
    summary = {
        "chosen_sector_size": size,
        "candidate_comparison": cmp_["matrix"],
        "grid_count": man["meta"]["census"]["total"],
        "world_sector_count": man["meta"]["census"]["intersecting"],
        "content_distribution": dist,
        "hotspot_sector": {"id": hot["sector_id"],
                           "buildings": hot["content_counts"]["buildings"]},
        "active_peak": perf["active_peak"],
        "prefetch_policy": "ahead-cone within prefetch_radius, budgeted",
        "load_latency_ms": {"p95": perf["load_p95_ms"]},
        "activation_latency_ms": {"p95": perf["activate_p95_ms"]},
        "manifest_query_ms": {"p95": perf["manifest_query_p95_ms"]},
        "lod_eval_ms": {"p95": perf["lod_eval_p95_ms"]},
        "memory_peak_MB": perf["mem_peak_MB"],
        "cache_peak_MB": perf["cache_peak_MB"],
        "cache_hit_ratio_traversal": round(sum(
            r["cache_hit_ratio"] for k, reps in cmp_["runs"].items()
            for r in reps) / sum(len(reps) for reps in cmp_["runs"].values()), 4),
        "cache_policy": cache["policies"] and sc["cache_policy"].get("eviction"),
        "frame_peak_ms": perf["worst_frame_ms"],
        "frame_p95_ms": perf["traversal_p95_ms"],
        "queue_peak": perf["queue_peak"],
        "spikes_traversal": perf["spikes"],
        "streaming_graph_checksum": man["meta"]["streaming_graph_checksum"],
        "lod_policy_checksum": lod_checksum,
        "semantic_checksum32": man["meta"]["semantic_checksum32"],
        "performance_baseline_id": baseline_id,
        "p06_aggregate": p06_agg,
    }
    with open(os.path.join(ROOT, "reports/p07_streaming_summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    commit = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                            capture_output=True, text=True).stdout.strip()
    baseline = {"commit": commit, "world_checksum": world_checksum,
                "p06_aggregate": p06_agg, "sector_size": size,
                "lod_checksum": lod_checksum, "environment": ctx,
                "benchmarks": cmp_["runs"], "matrix": cmp_["matrix"],
                "perf": perf, "performance_baseline_id": baseline_id,
                "status": "CURRENT_ENVIRONMENT; production TARGET_ENVIRONMENT_PENDING"}
    with open(os.path.join(ROOT, "reports/p07_performance_baseline.json"), "w") as f:
        json.dump(baseline, f, indent=1)
    print("summary + baseline written; baseline_id=%s" % baseline_id)
    return 0


if __name__ == "__main__":
    sys.exit(main())
