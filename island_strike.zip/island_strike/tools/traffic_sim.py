#!/usr/bin/env python3
"""ISLAND STRIKE P08 — deterministic fixed-step traffic runtime.

Hosts vehicles (vehicle_model), routes (A* over the derived lane graph),
signals/queues, spawn/despawn, tiers, spatial index, events, and P07
streaming pins. No rendering. Tick is pure logic: identical seeds + steps
=> identical discrete decisions at any render cadence.
"""
import hashlib
import heapq
import json
import math
import os
import random
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from vehicle_model import VehicleSpec, VehiclePool, new_vehicle, transition, ACTIVE
from sector_math import SectorGrid

FIXED_STEP = 0.1
HIERARCHY = {"primary": 0, "secondary": 1, "tertiary": 2, "local": 3,
             "rural": 3, "service": 4, "trail": 5}


def seed64(*parts):
    h = hashlib.sha256((":".join(["traffic"] + [str(p) for p in parts])).encode())
    return int(h.hexdigest()[:16], 16)


def rng_for(*parts):
    return random.Random(seed64(*parts))


def clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x


class Router:
    """Deterministic A* over lanes; movements are edges. Static topo + dynamic cost."""

    def __init__(self, graph, contract):
        self.g = graph
        self.tc = contract
        self.lanes = graph["lanes"]
        self.movements = graph["movements"]
        self.out = {}
        for mid, m in self.movements.items():
            if m["allowed"]:
                self.out.setdefault(m["from_lane"], []).append(mid)
        for v in self.out.values():
            v.sort()
        # lane-change edges: adjacent same edge+dir
        self.lc = {}
        for lid, l in self.lanes.items():
            for side, other in sorted(l.get("adjacent", {}).items()):
                self.lc.setdefault(lid, []).append(other)
        self.cache = {}
        self.congestion = {}  # lane -> occupancy 0..1 (bounded summary)
        self.congestion_tick = -1
        gv = graph["meta"]["generation_version"]
        rv = contract["routing_policy"]["policy_version"]
        self.ver = (graph["checksums"]["traffic_graph_checksum"], gv, rv)
        self.stats = {"queries": 0, "hits": 0, "expanded": 0}

    def set_congestion(self, occ, tick):
        self.congestion = dict(occ)
        self.congestion_tick = tick

    def _lane_cost(self, lid, spec, escape=False):
        l = self.lanes[lid]
        if l["access"] == "RESTRICTED" and spec.name != "emergency_hook":
            if not escape:
                return float("inf")
            return 500.0  # escape mode: exiting only, heavily penalized
        dist = l["length_m"]
        v = max(2.0, l["speed_legal_kph"] * 1000.0 / 3600.0)
        time_c = dist / v
        hier_c = HIERARCHY.get(l["class"], 3) * 8.0
        cong = self.congestion.get(lid, 0.0)
        return dist + time_c * 4.0 + hier_c + cong * 60.0

    def _dest_point(self, lid):
        p = self.lanes[lid]["pts"][-1]
        return (p[0], p[2])

    def plan(self, start_lane, dest_lane, spec, seed_tag="",
             max_expand=4000, alt=0):
        self.stats["queries"] += 1
        esc = (start_lane in self.lanes
               and self.lanes[start_lane]["access"] == "RESTRICTED"
               and spec.name != "emergency_hook")
        key = (start_lane, dest_lane, spec.name, self.ver, alt, seed_tag,
               self.congestion_tick, esc)
        if key in self.cache:
            self.stats["hits"] += 1
            return self.cache[key]
        if start_lane == dest_lane:
            res = {"lanes": [start_lane], "moves": [], "cost": 0.0,
                   "reason": "already-there"}
            self.cache[key] = res
            return res
        if start_lane not in self.lanes or dest_lane not in self.lanes:
            return {"lanes": [], "moves": [], "cost": float("inf"),
                    "reason": "ROUTE_FAILED:unknown-lane"}
        escape = esc
        if self._lane_cost(dest_lane, spec) == float("inf"):
            return {"lanes": [], "moves": [], "cost": float("inf"),
                    "reason": "ROUTE_FAILED:restricted-destination"}
        dx, dz = self._dest_point(dest_lane)
        rng = rng_for("route", seed_tag, start_lane, dest_lane, spec.name, alt)

        def h(lid):
            p = self.lanes[lid]["pts"][-1]
            return math.hypot(p[0] - dx, p[2] - dz)

        openh = [(h(start_lane), 0, 0, start_lane, [], [])]
        best = {start_lane: 0.0}
        expand = 0
        # deterministic variation: penalize a seeded subset of junction exits
        vary = {}
        while openh and expand < max_expand:
            _, tie, cost, lid, lanes_path, moves_path = heapq.heappop(openh)
            if cost > best.get(lid, float("inf")) + 1e-9:
                continue
            if lid == dest_lane:
                res = {"lanes": lanes_path + [lid], "moves": moves_path,
                       "cost": cost, "reason": "ok"}
                self.cache[key] = res
                return res
            expand += 1
            # movement successors
            for mid in self.out.get(lid, []):
                m = self.movements[mid]
                nl = m["to_lane"]
                step = self._lane_cost(nl, spec, escape)
                if step == float("inf"):
                    continue
                step += 25.0  # junction penalty
                if alt and m["junction"]:
                    vk = (m["junction"], mid)
                    if vk not in vary:
                        vary[vk] = rng.random()
                    step += vary[vk] * 120.0 * alt
                nc = cost + step
                if nc + 1e-9 < best.get(nl, float("inf")):
                    best[nl] = nc
                    heapq.heappush(openh, (nc + h(nl), expand, nc, nl,
                                           lanes_path + [lid], moves_path + [mid]))
            # lane-change successors (same edge+dir adjacency)
            for nl in self.lc.get(lid, []):
                nc = cost + 15.0
                if nc + 1e-9 < best.get(nl, float("inf")):
                    best[nl] = nc
                    heapq.heappush(openh, (nc + h(nl), expand + 0.5, nc, nl,
                                           lanes_path + [lid], moves_path + [None]))
        self.stats["expanded"] += expand
        return {"lanes": [], "moves": [], "cost": float("inf"),
                "reason": "ROUTE_FAILED:no-legal-path"}

    def invalidate(self):
        self.cache = {}


def load_connectors():
    """P04 connectors normalized to canonical [x,y,z] (source is [x,z,elev])."""
    g = json.load(open(os.path.join(ROOT, "data/derived/road_geometry.json")))
    out = {}
    for cid, c in g["connectors"].items():
        out[cid] = [[p[0], p[2], p[1]] for p in c["pts"]]
    return out


class TrafficWorld:
    def __init__(self, graph_path=None, contract_path=None, streaming=None,
                 focus=(1400.0, 150.0), seed_tag="world"):
        gp = graph_path or os.path.join(ROOT, "data/derived/traffic_graph.json")
        cp = contract_path or os.path.join(ROOT, "data/world/traffic_contract.json")
        self.graph = json.load(open(gp))
        self.tc = json.load(open(cp))
        self.lanes = self.graph["lanes"]
        self.movements = self.graph["movements"]
        self.junctions = self.graph["junctions"]
        self.signals = self.graph["signals"]
        self.spawn_zones = self.graph["spawn_zones"]
        self.density = self.graph["density_zones"]
        self.connectors = load_connectors()
        self.specs = {n: VehicleSpec(n, p)
                      for n, p in self.tc["vehicle_classes"].items()}
        self.router = Router(self.graph, self.tc)
        self.pool = VehiclePool()
        self.streaming = streaming  # P07 StreamingManager (sole authority) or None
        self.grid = SectorGrid(256, -2048.0)
        self.focus = list(focus)
        self.seed_tag = seed_tag
        self.tick_n = 0
        self.vehicles = {}      # id -> vehicle
        self.index = {}         # sector -> lane -> [vid sorted by s]
        self.queues = {}        # (junction, from_lane) -> [vid]
        self.sig_state = {}     # sig_id -> {phase, t, states:{mid:state}}
        for sid, s in self.signals.items():
            self.sig_state[sid] = {"phase": 0, "t": 0, "states": {}}
        self.events = []
        self.dropped_events = 0
        self.spawn_queue = []   # pending (zone, class)
        self.spawn_stats = {"accepted": 0, "rejected": 0, "deferred": 0,
                            "failed": 0, "reasons": {}}
        self.despawn_stats = {"retired": 0, "reasons": {}}
        self.route_failures = 0
        self.player = None
        self.congestion = {}
        self.max_events = 20000
        self.counters = {"leader_queries": 0, "lane_occupancy_queries": 0,
                         "junction_decisions": 0, "sector_syncs": 0}
        rj = json.load(open(os.path.join(ROOT, "data/derived/roads.json")))
        self.struct_edges = {}
        for b in rj.get("bridges", []):
            self.struct_edges[b["road_edge"]] = ("bridge", b["id"])
        for t in rj.get("tunnels", []):
            self.struct_edges[t["road_edge"]] = ("tunnel", t["id"])

    # ---------------- events ----------------
    def emit(self, typ, vid, data=None):
        if len(self.events) >= self.max_events:
            self.dropped_events += 1
            return
        self.events.append({"tick": self.tick_n, "type": typ, "vehicle": vid,
                            "data": data or {}})

    # ---------------- spatial index (sector -> lane -> s-sorted) ----------------
    def _index_add(self, v):
        sec = v["sector"]
        lane = v["lane"]
        if sec is None or lane is None:
            return
        cell = self.index.setdefault(sec, {}).setdefault(lane, [])
        if v["id"] not in cell:
            cell.append(v["id"])
            cell.sort(key=lambda i: self.vehicles[i]["s"])

    def _index_del(self, v):
        cell = self.index.get(v["sector"], {}).get(v["lane"], None)
        if cell and v["id"] in cell:
            cell.remove(v["id"])

    def leader_of(self, v):
        self.counters["leader_queries"] += 1
        cell = self.index.get(v["sector"], {}).get(v["lane"], [])
        best, bs = None, float("inf")
        for oid in cell:
            if oid == v["id"]:
                continue
            o = self.vehicles[oid]
            gap = o["s"] - v["s"] - o["spec"].length_m / 2 - v["spec"].length_m / 2
            if 0 <= gap < bs:
                bs, best = gap, o
        return best, (bs if best else float("inf"))

    def lane_occupancy(self, lane, s0, s1, exclude=None):
        self.counters["lane_occupancy_queries"] += 1
        n = 0
        for sec, lanes in self.index.items():
            for oid in lanes.get(lane, []):
                if oid == exclude:
                    continue
                s = self.vehicles[oid]["s"]
                if s0 <= s <= s1:
                    n += 1
        return n

    # ---------------- signals ----------------
    def sig_of_movement(self, mid):
        m = self.movements[mid]
        j = m["junction"]
        return self.signals.get("SIG:%s" % j) if j else None

    def sig_aspect(self, mid):
        s = self.sig_of_movement(mid)
        if s is None:
            return "UNCONTROLLED"
        st = self.sig_state[s["signal_id"]]
        return st["states"].get(mid, "RED")

    def _sig_tick(self):
        for sid, s in self.signals.items():
            st = self.sig_state[sid]
            ph = s["phases"][st["phase"]]
            st["t"] += 1
            if st["t"] >= ph["green_ticks"] + ph["yellow_ticks"]:
                st["t"] = 0
                st["phase"] = (st["phase"] + 1) % len(s["phases"])
                ph = s["phases"][st["phase"]]
                self.emit("signal_phase", None,
                          {"signal": sid, "phase": st["phase"]})
            yellow = st["t"] >= ph["green_ticks"]
            states = {}
            for p in s["phases"]:
                on = (p["phase"] == ph["phase"])
                for mid in p["movements"]:
                    if not on:
                        states[mid] = "RED"
                    elif mid in p.get("protected", []) and not yellow:
                        states[mid] = "PROTECTED"
                    else:
                        states[mid] = "YELLOW" if yellow else "GREEN"
            st["states"] = states

    # ---------------- queues ----------------
    def queue_join(self, v, junction):
        key = (junction, v["lane"])
        q = self.queues.setdefault(key, [])
        if v["id"] not in q:
            q.append(v["id"])
            v["queue"] = key
            self.emit("queue_join", v["id"], {"queue": list(key), "pos": len(q)})

    def queue_leave(self, v):
        if v.get("queue"):
            q = self.queues.get(v["queue"], [])
            if v["id"] in q:
                q.remove(v["id"])
            v["queue"] = None

    def queue_leader(self, junction, lane):
        q = self.queues.get((junction, lane), [])
        return q[0] if q else None

    # ---------------- streaming pins (P07 authoritative) ----------------
    def pin(self, v, sid, reason):
        if self.streaming is None:
            v["pins"].append(("local", sid, reason))
            self.emit("pin_create", v["id"],
                      {"pin": "local:%s" % sid, "sector": sid})
            return "local:%s" % sid
        if self.streaming.state.get(sid) == "LOADING":
            return None
        pid = self.streaming.pin_sector(sid, "traffic:%s" % v["id"], reason)
        v["pins"].append((pid, sid, reason))
        self.emit("pin_create", v["id"], {"pin": pid, "sector": sid})
        return pid

    def unpin(self, v, sid=None):
        keep = []
        for pid, s, reason in v["pins"]:
            if sid is not None and s != sid:
                keep.append((pid, s, reason))
                continue
            if self.streaming is not None and not str(pid).startswith("local"):
                self.streaming.release_pin(pid)
            self.emit("pin_release", v["id"], {"pin": pid, "sector": s})
        v["pins"] = keep

    # ---------------- player participant ----------------
    def set_player(self, x, z, lane=None, s=None, speed=0.0):
        sx, sz = self.grid.sector_of(x, z)
        self.player = {"x": x, "z": z, "lane": lane, "s": s, "speed": speed,
                       "sector": "SX%02dZ%02d" % (sx, sz)}
        self.focus = [x, z]

    # ---------------- spawn / despawn ----------------
    def request_spawns(self):
        rel = self.tc["despawn_policy"]["relevance_distance_m"]
        for zid in sorted(self.spawn_zones.keys()):
            z = self.spawn_zones[zid]
            if math.hypot(z["pos"][0] - self.focus[0],
                          z["pos"][2] - self.focus[1]) > rel:
                continue
            want = self.density_target(z)
            have = sum(1 for v in self.vehicles.values()
                       if v.get("zone") == zid and v["state"] in ACTIVE)
            if have < want:
                cls = self.pick_class(z)
                if cls:
                    self.spawn_queue.append((zid, cls))

    def density_target(self, z):
        dz = None
        for d in self.density.values():
            if d.get("settlement") == z["settlement"]:
                dz = d
                break
        base = dz["target_population"] if dz else 2
        share = max(1, base // 4)
        return min(share, z["capacity"] * 2)

    def pick_class(self, z):
        cands = []
        for n, spec in self.specs.items():
            w = spec.spawn_weight * z["class_modifiers"].get(n, 1.0)
            if w > 0:
                cands.append((n, w))
        if not cands:
            return None
        rng = rng_for("spawn", self.seed_tag, z["zone_id"], self.tick_n,
                      len(self.vehicles))
        tot = sum(w for _, w in cands)
        x = rng.random() * tot
        for n, w in sorted(cands):
            x -= w
            if x <= 0:
                return n
        return sorted(cands)[0][0]

    def try_spawn(self, zid, cls):
        z = self.spawn_zones[zid]
        lid = z["lanes"][0]
        lane = self.lanes[lid]
        spec = self.specs[cls]
        # safety: lane width fit
        if spec.width_m + 0.6 > lane["width_m"] + 2.0:
            return self._spawn_no("width", zid, cls)
        # safety: gap at s=8
        if self.lane_occupancy(lid, 0, 14.0):
            return self._spawn_no("occupied", zid, cls)
        # safety: player distance
        p = lane["pts"][min(4, len(lane["pts"]) - 1)]
        if self.player and math.hypot(p[0] - self.player["x"],
                                      p[2] - self.player["z"]) < \
                self.tc["spawn_policy"]["min_spawn_distance_from_player_m"]:
            return self._spawn_no("near_player", zid, cls)
        # safety: sector not LOADING
        if self.streaming is not None and \
                self.streaming.state.get(z["sector"]) == "LOADING":
            return self._spawn_no("sector_loading", zid, cls)
        v = self.pool.acquire(spec)
        v["born"] = self.tick_n
        v["zone"] = zid
        v["lane"] = lid
        v["s"] = 8.0
        v["pos"] = list(p)
        v["heading"] = self.lane_heading(lid, 8.0)
        v["speed"] = 0.0
        sx, sz = self.grid.sector_of(p[0], p[2])
        v["sector"] = "SX%02dZ%02d" % (sx, sz)
        self._struct_pin_sync(v)
        self.vehicles[v["id"]] = v
        self._index_add(v)
        transition(v, "INITIALIZING", "spawn %s %s" % (zid, cls))
        self.emit("spawn", v["id"], {"zone": zid, "class": cls})
        self.spawn_stats["accepted"] += 1
        return v

    def _spawn_no(self, reason, zid, cls):
        r = self.spawn_stats["reasons"]
        r[reason] = r.get(reason, 0) + 1
        self.spawn_stats["deferred"] += 1
        return None

    def lane_heading(self, lid, s):
        pts = self.lanes[lid]["pts"]
        i = self._segantil(pts, s)
        a, b = pts[i], pts[min(i + 1, len(pts) - 1)]
        return math.atan2(b[0] - a[0], b[2] - a[2])

    @staticmethod
    def _segantil(pts, s):
        # pts are ~2m resampled; index ~= s/2
        ds = 2.0
        i = int(s / ds)
        return max(0, min(i, len(pts) - 2))

    def pos_at(self, lid, s):
        pts = self.lanes[lid]["pts"]
        i = self._segantil(pts, s)
        a, b = pts[i], pts[min(i + 1, len(pts) - 1)]
        seg = math.dist((a[0], a[2]), (b[0], b[2]))
        t = 0.0 if seg < 1e-9 else clamp((s - i * 2.0) / seg, 0.0, 1.0)
        return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t,
                a[2] + (b[2] - a[2]) * t]

    def retire(self, v, reason):
        if v["state"] == "DESPAWNED":
            return
        self.queue_leave(v)
        self._index_del(v)
        self.unpin(v)
        transition(v, "DESPAWNING", reason)
        transition(v, "DESPAWNED", reason)
        r = self.despawn_stats["reasons"]
        r[reason] = r.get(reason, 0) + 1
        self.despawn_stats["retired"] += 1
        self.emit("despawn", v["id"], {"reason": reason})
        del self.vehicles[v["id"]]
        self.pool.release(v)

    def despawn_tick(self):
        rel = self.tc["despawn_policy"]["relevance_distance_m"]
        for v in list(self.vehicles.values()):
            if v["state"] in ("DESPAWNING", "DESPAWNED"):
                continue
            if v["pins"] or v.get("queue"):
                continue
            if v["state"] in ("TURNING", "CHANGING_LANE", "MERGING"):
                continue
            d = math.hypot(v["pos"][0] - self.focus[0],
                           v["pos"][2] - self.focus[1]) if v["pos"] else 0
            if v.get("route_done"):
                self.retire(v, "route_complete")
            elif d > rel and v["speed"] < 0.5 and \
                    self.tick_n - v.get("born", 0) > 60:
                self.retire(v, "outside_relevance")

    # ---------------- routing assignment ----------------
    def pick_destination(self, v):
        rng = rng_for("dest", self.seed_tag, v["id"], self.tick_n)
        cands = sorted(self.lanes.keys())
        if not cands:
            return None
        for _ in range(8):
            d = cands[rng.randrange(len(cands))]
            if d != v["lane"]:
                return d
        return None

    def fallback_dest(self, v):
        best, bd = None, float("inf")
        p = v["pos"]
        for lid, l in self.lanes.items():
            if lid == v["lane"]:
                continue
            if l["access"] == "RESTRICTED" and v["spec"].name != "emergency_hook":
                continue
            q = l["pts"][-1]
            d = math.hypot(q[0] - p[0], q[2] - p[2])
            if d < bd:
                bd, best = d, lid
        return best

    def assign_route(self, v):
        dest = self.pick_destination(v)
        if dest is None:
            self.emit("route_failed", v["id"], {"reason": "no-destination"})
            self.route_failures += 1
            return False
        rng = rng_for("route", self.seed_tag, v["id"], self.tick_n)
        alt = 1 if rng.random() < 0.35 else 0
        res = self.router.plan(v["lane"], dest, v["spec"],
                               seed_tag="%s:%s" % (self.seed_tag, v["id"]),
                               alt=alt)
        if not res["lanes"]:
            fb = self.fallback_dest(v)
            if fb and fb != v["lane"]:
                res = self.router.plan(v["lane"], fb, v["spec"],
                                       seed_tag="fb:%s" % v["id"], alt=0)
        if not res["lanes"]:
            self.emit("route_failed", v["id"], {"reason": res["reason"]})
            self.route_failures += 1
            transition(v, "FAILED", res["reason"])
            return False
        v["route"] = {"lanes": res["lanes"], "moves": res["moves"],
                      "i": 0, "dest": dest}
        v["route_done"] = False
        self.emit("route_assigned", v["id"],
                  {"dest": dest, "nlanes": len(res["lanes"])})
        return True

    def current_move(self, v):
        r = v.get("route")
        if not r:
            return None
        if r["i"] < len(r["moves"]):
            return r["moves"][r["i"]]
        return None
    # ---------------- per-vehicle update ----------------
    def update_full(self, v):
        st = v["state"]
        if st == "INITIALIZING":
            if self.assign_route(v):
                transition(v, "ROUTING", "route ok")
            return
        if st == "ROUTING":
            transition(v, "FOLLOWING", "lane acquired")
            return
        if st in ("FOLLOWING", "APPROACHING_JUNCTION", "WAITING", "STOPPED"):
            self._long_lat(v)
            return
        if st == "TURNING":
            self._turn_step(v)
            return
        if st == "CHANGING_LANE":
            self._lc_step(v)
            return
        if st == "MERGING":
            self._merge_step(v)
            return
        if st == "STOPPING":
            v["speed"] = max(0.0, v["speed"] - v["spec"].brake_ms2 * 0.7 * FIXED_STEP)
            if v["speed"] <= 0.05:
                v["speed"] = 0.0
                transition(v, "STOPPED", "halted")
            return
        if st == "RECOVERING":
            self._recover_step(v)
            return

    def _target_speed(self, v):
        lane = self.lanes[v["lane"]]
        i = self._segantil(lane["pts"], v["s"])
        vt = lane["v_target_ms"][min(i, len(lane["v_target_ms"]) - 1)]
        vt = min(vt, v["spec"].top_speed_ms)
        leader, gap = self.leader_of(v)
        want_gap = v["spec"].follow_gap(v["speed"])
        if leader and gap < want_gap + 6.0:
            # IDM-like: match leader, brake to gap
            dv = v["speed"] - leader["speed"]
            vt = min(vt, leader["speed"] + max(0.0, gap - want_gap) * 0.8
                     - max(0.0, dv) * 0.5)
        if self.player and self.player.get("lane") == v["lane"] \
                and self.player.get("s") is not None:
            pg = self.player["s"] - v["s"]
            if 0 < pg < want_gap + 10.0:
                vt = min(vt, self.player["speed"] + max(0.0, pg - want_gap) * 0.6)
        return max(0.0, vt), leader

    def _long_lat(self, v):
        lane = self.lanes[v["lane"]]
        vt, leader = self._target_speed(v)
        if leader and leader["speed"] < 0.5 * vt and vt > 3.0 and \
                v["state"] == "FOLLOWING":
            v["timers"]["lc_want"] = v["timers"].get("lc_want", 0) + 1
            if v["timers"]["lc_want"] > 40:
                v["timers"]["lc_want"] = 0
                for side in ("inner", "outer"):
                    tgt = lane.get("adjacent", {}).get(side)
                    if tgt and self.request_lane_change(v, tgt):
                        break
        else:
            v["timers"]["lc_want"] = 0
        rem = lane["length_m"] - v["s"]
        mid = self.current_move(v)
        # junction approach
        if mid is not None and rem < 60.0:
            if v["state"] == "FOLLOWING":
                transition(v, "APPROACHING_JUNCTION", mid)
            if self.movements[mid]["control"] == "MERGE" and \
                    v["state"] == "APPROACHING_JUNCTION":
                transition(v, "MERGING", mid)
                self._merge_step(v)
                return
            ok, why = self.junction_decision(v, mid, rem)
            if not ok:
                # must stop at stop line
                stop_s = lane["length_m"] - 1.5
                d = stop_s - v["s"]
                if d <= 0.6:
                    v["speed"] = 0.0
                    if v["state"] != "WAITING":
                        transition(v, "WAITING", why)
                    m = self.movements[mid]
                    if m["junction"]:
                        self.queue_join(v, m["junction"])
                    return
                vt = min(vt, max(0.0, math.sqrt(max(0.0, 2 * 3.0 * d))))
                if v["state"] == "WAITING":
                    transition(v, "APPROACHING_JUNCTION", "creep")
            else:
                if v["state"] == "WAITING":
                    leader_q = None
                    m = self.movements[mid]
                    if m["junction"]:
                        leader_q = self.queue_leader(m["junction"], v["lane"])
                    if leader_q is None or leader_q == v["id"]:
                        self.queue_leave(v)
                        transition(v, "APPROACHING_JUNCTION", "released:" + why)
                    else:
                        vt = 0.0
        if v["state"] == "STOPPED" and vt > 0.5:
            transition(v, "FOLLOWING", "rolling")
        # integrate
        spec = v["spec"]
        if vt > v["speed"]:
            v["speed"] = min(vt, v["speed"] + spec.accel_ms2 * FIXED_STEP)
        else:
            v["speed"] = max(vt, v["speed"] - spec.brake_ms2 * 0.8 * FIXED_STEP)
        v["s"] += v["speed"] * FIXED_STEP
        v["pos"] = self.pos_at(v["lane"], v["s"])
        v["heading"] = self.lane_heading(v["lane"], v["s"])
        self._sector_sync(v)
        # lane end: take movement or finish
        if v["s"] >= lane["length_m"] - 0.5:
            self._arrive_lane_end(v, mid)

    def junction_decision(self, v, mid, rem):
        self.counters["junction_decisions"] += 1
        m = self.movements[mid]
        ctl = m["control"]
        if ctl in ("UNCONTROLLED", "UNCONTROLLED_THROUGH"):
            return True, "free"
        if ctl == "SIGNAL":
            asp = self.sig_aspect(mid)
            if asp in ("GREEN", "PROTECTED"):
                return True, asp
            if asp == "YELLOW":
                # stop if able
                if v["spec"].braking_distance(v["speed"]) < rem:
                    return False, "yellow-stop"
                return True, "yellow-clear"
            return False, "red"
        if ctl == "YIELD":
            # gap on target lane near exit point
            if self.lane_occupancy(m["to_lane"], 0, 25.0, exclude=v["id"]):
                return False, "yield-gap"
            return True, "yield-ok"
        if ctl == "MERGE":
            return self._merge_gap(v, m)
        return True, "default-go"

    def _merge_gap(self, v, m):
        occ = self.lane_occupancy(m["to_lane"], 0, 30.0, exclude=v["id"])
        if occ == 0:
            return True, "merge-clear"
        # require time gap: check nearest approacher speed (conservative)
        return False, "merge-wait"

    def _arrive_lane_end(self, v, mid):
        if mid is None:
            # lane-change pseudo step or route lane advance
            self._advance_route(v, None)
            return
        m = self.movements[mid]
        self.queue_leave(v)
        cpts = m.get("turn_pts") or (
            self.connectors.get(m["connector_ref"])
            if m["connector_ref"] else None)
        if cpts and len(cpts) >= 2:
            v["turn_pts"] = cpts
            v["turn_i"] = 0
            transition(v, "TURNING", mid)
            self.emit("junction_entry", v["id"], {"move": mid})
        else:
            self._advance_route(v, mid)

    def _advance_route(self, v, mid):
        r = v["route"]
        self._index_del(v)
        if mid is not None:
            nl = self.movements[mid]["to_lane"]
            r["i"] += 1
        else:
            # lane-change step: next route lane
            if r["i"] + 1 < len(r["lanes"]):
                r["i"] += 1
                nl = r["lanes"][r["i"]]
            else:
                v["route_done"] = True
                v["s"] = self.lanes[v["lane"]]["length_m"] - 0.5
                v["speed"] = 0.0
                self._index_add(v)
                self.emit("route_complete", v["id"], {})
                if v["state"] != "STOPPED":
                    transition(v, "STOPPING", "route complete")
                return
        v["lane"] = nl
        v["s"] = 0.0
        v["pos"] = self.pos_at(nl, 0.0)
        v["heading"] = self.lane_heading(nl, 0.0)
        self._sector_sync(v)
        self._struct_pin_sync(v)
        self._index_add(v)
        if r["i"] >= len(r["lanes"]) - 1 and mid is not None:
            # reached final lane; finish when it ends
            pass
        if v.get("turn_pts"):
            del v["turn_pts"]
        self.emit("junction_exit", v["id"], {"lane": nl})
        if nl == r["dest"] and r["i"] >= len(r["lanes"]) - 1:
            v["pending_done"] = True
        transition(v, "FOLLOWING", "advanced")

    def _turn_step(self, v):
        pts = v.get("turn_pts", [])
        i = v.get("turn_i", 0)
        step = max(0.5, v["speed"] * FIXED_STEP)
        # walk pts by distance
        d = 0.0
        while i < len(pts) - 1 and d < step:
            d += math.dist((pts[i][0], pts[i][2]),
                           (pts[i + 1][0], pts[i + 1][2]))
            i += 1
        v["turn_i"] = i
        v["pos"] = list(pts[min(i, len(pts) - 1)])
        vt = min(8.0, v["speed"] + v["spec"].accel_ms2 * FIXED_STEP)
        v["speed"] = vt
        if i >= len(pts) - 1:
            mid = self.current_move(v)
            self._advance_route(v, mid)

    def _struct_pin_sync(self, v):
        edge = v["lane"].rsplit(":", 2)[0]
        want = self.struct_edges.get(edge)
        have = [p for p in v["pins"] if p[2].startswith("struct:")]
        if want and not have:
            self.pin(v, v["sector"], "struct:%s:%s" % (want[0], want[1]))
        elif not want and have:
            for pid, sid, reason in list(have):
                self.unpin(v, sid)

    def _sector_sync(self, v):
        if not v["pos"]:
            return
        sx, sz = self.grid.sector_of(v["pos"][0], v["pos"][2])
        sid = "SX%02dZ%02d" % (sx, sz)
        if sid != v["sector"]:
            self._index_del(v)
            v["sector"] = sid
            self._index_add(v)
    # ---------------- lane change / merge ----------------
    def request_lane_change(self, v, target):
        lane = self.lanes[v["lane"]]
        if lane["length_m"] - v["s"] < 30.0:
            return False  # policy: none near unresolved junction
        if self.lane_occupancy(target, v["s"] - 8.0, v["s"] + 12.0,
                               exclude=v["id"]):
            return False
        v["lc_target"] = target
        v["lc_t"] = 0.0
        self._index_del(v)
        transition(v, "CHANGING_LANE", target)
        self.emit("lane_change_start", v["id"], {"to": target})
        return True

    def _lc_step(self, v):
        tgt = v.get("lc_target")
        dur = v["spec"].lane_change_s
        v["lc_t"] += FIXED_STEP / dur
        if v["lc_t"] < 0.4 and self.lane_occupancy(
                tgt, v["s"] - 8.0, v["s"] + 12.0, exclude=v["id"]):
            # cancel: gap lost early
            v["lc_target"] = None
            self._index_add(v)
            transition(v, "FOLLOWING", "lc-cancel")
            self.emit("lane_change_cancel", v["id"], {})
            return
        v["s"] += v["speed"] * FIXED_STEP
        p0 = self.pos_at(v["lane"], v["s"])
        p1 = self.pos_at(tgt, v["s"])
        t = min(1.0, v["lc_t"])
        v["pos"] = [p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t,
                    p0[2] + (p1[2] - p0[2]) * t]
        if v["lc_t"] >= 1.0:
            r = v.get("route")
            v["lane"] = tgt
            v["lc_target"] = None
            if v["pos"]:
                sx, sz = self.grid.sector_of(v["pos"][0], v["pos"][2])
                v["sector"] = "SX%02dZ%02d" % (sx, sz)
            self._index_add(v)
            if r and tgt != r["lanes"][r["i"]]:
                res = self.router.plan(tgt, r["dest"], v["spec"],
                                       seed_tag="lc:%s:%d" % (v["id"],
                                                             self.tick_n))
                if res["lanes"]:
                    v["route"] = {"lanes": res["lanes"], "moves": res["moves"],
                                  "i": 0, "dest": r["dest"]}
                    self.emit("route_replanned", v["id"], {"lane": tgt})
                else:
                    v["route"]["lanes"][r["i"]] = tgt
                    self.emit("route_rebased", v["id"], {"lane": tgt})
            transition(v, "FOLLOWING", "lc-done")
            self.emit("lane_change_done", v["id"], {"lane": tgt})

    def _merge_step(self, v):
        mid = self.current_move(v)
        m = self.movements[mid]
        ok, why = self._merge_gap(v, m)
        if ok:
            self._arrive_lane_end(v, mid)
        else:
            v["speed"] = max(0.0, v["speed"] - 3.0 * FIXED_STEP)
            m2 = self.movements[mid]
            if m2["junction"]:
                self.queue_join(v, m2["junction"])

    # ---------------- stuck / wrong-way ----------------
    def _monitor(self, v):
        t = v["timers"]
        last_s = t.get("mon_s", v["s"])
        last_tick = t.get("mon_tick", self.tick_n)
        if self.tick_n - last_tick >= 50:
            moved = abs(v["s"] - last_s)
            want_move = v["state"] in ("FOLLOWING", "APPROACHING_JUNCTION",
                                       "TURNING", "MERGING")
            if want_move and moved < 0.5 and v["speed"] < 0.3:
                t["stuck_ticks"] = t.get("stuck_ticks", 0) + 50
                if t["stuck_ticks"] >= 100:
                    v["flags"]["stuck"] = True
                    self.emit("stuck", v["id"],
                              {"at": v["lane"], "s": round(v["s"], 1)})
                    transition(v, "RECOVERING", "stuck")
            else:
                t["stuck_ticks"] = 0
            t["mon_s"] = v["s"]
            t["mon_tick"] = self.tick_n
        # wrong-way: heading vs lane tangent
        if v["state"] in ("FOLLOWING", "APPROACHING_JUNCTION"):
            tan = self.lane_heading(v["lane"], v["s"])
            dh = abs((v["heading"] - tan + math.pi) % (2 * math.pi) - math.pi)
            if dh > 2.2:
                t["ww_ticks"] = t.get("ww_ticks", 0) + 1
                if t["ww_ticks"] >= 10:
                    v["flags"]["wrong_way"] = True
                    self.emit("wrong_way", v["id"], {"dh": round(dh, 2)})
                    transition(v, "RECOVERING", "wrong-way")
            else:
                t["ww_ticks"] = 0

    def _recover_step(self, v):
        ladder = v["timers"].get("rec_step", 0)
        if ladder == 0:
            # re-evaluate leader: brief stop then continue
            v["speed"] = 0.0
            v["timers"]["rec_step"] = 1
            v["flags"].pop("stuck", None)
            v["flags"].pop("wrong_way", None)
        elif ladder == 1:
            # re-route
            if self.assign_route(v):
                v["timers"]["rec_step"] = 0
                v["timers"]["stuck_ticks"] = 0
                transition(v, "ROUTING", "recovered-reroute")
                self.emit("recovered", v["id"], {})
            else:
                v["timers"]["rec_step"] = 2
        else:
            self.emit("recovery_failed", v["id"], {})
            self.retire(v, "recovery_failed")

    # ---------------- tiers ----------------
    def tier_of(self, v):
        if not v["pos"]:
            return "FULL"
        if v["state"] in ("INITIALIZING", "ROUTING", "RECOVERING", "TURNING",
                          "CHANGING_LANE", "MERGING", "WAITING"):
            d = math.hypot(v["pos"][0] - self.focus[0],
                           v["pos"][2] - self.focus[1])
            return "FULL" if d < 150.0 else "SIMPLIFIED"
        d = math.hypot(v["pos"][0] - self.focus[0],
                       v["pos"][2] - self.focus[1])
        if d < 150.0:
            return "FULL"
        if d < 400.0:
            return "SIMPLIFIED"
        if d < 800.0:
            return "PROXY"
        return "ABSTRACT"

    def _update_tiered(self, v):
        new = self.tier_of(v)
        if new != v["tier"]:
            self.emit("tier_change", v["id"], {"frm": v["tier"], "to": new})
            v["tier"] = new
        if v["state"] == "FAILED":
            n = v["timers"].get("rec_attempts", 0)
            if n >= 3:
                self.retire(v, "failed-exhausted")
                return
            v["timers"]["rec_attempts"] = n + 1
            v["timers"]["rec_step"] = 0
            transition(v, "RECOVERING", "auto-recover")
            return
        if v["tier"] == "FULL":
            self.update_full(v)
            self._monitor(v)
        elif v["tier"] == "SIMPLIFIED":
            if self.tick_n % 2 == 0:
                self.update_full(v)
        elif v["tier"] == "PROXY":
            if self.tick_n % 10 == 0:
                self._proxy_step(v, 10)
        else:
            if self.tick_n % 50 == 0:
                self._proxy_step(v, 50)

    def _proxy_step(self, v, nticks):
        if v["state"] not in ACTIVE or v["state"] in (
                "WAITING", "STOPPED", "STOPPING", "TURNING",
                "CHANGING_LANE", "MERGING"):
            return
        lane = self.lanes[v["lane"]]
        i = self._segantil(lane["pts"], v["s"])
        vt = lane["v_target_ms"][min(i, len(lane["v_target_ms"]) - 1)]
        v["speed"] = vt
        v["s"] += vt * FIXED_STEP * nticks
        if v["s"] >= lane["length_m"] - 0.5:
            mid = self.current_move(v)
            if mid is None and v.get("pending_done"):
                v["route_done"] = True
                return
            self._arrive_lane_end(v, mid)
            if v["state"] == "TURNING":
                # proxy skips connector detail: jump to exit lane
                self._advance_route(v, mid)
        else:
            v["pos"] = self.pos_at(v["lane"], v["s"])
            self._sector_sync(v)
    # ---------------- congestion + main tick ----------------
    def refresh_congestion(self):
        occ = {}
        for sec, lanes in self.index.items():
            for lid, cell in lanes.items():
                L = self.lanes[lid]["length_m"]
                occ[lid] = min(1.0, len(cell) * 8.0 / max(1.0, L))
        self.congestion = occ
        self.router.set_congestion(occ, self.tick_n)

    def spawn_tick(self):
        budget = self.tc["spawn_policy"]["attempt_budget_per_tick"]
        if getattr(self, "auto_spawn", True):
            self.request_spawns()
        n = 0
        still = []
        for zid, cls in self.spawn_queue:
            if n >= budget:
                still.append((zid, cls))
                continue
            if self.try_spawn(zid, cls):
                n += 1
            else:
                still.append((zid, cls))
        self.spawn_queue = still[-200:]

    def tick(self):
        self.tick_n += 1
        self._sig_tick()
        if self.tick_n % 50 == 0:
            self.refresh_congestion()
        self.spawn_tick()
        for vid in sorted(self.vehicles.keys()):
            v = self.vehicles.get(vid)
            if v is None:
                continue
            try:
                self._update_tiered(v)
            except Exception as e:
                import traceback as _tb
                v["diag"].append("tick-exc: %r | %s" % (
                    e, _tb.format_exc(limit=9).replace("\n", " <- ")))
                transition(v, "FAILED", "tick exception")
        self.despawn_tick()
        if self.streaming is not None and hasattr(self.streaming, "tick"):
            pass  # streaming advances on its own schedule; pins queried live

    # ---------------- diagnostics ----------------
    def stats(self):
        return {"tick": self.tick_n, "vehicles": len(self.vehicles),
                "counters": dict(self.counters),
                "spawn": dict(self.spawn_stats), "despawn": dict(self.despawn_stats),
                "route_failures": self.route_failures,
                "events": len(self.events), "dropped_events": self.dropped_events,
                "router": dict(self.router.stats),
                "pool": dict(self.pool.stats),
                "queues": sum(len(q) for q in self.queues.values()),
                "pins": sum(len(v["pins"]) for v in self.vehicles.values())}

    def check_leaks(self):
        bad = []
        for v in self.vehicles.values():
            if v["state"] == "DESPAWNED":
                bad.append(("despawned-live", v["id"]))
        for key, q in self.queues.items():
            for vid in q:
                if vid not in self.vehicles:
                    bad.append(("orphan-queue", vid))
        seen = {}
        for sec, lanes in self.index.items():
            for lid, cell in lanes.items():
                for vid in cell:
                    if vid in seen:
                        bad.append(("dup-index", vid))
                    seen[vid] = True
                    if vid not in self.vehicles:
                        bad.append(("orphan-index", vid))
        for vid in self.vehicles:
            if vid not in seen and self.vehicles[vid]["state"] not in (
                    "SPAWNED", "INITIALIZING", "CHANGING_LANE", "TURNING"):
                bad.append(("missing-index", vid))
        return bad
