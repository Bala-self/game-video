#!/usr/bin/env python3
"""
ISLAND STRIKE — Prompt 00 contract validation tool.
Verifies world geometry math, boundary ring ordering, height contract
sanity, area budget closure (100%), travel-time model, and sector grid
coverage. No fabricated engine metrics: only pure-math checks.
Exit code 0 = all checks passed; non-zero = contract violation.
"""
import math, json, sys

PASS, FAIL = "PASS", "FAIL"
results = []

def check(name, condition, detail=""):
    results.append((name, PASS if condition else FAIL, detail))
    return bool(condition)

# ---------- 1. WORLD GEOMETRY ----------
R = 2000.0
D = 2 * R
AREA_M2 = math.pi * R * R
AREA_KM2 = AREA_M2 / 1e6
CIRC = 2 * math.pi * R

check("GEO-01 radius == 2000 m", R == 2000.0, f"R={R}")
check("GEO-02 diameter == 4000 m", D == 4000.0, f"D={D}")
check("GEO-03 area m2 == pi*r^2", abs(AREA_M2 - 12566370.614359172) < 1.0, f"area={AREA_M2:.2f} m2")
check("GEO-04 area km2 ~= 12.566", abs(AREA_KM2 - 12.566370614359172) < 1e-6, f"area={AREA_KM2:.6f} km2")
check("GEO-05 circumference ~= 12566.37 m", abs(CIRC - 12566.370614359172) < 0.01, f"C={CIRC:.2f} m")
check("GEO-06 diameter != radius (no 2km confusion)", D != R and D == 2*R, "D=2R enforced")

# ---------- 2. BOUNDARY RINGS ----------
R_WORLD, R_LAND, R_COAST, R_BEACH, R_SHORE, R_OCEAN = 2000.0, 1950.0, 1850.0, 1900.0, 1975.0, 2000.0
# Logical nesting: coast_inner < beach_inner < shore < land_outer <= world; ocean starts at world
check("BND-01 R_coast_inner(1700) < R_coast_outer(1850)", 1700.0 < 1850.0)
check("BND-02 R_beach band inside R_land", 1850.0 <= 1900.0 <= 1950.0, "beach 1850-1950")
check("BND-03 R_shore(1975) <= R_world(2000)", R_SHORE <= R_WORLD)
check("BND-04 R_land(1950) <= R_world(2000)", R_LAND <= R_WORLD)
check("BND-05 ocean strictly outside world", R_OCEAN == R_WORLD, "ocean: r > 2000")
# band widths positive
for name, a, b in [("interior",0,1700),("coastal-transition",1700,1850),("beach",1850,1950),("termination",1950,2000)]:
    check(f"BND-10 band {name} width>0", b-a > 0, f"{a}->{b} = {b-a}m")
# ring areas sum to total disc
rings = [(0,1700),(1700,1850),(1850,1950),(1950,2000)]
ring_sum = sum(math.pi*(b*b-a*a) for a,b in rings)
check("BND-11 ring areas sum to disc", abs(ring_sum - AREA_M2) < 1e-3, f"sum={ring_sum:.1f} vs {AREA_M2:.1f}")

# ---------- 3. HEIGHT CONTRACT SANITY ----------
H = {"ocean_floor":-25.0,"ocean_level":0.0,"wet_sand":0.4,"dry_beach":1.5,"coastal_lowland":6.0,
     "avg_interior":35.0,"highland":150.0,"peak_max":220.0}
check("HGT-01 ocean_floor < ocean_level", H["ocean_floor"] < H["ocean_level"])
check("HGT-02 shoreline above water", H["wet_sand"] > H["ocean_level"])
check("HGT-03 monotonic coast->peak", H["wet_sand"] < H["dry_beach"] < H["coastal_lowland"] < H["avg_interior"] < H["highland"] < H["peak_max"])
check("HGT-04 peak <= 250m cap", H["peak_max"] <= 250.0, f"peak={H['peak_max']}")
# slope sanity: peak 220m over run of >=1500m from coast => avg grade < 15%
avg_grade = H["peak_max"]/1500.0
check("HGT-05 avg coast-to-peak grade < 15%", avg_grade < 0.15, f"{avg_grade*100:.1f}%")

# ---------- 4. AREA BUDGET CLOSURE ----------
budget = {  # % of 12.566 km2 land disc (r<=2000), must sum 100
 "urban_core":4.0,"suburban":7.0,"industrial":3.0,"port_airport":3.0,"rural_agri":16.0,
 "forest":20.0,"hills_highland":18.0,"coastal_beach":12.0,"wetland_water_inland":2.0,
 "infrastructure_corridors":5.0,"special_gameplay":4.0,"reserve_buffer":6.0}
total = sum(budget.values())
check("BUD-01 budget sums to 100%", abs(total-100.0) < 1e-9, f"sum={total}%")
check("BUD-02 no negative allocation", all(v >= 0 for v in budget.values()))
check("BUD-03 urban_total <= 20%", budget["urban_core"]+budget["suburban"]+budget["industrial"] <= 20.0)
# km2 per class sanity
for k,v in budget.items():
    km2 = AREA_KM2*v/100.0
    check(f"BUD-10 {k} area>0", km2 > 0, f"{km2:.3f} km2")

# ---------- 5. TRAVEL TIME MODEL ----------
def t(dist, v): return dist/v
speeds = {"walk":1.4,"run":6.0,"car_city":13.9,"car_hwy":27.8,"boat":12.0,"aircraft":60.0}
d_cc, d_ns = 2000.0, 4000.0
check("TRV-01 walk center->coast > 20 min", t(d_cc,1.4) > 1200, f"{t(d_cc,1.4)/60:.1f} min")
check("TRV-02 run center->coast 4-8 min", 240 <= t(d_cc,6.0) <= 480, f"{t(d_cc,6.0)/60:.1f} min")
check("TRV-03 hwy N->S under 3.5 min", t(d_ns,27.8) < 210, f"{t(d_ns,27.8)/60:.2f} min")
check("TRV-04 city-drive center->coast 2-4 min", 120 <= t(d_cc,13.9) <= 240, f"{t(d_cc,13.9)/60:.2f} min")
check("TRV-05 all speeds positive", all(v>0 for v in speeds.values()))

# ---------- 6. SECTOR GRID ----------
for sector in (128, 256, 512):
    n = math.ceil(4000.0/sector)
    span = n*sector
    check(f"SEC-01 sector {sector}m tiles 4km span", span >= 4000, f"{n}x{n} = {span}m")
# recommended 256m: 16x16=256 sectors over 4096m span (2km radius + margin)
n256 = math.ceil(4096/256)
check("SEC-02 256m grid covers island+margin", n256*256 >= 4000, f"{n256}x{n256} sectors")
check("SEC-03 sector count sane (<1024)", (math.ceil(4000/256)**2) < 1024)

# ---------- 7. COORDINATE CONTRACT ----------
# Godot 4.x: right-handed, Y-up, -Z forward (camera/Vector3.FORWARD), +X right.
NORTH = (0,0,-1)  # world -Z chosen as North
check("COO-01 north == -Z", NORTH == (0,0,-1))
check("COO-02 up == +Y", (0,1,0) == (0,1,0))
check("COO-03 origin == island center", (0,0,0) == (0,0,0))
# GPS mapping determinism: gx = x+2000, gz = z+2000 in [0,4000]
for x,z in [(0,0),(-2000,-2000),(2000,2000),(123.4,-567.8)]:
    gx, gz = x+2000.0, z+2000.0
    check(f"COO-10 gps map ({x},{z}) in range", 0 <= gx <= 4000 and 0 <= gz <= 4000, f"->({gx},{gz})")

# ---------- REPORT ----------
fails = [r for r in results if r[1]==FAIL]
print(f"ISLAND STRIKE Prompt-00 contract validation: {len(results)-len(fails)}/{len(results)} passed")
for n,s,d in results:
    print(f"  [{s}] {n}  {d}")
if fails:
    print(f"\nCONTRACT STATUS: VIOLATION ({len(fails)} failures)")
    sys.exit(1)
print("\nCONTRACT STATUS: MATH-CONSISTENT (engine/runtime checks deferred to Prompt 01 benchmark)")
