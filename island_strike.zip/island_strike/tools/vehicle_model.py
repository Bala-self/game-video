#!/usr/bin/env python3
"""ISLAND STRIKE P08 — vehicle class model, state machine, lifecycle, pooling.

Pure data + logic (no world I/O). The runtime world lives in traffic_sim.py.
States and transitions implement traffic_contract junction/lifecycle policy.
"""
import math

STATES = ("SPAWNED", "INITIALIZING", "ROUTING", "FOLLOWING",
          "APPROACHING_JUNCTION", "WAITING", "TURNING", "CHANGING_LANE",
          "MERGING", "STOPPING", "STOPPED", "RECOVERING", "DESPAWNING",
          "DESPAWNED", "FAILED")

# Legal transitions: state -> set(next). FAILED/DESPAWNED are terminal sinks
# (FAILED may go to RECOVERING or DESPAWNING exactly once via recover/retire).
TRANSITIONS = {
    "SPAWNED": {"INITIALIZING", "DESPAWNING", "FAILED"},
    "INITIALIZING": {"ROUTING", "DESPAWNING", "FAILED"},
    "ROUTING": {"FOLLOWING", "APPROACHING_JUNCTION", "DESPAWNING", "FAILED"},
    "FOLLOWING": {"APPROACHING_JUNCTION", "TURNING", "CHANGING_LANE",
                  "MERGING", "STOPPING", "RECOVERING", "DESPAWNING",
                  "FAILED"},
    "APPROACHING_JUNCTION": {"WAITING", "TURNING", "STOPPING", "FOLLOWING",
                             "RECOVERING", "DESPAWNING", "FAILED"},
    "WAITING": {"APPROACHING_JUNCTION", "TURNING", "FOLLOWING", "RECOVERING",
                "DESPAWNING", "FAILED"},
    "TURNING": {"FOLLOWING", "APPROACHING_JUNCTION", "RECOVERING",
                "DESPAWNING", "FAILED"},
    "CHANGING_LANE": {"FOLLOWING", "APPROACHING_JUNCTION", "RECOVERING",
                      "DESPAWNING", "FAILED"},
    "MERGING": {"FOLLOWING", "APPROACHING_JUNCTION", "RECOVERING",
                "DESPAWNING", "FAILED"},
    "STOPPING": {"STOPPED", "FOLLOWING", "RECOVERING", "DESPAWNING", "FAILED"},
    "STOPPED": {"FOLLOWING", "APPROACHING_JUNCTION", "RECOVERING",
                "DESPAWNING", "FAILED"},
    "RECOVERING": {"FOLLOWING", "ROUTING", "STOPPING", "DESPAWNING", "FAILED"},
    "DESPAWNING": {"DESPAWNED", "FAILED"},
    "DESPAWNED": set(),
    "FAILED": {"RECOVERING", "DESPAWNING"},
}

ACTIVE = frozenset(s for s in STATES if s not in ("DESPAWNING", "DESPAWNED"))


def is_legal(frm, to):
    return to in TRANSITIONS.get(frm, set())


class VehicleSpec:
    """Data-driven class parameters (single source: traffic_contract)."""

    FIELDS = ("length_m", "width_m", "height_m", "mass_kg", "accel_ms2",
              "brake_ms2", "top_speed_kph", "turn_radius_m", "reaction_s",
              "lane_change_s", "spawn_weight")

    def __init__(self, name, params):
        self.name = name
        for f in self.FIELDS:
            setattr(self, f, float(params[f]))
        self.top_speed_ms = self.top_speed_kph * 1000.0 / 3600.0
        self.tier = params.get("tier", "STANDARD")

    def braking_distance(self, v_ms, comfort=1.0):
        b = self.brake_ms2 * comfort
        return v_ms * v_ms / (2.0 * b) + v_ms * self.reaction_s

    def follow_gap(self, v_ms, standstill=2.5):
        # IDM-style: standstill + reaction*v + braking-difference margin
        return standstill + v_ms * self.reaction_s + (v_ms * v_ms) / (2.0 * self.brake_ms2) * 0.5

    def curve_speed(self, radius_m, a_lat=2.5):
        if radius_m is None or radius_m == float("inf") or radius_m <= 0:
            return self.top_speed_ms
        return min(self.top_speed_ms, math.sqrt(a_lat * radius_m))


def new_vehicle(veh_id, spec):
    return {"id": veh_id, "class": spec.name, "state": "SPAWNED",
            "spec": spec, "route": None, "lane": None, "s": 0.0,
            "pos": None, "heading": 0.0, "speed": 0.0,
            "sector": None, "tier": "FULL", "queue": None,
            "signal_state": None, "timers": {}, "flags": {},
            "pins": [], "diag": []}


def reset_vehicle(v):
    keep = {"id", "class", "spec"}
    for k in [k for k in v if k not in keep]:
        del v[k]
    v.update({"state": "SPAWNED", "route": None, "lane": None, "s": 0.0,
              "pos": None, "heading": 0.0, "speed": 0.0,
              "sector": None, "tier": "FULL", "queue": None,
              "signal_state": None, "timers": {}, "flags": {},
              "pins": [], "diag": []})
    return v


def transition(v, new_state, reason=""):
    frm = v["state"]
    if new_state == frm:
        return True, ""
    if new_state not in STATES:
        d = "unknown state %s" % new_state
        v["diag"].append(d)
        return False, d
    if not is_legal(frm, new_state):
        d = "ILLEGAL %s->%s (%s)" % (frm, new_state, reason)
        v["diag"].append(d)
        v["state"] = "FAILED"
        v["flags"]["failed_transition"] = [frm, new_state, reason]
        return False, d
    v["state"] = new_state
    if reason:
        v["diag"].append("%s->%s %s" % (frm, new_state, reason))
    return True, ""


class VehiclePool:
    """Runtime pooling keyed by (class, tier_mode). Reset-validated both ways."""

    def __init__(self):
        self.free = {}
        self.live = {}
        self.seq = 0
        self.stats = {"acquired": 0, "released": 0, "reset_fail": 0}

    def acquire(self, spec, tier_mode="FULL"):
        key = (spec.name, tier_mode)
        stack = self.free.setdefault(key, [])
        self.seq += 1
        if stack:
            v = stack.pop()
            reset_vehicle(v)
            # unique id per generation: recycled dict, never recycled id
            v["id"] = "V%06d" % self.seq
        else:
            v = new_vehicle("V%06d" % self.seq, spec)
        # validate fully-reset state on acquire
        bad = [k for k, w in (("route", None), ("lane", None), ("queue", None),
                              ("signal_state", None), ("pins", []), ("pos", None))
               if v.get(k) != w]
        if bad or v["state"] != "SPAWNED":
            self.stats["reset_fail"] += 1
            reset_vehicle(v)
            v["diag"].append("acquire forced reset: %s" % (bad,))
        v["tier"] = tier_mode
        self.live[v["id"]] = v
        self.stats["acquired"] += 1
        return v

    def release(self, v):
        if v["id"] in self.live:
            del self.live[v["id"]]
        v["pins"] = []
        v["queue"] = None
        v["route"] = None
        v["lane"] = None
        v["signal_state"] = None
        v["timers"] = {}
        v["flags"] = {}
        reset_vehicle(v)
        key = (v["class"], v.get("tier", "FULL"))
        self.free.setdefault(key, []).append(v)
        self.stats["released"] += 1
