#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 03 — road network validator.

Suites: static | cross <godot-metrics.json> | inject | reproduce.
STATIC-ROAD validates data/derived/roads.json (built by road_model.py)
against data/world/road_contract.json + live terrain/coast (P02 LOCKED).
"""
import json
import math
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import Field, fnv1a_hex  # noqa: E402
from validate_terrain import sample_polyline, profile, ell_nd  # noqa: E402
from road_model import RoadNetwork, bore_grades, deflection_deg  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROAD_CC = os.path.join(ROOT, "data/world/road_contract.json")
ROAD_CC_SCHEMA = os.path.join(ROOT, "data/world/road_contract.schema.json")
ROAD_AU = os.path.join(ROOT, "data/roads/authoring.json")
ROADS_JSON = os.path.join(ROOT, "data/derived/roads.json")


class Tally:
    def __init__(self):
        self.n = 0
        self.bad = []

    def check(self, name, ok, detail=""):
        self.n += 1
        print("  [%s] %s  %s" % ("PASS" if ok else "FAIL", name, detail))
        if not ok:
            self.bad.append(name)

    def report(self, suite):
        print("%s: %d/%d passed" % (suite, self.n - len(self.bad), self.n))
        return not self.bad


def articulation_points(adj):
    disc, low, on = {}, {}, {}
    counter = [0]
    arts = set()

    def dfs(u, parent):
        disc[u] = low[u] = counter[0]
        counter[0] += 1
        kids = 0
        for v in adj.get(u, ()):
            if v == parent:
                continue
            if v in disc:
                low[u] = min(low[u], disc[v])
            else:
                kids += 1
                dfs(v, u)
                low[u] = min(low[u], low[v])
                if parent is None and kids > 1:
                    arts.add(u)
                if parent is not None and low[v] >= disc[u]:
                    arts.add(u)

    for u in adj:
        if u not in disc:
            dfs(u, None)
    return arts


def components(adj):
    seen, comps = set(), []
    for u in adj:
        if u in seen:
            continue
        stack, c = [u], set()
        while stack:
            w = stack.pop()
            if w in seen:
                continue
            seen.add(w)
            c.add(w)
            stack.extend(adj.get(w, ()))
        comps.append(c)
    return comps


def cmd_static():
    t = Tally()
    rc = json.load(open(ROAD_CC))
    ra = json.load(open(ROAD_AU))
    f = Field()
    r = json.load(open(ROADS_JSON))
    nodes, edges = r["nodes"], r["edges"]
    tol = rc["validation_thresholds"]["float_tol"]

    # ---- S: schema + versions ----
    try:
        import jsonschema
        jsonschema.validate(rc, json.load(open(ROAD_CC_SCHEMA)))
        t.check("S-schema:road_contract", True)
    except Exception as e:
        t.check("S-schema:road_contract", False, str(e)[:120])
    m = ra["meta"]
    t.check("S-ver:road", m["road_version"] == rc["road_version"] == r["meta"]["road_version"],
            r["meta"]["road_version"])
    t.check("S-ver:terrain-ref", m["terrain_version"] == rc["terrain_version_reference"]
            == f.tc["terrain_version"], f.tc["terrain_version"])
    t.check("S-ver:coast-ref", m["coast_version"] == rc["coast_version_reference"]
            == f.cc["coast_version"], f.cc["coast_version"])
    t.check("S-ver:world", m["world_version"] == rc["world_version"] == f.wc["world_version"])
    t.check("S-seed-ns", m["seed_namespace"] == rc["road_seed_namespace"] == "roads")
    t.check("S-gates-echo",
            r["meta"]["class_gates"] == {
                k: {"short": v["max_grade_short_pct"],
                    "sustained": v["max_grade_sustained_pct"],
                    "rmin": v["min_turning_radius_m"], "corner": v["max_corner_deg"]}
                for k, v in rc["road_classes"].items()},
            "export carries live contract gates (stale-copy detectable)")

    # ---- N: nodes ----
    ids = [n["id"] for n in ra["nodes"]]
    t.check("N-unique", len(ids) == len(set(ids)) and set(ids) == set(nodes),
            "%d nodes" % len(nodes))
    min_sp, urb_sp = rc["minimum_spacing"]["node_min_spacing_m"], \
        rc["minimum_spacing"]["urban_node_min_spacing_m"]
    worst, worst_pair = 1e9, None
    nl = sorted(nodes.values(), key=lambda n: n["id"])
    for i in range(len(nl)):
        for j in range(i + 1, len(nl)):
            d = math.hypot(nl[i]["x"] - nl[j]["x"], nl[i]["z"] - nl[j]["z"])
            if d < worst:
                worst, worst_pair = d, (nl[i]["id"], nl[j]["id"])
    urb = {n["id"] for n in nl if n["region"] == "urban_core"}
    ok_sp = True
    for i in range(len(nl)):
        for j in range(i + 1, len(nl)):
            d = math.hypot(nl[i]["x"] - nl[j]["x"], nl[i]["z"] - nl[j]["z"])
            floor = urb_sp if nl[i]["id"] in urb and nl[j]["id"] in urb else min_sp
            if d < floor:
                ok_sp = False
    t.check("N-spacing", ok_sp, "min=%.1fm %s" % (worst, worst_pair))
    allowed_t = set(rc["intersection_rules"]["allowed_types"]) | {"junction"}
    bad_t = [n["id"] for n in nl if n["type"] not in allowed_t]
    t.check("N-types", not bad_t, bad_t[:4])
    bad_r, bad_e, bad_d = [], [], []
    deg = {nid: 0 for nid in nodes}
    for e in edges.values():
        deg[e["from_node"]] = deg.get(e["from_node"], 0) + 1
        deg[e["to_node"]] = deg.get(e["to_node"], 0) + 1
    for n in nl:
        if f.region_at(n["x"], n["z"]) != n["region"]:
            bad_r.append(n["id"])
        if abs(f.height(n["x"], n["z"]) - n["elev"]) > 1e-6:
            bad_e.append(n["id"])
        if deg.get(n["id"], 0) != n["degree"]:
            bad_d.append(n["id"])
    t.check("N-regions", not bad_r, bad_r[:4])
    t.check("N-elevations", not bad_e, bad_e[:4])
    t.check("N-degrees", not bad_d, bad_d[:4])
    t.check("N-roundabout", nodes["hub_city"]["type"] == "roundabout"
            and nodes["hub_city"]["radius_m"] == 25.0
            and nodes["hub_city"]["degree"] == 6, "hub 6-arm roundabout")
    cap5 = rc["intersection_rules"]["max_approaches"]
    cap6 = rc["intersection_rules"]["roundabout_max"]
    bad_deg = [n["id"] for n in nl
               if n["degree"] > (cap6 if n["type"] == "roundabout" else cap5)]
    t.check("N-degree-caps", not bad_deg, bad_deg[:4])
    cmd_static_edges(t, rc, ra, f, r, nodes, edges, deg)
    cmd_static_gates(t, rc, ra, f, r, nodes, edges, deg)
    cmd_static_net(t, rc, ra, f, r, nodes, edges, deg)
    return t, rc, ra, f, r, nodes, edges, deg


def cmd_static_edges(t, rc, ra, f, r, nodes, edges, deg):
    tol = rc["validation_thresholds"]["float_tol"]
    allow_acc = set(rc["access_profiles"]["edge_values"])
    # ---- E: edge ownership ----
    eids = sorted(edges)
    t.check("E-unique", len(eids) == len(set(eids)), "%d edges" % len(eids))
    bad_ref = [eid for eid, e in edges.items()
               if e["from_node"] not in nodes or e["to_node"] not in nodes]
    t.check("E-refs", not bad_ref, bad_ref[:4])
    self_e = [eid for eid, e in edges.items() if e["from_node"] == e["to_node"]]
    t.check("E-no-self", not self_e, self_e[:4])
    zero = [eid for eid, e in edges.items() if e["length_m"] < 1.0]
    t.check("E-no-zero", not zero, zero[:4])
    bad_v = [eid for eid, e in edges.items() if e["geometry_version"] != 1]
    t.check("E-geomver", not bad_v, bad_v[:4])
    bad_a = [eid for eid, e in edges.items()
             if e["access"] not in allow_acc or e["class"] not in rc["road_classes"]]
    t.check("E-class-access", not bad_a, bad_a[:4])
    # metrics recomputation from exported samples (independent re-proof)
    bad_L, bad_g, bad_elev, bad_mono = [], [], [], []
    for eid in eids:
        e = edges[eid]
        sl = e["samples"]
        Lc = sum(math.hypot(sl[i + 1]["x"] - sl[i]["x"], sl[i + 1]["z"] - sl[i]["z"])
               for i in range(len(sl) - 1))
        if abs(Lc - e["length_m"]) / max(1.0, Lc) > tol:
            bad_L.append(eid)
        if abs(sl[0]["elev"] - e["elev_start"]) > 1e-6 or \
           abs(sl[-1]["elev"] - e["elev_end"]) > 1e-6:
            bad_elev.append(eid)
        if any(sl[i + 1]["d"] <= sl[i]["d"] for i in range(len(sl) - 1)):
            bad_mono.append(eid)
        pts = [(s["x"], s["z"]) for s in sl]
        if e["tunnel"]:
            hs = [s["elev"] for s in sl]
            ds = [s["d"] - sl[0]["d"] for s in sl]
            _, gr, roll = bore_grades(hs, ds)
            if gr and (abs(max(gr) - e["grade_short_all"]) > 1e-6
                       or abs(max(roll) - e["grade_sustained_all"]) > 1e-6):
                bad_g.append(eid)
    # surface grades: route-full re-profile (P02 method), then slice maxima.
    # Slice-local profiling would truncate the smoothing window at junctions.
    by_route = {}
    for eid in eids:
        by_route.setdefault(edges[eid]["route"], []).append(eid)
    for rid, rids in sorted(by_route.items()):
        rids.sort()
        if edges[rids[0]]["tunnel"]:
            continue
        full = []
        for eid in rids:
            sl = edges[eid]["samples"]
            full.extend(sl if not full else sl[1:])
        pts = [(s["x"], s["z"]) for s in full]
        _, _, gr, roll = profile(f, pts)
        off = 0
        for eid in rids:
            n = len(edges[eid]["samples"])
            gs = gr[off:off + n - 1]
            rs = roll[off:off + n - 1]
            off += n - 1
            e = edges[eid]
            if gs and (abs(max(gs) - e["grade_short_all"]) > 1e-6
                       or abs(max(rs) - e["grade_sustained_all"]) > 1e-6):
                bad_g.append(eid)
    t.check("E-length-recompute", not bad_L, bad_L[:4])
    t.check("E-elev-ends", not bad_elev, bad_elev[:4])
    t.check("E-monotonic", not bad_mono, bad_mono[:4])
    t.check("E-grade-recompute", not bad_g, bad_g[:4])
    # terrain-follow: surface samples sit on the field (tunnel exempt)
    fol = rc["validation_thresholds"]["terrain_follow_tol_m"]
    bad_f = []
    for eid in eids:
        e = edges[eid]
        if e["tunnel"]:
            continue
        for s in e["samples"]:
            if abs(f.height(s["x"], s["z"]) - s["elev"]) > fol:
                bad_f.append(eid)
                break
    t.check("E-terrain-follow", not bad_f, bad_f[:4])
    # coast: sample coast_d recompute + setbacks
    bad_c, bad_s = [], []
    exc_routes = {rt["id"] for rt in ra["routes"] if "coast_exception" in rt}
    for eid in eids:
        e = edges[eid]
        for s in e["samples"]:
            rr = math.hypot(s["x"], s["z"])
            dd = f.loop.rs(f.loop.theta(s["x"], s["z"])) - rr
            if abs(dd - s["coast_d"]) > 1e-6:
                bad_c.append(eid)
                break
        need = rc["coast_rules"]["exception_floor_m"] if e["route"] in exc_routes \
            else rc["coast_rules"]["setback_m"][e["class"]]
        if e["coast_min_m"] < need - 1e-9:
            bad_s.append((eid, round(e["coast_min_m"], 1), need))
    t.check("E-coast-recompute", not bad_c, bad_c[:4])
    t.check("E-coast-setback", not bad_s, bad_s[:4])
    return t


def cmd_static_gates(t, rc, ra, f, r, nodes, edges, deg):
    # ---- G: grade gates per class (open alignment) ----
    bad_g = []
    for eid in sorted(edges):
        e = edges[eid]
        if e["tunnel"]:
            continue
        cap = rc["road_classes"][e["class"]]
        if e["max_grade_short"] > cap["max_grade_short_pct"] + 1e-9 or \
           e["max_grade_sustained"] > cap["max_grade_sustained_pct"] + 1e-9:
            bad_g.append((eid, round(e["max_grade_short"], 1),
                          round(e["max_grade_sustained"], 1)))
    t.check("G-grade-caps", not bad_g, bad_g[:4])
    # works exclusion honest: excluded samples really inside discs
    discs = []
    for c in f.au["corridors"]:
        if c["type"] == "tunnel":
            for pp, pr in zip(c["portals"], c["portal_works_r_m"]):
                discs.append(((float(pp[0]), float(pp[1])), float(pr)))
    bad_w = []
    for eid in sorted(edges):
        e = edges[eid]
        if e["tunnel"]:
            continue
        sl = e["samples"]
        inside = sum(1 for s in sl[:-1]
                     if any(math.hypot(s["x"] - w[0][0], s["z"] - w[0][1]) < w[1]
                            for w in discs))
        if inside != e["works_excluded"]:
            bad_w.append((eid, inside, e["works_excluded"]))
    t.check("G-works-honest", not bad_w, bad_w[:4])
    appr = [e["portal_approach_max"] for e in edges.values() if e["portal_approach_max"] > 0]
    t.check("G-portal-approach", all(a <= rc["grade_limits"]["portal_approach_max_pct"] + 1e-9
                                     for a in appr),
            "max=%.2f" % (max(appr) if appr else 0.0))
    # ---- V: curvature ----
    pol = rc["fillet_policy"]
    bad_r, bad_c, bad_inf = [], [], []
    for eid in sorted(edges):
        e = edges[eid]
        cap = rc["road_classes"][e["class"]]
        if e["class"] in pol["applies_to"] and not e["tunnel"]:
            if e["residual_open_max"] > pol["residual_cap_deg"] + 1e-9:
                bad_r.append((eid, e["residual_open_max"]))
        else:
            if e["residual_open_max"] > cap["max_corner_deg"] + 1e-9:
                bad_r.append((eid, e["residual_open_max"]))
        for sk in e["skipped_corners"]:
            if "junction" in sk.get("reason", ""):
                continue
            ax, az = sk["anchor"]
            in_w = any(math.hypot(ax - w[0][0], az - w[0][1]) < w[1] for w in discs)
            if "FILLET_INFEASIBLE" in sk.get("reason", ""):
                if not in_w:
                    bad_inf.append((eid, sk["anchor"]))
                continue
            if in_w:
                continue  # works-disc geometry owned by P04 earthworks
            if sk["deflection_deg"] > cap["max_corner_deg"] + 1e-9:
                bad_c.append((eid, sk["deflection_deg"], sk.get("reason")))
    t.check("V-residual", not bad_r, bad_r[:4])
    t.check("V-skipped-caps", not bad_c, bad_c[:4])
    t.check("V-infeasible-in-works", not bad_inf, bad_inf[:4])
    # pinches: open non-junction length-capped + factor-consistent;
    # works-disc pinches recorded for P04 coordination instead
    bad_p, pinch_len, works_len = [], 0.0, 0.0
    for eid in sorted(edges):
        e = edges[eid]
        rmin = rc["road_classes"][e["class"]]["min_turning_radius_m"]
        tot = 0.0
        for p in e["pinches"]:
            if p["junction"]:
                continue
            if abs(p["curve_factor"] - round(max(0.3, p["min_r"] / rmin), 4)) > 1e-9:
                bad_p.append((eid, "factor"))
            if p["works"]:
                works_len += p["s1"] - p["s0"]
                continue
            tot += p["s1"] - p["s0"]
        pinch_len += tot
        if tot > 0.15 * e["length_m"] + 1e-9:
            bad_p.append((eid, round(tot, 1)))
    t.check("V-pinches", not bad_p, bad_p[:4] + ["open=%.0fm" % pinch_len])
    t.check("V-works-pinches", True, "works=%.0fm (P04 coordination)" % works_len)
    cf_bad = [eid for eid, e in edges.items()
              if abs(e["effective_speed_kph"]
                     - round(e["design_speed_kph"] * e["curve_factor"], 1)) > 1e-9]
    t.check("V-speed-consistent", not cf_bad, cf_bad[:4])
    # ---- B: beach / coast structure ----
    exc_routes = {rt["id"] for rt in ra["routes"] if "coast_exception" in rt}
    allow = rc["coast_rules"]["beach_sample_allowance"]
    bad_b = []
    for eid in sorted(edges):
        e = edges[eid]
        if e["beach_samples"] == 0:
            continue
        if e["route"] not in exc_routes:
            bad_b.append((eid, "no-exception"))
            continue
        if e["beach_samples"] > allow:
            bad_b.append((eid, e["beach_samples"]))
        if len(e["beach_spans"]) != 1:
            bad_b.append((eid, "spans=%d" % len(e["beach_spans"])))
        elif e["beach_spans"][0][1] < e["n_samples"] - 3:
            bad_b.append((eid, "not-coast-end"))
        term = nodes[e["to_node"]]
        rr = math.hypot(term["x"], term["z"])
        if f.loop.rs(f.loop.theta(term["x"], term["z"])) - rr \
                < rc["coast_rules"]["exception_floor_m"] - 1e-9:
            bad_b.append((eid, "terminal-floor"))
        if term["elev"] <= rc["validation_thresholds"]["waterline_tol_m"]:
            bad_b.append((eid, "terminal-water"))
    t.check("B-beach-structure", not bad_b, bad_b[:4])
    # ---- W: runway + water ----
    bad_rw = [(eid, e["runway_inside"]) for eid, e in edges.items() if e["runway_inside"]]
    t.check("W-runway-clear", not bad_rw, bad_rw[:4])
    # bridge spans all have candidate records with complete fields
    need = set(rc["bridge_policy"]["candidate_fields"])
    spanned = {eid for eid, e in edges.items() if "bridge_span" in e}
    covered = {b["road_edge"] for b in r["bridges"]}
    t.check("W-spans-covered", spanned == covered, "%d spans" % len(spanned))
    bad_bf = [b["id"] for b in r["bridges"] if set(b) < need or b["validation"] != "candidate"]
    t.check("W-bridge-fields", not bad_bf, bad_bf[:4])
    return t


def cmd_static_net(t, rc, ra, f, r, nodes, edges, deg):
    # ---- T: tunnel (terrain-contract bore rules, referenced live) ----
    tch = f.tc["validation"]["tunnel_checks"]
    te = next(e for e in edges.values() if e["tunnel"])
    tg = abs(te["elev_end"] - te["elev_start"]) / te["length_m"] * 100.0
    deep = [s["cover"] for s in te["samples"]
            if 150 < s["d"] - te["samples"][0]["d"]
            < (te["samples"][-1]["d"] - te["samples"][0]["d"]) - 150]
    tn = r["tunnels"][0]
    t.check("T-bore-grade", tg <= tch["bore_grade_pct"], "%.2f" % tg)
    t.check("T-cover", min(deep) >= tch["min_cover_m"], "%.0f" % min(deep))
    t.check("T-bend", te["bend_max_deg"] <= tch["max_bend_deg"], te["bend_max_deg"])
    pg = []
    for pid in ("jn_E_portal", "jn_W_portal"):
        p = nodes[pid]
        rr = math.hypot(p["x"], p["z"])
        dd = f.loop.rs(f.loop.theta(p["x"], p["z"])) - rr
        if dd < tch["portal_min_d_shore_m"]:
            pg.append((pid, "d_shore"))
        g = max(f.slope_grade(p["x"] + dx, p["z"] + dz)[1]
                for dx, dz in ((25, 0), (-25, 0), (0, 25), (0, -25)))
        if g > tch["portal_max_ground_pct"]:
            pg.append((pid, "ground"))
    t.check("T-portals", not pg, pg[:2])
    t.check("T-record", tn["road_edge"] == te["id"] and tn["validation"] == "pending"
            and abs(tn["grade_pct"] - tg) < 1e-6
            and abs(tn["terrain_cover_m"] - min(deep)) < 1e-6,
            "turns E=%.0f W=%.0f" % (tn["portal_turn_E_deg"], tn["portal_turn_W_deg"]))
    t.check("T-access", te["access"] == "PUBLIC" and te["class"] == "primary")
    # ---- X: P02 exclusion floors hold on filleted ring ----
    au = f.au
    excl = {}
    for rg in au["regions"]:
        for s in rg.get("shapes", []):
            tag = s.get("tag") or rg["id"]
            if rg["id"] == "urban_core" and tag == "urban_core":
                excl["urban"] = (s, 1.05)
            if tag == "port_shape":
                excl["port_shape"] = (s, 1.15)
            if tag == "resort_shape":
                excl["resort"] = (s, 1.10)
            if tag == "restricted_shape":
                excl["restricted"] = (s, 1.05)
    ringsamp = [s for eid, e in edges.items() if eid.startswith("E_ring_hw_0")
                for s in e["samples"]]
    bad_x = []
    for name, (s, floor) in sorted(excl.items()):
        m = min(ell_nd(x["x"], x["z"], s) for x in ringsamp)
        if m < floor:
            bad_x.append((name, round(m, 3), floor))
    lkm = min(ell_nd(x["x"], x["z"], lk) for x in ringsamp
              for lk in au["drainage"]["lakes"])
    if lkm < 1.30:
        bad_x.append(("lake", round(lkm, 3), 1.30))
    t.check("X-exclusions", not bad_x, bad_x[:4])
    # ---- K: graph + connectivity ----
    adj = {}
    for e in edges.values():
        adj.setdefault(e["from_node"], []).append(e["to_node"])
        adj.setdefault(e["to_node"], []).append(e["from_node"])
    for k in adj:
        adj[k] = sorted(set(adj[k]))
    comps = components(adj)
    t.check("K-connected", len(comps) == 1, "%d comp" % len(comps))
    arts = articulation_points(adj)
    t.check("K-articulation", True, "%d: %s" % (len(arts), sorted(arts)[:8]))
    # dead ends exactly the authored set
    authored_de = {n["id"] for n in ra["nodes"] if "dead_end" in n}
    actual_de = {nid for nid, d in deg.items() if d == 1}
    t.check("K-deadends", authored_de == actual_de,
            "%d ends" % len(actual_de))
    bad_de = []
    for nid in actual_de:
        n = nodes[nid]
        rec = next(q for q in ra["nodes"] if q["id"] == nid)["dead_end"]
        for k in rc["dead_end_policy"]["require"]:
            if k == "road_class":
                continue
            if k == "access":
                if n["access"] not in set(rc["access_profiles"]["edge_values"]):
                    bad_de.append(nid)
            elif k not in rec:
                bad_de.append((nid, k))
    t.check("K-deadend-records", not bad_de, bad_de[:4])
    # ring cycle: E portal reaches W portal via ring AND via tunnel
    rn = RoadNetwork(rc, ra, f).build()
    ring_only = rn.find_route("jn_E_portal", "jn_W_portal", "public")
    uses_tunnel = ring_only and any("tunnel" in eid for eid in ring_only["edges"])
    t.check("K-ring-cycle", ring_only is not None, "via=%s" %
            ("tunnel" if uses_tunnel else "surface"))
    # ---- Q: route queries ----
    dests = [(d["id"], d["node"], d.get("access", "PUBLIC")) for d in ra["destinations"]
             if d["node"]]
    prof_of = {"PUBLIC": "public", "SERVICE": "service", "RESTRICTED": "restricted"}
    bad_q, tot_len = [], 0.0
    for did, node, acc in dests:
        prof = prof_of[acc]
        rt = rn.find_route("hub_city", node, prof)
        if rt is None:
            bad_q.append(did)
        else:
            tot_len += rt["length_m"]
    t.check("Q-destinations", not bad_q, bad_q)
    t.check("Q-public-blocks-restricted",
            rn.find_route("hub_city", "gate_restricted", "public") is None
            and rn.find_route("hub_city", "forest_depot", "public") is None)
    t.check("Q-emergency-passes",
            rn.find_route("hub_city", "gate_restricted", "emergency") is not None
            and rn.find_route("hub_city", "forest_depot", "service") is not None)
    nr = rn.nearest_road(1400, 150)
    t.check("Q-nearest", nr["edge"].startswith("E_") and nr["dist_m"] < 5.0,
            "%s %.1fm" % (nr["edge"], nr["dist_m"]))
    nn = rn.nearest_node(1401, 151)
    t.check("Q-nearest-node", nn["id"] == "hub_city")
    ra_e = rn.road_at(1400, 150)
    t.check("Q-road-at", ra_e in edges
            and "hub_city" in (edges[ra_e]["from_node"], edges[ra_e]["to_node"])
            if ra_e else False, ra_e)
    # ---- H: handoff completeness + lengths ----
    need = {"design_speed_kph", "effective_speed_kph", "curve_factor", "width_m",
            "surface", "access", "region", "class"}
    bad_h = [eid for eid, e in edges.items() if not need <= set(e)]
    t.check("H-handoff-fields", not bad_h, bad_h[:4])
    by_class, by_region = {}, {}
    for e in edges.values():
        by_class[e["class"]] = by_class.get(e["class"], 0.0) + e["length_m"]
        by_region[e["region"]] = by_region.get(e["region"], 0.0) + e["length_m"]
    tot = sum(by_class.values())
    t.check("H-lengths", abs(tot - sum(e["length_m"] for e in edges.values())) < 1e-9,
            "total=%.2fkm %s" % (tot / 1000, {k: round(v) for k, v in by_class.items()}))
    # ---- C: checksum recompute ----
    t.check("C-checksum", rn.checksum() == r["checksum"], r["checksum"][:12])
    return t


ROAD_TOOL = "res://tests/godot/tools/road_check.gd"


def godot_bin():
    for cand in [os.environ.get("GODOT_BIN"),
                 os.path.join(ROOT, "tools/.godot/godot")]:
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    raise SystemExit("Godot binary not found (run tools/fetch_godot.py)")


def cmd_cross():
    # Tolerance contract (§78), set from measured evidence (2026-09-21):
    # lengths agree 5.7e-12 -> tol 1e-9; node elev rel 3.5e-15 -> tol 1e-9;
    # grades agree 2.2e-13 -> tol 1e-9 abs; checksum + routes exact.
    t = Tally()
    rc = json.load(open(ROAD_CC))
    r = json.load(open(ROADS_JSON))
    cmd = [godot_bin(), "--headless", "--path", ROOT, "--script", ROAD_TOOL,
           "--", "--verify", "res://data/derived/roads.json"]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
    line = next((l for l in p.stdout.splitlines() if l.startswith("ROAD_METRICS ")), None)
    t.check("X-run", p.returncode == 0 and line is not None,
            "exit=%d" % p.returncode)
    if line is None:
        print(p.stdout[-1500:])
        print(p.stderr[-1500:], file=sys.stderr)
        return t.report("CROSS-ROAD")
    gd = json.loads(line[len("ROAD_METRICS "):])
    t.check("X-counts", gd["counts"] == {"nodes": len(r["nodes"]), "edges": len(r["edges"])},
            gd["counts"])
    bad_L = [eid for eid, e in r["edges"].items()
             if abs(gd["lengths"][eid] - e["length_m"]) > 1e-9]
    t.check("X-lengths", not bad_L, bad_L[:4])
    bad_E = [nid for nid, n in r["nodes"].items()
             if abs(gd["node_elev"][nid] - n["elev"]) / max(1.0, abs(n["elev"])) > 1e-9]
    t.check("X-node-elev", not bad_E, bad_E[:4])
    bad_G = []
    for eid, e in r["edges"].items():
        if e["tunnel"]:
            continue  # twin samples the surface; the bore is authored
        g = gd["grades"][eid]
        if abs(g[0] - e["grade_short_all"]) > 1e-9 or \
           abs(g[1] - e["grade_sustained_all"]) > 1e-9:
            bad_G.append(eid)
    t.check("X-grades", not bad_G, bad_G[:4])
    t.check("X-checksum", gd["checksum"] == r["checksum"], gd["checksum"][:12])
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    rn = RoadNetwork().build()
    bad_R = []
    for key, gr in sorted(gd["routes"].items()):
        a, b = key.split(">")
        dst, prof = b.split(":")
        pr = rn.find_route(a, dst, prof)
        if pr is None or gr["nodes"] != pr["nodes"] \
           or abs(gr["length_m"] - pr["length_m"]) > 1e-9:
            bad_R.append(key)
    t.check("X-routes", not bad_R, "%d/12" % (12 - len(bad_R)))
    return t.report("CROSS-ROAD")


import contextlib


@contextlib.contextmanager
def _mutate(path, fn):
    raw = open(path).read()
    try:
        doc = json.loads(raw)
        fn(doc)
        json.dump(doc, open(path, "w"), indent=2)
        yield
    finally:
        open(path, "w").write(raw)


def _run(args, timeout=300):
    return subprocess.run(args, capture_output=True, text=True, timeout=timeout)


def cmd_inject():
    t = Tally()
    py = sys.executable
    # I1: authoring version vs contract -> build refuses
    def _ver(d):
        d["meta"]["road_version"] = "9.9.9"
    with _mutate(ROAD_AU, _ver):
        p = _run([py, "tools/road_model.py"])
        t.check("I-version-roof", p.returncode != 0 and "road_version" in p.stderr,
                "exit=%d" % p.returncode)
    # I2: grade cap below reality -> STATIC gate fires (caps live in validator)
    def _cap2(d):
        d["road_classes"]["primary"]["max_grade_short_pct"] = 2.0
    with _mutate(ROAD_CC, _cap2):
        p = _run([py, "tools/validate_roads.py", "static"])
        t.check("I-grade-gate", p.returncode != 0 and "G-grade-caps" in p.stdout
                and "FAIL" in p.stdout, "exit=%d" % p.returncode)
    # I3: node off the world disc -> build refuses
    def _off(d):
        d["nodes"][0]["xy"] = [99999.0, 0.0]
    with _mutate(ROAD_AU, _off):
        p = _run([py, "tools/road_model.py"])
        t.check("I-off-terrain", p.returncode != 0 and "off-terrain" in p.stderr,
                "exit=%d" % p.returncode)
    # I4: split references unknown node -> build refuses
    def _unk(d):
        d["routes"][0]["splits"][0] = "nope_missing"
    with _mutate(ROAD_AU, _unk):
        p = _run([py, "tools/road_model.py"])
        t.check("I-unknown-node", p.returncode != 0 and "unknown node" in p.stderr,
                "exit=%d" % p.returncode)
    # I5: tampered sample -> static C-checksum catches it
    def _samp(r):
        r["edges"]["E_art_port_00"]["samples"][5]["x"] += 1.0
    with _mutate(ROADS_JSON, _samp):
        p = _run([py, "tools/validate_roads.py", "static"])
        t.check("I-tamper-sample", p.returncode != 0 and "C-checksum" in p.stdout
                and "FAIL" in p.stdout, "exit=%d" % p.returncode)
    # I6: tampered summary field -> static recompute catches it
    def _summ(r):
        r["edges"]["E_art_port_00"]["length_m"] += 1.0
    with _mutate(ROADS_JSON, _summ):
        p = _run([py, "tools/validate_roads.py", "static"])
        t.check("I-tamper-summary", p.returncode != 0 and "FAIL" in p.stdout,
                "exit=%d" % p.returncode)
    # restore-guard: everything green again after the mutations
    p = _run([py, "tools/road_model.py"])
    t.check("I-restore-build", p.returncode == 0, "exit=%d" % p.returncode)
    p = _run([py, "tools/validate_roads.py", "static"])
    t.check("I-restore-static", p.returncode == 0 and "62/62" in p.stdout,
            p.stdout.strip().splitlines()[-1] if p.stdout else "no output")
    return t.report("INJECT-ROAD")


def cmd_reproduce():
    t = Tally()
    py = sys.executable
    p1 = _run([py, "tools/road_model.py"])
    a = open(ROADS_JSON, "rb").read()
    p2 = _run([py, "tools/road_model.py"])
    b = open(ROADS_JSON, "rb").read()
    t.check("R-builds-ok", p1.returncode == 0 and p2.returncode == 0,
            "exits=%d,%d" % (p1.returncode, p2.returncode))
    t.check("R-byte-identical", a == b, "%d bytes" % len(a))
    ca = json.loads(a)["checksum"]
    t.check("R-checksum-stable", ca == "0e28622c1bb2185b", ca[:12])
    p = _run([py, "tools/validate_roads.py", "static"])
    t.check("R-static-green", p.returncode == 0 and "62/62" in p.stdout,
            p.stdout.strip().splitlines()[-1] if p.stdout else "no output")
    return t.report("REPRODUCE-ROAD")


def cmd_smoke():
    t = Tally()
    py = sys.executable
    p = _run([py, "tools/road_smoke.py", "--json"], timeout=300)
    t.check("M-run", p.returncode == 0, "exit=%d" % p.returncode)
    if p.returncode != 0:
        print(p.stdout[-1000:])
        print(p.stderr[-1000:], file=sys.stderr)
        return t.report("SMOKE-ROAD")
    doc = json.loads(p.stdout)
    t.check("M-trips", not doc["fails"] and len(doc["trips"]) == 13,
            doc["fails"][:3] if doc["fails"] else "13/13")
    tour = doc["trips"]["GRAND_TOUR"]
    t.check("M-tour", 19000.0 < tour["distance_m"] < 19600.0
            and tour["avg_kph"] >= 15.0,
            "%.0fm avg=%.1f" % (tour["distance_m"], tour["avg_kph"]))
    ev = [os.path.join(ROOT, "docs/evidence", f) for f in
          ("p03_plan.png", "p03_tour_elev.png", "p03_tour_speed.png")]
    ok = all(os.path.isfile(f) and os.path.getsize(f) > 10000 for f in ev)
    t.check("M-evidence", ok, [os.path.basename(f) for f in ev])
    return t.report("SMOKE-ROAD")


def cmd_perf():
    # Budgets set from measured evidence + wide margin (2026-09-21).
    t = Tally()
    py = sys.executable
    t0 = __import__("time").perf_counter()
    p = _run([py, "tools/road_model.py"])
    dt_build = __import__("time").perf_counter() - t0
    t.check("P-build", p.returncode == 0 and dt_build < 30.0, "%.1fs" % dt_build)
    t0 = __import__("time").perf_counter()
    p = _run([py, "tools/validate_roads.py", "static"])
    dt_static = __import__("time").perf_counter() - t0
    t.check("P-static", p.returncode == 0 and dt_static < 60.0, "%.1fs" % dt_static)
    t0 = __import__("time").perf_counter()
    p = _run([py, "tools/road_smoke.py", "--json"], timeout=300)
    dt_smoke = __import__("time").perf_counter() - t0
    t.check("P-smoke", p.returncode == 0 and dt_smoke < 60.0, "%.1fs" % dt_smoke)
    sys.path.insert(0, os.path.join(ROOT, "tools"))
    from road_model import RoadNetwork
    rn = RoadNetwork().build()
    qs = [("hub_city", "port_gate", "public"), ("hub_city", "air_gate", "public"),
          ("hub_city", "village_center", "public"), ("hub_city", "sub_center", "public"),
          ("hub_city", "resort_waterfront", "public"), ("hub_city", "ridge_end", "public"),
          ("hub_city", "waterfront_access", "public"), ("hub_city", "jn_W_portal", "public"),
          ("hub_city", "forest_depot", "service"), ("hub_city", "gate_restricted", "restricted"),
          ("jn_ring_W", "jn_ring_S", "public"), ("port_gate", "air_gate", "public")]
    t0 = __import__("time").perf_counter()
    n_ok = sum(1 for a, b, pr in qs if rn.find_route(a, b, pr) is not None)
    dt_q = (__import__("time").perf_counter() - t0) / len(qs)
    t.check("P-query", n_ok == 12 and dt_q < 0.5, "%.1fms/q" % (dt_q * 1000))
    sz = os.path.getsize(ROADS_JSON)
    t.check("P-export-size", sz < 2_000_000, "%dKB" % (sz // 1024))
    return t.report("PERF-ROAD")


def cmd_regress():
    t = Tally()
    py = sys.executable
    # P02 untouched (read-only suites only; P02 is LOCKED)
    p = _run([py, "tools/validate_terrain.py", "static"], timeout=600)
    t.check("G-p02-static", p.returncode == 0,
            p.stdout.strip().splitlines()[-1] if p.stdout else "no output")
    # P03 full chain green
    for suite in ("static", "cross", "inject", "reproduce", "smoke", "perf"):
        p = _run([py, "tools/validate_roads.py", suite], timeout=900)
        last = p.stdout.strip().splitlines()[-1] if p.stdout.strip() else "no output"
        t.check("G-p03-%s" % suite, p.returncode == 0, last)
    r = json.load(open(ROADS_JSON))
    t.check("G-checksum-pinned", r["checksum"] == "0e28622c1bb2185b",
            r["checksum"][:12])
    return t.report("REGRESS-ROAD")


# ==== more suites appended below ====


def main(argv):
    if len(argv) < 2 or argv[1] not in ("static", "cross", "inject", "reproduce",
                                               "smoke", "perf", "regress"):
        print("usage: validate_roads.py static|cross|inject|reproduce|smoke|perf|regress")
        return 2
    if argv[1] == "static":
        t = cmd_static()[0]
        return 0 if t.report("STATIC-ROAD") else 1
    if argv[1] == "cross":
        return 0 if cmd_cross() else 1
    if argv[1] == "inject":
        return 0 if cmd_inject() else 1
    if argv[1] == "reproduce":
        return 0 if cmd_reproduce() else 1
    if argv[1] == "smoke":
        return 0 if cmd_smoke() else 1
    if argv[1] == "perf":
        return 0 if cmd_perf() else 1
    if argv[1] == "regress":
        return 0 if cmd_regress() else 1
    print("suite %s not yet implemented" % argv[1])
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
