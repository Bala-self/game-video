#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 09 -- navigation + population generator.

Derives pedestrian navigation (areas/graph/links/crossings) and NPC
population zones from LOCKED P02/P03/P04/P05/P06/P07/P08 inputs.
Pure derivation: no RNG. All records canonically sorted.

Outputs (data/derived/):
  npc_navigation_manifest.json  areas/nodes/edges/crossings + evidence
  npc_population_manifest.json  zones/archetypes/targets
  npc_spawn_zones.json          spawn/despawn points per zone
  npc_behavior_policy.json      destination weights per class x schedule
  npc_perception_policy.json    per-archetype perception ranges
"""
import hashlib
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sector_math import SectorGrid, sector_id  # noqa: E402
from terrain_model import Field  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DD = os.path.join(ROOT, "data/derived")
DW = os.path.join(ROOT, "data/world")
CELL = 32.0


def fnv1a64_hex(s):
    h = 0xCBF29CE484222325
    for b in s.encode():
        h ^= b
        h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
    return "%016x" % h


def canon(obj):
    # Canonical form shared with npc_check.gd: Godot parses every JSON
    # number as float, so integral numbers render as "N.0" on both sides.
    if isinstance(obj, dict):
        return "{" + ",".join(
            json.dumps(k) + ":" + canon(obj[k])
            for k in sorted(obj.keys())) + "}"
    if isinstance(obj, (list, tuple)):
        return "[" + ",".join(canon(v) for v in obj) + "]"
    if isinstance(obj, str):
        return json.dumps(obj)
    if isinstance(obj, bool):
        return "true" if obj else "false"
    if obj is None:
        return "null"
    if isinstance(obj, int):
        return str(obj) + ".0"
    if isinstance(obj, float):
        if obj.is_integer() and abs(obj) < 1e15:
            return str(int(obj)) + ".0"
        return repr(obj)
    return json.dumps(obj)


def q3(v):
    return round(float(v), 3)


def dist_pt_seg(px, pz, ax, az, bx, bz):
    dx, dz = bx - ax, bz - az
    L2 = dx * dx + dz * dz
    if L2 <= 1e-12:
        return math.hypot(px - ax, pz - az)
    t = max(0.0, min(1.0, ((px - ax) * dx + (pz - az) * dz) / L2))
    return math.hypot(px - (ax + t * dx), pz - (az + t * dz))


def point_in_poly(x, z, poly):
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, zi = poly[i][0], poly[i][1]
        xj, zj = poly[j][0], poly[j][1]
        if ((zi > z) != (zj > z)) and \
                (x < (xj - xi) * (z - zi) / (zj - zi + 1e-12) + xi):
            inside = not inside
        j = i
    return inside


class Hash:
    def __init__(self):
        self.cells = {}

    def add_seg(self, ax, az, bx, bz, payload):
        x0 = int(math.floor(min(ax, bx) / CELL))
        x1 = int(math.floor(max(ax, bx) / CELL))
        z0 = int(math.floor(min(az, bz) / CELL))
        z1 = int(math.floor(max(az, bz) / CELL))
        for cx in range(x0, x1 + 1):
            for cz in range(z0, z1 + 1):
                self.cells.setdefault((cx, cz), []).append(
                    (ax, az, bx, bz, payload))

    def add_point(self, x, z, payload):
        c = (int(math.floor(x / CELL)), int(math.floor(z / CELL)))
        self.cells.setdefault(c, []).append(payload)

    def near_segs(self, x, z):
        c = (int(math.floor(x / CELL)), int(math.floor(z / CELL)))
        out = []
        for dx in (-1, 0, 1):
            for dz in (-1, 0, 1):
                out.extend(self.cells.get((c[0] + dx, c[1] + dz), []))
        return out

    def near_points(self, x, z):
        return self.near_segs(x, z)


def load(p):
    with open(os.path.join(DD if not p.startswith("world") else ROOT,
                           p)) as f:
        return json.load(f)


def main():
    tc = json.load(open(os.path.join(DW, "npc_contract.json")))
    roads = json.load(open(os.path.join(DD, "roads.json")))
    graph = json.load(open(os.path.join(DD, "traffic_graph.json")))
    places = json.load(open(os.path.join(DD, "places.json")))
    buildings = json.load(open(os.path.join(DD, "buildings.json")))["buildings"]
    navrows = json.load(open(os.path.join(DD, "p06_handoff_nav.json")))["rows"]
    districts = {d["id"]: d for d in
                 json.load(open(os.path.join(DD, "districts.json")))["districts"]}
    auth = json.load(open(os.path.join(ROOT, "data/terrain/authoring.json")))
    rivers = auth["drainage"]["rivers"]
    grid = SectorGrid(256)
    field = Field()

    walk = tc["walkability"]
    blocked_regions = set(walk["blocked_regions"])
    max_slope = walk["max_slope_grade"]
    river_clear = walk["river_clearance_m"]
    restr_pol = set(walk["restricted_policies"])
    agent = tc["agent_profile_standard"]

    edge_half = {}
    for eid, e in roads["edges"].items():
        edge_half[eid] = float(e.get("width_m", 8.0)) / 2.0

    # ---- spatial hashes ----
    lanesegs = Hash()
    for lid in sorted(graph["lanes"].keys()):
        L = graph["lanes"][lid]
        pts = L["pts"]
        for i in range(len(pts) - 1):
            lanesegs.add_seg(pts[i][0], pts[i][2], pts[i + 1][0],
                             pts[i + 1][2],
                             (lid, L["edge"], L["width_m"],
                              L["speed_legal_kph"], L["access"]))
    bhash = Hash()
    for b in buildings:
        fp = b["footprint"]
        for i in range(len(fp) - 1):
            bhash.add_seg(fp[i][0], fp[i][1], fp[i + 1][0], fp[i + 1][1],
                          b["id"])
    bld_by_id = {b["id"]: b for b in buildings}
    restr_polys = []
    for o in places["open_spaces"]:
        if o["navigation_policy"] in restr_pol:
            restr_polys.append(o["bounds"])

    def river_dist(x, z):
        best = 1e18
        for rv in rivers:
            pts = rv["points"]
            hw = float(rv["width_m"]) / 2.0
            for i in range(len(pts) - 1):
                d = dist_pt_seg(x, z, pts[i][0], pts[i][1],
                                pts[i + 1][0], pts[i + 1][1]) - hw
               
                best = min(best, d)
        return best

    def road_dist(x, z):
        best = 1e18
        bestrec = None
        for (ax, az, bx, bz, rec) in lanesegs.near_segs(x, z):
            d = dist_pt_seg(x, z, ax, az, bx, bz)
            if d < best:
                best = d
                bestrec = rec
        return best, bestrec

    def inside_building(x, z):
        for (ax, az, bx, bz, bid) in bhash.near_segs(x, z):
            fp = bld_by_id[bid]["footprint"]
            if point_in_poly(x, z, fp):
                return bid
        return None

    def point_test(x, z):
        """(ok, evidence). Cheap tests first."""
        r = math.hypot(x, z)
        if r > 2000.0:
            return False, {"reason": "outside_world", "r": q3(r)}
        reg = field.region_at(x, z)
        if reg in blocked_regions:
            return False, {"reason": "water_region", "region": reg}
        rd = river_dist(x, z)
        if rd < river_clear:
            return False, {"reason": "river", "river_dist": q3(rd),
                           "region": reg}
        dd, rec = road_dist(x, z)
        if rec is not None:
            clear = edge_half.get(rec[1], 4.0) + 0.5
            if dd < clear:
                return False, {"reason": "road", "road_dist": q3(dd),
                               "edge": rec[1], "region": reg}
        bid = inside_building(x, z)
        if bid is not None:
            return False, {"reason": "building", "building": bid,
                           "region": reg}
        _deg, pct = field.slope_grade(x, z)
        if pct / 100.0 > max_slope:
            return False, {"reason": "slope",
                           "slope_grade": q3(pct / 100.0), "region": reg}
        for rp in restr_polys:
            if point_in_poly(x, z, rp):
                return False, {"reason": "restricted",
                               "region": reg}
        return True, {"region": reg, "slope_grade": q3(pct / 100.0),
                      "river_dist": q3(rd),
                      "road_dist": None if dd > 1e17 else q3(dd)}

    def seg_ok(ax, az, bx, bz, step=2.0):
        L = math.hypot(bx - ax, bz - az)
        n = max(1, int(math.ceil(L / step)))
        for i in range(n + 1):
            t = i / n
            ok, _ = point_test(ax + (bx - ax) * t, az + (bz - az) * t)
            if not ok:
                return False
        return True

    def snap_walkable(x, z, rmax):
        ok, _ = point_test(x, z)
        if ok:
            return x, z, 0.0
        r = 2.0
        while r <= rmax:
            n = max(8, int(2 * math.pi * r / 2.0))
            for i in range(n):
                a = 2 * math.pi * i / n
                px, pz = x + r * math.cos(a), z + r * math.sin(a)
                ok, _ = point_test(px, pz)
                if ok:
                    return px, pz, r
            r += 2.0
        return None

    # ---- areas ----
    areas = []
    area_samples = {}
    for o in sorted(places["open_spaces"], key=lambda d: d["id"]):
        if o["navigation_policy"] != "walkable":
            continue
        b = o["bounds"]
        xs = [p[0] for p in b]
        zs = [p[1] for p in b]
        okc = totc = 0
        why = {}
        pts = []
        gx = min(xs)
        while gx <= max(xs):
            gz = min(zs)
            while gz <= max(zs):
                if point_in_poly(gx, gz, b):
                    totc += 1
                    ok, ev = point_test(gx, gz)
                    if ok:
                        okc += 1
                        pts.append((q3(gx), q3(gz)))
                    else:
                        k = ev.get("reason", "?")
                        why[k] = why.get(k, 0) + 1
                gz += 4.0
            gx += 4.0
        cov = (okc / totc) if totc else 0.0
        if cov < 0.25 or not pts:
            continue
        aid = "AR-" + o["id"]
        areas.append({"id": aid, "open_space": o["id"],
                      "district": o["district"],
                      "settlement": o["settlement"],
                      "purpose": o["purpose"], "coverage": round(cov, 4),
                      "samples": totc, "walkable": okc,
                      "blocked": why})
        area_samples[aid] = pts
    areas.sort(key=lambda d: d["id"])

    # ---- nodes ----
    nodes = {}
    dropped = {"entry": 0, "landmark": 0, "arrival": 0, "area": 0}

    def add_node(nid, kind, x, z, **extra):
        ok, ev = point_test(x, z)
        if not ok:
            return None
        try:
            y = field.height(x, z)
        except Exception:
            y = 0.0
        sx, sz = grid.sector_of(x, z)
        rec = {"id": nid, "kind": kind, "x": q3(x), "y": q3(y),
               "z": q3(z), "sector": sector_id(sx, sz)}
        rec.update(ev)
        rec.update(extra)
        nodes[nid] = rec
        return rec

    os_by_id = {o["id"]: o for o in places["open_spaces"]}
    for a in areas:
        o = os_by_id[a["open_space"]]
        b = o["bounds"]
        cx = sum(p[0] for p in b) / len(b)
        cz = sum(p[1] for p in b) / len(b)
        # snap centroid to nearest walkable sample
        cand = sorted(area_samples[a["id"]],
                      key=lambda p: (p[0] - cx) ** 2 + (p[1] - cz) ** 2)
        if cand and (cand[0][0] - cx) ** 2 + \
                (cand[0][1] - cz) ** 2 <= 100.0:
            cx, cz = cand[0]
        r = add_node("NC-" + a["id"], "AREA_CENTROID", cx, cz, area=a["id"])
        if r is None:
            dropped["area"] += 1
        for i in range(len(b)):
            p0, p1 = b[i], b[(i + 1) % len(b)]
            mx, mz = (p0[0] + p1[0]) / 2.0, (p0[1] + p1[1]) / 2.0
            # pull toward centroid for clearance
            px = mx + (cx - mx) * 0.15
            pz = mz + (cz - mz) * 0.15
            add_node("NM-%s-E%d" % (a["id"], i), "AREA_MID", px, pz,
                     area=a["id"])

    for i, row in enumerate(sorted(navrows,
                                   key=lambda d: (d["building"],
                                                  d["entrance"][0],
                                                  d["entrance"][1]))):
        ex, ez = row["entrance"]
        sn = snap_walkable(ex, ez, 30.0)
        if sn is None:
            dropped["entry"] += 1
            continue
        r = add_node("NE-%06d" % i, "ENTRY", sn[0], sn[1],
                     building=row["building"],
                     access_type=row.get("access_type", "?"),
                     snap_m=sn[2])
        if r is None:
            dropped["entry"] += 1

    for lm in sorted(places["landmarks"], key=lambda d: d["id"]):
        sn = snap_walkable(lm["at"][0], lm["at"][1], 40.0)
        if sn is None:
            dropped["landmark"] += 1
            continue
        r = add_node("NL-" + lm["id"], "LANDMARK", sn[0], sn[1],
                     landmark=lm["id"], tier=lm["tier"], snap_m=sn[2])
        if r is None:
            dropped["landmark"] += 1

    for av in sorted(places["arrivals"], key=lambda d: d["id"]):
        sn = snap_walkable(av["entry"][0], av["entry"][1], 60.0)
        if sn is None:
            dropped["arrival"] += 1
            continue
        r = add_node("NV-" + av["id"], "ARRIVAL", sn[0], sn[1],
                     arrival=av["id"],
                     envelope_r=av.get("envelope_r", 80.0),
                     snap_m=sn[2])
        if r is None:
            dropped["arrival"] += 1

    # ---- walk edges ----
    edges = []
    edge_keys = set()

    def add_edge(a, b_, kind, **extra):
        if a == b_ or a not in nodes or b_ not in nodes:
            return False
        k = tuple(sorted((a, b_)))
        if k in edge_keys:
            return False
        A, B = nodes[a], nodes[b_]
        if not seg_ok(A["x"], A["z"], B["x"], B["z"]):
            return False
        L = math.hypot(B["x"] - A["x"], B["z"] - A["z"])
        rec = {"a": a, "b": b_, "kind": kind, "length_m": q3(L),
               "corridor_m": 2.0,
               "sector_portal": A["sector"] != B["sector"]}
        rec.update(extra)
        edges.append(rec)
        edge_keys.add(k)
        return True

    by_area = {}
    for nid, n in nodes.items():
        if n["kind"] in ("AREA_CENTROID", "AREA_MID"):
            by_area.setdefault(n["area"], []).append(nid)
    for aid in sorted(by_area.keys()):
        ids = sorted(by_area[aid])
        cents = [i for i in ids if nodes[i]["kind"] == "AREA_CENTROID"]
        mids = [i for i in ids if nodes[i]["kind"] == "AREA_MID"]
        for m in mids:
            for c in cents:
                add_edge(c, m, "AREA_STAR")

    mids = sorted(n for n, d in nodes.items()
                  if d["kind"] == "AREA_MID")
    for i in range(len(mids)):
        for j in range(i + 1, len(mids)):
            A, B = nodes[mids[i]], nodes[mids[j]]
            if A["area"] == B["area"]:
                continue
            if math.hypot(B["x"] - A["x"], B["z"] - A["z"]) <= 80.0:
                add_edge(mids[i], mids[j], "AREA_ADJ")

    def nearest(node_ids, x, z, rmax):
        cands = nearest_k(node_ids, x, z, rmax, 1)
        return cands[0] if cands else None

    def nearest_k(node_ids, x, z, rmax, k):
        scored = []
        for nid in node_ids:
            n = nodes[nid]
            d2 = (n["x"] - x) ** 2 + (n["z"] - z) ** 2
            if d2 <= rmax * rmax:
                scored.append((d2, nid))
        scored.sort()
        return [nid for _, nid in scored[:k]]

    area_nodes = sorted(n for n, d in nodes.items()
                        if d["kind"] in ("AREA_CENTROID", "AREA_MID"))

    def attach(nid, pool, rmax, kind, k=3, **extra):
        n = nodes[nid]
        for t in nearest_k([p for p in pool if p != nid],
                           n["x"], n["z"], rmax, k):
            if add_edge(nid, t, kind, **extra):
                return True
        return False

    for nid in sorted(n for n, d in nodes.items()
                      if d["kind"] == "ENTRY"):
        n = nodes[nid]
        pool = sorted(set(area_nodes) |
                      set(m for m, d in nodes.items()
                          if d["kind"] == "ENTRY"))
        attach(nid, pool, 100.0, "ENTRY_LINK", building=n["building"])
    for nid in sorted(n for n, d in nodes.items()
                      if d["kind"] in ("LANDMARK", "ARRIVAL")):
        pool = sorted(set(area_nodes) |
                      set(m for m, d in nodes.items()
                          if d["kind"] == "ENTRY"))
        attach(nid, pool, 150.0, "POI_LINK")

    # ---- derived crossings (PUBLIC lanes, speed <= 50) ----
    edge_extent = {}
    for lid2 in sorted(graph["lanes"].keys()):
        L2 = graph["lanes"][lid2]
        e = L2["edge"]
        ext = abs(float(L2.get("offset_m", 0.0))) + \
            float(L2["width_m"]) / 2.0
        edge_extent[e] = max(edge_extent.get(e, 0.0), ext)
    crossings = []
    cross_stats = {"candidates": 0, "bad_endpoints": 0, "unattached": 0,
                   "duplicates": 0}
    seen_ek = set()
    for lid in sorted(graph["lanes"].keys()):
        L = graph["lanes"][lid]
        if L["access"] != "PUBLIC" or L["speed_legal_kph"] > 50:
            continue
        pts = L["pts"]
        hw = max(edge_half.get(L["edge"], 4.0),
                 edge_extent.get(L["edge"], 0.0))
        # walk arc length, stations every 120 m
        segs = []
        acc = 0.0
        for i in range(len(pts) - 1):
            sl = math.hypot(pts[i + 1][0] - pts[i][0],
                            pts[i + 1][2] - pts[i][2])
            segs.append((acc, acc + sl, i))
            acc += sl
        if acc < 40.0:
            continue
        st = 60.0
        k = 0
        while st < acc - 20.0:
            if (L["edge"], k) in seen_ek:
                cross_stats["duplicates"] += 1
                st += 120.0
                k += 1
                continue
            for (a0, a1, i) in segs:
                if a0 <= st <= a1:
                    break
            t = (st - a0) / max(1e-9, a1 - a0)
            cx = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * t
            cz = pts[i][2] + (pts[i + 1][2] - pts[i][2]) * t
            dx = pts[i + 1][0] - pts[i][0]
            dz = pts[i + 1][2] - pts[i][2]
            dl = math.hypot(dx, dz) or 1.0
            nx, nz = -dz / dl, dx / dl
            off = hw + 2.5
            cross_stats["candidates"] += 1

            def snap_side(side):
                bx0, bz0 = cx + nx * off * side, cz + nz * off * side
                ok, _ = point_test(bx0, bz0)
                if ok:
                    return bx0, bz0
                r = 2.0
                while r <= 15.0:
                    n = max(8, int(2 * math.pi * r / 2.0))
                    for i in range(n):
                        a = 2 * math.pi * i / n
                        px, pz = bx0 + r * math.cos(a), \
                            bz0 + r * math.sin(a)
                        if ((px - cx) * nx + (pz - cz) * nz) * side \
                                < 1.0:
                            continue
                        ok, _ = point_test(px, pz)
                        if ok:
                            return px, pz
                    r += 2.0
                return None
            sa = snap_side(1.0)
            sb = snap_side(-1.0)
            if sa is None or sb is None:
                cross_stats["bad_endpoints"] += 1
                st += 120.0
                k += 1
                continue
            ax, az = sa
            bx, bz = sb
            # both endpoints near the walk network?
            if nearest(area_nodes, ax, az, 80.0) is None or \
                    nearest(area_nodes, bx, bz, 80.0) is None:
                cross_stats["unattached"] += 1
                st += 120.0
                k += 1
                continue
            na = add_node("NX-%s-%d-A" % (lid, k), "CROSSING_END",
                          ax, az, edge=L["edge"], lane=lid)
            nb = add_node("NX-%s-%d-B" % (lid, k), "CROSSING_END",
                          bx, bz, edge=L["edge"], lane=lid)
            if na is None or nb is None:
                st += 120.0
                k += 1
                continue
            cid = "CR-%s-%d" % (lid, k)
            wid = 2.0 * off
            crossings.append({"id": cid, "lane": lid, "edge": L["edge"],
                              "a": na["id"], "b": nb["id"],
                              "width_m": q3(wid),
                              "speed_kph": L["speed_legal_kph"],
                              "mid": [q3(cx), q3(cz)]})
            seen_ek.add((L["edge"], k))
            kk = tuple(sorted((na["id"], nb["id"])))
            A, B = nodes[na["id"]], nodes[nb["id"]]
            edges.append({"a": na["id"], "b": nb["id"], "kind": "CROSSING",
                          "length_m": q3(wid), "corridor_m": 3.0,
                          "sector_portal": A["sector"] != B["sector"],
                          "crossing": cid, "edge": L["edge"],
                          "lane": lid})
            edge_keys.add(kk)
            poolx = sorted(set(area_nodes) |
                           set(m for m, d in nodes.items()
                               if d["kind"] in ("ENTRY", "CROSSING_END")))
            for end in (na["id"], nb["id"]):
                attach(end, poolx, 100.0, "CROSSING_APPROACH",
                       crossing=cid)
            st += 120.0
            k += 1

    # ---- population zones ----
    BASE = {"core_high": 120, "urban_mid": 60, "suburban_low": 25,
            "industrial_yard": 20, "resort_open": 45,
            "rural_cluster": 12, "rural_disperse": 6,
            "forest_tiny": 4, "highland_cluster": 10,
            "secure_compound": 0}
    bld_by_district = {}
    for b in buildings:
        bld_by_district.setdefault(b["district"], []).append(b["id"])
    area_by_district = {}
    for a in areas:
        area_by_district.setdefault(a["district"], []).append(a["id"])
    zones = []
    for did in sorted(districts.keys()):
        d = districts[did]
        prof = d.get("density_profile", "rural_disperse")
        base = BASE.get(prof, 6)
        aids = area_by_district.get(did, [])
        warea = sum(a["walkable"] * 16.0 for a in areas
                    if a["id"] in aids)
        nb = len(bld_by_district.get(did, []))
        blocked = (d["class"] == "RESTRICTED" or
                   prof == "secure_compound")
        tgt = 0 if blocked else int(round(base * (1.0 + warea / 20000.0)
                                                   + nb * 0.5))
        zones.append({"zone_id": "PZ-" + did, "district": did,
                      "settlement": d.get("settlement"),
                      "class": d["class"], "density_profile": prof,
                      "type": "district",
                      "target_population": tgt,
                      "peak_population": int(math.ceil(tgt * 1.5)),
                      "areas": sorted(aids),
                      "buildings": nb,
                      "walkable_m2": round(warea, 1),
                      "restrictions": ["POPULATION_BLOCKED",
                                       "SPAWN_BLOCKED"] if blocked else [],
                      "priority": 0 if blocked else
                      (3 if base >= 60 else (2 if base >= 20 else 1))})
    # arrival zones
    for av in sorted(places["arrivals"], key=lambda d: d["id"]):
        zones.append({"zone_id": "PZ-" + av["id"],
                      "district": None,
                      "settlement": av.get("settlement"),
                      "class": "ARRIVAL", "density_profile": "arrival",
                      "type": "arrival", "target_population": 8,
                      "peak_population": 12, "areas": [],
                      "buildings": 0, "walkable_m2": 0.0,
                      "restrictions": [], "priority": 2})
    zones.sort(key=lambda d: d["id"] if "id" in d else d["zone_id"])

    ARCH = {
        "CIVILIAN": {"walk": 1.4, "run": 3.0, "turn": 180.0, "radius": 0.35,
                     "los": 40.0, "fov": 150.0, "prox": 8.0, "react": 5,
                     "traffic": True, "despawn": 5},
        "WORKER": {"walk": 1.5, "run": 3.0, "turn": 180.0, "radius": 0.35,
                   "los": 40.0, "fov": 150.0, "prox": 8.0, "react": 5,
                   "traffic": True, "despawn": 5},
        "COMMUTER": {"walk": 1.6, "run": 3.2, "turn": 200.0, "radius": 0.35,
                     "los": 45.0, "fov": 150.0, "prox": 8.0, "react": 4,
                     "traffic": True, "despawn": 6},
        "SHOPPER": {"walk": 1.2, "run": 2.8, "turn": 160.0, "radius": 0.35,
                    "los": 35.0, "fov": 160.0, "prox": 7.0, "react": 6,
                    "traffic": True, "despawn": 5},
        "TOURIST": {"walk": 1.1, "run": 2.6, "turn": 150.0, "radius": 0.35,
                    "los": 50.0, "fov": 170.0, "prox": 7.0, "react": 7,
                    "traffic": True, "despawn": 4},
        "RESIDENT": {"walk": 1.4, "run": 3.0, "turn": 180.0, "radius": 0.35,
                     "los": 40.0, "fov": 150.0, "prox": 9.0, "react": 5,
                     "traffic": True, "despawn": 5},
        "SERVICE_HOOK": {"walk": 1.5, "run": 3.2, "turn": 200.0,
                         "radius": 0.4, "los": 45.0, "fov": 150.0,
                         "prox": 8.0, "react": 4, "traffic": True,
                         "despawn": 8},
        "SECURITY_HOOK": {"walk": 1.5, "run": 3.4, "turn": 220.0,
                          "radius": 0.4, "los": 55.0, "fov": 160.0,
                          "prox": 10.0, "react": 3, "traffic": True,
                          "despawn": 9},
        "EMERGENCY_HOOK": {"walk": 1.7, "run": 3.8, "turn": 240.0,
                           "radius": 0.4, "los": 60.0, "fov": 170.0,
                           "prox": 12.0, "react": 2, "traffic": False,
                           "despawn": 9},
    }
    CLW = {
        "CITY_CORE": {"SHOPPER": 30, "COMMUTER": 25, "CIVILIAN": 20,
                      "TOURIST": 10, "RESIDENT": 10, "WORKER": 5},
        "COMMERCIAL": {"SHOPPER": 40, "COMMUTER": 20, "CIVILIAN": 20,
                       "WORKER": 10, "TOURIST": 10},
        "MIXED_USE": {"RESIDENT": 30, "SHOPPER": 25, "CIVILIAN": 20,
                      "COMMUTER": 15, "WORKER": 10},
        "CIVIC": {"CIVILIAN": 35, "COMMUTER": 25, "TOURIST": 20,
                  "RESIDENT": 20},
        "RESIDENTIAL_INNER": {"RESIDENT": 60, "CIVILIAN": 25,
                              "COMMUTER": 15},
        "RESIDENTIAL_OUTER": {"RESIDENT": 65, "CIVILIAN": 20,
                              "COMMUTER": 15},
        "SUBURBAN": {"RESIDENT": 60, "CIVILIAN": 25, "COMMUTER": 15},
        "INDUSTRIAL": {"WORKER": 60, "COMMUTER": 25, "CIVILIAN": 15},
        "PORT": {"WORKER": 55, "COMMUTER": 25, "CIVILIAN": 20},
        "AIRFIELD": {"COMMUTER": 40, "WORKER": 35, "CIVILIAN": 25},
        "RESORT": {"TOURIST": 60, "SHOPPER": 20, "CIVILIAN": 20},
        "WATERFRONT": {"TOURIST": 35, "SHOPPER": 25, "RESIDENT": 20,
                       "CIVILIAN": 20},
        "RURAL_VILLAGE": {"RESIDENT": 70, "CIVILIAN": 30},
        "AGRICULTURAL": {"RESIDENT": 60, "WORKER": 30, "CIVILIAN": 10},
        "FOREST_SETTLEMENT": {"RESIDENT": 70, "CIVILIAN": 30},
        "HIGHLAND_SETTLEMENT": {"RESIDENT": 60, "TOURIST": 20,
                                "CIVILIAN": 20},
        "RESTRICTED": {},
        "ARRIVAL": {"COMMUTER": 40, "TOURIST": 30, "CIVILIAN": 30},
    }
    for z in zones:
        z["archetype_weights"] = CLW.get(z["class"], {"CIVILIAN": 100})

    # ---- spawn / despawn points ----
    area_node_xy = {}
    for _nid, _nd in nodes.items():
        if _nd["kind"] in ("AREA_CENTROID", "AREA_MID"):
            area_node_xy.setdefault(_nd["area"], []).append(
                (_nd["x"], _nd["z"]))
    bdist = {b["id"]: b["district"] for b in buildings}
    spawn_zones = {}
    for z in zones:
        pts = []
        if not z["areas"] and z.get("district"):
            for _nid, _nd in nodes.items():
                if _nd["kind"] == "ENTRY" and \
                        bdist.get(_nd["building"]) == z["district"]:
                    pts.append((_nd["x"], _nd["z"]))
        for aid in z["areas"]:
            nxy = area_node_xy.get(aid, [])
            for (sx, sz) in area_samples.get(aid, []):
                if any((sx - nx) ** 2 + (sz - nz) ** 2 <= 625.0
                       for (nx, nz) in nxy):
                    pts.append((sx, sz))
        pts = sorted(set(pts))
        if len(pts) > 60:
            stride = len(pts) / 60.0
            pts = [pts[int(i * stride)] for i in range(60)]
        if z["type"] == "arrival":
            for nid, n in nodes.items():
                if n["kind"] == "ARRIVAL" and \
                        ("NV-" + z["zone_id"][3:]) == nid:
                    pts.append((n["x"], n["z"]))
        sp = [{"x": p[0], "z": p[1]} for p in sorted(set(pts))]
        spawn_zones[z["zone_id"]] = {"spawn_points": sp,
                                     "despawn_points": list(sp)}

    # ---- behavior + perception policies ----
    CATS = tc["behavior_policy"]["categories"]
    base_w = {
        "CITY_CORE": {"SHOP": 30, "WORK": 25, "LANDMARK": 10, "PARK": 8,
                      "OPEN_SPACE": 8, "HOME": 5, "RETURN": 5,
                      "RANDOM_WALK": 5, "ARRIVAL": 2, "TRANSIT_HOOK": 2},
        "default": {"HOME": 20, "WORK": 20, "OPEN_SPACE": 15, "PARK": 10,
                    "SHOP": 10, "RETURN": 8, "RANDOM_WALK": 8,
                    "LANDMARK": 4, "ARRIVAL": 3, "TRANSIT_HOOK": 2},
        "RESORT": {"PARK": 25, "LANDMARK": 20, "OPEN_SPACE": 20,
                   "SHOP": 12, "RANDOM_WALK": 8, "HOME": 5, "WORK": 3,
                   "RETURN": 4, "ARRIVAL": 2, "TRANSIT_HOOK": 1},
        "INDUSTRIAL": {"WORK": 55, "RETURN": 10, "HOME": 10,
                       "OPEN_SPACE": 8, "RANDOM_WALK": 7, "SHOP": 4,
                       "PARK": 2, "LANDMARK": 1, "ARRIVAL": 2,
                       "TRANSIT_HOOK": 1},
        "PORT": {"WORK": 50, "RETURN": 10, "HOME": 10, "OPEN_SPACE": 10,
                 "RANDOM_WALK": 8, "SHOP": 5, "ARRIVAL": 4, "PARK": 1,
                 "LANDMARK": 1, "TRANSIT_HOOK": 1},
        "RESIDENTIAL": {"HOME": 45, "RETURN": 12, "OPEN_SPACE": 12,
                        "PARK": 8, "SHOP": 8, "WORK": 6, "RANDOM_WALK": 5,
                        "LANDMARK": 2, "ARRIVAL": 1, "TRANSIT_HOOK": 1},
        "RURAL": {"HOME": 40, "OPEN_SPACE": 20, "RANDOM_WALK": 12,
                  "WORK": 10, "RETURN": 8, "PARK": 4, "SHOP": 3,
                  "LANDMARK": 1, "ARRIVAL": 1, "TRANSIT_HOOK": 1},
        "ARRIVAL": {"ARRIVAL": 30, "TRANSIT_HOOK": 15, "WORK": 15,
                    "OPEN_SPACE": 12, "RANDOM_WALK": 10, "SHOP": 6,
                    "HOME": 4, "RETURN": 4, "PARK": 2, "LANDMARK": 2},
    }
    classmap = {"CITY_CORE": "CITY_CORE", "COMMERCIAL": "CITY_CORE",
                "MIXED_USE": "default", "CIVIC": "default",
                "RESIDENTIAL_INNER": "RESIDENTIAL",
                "RESIDENTIAL_OUTER": "RESIDENTIAL",
                "SUBURBAN": "RESIDENTIAL", "INDUSTRIAL": "INDUSTRIAL",
                "PORT": "PORT", "AIRFIELD": "INDUSTRIAL",
                "RESORT": "RESORT", "WATERFRONT": "default",
                "RURAL_VILLAGE": "RURAL", "AGRICULTURAL": "RURAL",
                "FOREST_SETTLEMENT": "RURAL",
                "HIGHLAND_SETTLEMENT": "RURAL", "RESTRICTED": "default",
                "ARRIVAL": "ARRIVAL"}
    sched_mult = {"MORNING": {"WORK": 2.0, "HOME": 0.5},
                  "DAY": {"SHOP": 1.5, "PARK": 1.5, "LANDMARK": 1.5},
                  "EVENING": {"HOME": 2.0, "SHOP": 1.3},
                  "NIGHT": {"HOME": 3.0, "WORK": 0.3, "RANDOM_WALK": 0.5}}
    dest_w = {}
    for cls in sorted(set(list(classmap.values()) + ["default"])):
        b = base_w.get(cls, base_w["default"])
        for sched in ("MORNING", "DAY", "EVENING", "NIGHT"):
            w = dict(b)
            for k, m in sched_mult[sched].items():
                if k in w:
                    w[k] = round(w[k] * m, 2)
            dest_w["%s|%s" % (cls, sched)] = w
    # P09-D13: movement/behavior machines are POLICY DATA (sim + engine
    # load these tables; no hardcoded transitions in runtimes).
    MOVE_MACHINE = {
        "SPAWNED": ["DESPAWNING", "FAILED", "INITIALIZING"],
        "INITIALIZING": ["DESPAWNING", "FAILED", "IDLE", "RECOVERING"],
        "IDLE": ["DESPAWNING", "FAILED", "INTERACTING", "PAUSED",
                 "RECOVERING", "WAITING", "WALKING"],
        "WALKING": ["AVOIDING", "CROSSING", "DESPAWNING", "FAILED",
                    "IDLE", "INTERACTING", "PAUSED", "RECOVERING",
                    "RUNNING", "STUCK", "TURNING", "WAITING"],
        "WAITING": ["CROSSING", "DESPAWNING", "FAILED", "IDLE",
                    "PAUSED", "RECOVERING", "STUCK", "WALKING"],
        "CROSSING": ["DESPAWNING", "FAILED", "IDLE", "PAUSED",
                     "RECOVERING", "STUCK", "WALKING"],
        "TURNING": ["DESPAWNING", "FAILED", "IDLE", "PAUSED",
                    "RECOVERING", "STUCK", "WAITING", "WALKING"],
        "AVOIDING": ["DESPAWNING", "FAILED", "IDLE", "PAUSED",
                     "RECOVERING", "STUCK", "WAITING", "WALKING"],
        "RUNNING": ["AVOIDING", "DESPAWNING", "FAILED", "IDLE",
                    "PAUSED", "RECOVERING", "STUCK", "WALKING"],
        "FLEEING_HOOK": ["DESPAWNING", "FAILED", "IDLE", "RUNNING"],
        "INTERACTING": ["DESPAWNING", "FAILED", "IDLE", "PAUSED",
                        "WALKING"],
        "PAUSED": ["CROSSING", "DESPAWNING", "FAILED", "IDLE",
                   "WAITING", "WALKING"],
        "STUCK": ["DESPAWNING", "FAILED", "RECOVERING"],
        "RECOVERING": ["DESPAWNING", "FAILED", "IDLE", "WAITING",
                       "WALKING"],
        "DESPAWNING": ["DESPAWNED", "FAILED"],
        "DESPAWNED": [],
        "FAILED": ["DESPAWNING", "RECOVERING"],
    }
    BEH_MACHINE = {
        "IDLE": ["AVOID", "DESPAWN", "INTERACT", "REACT", "RECOVER",
                 "TRAVEL", "WAIT"],
        "TRAVEL": ["AVOID", "DESPAWN", "IDLE", "INTERACT", "REACT",
                   "RECOVER", "WAIT"],
        "WAIT": ["AVOID", "DESPAWN", "IDLE", "INTERACT", "REACT",
                 "RECOVER", "TRAVEL"],
        "INTERACT": ["DESPAWN", "IDLE", "REACT", "RECOVER", "TRAVEL",
                     "WAIT"],
        "AVOID": ["DESPAWN", "IDLE", "REACT", "RECOVER", "TRAVEL",
                  "WAIT"],
        # REACT has no self-loop and no INTERACT edge: repeat
        # deliveries are deduped and the machine forbids re-trigger.
        "REACT": ["AVOID", "DESPAWN", "IDLE", "RECOVER", "TRAVEL",
                  "WAIT"],
        "RECOVER": ["DESPAWN", "IDLE", "REACT", "TRAVEL", "WAIT"],
        "DESPAWN": [],
    }
    beh = {"policy_version": tc["behavior_policy"]["policy_version"],
           "categories": CATS,
           "class_map": classmap,
           "weights": dest_w,
           "class_archetype_weights": CLW,
           "movement_machine": {"machine_version": "move/1",
                                "states": MOVE_MACHINE},
           "behavior_machine": {"machine_version": "beh/1",
                                "states": BEH_MACHINE}}

    perc = {"policy_version": tc["perception_policy"]["policy_version"],
            "budget": tc["perception_policy"]["budget"],
            "archetypes": {k: {"los_m": v["los"], "fov_deg": v["fov"],
                                "proximity_m": v["prox"],
                                "reaction_ticks": v["react"],
                                "traffic_awareness": v["traffic"]}
                           for k, v in sorted(ARCH.items())}}

    # ---- checksums + writes ----
    nodes_l = [nodes[k] for k in sorted(nodes.keys())]
    edges_s = sorted(edges, key=lambda e: (e["a"], e["b"], e["kind"]))
    cross_s = sorted(crossings, key=lambda c: c["id"])
    settings = {"navigation_version": tc["navigation_version"],
                "agent": agent["radius_m"],
                "max_slope": max_slope,
                "river_clear": river_clear,
                "restricted": sorted(restr_pol),
                "cross_speed_max": 50,
                "cross_station_m": 120.0,
                "link_radius_m": 80.0}
    nav_core = {"areas": areas, "nodes": nodes_l, "edges": edges_s,
                "crossings": cross_s, "settings": settings,
                "sources": tc["sources"]}
    nav_checksum = fnv1a64_hex(canon(nav_core))
    pop_core = {"zones": zones, "archetypes": ARCH,
                "population_version": tc["population_version"],
                "sources": tc["sources"]}
    pop_checksum = fnv1a64_hex(canon(pop_core))
    pol_core = {"movement": tc["movement_policy"],
                "perception": tc["perception_policy"],
                "behavior": tc["behavior_policy"],
                "tiers": tc["simulation_tier_policy"],
                "lod": tc["lod_policy"],
                "performance": tc["performance_policy"]}
    pol_checksum = fnv1a64_hex(canon(pol_core))

    manifest = dict(nav_core)
    manifest["npc_navigation_checksum"] = nav_checksum
    manifest["stats"] = {"areas": len(areas), "nodes": len(nodes_l),
                         "edges": len(edges_s),
                         "crossings": len(cross_s),
                         "dropped_nodes": dropped,
                         "crossing_stats": cross_stats}
    json.dump(manifest, open(os.path.join(DD, "npc_navigation_manifest.json"),
                             "w"), indent=1, sort_keys=True)
    pop = dict(pop_core)
    pop["npc_population_checksum"] = pop_checksum
    pop["npc_policy_checksum"] = pol_checksum
    json.dump(pop, open(os.path.join(DD, "npc_population_manifest.json"),
                        "w"), indent=1, sort_keys=True)
    json.dump({"zones": spawn_zones,
               "spawn_policy": tc["spawn_policy"]["policy_version"]},
              open(os.path.join(DD, "npc_spawn_zones.json"), "w"),
              indent=1, sort_keys=True)
    beh["npc_behavior_checksum"] = fnv1a64_hex(canon(
        {k: v for k, v in beh.items()
         if k != "npc_behavior_checksum"}))
    perc["npc_perception_checksum"] = fnv1a64_hex(canon(
        {k: v for k, v in perc.items()
         if k != "npc_perception_checksum"}))
    json.dump(beh, open(os.path.join(DD, "npc_behavior_policy.json"),
                        "w"), indent=1, sort_keys=True)
    json.dump(perc, open(os.path.join(DD, "npc_perception_policy.json"),
                         "w"), indent=1, sort_keys=True)
    print("nav=%s areas=%d nodes=%d edges=%d crossings=%d dropped=%s" % (
        nav_checksum, len(areas), len(nodes_l), len(edges_s),
        len(cross_s), dropped))
    print("pop=%s pol=%s zones=%d targets=%d" % (
        pop_checksum, pol_checksum, len(zones),
        sum(z["target_population"] for z in zones)))


if __name__ == "__main__":
    main()
