"""P10 §87 WORLD-SCALE COVERAGE: all 12 coverage labels exercised.

For each label: move to district center, settle, verify sector READY,
no illegals/leaks, record population. Writes reports/p10/coverage.json.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
os.chdir(ROOT)

from gameplay_sim import GameWorld  # noqa: E402
from gameplay_gen import COVERAGE, bounds_center  # noqa: E402

LABELS = ["CITY", "SUBURBAN", "INDUSTRIAL", "PORT", "AIRFIELD",
          "RURAL", "FOREST", "WETLAND", "RESORT", "HIGHLAND",
          "COAST", "RESTRICTED"]


def main():
    assert set(LABELS) == set(COVERAGE), "coverage map drift"
    g = GameWorld(seed_tag="COVERAGE", player_start=(1401.0, 209.0))
    for _ in range(30):
        g.tick()
    rows = []
    fails = 0
    for lab in LABELS:
        did = COVERAGE[lab]
        cx, cz = bounds_center(g.districts[did]["bounds"])
        g.player["x"], g.player["z"] = cx, cz
        g.player["move_target"] = None
        g._step_player()
        for _ in range(30):
            g.tick()
        sid = g.npc.sector_of(cx, cz)
        st = g.npc.sector_state(sid)
        near_n = sum(1 for n in g.npc.npcs.values()
                     if abs(n["x"] - cx) < 200 and
                     abs(n["z"] - cz) < 200)
        ok = (st == "READY" and not g.illegal and
              not g.check_leaks())
        fails += (not ok)
        rows.append({"label": lab, "district": did, "sector": sid,
                     "state": st, "npcs_near": near_n,
                     "npcs_total": len(g.npc.npcs),
                     "vehicles": len(g.traffic.vehicles),
                     "pass": ok})
        print("  [%s] %-10s %s %s npcs=%d" % (
            "OK" if ok else "FAIL", lab, did, st, near_n),
            flush=True)
    g.shutdown()
    doc = {"result": "COVERAGE_OK" if not fails else "COVERAGE_FAIL",
           "rows": rows,
           "checks": "%d/%d" % (len(rows) - fails, len(rows))}
    with open("reports/p10/coverage.json", "w") as f:
        json.dump(doc, f, indent=1)
    print(doc["result"], doc["checks"])
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
