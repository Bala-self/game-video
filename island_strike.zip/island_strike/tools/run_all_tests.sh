#!/usr/bin/env bash
# ISLAND STRIKE — reproducible CI/test command path (Prompt 01, §35).
# Order: contract math -> foundation static -> import -> parse -> engine tests ->
# dump+cross -> inject -> reproduce -> smoke+audit -> benchmarks -> compare.
# Any failure aborts (set -e) with a non-zero exit. Logs under reports/logs/.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
GODOT_BIN="${GODOT_BIN:-$ROOT/tools/.godot/godot}"
if [ ! -x "$GODOT_BIN" ]; then GODOT_BIN="$(command -v godot || true)"; fi
if [ -z "${GODOT_BIN:-}" ] || [ ! -x "$GODOT_BIN" ]; then
  echo "Godot not found. Set GODOT_BIN or run: python3 tools/fetch_godot.py"
  exit 2
fi
export GODOT_BIN
echo "Using Godot: $GODOT_BIN ($("$GODOT_BIN" --version))"
mkdir -p reports/logs reports/performance

step() { echo; echo "===== STEP $1: $2 ====="; }

step 1 "world-contract math validator (Prompt 00, must stay 53/53)"
python3 tools/validate_world_contract.py | tail -2

step 2 "foundation static checks (no engine)"
python3 tools/validate_foundation.py static | tail -3

step 3 "resource import"
"$GODOT_BIN" --headless --path . --import > reports/logs/import.log 2>&1
python3 tools/validate_foundation.py audit-log reports/logs/import.log

step 4 "static parse of every GDScript"
FAIL=0
while IFS= read -r f; do
  if ! "$GODOT_BIN" --headless --path . --check-only --script "$f" > reports/logs/parse_tmp.log 2>&1; then
    echo "PARSE-FAIL: $f"; head -5 reports/logs/parse_tmp.log; FAIL=1
  fi
done < <(find scripts tests scenes -name '*.gd' | sort)
[ "$FAIL" -eq 0 ] || { echo "parse failures present"; exit 1; }
echo "all $(find scripts tests scenes -name '*.gd' | wc -l) scripts parse OK"

step 5 "headless engine tests (unit + integration)"
"$GODOT_BIN" --headless --path . --script res://tests/godot/test_runner.gd \
  > reports/logs/engine_tests.log 2> reports/logs/engine_tests.err
grep -E "TEST_SUMMARY|TEST_RUN" reports/logs/engine_tests.log

step 6 "registry dump + cross-layer validation"
"$GODOT_BIN" --headless --path . --script res://tests/godot/tools/contract_check.gd \
  -- --dump /tmp/is_ci_dump.json > reports/logs/dump.log 2>&1
grep -E "CONTRACT_OK" reports/logs/dump.log
python3 tools/validate_foundation.py cross /tmp/is_ci_dump.json | tail -3

step 7 "failure injection (mutants must fail loudly)"
python3 tools/validate_foundation.py inject | tail -3

step 8 "reproducibility (two runs, identical deterministic core)"
python3 tools/validate_foundation.py reproduce | tail -3

step 9 "runtime smoke (main scene, 30 frames) + log audit"
"$GODOT_BIN" --headless --path . --quit-after 30 \
  > reports/logs/smoke.log 2> reports/logs/smoke.err
python3 tools/validate_foundation.py audit-log reports/logs/smoke.log reports/logs/smoke.err | tail -3

step 10 "micro-benchmarks (in-engine)"
"$GODOT_BIN" --headless --path . --script res://tests/godot/benchmarks/foundation_benchmark.gd \
  > reports/logs/microbench.log 2>&1
grep -E "BENCH_OK" reports/logs/microbench.log

step 11 "macro-benchmarks (cold start + frame stats)"
python3 tools/validate_foundation.py bench-macro | tail -3

step 12 "baseline comparison (informational)"
python3 tools/benchmark/compare_baseline.py \
  reports/performance/foundation_baseline.json reports/performance/foundation_baseline.json \
  | head -6 || true

echo
echo "ALL STEPS PASSED"
