"""P10 §88 FULL-STACK STRESS: dense city + traffic + NPCs + active
mission + wanted pursuit + event + streaming + save/checkpoint activity,
sustained measured run. Methodology: process_time_ns CPU per tick,
ru_maxrss + /proc VmRSS memory (established P08-D12 discipline).

Writes reports/p10/stress.json. Exit 0 iff bounded + clean.
"""
import json
import math
import os
import resource
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
os.chdir(ROOT)

from gameplay_sim import GameWorld  # noqa: E402

TICKS = 1200
SAMPLE_EVERY = 100


def rss_kb():
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1])
    except OSError:
        return 0
    return 0


def p10_pins(g):
    n = sum(1 for p in g.npc.pins.values()
            if str(p.get("owner", "")).split(":")[0] in (
                "mission", "police"))
    for v in g.traffic.vehicles.values():
        for (_p, _s, r) in v.get("pins", []):
            if str(r).split(":")[0] in ("mission", "police"):
                n += 1
    return n


def main():
    print("STRESS: booting dense-city full stack...", flush=True)
    g = GameWorld(seed_tag="STRESS", player_start=(1401.0, 209.0),
                  start_money=500)
    for _ in range(60):
        g.tick()
    # active mission with roles + pursuit + armed event
    sc = g.missions["M-ESCORT-01"]["start_conditions"]["player_at"]
    g.player["x"], g.player["z"] = sc["point"]
    g._step_player()
    for _ in range(10):
        g.tick()
    g.act_offer("M-ESCORT-01")
    g.act_accept("M-ESCORT-01")
    ok, iid = g.act_start("M-ESCORT-01")
    assert ok, iid
    for i in range(6):
        n = g.npc.acquire(
            "CIVILIAN", "PZ-D-hub-core", g.player["x"] +
            ((i % 3) - 1) * 6.0, g.player["z"] +
            ((i // 3) - 1) * 6.0, context="crowd")
        if n is not None:
            n["tier"] = "T3_full"
    g.npc._rehash()
    g.commit_offense("TRESPASS", g.player["x"], g.player["z"])
    g.commit_offense("TRESPASS", g.player["x"], g.player["z"])
    g.arm_event("EVT-market-day")
    pts = []
    for m in g.missions.values():
        pts.append(m["start_conditions"]["player_at"]["point"])
    samples = []
    cpu_ms, wall_ms = [], []
    mids = ["M-ESCORT-01", "M-MEET-01", "M-TRAVEL-01", "M-FOLLOW-01"]
    for t in range(TICKS):
        if t % 200 == 0 and t:
            pt = pts[(t // 200) % len(pts)]
            g.player["x"], g.player["z"] = pt
            g.player["move_target"] = None
            g._step_player()
            # sustain mission pressure: (re)start when idle
            if g.active is None:
                mid = mids[(t // 200) % len(mids)]
                sc = g.missions[mid]["start_conditions"][
                    "player_at"]
                g.player["x"], g.player["z"] = sc["point"]
                g._step_player()
                if g.mstates[mid] == "AVAILABLE":
                    g.act_offer(mid)
                if g.mstates[mid] == "OFFERED":
                    g.act_accept(mid)
                if g.mstates[mid] == "ACCEPTED":
                    g.act_start(mid)
            # sustain wanted pressure: crowd + re-offend when clear
            if g.wanted["level"] == "NONE":
                for i in range(4):
                    n = g.npc.acquire(
                        "CIVILIAN", "PZ-D-hub-core",
                        g.player["x"] + (i - 1.5) * 5.0,
                        g.player["z"], context="crowd")
                    if n is not None:
                        n["tier"] = "T3_full"
                g.npc._rehash()
                g.commit_offense("TRESPASS", g.player["x"],
                                 g.player["z"])
        if t % 200 == 100:
            g.save_game("stress-%d" % t)
        c0, w0 = time.process_time_ns(), time.perf_counter_ns()
        g.tick()
        cpu_ms.append((time.process_time_ns() - c0) / 1e6)
        wall_ms.append((time.perf_counter_ns() - w0) / 1e6)
        if t % SAMPLE_EVERY == 0 or t == TICKS - 1:
            samples.append({
                "tick": g.tick_n,
                "cpu_ms_tick": round(sum(cpu_ms[-100:]) /
                                     len(cpu_ms[-100:]), 3),
                "wall_ms_tick": round(sum(wall_ms[-100:]) /
                                      len(wall_ms[-100:]), 3),
                "rss_kb": rss_kb(),
                "npcs": len(g.npc.npcs),
                "vehicles": len(g.traffic.vehicles),
                "pins_p10": p10_pins(g),
                "subs": len(g.subs),
                "txns": len(g.txns),
                "bus": len(g.bus),
                "wanted": g.wanted["level"],
                "mission": g.active["mid"] if g.active else None,
                "pursuit": g.wanted["pursuit"]["state"]
                if g.wanted["pursuit"] else None})
            s = samples[-1]
            print("  t=%d cpu=%.2fms wall=%.2fms rss=%dKB npc=%d "
                  "veh=%d pins=%d %s/%s/%s" % (
                      s["tick"], s["cpu_ms_tick"],
                      s["wall_ms_tick"], s["rss_kb"], s["npcs"],
                      s["vehicles"], s["pins_p10"], s["mission"],
                      s["wanted"], s["pursuit"]), flush=True)
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # bounded-growth verdicts (no unexplained unbounded growth)
    pins = [s["pins_p10"] for s in samples]
    subs = [s["subs"] for s in samples]
    rss = [s["rss_kb"] for s in samples]
    checks = {
        "pins_bounded": max(pins) <= 8,
        "subs_bounded": max(subs) <= 4,
        "rss_growth_kb": rss[-1] - rss[0],
        "rss_bounded": rss[-1] - rss[0] < 150000,
        "no_illegals": not g.illegal,
        "no_leaks": not g.check_leaks(),
    }
    ok_all = all(checks.values())
    # per-system tick profile (P10 _timed sections)
    prof = {}
    if hasattr(g, "perf"):
        for k, v in sorted(g.perf.items()):
            prof[k] = {"cpu_ms_total": round(v["cpu"] * 1000.0, 1),
                       "n": v["n"],
                       "cpu_ms_mean": round(
                           v["cpu"] * 1000.0 / max(v["n"], 1), 4)}
    doc = {"result": "STRESS_OK" if ok_all else "STRESS_FAIL",
           "ticks": TICKS,
           "cpu_ms_tick_mean": round(sum(cpu_ms) / len(cpu_ms), 3),
           "cpu_ms_tick_p95": round(sorted(cpu_ms)[
               int(len(cpu_ms) * 0.95)], 3),
           "wall_ms_tick_mean": round(sum(wall_ms) / len(wall_ms),
                                      3),
           "peak_rss_kb": peak,
           "samples": samples, "checks": checks, "profile": prof}
    with open("reports/p10/stress.json", "w") as f:
        json.dump(doc, f, indent=1)
    print(("STRESS_OK " if ok_all else "STRESS_FAIL ") +
          "cpu=%.2fms wall=%.2fms peak=%dKB" % (
              doc["cpu_ms_tick_mean"], doc["wall_ms_tick_mean"],
              peak))
    return 0 if ok_all else 1


if __name__ == "__main__":
    raise SystemExit(main())
