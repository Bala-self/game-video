"""P10 §89 FINAL LONG-RUN: cycle travel/mission/failure/retry/economy/
wanted/escape/save/load/district-transition; start/mid/end bounded +
explainable. Writes reports/p10/longrun.json.
"""
import json
import math
import os
import resource
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
os.chdir(ROOT)

from gameplay_sim import GameWorld  # noqa: E402

ROUNDS = 3


def rss_kb():
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1])
    except OSError:
        return 0
    return 0


def goto(g, mid):
    sc = g.missions[mid]["start_conditions"]["player_at"]
    g.player["x"], g.player["z"] = sc["point"]
    g.player["move_target"] = None
    g._step_player()
    for _ in range(10):
        g.tick()


def snap(g, tag):
    return {"tag": tag, "tick": g.tick_n, "rss_kb": rss_kb(),
            "pins_npc": len(g.npc.pins),
            "npcs": len(g.npc.npcs),
            "vehicles": len(g.traffic.vehicles),
            "instances": g.inst_seq, "txns": len(g.txns),
            "subs": len(g.subs), "flags": len(g.world_flags),
            "completed": len(g.completed)}


def play_meet(g):
    o = g.missions["M-MEET-01"]["objective_defs"][0]
    g.act_move(*o["requirements"]["point"])
    for _ in range(1500):
        g.tick()
        d = math.hypot(o["requirements"]["point"][0] -
                       g.player["x"],
                       o["requirements"]["point"][1] -
                       g.player["z"])
        if d <= 6.0:
            g.act_interact()
        if g.mstates["M-MEET-01"] in ("SUCCEEDED", "COOLDOWN"):
            break


def main():
    t0 = time.perf_counter()
    g = GameWorld(seed_tag="LONGRUN", player_start=(1401.0, 209.0),
                  start_money=500)
    for _ in range(30):
        g.tick()
    snaps = [snap(g, "start")]
    print("start:", snaps[0], flush=True)
    districts = ["D-hub-core", "D-vil-core", "D-port-ops",
                 "D-hub-core"]
    for r in range(ROUNDS):
        # travel leg (honest walk between mission points)
        goto(g, "M-TRAVEL-01")
        o = g.missions["M-TRAVEL-01"]["objective_defs"][0]
        g.act_move(*o["requirements"]["point"])
        for _ in range(400):
            g.tick()
        # mission: meet complete (first round) / retry cycle
        goto(g, "M-MEET-01")
        if r == 0:
            g.act_offer("M-MEET-01")
            g.act_accept("M-MEET-01")
            g.act_start("M-MEET-01")
            play_meet(g)
        # failure: escort NPC loss (instant honest fail per P09 lock)
        goto(g, "M-ESCORT-01")
        g.act_offer("M-ESCORT-01")
        g.act_accept("M-ESCORT-01")
        ok, _ = g.act_start("M-ESCORT-01")
        if ok:
            nid = g.active["npcs"].get("ESCORT_TARGET")
            n = g.npc.npcs.get(nid)
            g.npc.despawn(n, "longrun_removal")
            for _ in range(5):
                g.tick()
        assert g.mstates["M-ESCORT-01"] in ("FAILED", "COOLDOWN"), \
            g.mstates["M-ESCORT-01"]
        for _ in range(650):
            g.tick()
            if g.tick_n >= g.cooldowns.get("M-ESCORT-01", 0):
                break
        # retry then abort (attempt counted, cooldown again)
        g.act_retry("M-ESCORT-01")
        g.act_abort()
        for _ in range(650):
            g.tick()
            if g.tick_n >= g.cooldowns.get("M-ESCORT-01", 0):
                break
        # economy
        shop = g.eco["shops"][r % len(g.eco["shops"])]
        g.player["x"], g.player["z"] = shop["point"]
        g._step_player()
        g.act_buy(shop["shop_id"], shop["business"])
        g.act_sell(shop["shop_id"], shop["business"])
        # wanted + escape (flee far, break contact)
        for i in range(4):
            n = g.npc.acquire(
                "CIVILIAN", "PZ-D-hub-core", g.player["x"] +
                ((i % 2)) * 8.0 - 4.0, g.player["z"] +
                (i // 2) * 8.0 - 4.0, context="crowd")
            if n is not None:
                n["tier"] = "T3_full"
        g.npc._rehash()
        for _ in range(5):
            g.tick()
        g.commit_offense("TRESPASS", g.player["x"], g.player["z"])
        for _ in range(10):
            g.tick()
        g.player["x"] += 500.0
        g.player["z"] += 500.0
        g._step_player()
        for _ in range(1500):
            g.tick()
            if g.wanted["level"] == "NONE":
                break
        assert g.wanted["level"] == "NONE", g.wanted["level"]
        # save + load + district transition
        g.save_game("long-%d" % r)
        ok, why = g.load_game("long-%d" % r)
        assert ok, why
        from gameplay_gen import bounds_center
        cx, cz = bounds_center(
            g.districts[districts[(r + 1) % len(districts)]]["bounds"])
        g.player["x"], g.player["z"] = cx, cz
        g.player["move_target"] = None
        g._step_player()
        for _ in range(30):
            g.tick()
        snaps.append(snap(g, "round-%d" % r))
        print("round %d:" % r, snaps[-1], flush=True)
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    s0, sN = snaps[0], snaps[-1]
    # explainable deltas: txns/instances grow linearly w/ rounds;
    # everything else must return near baseline
    tx_per_round = (sN["txns"] - s0["txns"]) / ROUNDS
    checks = {
        "pins_stable": sN["pins_npc"] <= s0["pins_npc"] + 2,
        "subs_stable": sN["subs"] <= 2,
        "npcs_bounded": sN["npcs"] < 1200,
        "flags_small": sN["flags"] < 30,
        "tx_linear": tx_per_round < 12,
        "rss_growth_kb": sN["rss_kb"] - s0["rss_kb"],
        "rss_bounded": sN["rss_kb"] - s0["rss_kb"] < 150000,
        "no_illegals": not g.illegal,
        "no_leaks": not g.check_leaks(),
    }
    ok_all = all(checks.values())
    g.shutdown()
    doc = {"result": "LONGRUN_OK" if ok_all else "LONGRUN_FAIL",
           "rounds": ROUNDS, "elapsed_s": round(
               time.perf_counter() - t0, 1),
           "peak_rss_kb": peak, "snaps": snaps, "checks": checks}
    with open("reports/p10/longrun.json", "w") as f:
        json.dump(doc, f, indent=1)
    print(doc["result"], {k: checks[k] for k in checks})
    return 0 if ok_all else 1


if __name__ == "__main__":
    raise SystemExit(main())
