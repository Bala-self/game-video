#!/usr/bin/env python3
"""ISLAND STRIKE — terrain/coast design tuning harness (Prompt 02).

Measures the Python twin (tools/terrain_model.py) against locked targets:
  1 coast geometry  2 curvature  3 beach runs/shares  4 region census (disc-based)
  5 heights  6 runway  7 river  8 cliff transect  9 beach+seabed profiles
  10 corridor grades  11 section-79 backing probes  12 loop probes
  13 urban grades/variance/lake/geography-fraction  14 feature spacing.
Run:  python3 tools/tune_terrain.py
"""
import math, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools.terrain_model import Field, CoastLoop, poly_dist, ring_dist  # noqa: E402

TAU = 2 * math.pi
DISC = math.pi * 2000.0 ** 2
t0 = time.time()
f = Field()
print('build Field: %.1fs' % (time.time() - t0))

# ---- 1. coast geometry ----
N = len(f.lut)
print('lut_n=%d spacing=%.2fm' % (N, f.coast_length / N))
ths = [i * TAU / N for i in range(N)]
rss = [f.loop.rs(t) for t in ths]
mean_rs = sum(rss) / N
var = sum((r - mean_rs) ** 2 for r in rss) / N
loop_len = f.coast_length
print('loop=%.1fm nominal_tort=%.4f shape_tort=%.4f mean_rs=%.1f std=%.1f range=%.0f' % (
    loop_len, loop_len / (TAU * 2000.0), loop_len / (TAU * mean_rs),
    mean_rs, math.sqrt(var), max(rss) - min(rss)))
print('rs min=%.1f max=%.1f pos_scale=%.3f neg_scale=%.3f' % (
    min(rss), max(rss), f.loop.pos_scale, f.loop.neg_scale))

# ---- 2. curvature ----
kmax = max(abs(e['curv']) for e in f.lut)
klim = f.cc['validation']['max_curvature_per_m']
print('curv max=%.5f limit=%.3f %s' % (kmax, klim, 'OK' if kmax < klim else 'VIOLATION'))
for name, deg in [('cove_west', 270), ('marina', 127), ('resort', 235),
                  ('headland', 310), ('city', 90), ('cove_ne', 41), ('north', 2)]:
    i = int(round(deg / 360 * N)) % N
    e = f.lut[i]
    print('  %-9s k=%+.5f conc=%+.2f class=%-16s w=%5.1f owner=%s' % (
        name, e['curv_meso'], -e['curv_meso'] * 300.0, e['class'], e['width'], e['region']))

# ---- 3. beach runs + locked shares ----
runs = Field._runs(f.lut, loop_len)
print('runs=%d min_run=%.0fm classes=%d/9' % (
    len(runs), min(r[3] for r in runs), len(set(r[2] for r in runs))))
hist = {}
for (_, _, cl, ln) in runs:
    hist[cl] = hist.get(cl, 0) + ln
stol_rel = f.cc['validation']['share_tol_rel']
stol_abs = f.cc['validation']['share_tol_abs_pp']
for b in f.cc['beach_classes']:
    cl, tgt = b['key'], b['share_pct']
    got = 100 * hist.get(cl, 0) / loop_len
    ok = abs(got - tgt) <= max(stol_rel * tgt, stol_abs)
    print('  %-16s locked=%4.1f got=%5.1f %s' % (cl, tgt, got, 'OK' if ok else '<-- DRIFT'))
# adjacency: cliff never next to port classes
for k in range(len(runs)):
    a, b = runs[k][2], runs[(k + 1) % len(runs)][2]
    if (a == 'cliff' and b in ('industrial_port', 'marina')) or \
       (b == 'cliff' and a in ('industrial_port', 'marina')):
        print('  ADJACENCY VIOLATION:', a, b)
print('  adjacency cliff/port: checked')

# ---- 4. region census (8 m grid, disc-based vs locked §7) ----
counts, land = {}, 0
for gz in range(-250, 250):
    for gx in range(-250, 250):
        x, z = gx * 8 + 4, gz * 8 + 4
        if x * x + z * z > 2000 * 2000:
            continue
        rid = f.region_at(x, z)
        if rid == 'open_water':
            continue
        land += 1
        counts[rid] = counts.get(rid, 0) + 1
B = f.tc['budgets']['region_share_pct']
rtol_rel = f.tc['validation']['region_tol_rel']
rtol_abs = f.tc['validation']['region_tol_abs_pp']
print('land=%.2fkm2 sea=%.2fkm2' % (land * 64 / 1e6, (DISC - land * 64) / 1e6))
for rid, tgt in sorted(B.items(), key=lambda kv: -kv[1]):
    area = counts.get(rid, 0) * 64
    got = 100 * area / DISC
    ok = abs(got - tgt) <= max(rtol_rel * tgt, rtol_abs)
    print('  %-20s locked=%4.1f got=%5.1f %s' % (rid, tgt, got, 'OK' if ok else '<-- DRIFT'))

# ---- 5. heights (8 m grid, land) ----
hmin, hmax, hsum, hn = 1e9, -1e9, 0.0, 0
peak, peak_xy = -1e9, (0, 0)
over220, clamped250 = 0, 0
for gz in range(-250, 250):
    for gx in range(-250, 250):
        x, z = gx * 8 + 4, gz * 8 + 4
        if x * x + z * z > 2000 * 2000 or not f.is_land(x, z):
            continue
        hn += 1
        h = f.height(x, z)
        hsum += h
        hmin = min(hmin, h)
        hmax = max(hmax, h)
        if h > peak:
            peak, peak_xy = h, (x, z)
        if h > 220.0:
            over220 += 1
        if f.height_raw(x, z) > 250.0:
            clamped250 += 1
pb = f.tc['validation']['peak_design_band_m']
print('land h: min=%.1f max=%.1f mean=%.1f peak=%.1f at %s band=[%.0f,%.0f] %s over220=%d clamped250=%d' % (
    hmin, hmax, hsum / hn, peak, peak_xy, pb[0], pb[1],
    'OK' if pb[0] <= peak <= pb[1] else '<-- OUT', over220, clamped250))

# ---- 6. runway ----
rw = f.au['runway']
hd = math.radians(rw['heading_deg'])
ax, az = math.sin(hd), -math.cos(hd)
cx, cz = rw['center']
devs = []
for u in range(-400, 401, 20):
    for v in (-40, -20, 0, 20, 40):
        x, z = cx + u * ax - v * az, cz + u * az + v * ax
        devs.append(abs(f.height(x, z) - rw['target_m']))
print('runway %s: max_dev=%.3fm' % (rw['id'], max(devs)))

# ---- 7. river profile ----
riv = f.au['drainage']['rivers'][0]
print('river %s:' % riv['id'])
pts = riv['points']
for i, (px, pz) in enumerate(pts):
    h = f.height(px, pz)
    q = pts[min(i + 1, len(pts) - 1)]
    dx, dz = q[0] - px, q[1] - pz
    L = math.hypot(dx, dz) or 1.0
    ho = f.height(px - dz / L * 40, pz + dx / L * 40)
    print('  pt%d (%6.0f,%6.0f) h=%6.1f carve=%4.1f' % (i, px, pz, h, ho - h))

# ---- 8. cliff transect ----
print('cliff transect theta=306 (d inland, h):')
thc = math.radians(306.0)
rsc = f.loop.rs(thc)
prev = None
for d in [0, 4, 8, 16, 30, 50, 80, 120, 150, 200]:
    x, z = (rsc - d) * math.sin(thc), -(rsc - d) * math.cos(thc)
    h = f.height(x, z)
    sl = '' if prev is None else ' slope=%.0fdeg' % math.degrees(math.atan((h - prev[0]) / (d - prev[1])))
    print('  d=%3d h=%6.1f%s' % (d, h, sl))
    prev = (h, d)

# ---- 9. beach + seabed profiles per class ----
print('beach/seabed profiles:')
seen = {}
for e in f.lut:
    if e['class'] not in seen:
        seen[e['class']] = e
for cl in sorted(seen):
    e = seen[cl]
    th, rs = e['theta'], e['rs']
    w = e['width']
    hs = []
    for d in [0.0, w, 150.0]:
        x, z = (rs - d) * math.sin(th), -(rs - d) * math.cos(th)
        hs.append(f.height(x, z))
    sea = []
    for s in [50.0, 150.0, 300.0]:
        x, z = (rs + s) * math.sin(th), -(rs + s) * math.cos(th)
        sea.append(f.height(x, z))
    print('  %-16s berm=%.1f w=%5.1f h(0,w,150)=%s sea(50,150,300)=%s' % (
        cl, e['berm'], w, ' '.join('%6.1f' % v for v in hs),
        ' '.join('%6.1f' % v for v in sea)))

# ---- 10. corridors: grades, tunnel, exclusions, junctions ----
def sample_polyline(P, step_m=10.0):
    path = []
    for i in range(len(P) - 1):
        ax0, az0 = P[i]
        bx0, bz0 = P[i + 1]
        L = math.hypot(bx0 - ax0, bz0 - az0)
        n = max(1, int(L / step_m))
        for j in range(n):
            path.append((ax0 + (bx0 - ax0) * j / n, az0 + (bz0 - az0) * j / n))
    path.append(tuple(P[-1]))
    return path

def profile(path):
    hs = [f.height(x, z) for (x, z) in path]
    ds = [0.0]
    for i in range(1, len(path)):
        ds.append(ds[-1] + math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1]))
    win = 5  # +-50m smoothing per contract corridor_grade_method
    sm = [sum(hs[max(0, i - win):i + win + 1]) / len(hs[max(0, i - win):i + win + 1])
          for i in range(len(hs))]
    step = ds[1] - ds[0] if len(ds) > 1 else 10.0
    gr = [abs(sm[i + 1] - sm[i]) / step * 100.0 for i in range(len(sm) - 1)]
    w200 = max(1, int(200 / step))
    roll = [sum(gr[max(0, i - w200 + 1):i + 1]) / len(gr[max(0, i - w200 + 1):i + 1])
            for i in range(len(gr))]
    return ds, sm, gr, roll

print('corridor grades (P02 ground-compatibility, section 26; macro 50m smooth):')
gcaps = f.tc['validation']['corridor_ground_caps_pct']
rcaps = f.tc['validation']['corridor_grade_caps_pct']
tch = f.tc['validation']['tunnel_checks']
ring_path = None
for cor in f.au['corridors']:
    if cor['type'] == 'ring':
        n = int(TAU * cor['r_m'] / 10.0)
        path = [(cor['r_m'] * math.sin(i * TAU / n), -cor['r_m'] * math.cos(i * TAU / n))
                for i in range(n)]
    else:
        path = sample_polyline(cor['points'])
    if cor['id'] == 'ring_hw':
        ring_path = path
    ds, sm, gr, roll = profile(path)
    if cor['type'] == 'tunnel':
        hp0 = f.height(*cor['portals'][0])
        hp1 = f.height(*cor['portals'][1])
        tg = abs(hp1 - hp0) / ds[-1] * 100.0
        bore_y = [hp0 + (hp1 - hp0) * d / ds[-1] for d in ds]
        cover = [s - b for (s, b) in zip(sm, bore_y)]
        deep = [c for (c, d) in zip(cover, ds) if 150 < d < ds[-1] - 150]
        p0, p1, p2 = [tuple(p) for p in cor['points']]
        v1 = (p1[0] - p0[0], p1[1] - p0[1])
        v2 = (p2[0] - p1[0], p2[1] - p1[1])
        bend = math.degrees(math.acos(max(-1.0, min(1.0, (v1[0] * v2[0] + v1[1] * v2[1]) /
            (math.hypot(*v1) * math.hypot(*v2))))))
        ok = tg <= tch['bore_grade_pct'] and min(deep) >= tch['min_cover_m'] and bend <= tch['max_bend_deg']
        print('  %-13s TUNNEL len=%.2fkm bore_grade=%.2f%% (cap %.0f) min_deep_cover=%.0fm (floor %.0f) bend=%.1fdeg (cap %.0f) %s' % (
            cor['id'], ds[-1] / 1000, tg, tch['bore_grade_pct'], min(deep), tch['min_cover_m'],
            bend, tch['max_bend_deg'], 'OK' if ok else '<-- VIOLATION'))
        for (px, pz), pr in zip(cor['portals'], cor['portal_works_r_m']):
            r = math.hypot(px, pz)
            th = math.degrees(math.atan2(px, -pz)) % 360
            dd = f.loop.rs(math.radians(th)) - r
            hp = f.height(px, pz)
            print('    portal (%d,%d): h=%.0f d_shore=%.0f (floor %.0f) works_r=%.0f region=%s %s' % (
                px, pz, hp, dd, tch['portal_min_d_shore_m'], pr, f.region_at(px, pz),
                'OK' if dd >= tch['portal_min_d_shore_m'] else '<-- VIOLATION'))
        continue
    cap, rcap = gcaps[cor['class']], rcaps[cor['class']]
    short, sust = max(gr), max(roll)
    ok = short <= cap['short'] and sust <= cap['sustained']
    print('  %-13s class=%-9s len=%.1fkm short=%.1f%% (gcap %.0f) sust=%.1f%% (gcap %.0f) %s' % (
        cor['id'], cor['class'], ds[-1] / 1000, short, cap['short'], sust, cap['sustained'],
        'OK' if ok else '<-- VIOLATION'))
    imax = max(range(len(gr)), key=lambda i: gr[i])
    print('    worst at dist=%.0fm h=%.0fm grade=%.1f%% near (%0.f,%0.f)%s' % (
        ds[imax], sm[imax], gr[imax], path[imax][0], path[imax][1],
        ' [P04-bench: exceeds road cap]' if gr[imax] > rcap['short'] else ''))
    if sust > rcap['sustained']:
        print('    sustained %.1f%% exceeds road cap %.0f%% [P04-bench]' % (sust, rcap['sustained']))

# 10b. ring exclusion scan (every ~25 m vs urban/port/resort/restricted/runway/lake)
def ell_nd(x, z, s):
    return math.hypot((x - s['cx']) / s['rx'], (z - s['cz']) / s['rz'])
excl = {}
for r in f.au['regions']:
    for s in r.get('shapes', []):
        tag = s.get('tag') or r['id']
        if r['id'] == 'urban_core' and tag == 'urban_core':
            excl['urban'] = (s, 1.05)
        if tag == 'port_shape':
            excl['port_shape'] = (s, 1.15)
        if tag == 'resort_shape':
            excl['resort'] = (s, 1.10)
        if tag == 'restricted_shape':
            excl['restricted'] = (s, 1.05)
rw = f.au['runway']
lk = f.au['drainage']['lakes'][0]
print('ring exclusion scan (min normalized distance / clearance along ring_hw):')
scan = ring_path[::3]
for name, (s, floor) in sorted(excl.items()):
    vals = [(ell_nd(x, z, s), x, z) for (x, z) in scan]
    m, mx, mz = min(vals)
    print('  %-10s min_nd=%.3f (floor %.2f) at (%0.f,%0.f) %s' % (
        name, m, floor, mx, mz, 'OK' if m >= floor else '<-- VIOLATION'))
rwc = [max(a, b) for (a, b) in
       [(max(rw['center'][0] - rw['length_m'] / 2 - 60 - x, x - (rw['center'][0] + rw['length_m'] / 2 + 60)),
         max(rw['center'][1] - rw['width_m'] / 2 - 60 - z, z - (rw['center'][1] + rw['width_m'] / 2 + 60)))
        for (x, z) in scan]]
print('  runway     min_clear=%.0fm (strip+60m margin, floor 0) %s' % (
    min(rwc), 'OK' if min(rwc) >= 0 else '<-- VIOLATION'))
lkm = [min(ell_nd(x, z, lk), 9.99) for (x, z) in scan]
print('  lake       min_nd=%.3f (floor 1.30) %s' % (min(lkm), 'OK' if min(lkm) >= 1.30 else '<-- VIOLATION'))

# 10c. junctions (radial ends in ring band; spur start in portal disc, end on fence)
from tools.terrain_model import poly_dist as _pd
ringc = next(c for c in f.au['corridors'] if c['id'] == 'ring_hw')
tunc = next(c for c in f.au['corridors'] if c['id'] == 'ring_hw_north_tunnel')
print('junctions:')
for cid, end in [('radial_north', -1), ('radial_south', -1), ('radial_west', -1)]:
    c = next(x for x in f.au['corridors'] if x['id'] == cid)
    p = c['points'][end]
    dd = _pd(p[0], p[1], ringc['points'])
    print('  %-13s end (%d,%d) to ring_hw: %.1fm (cap 15) %s' % (
        cid, p[0], p[1], dd, 'OK' if dd <= 15 else '<-- VIOLATION'))
sp = next(x for x in f.au['corridors'] if x['id'] == 'spur_restricted_access')
s0, s1 = sp['points'][0], sp['points'][-1]
d0 = math.hypot(s0[0] - tunc['portals'][0][0], s0[1] - tunc['portals'][0][1])
print('  spur start (%d,%d) to E portal: %.1fm (cap %.0f) %s' % (
    s0[0], s0[1], d0, tunc['portal_works_r_m'][0], 'OK' if d0 <= tunc['portal_works_r_m'][0] else '<-- VIOLATION'))
rs = excl['restricted'][0]
g = ell_nd(s1[0], s1[1], rs)
print('  spur end (%d,%d) fence gate |nd-1|=%.3f (cap 0.05) %s' % (
    s1[0], s1[1], abs(g - 1), 'OK' if abs(g - 1) <= 0.05 else '<-- VIOLATION'))

# 10d. corridor-corridor surface intersections (info: P04 junction candidates)
def seg_x(p1, p2, p3, p4):
    d = (p2[0] - p1[0]) * (p4[1] - p3[1]) - (p2[1] - p1[1]) * (p4[0] - p3[0])
    if abs(d) < 1e-9:
        return None
    t = ((p3[0] - p1[0]) * (p4[1] - p3[1]) - (p3[1] - p1[1]) * (p4[0] - p3[0])) / d
    u = ((p3[0] - p1[0]) * (p2[1] - p1[1]) - (p3[1] - p1[1]) * (p2[0] - p1[0])) / d
    if 0 <= t <= 1 and 0 <= u <= 1:
        return (p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1]))
    return None
print('corridor intersections (surface, info):')
surf = [c for c in f.au['corridors'] if c['type'] in ('polyline', 'ring')]
for i in range(len(surf)):
    for j in range(i + 1, len(surf)):
        A, B = surf[i], surf[j]
        PA = sample_polyline(A['points'], 25.0) if A['type'] == 'polyline' else None
        PB = sample_polyline(B['points'], 25.0) if B['type'] == 'polyline' else None
        if PA is None or PB is None:
            continue
        hits = set()
        for a in range(len(PA) - 1):
            for b in range(len(PB) - 1):
                h = seg_x(PA[a], PA[a + 1], PB[b], PB[b + 1])
                if h:
                    hits.add((round(h[0] / 50) * 50, round(h[1] / 50) * 50))
        if hits:
            print('  %s x %s: %s' % (A['id'], B['id'], sorted(hits)))

# ---- 11. section-79 backing probes (hinterland at d=+40) ----
def hinterland(x, z):
    ws = f.regions.weights(x, z)
    if not ws:
        return ('reserve_buffer', '')
    ws.sort(key=lambda e: (-e['w'], -e['pri']))
    top = ws[0]
    if top['w'] < 0.15:
        return ('reserve_buffer', '')
    return (top['id'], top['tag'])

print('backing probes (hinterland region/tag at d=+40):')
for deg in [80, 84, 88, 92, 96, 100, 102, 104, 108, 112, 116, 120, 127, 134,
            230, 234, 238, 240, 8, 12, 16, 20, 0, 306]:
    th = math.radians(deg)
    rs = f.loop.rs(th)
    x, z = (rs - 40) * math.sin(th), -(rs - 40) * math.cos(th)
    rid, tag = hinterland(x, z)
    print('  th=%3d owner=%-18s hinterland=%-18s tag=%s' % (
        deg, f.lut[int(round(deg / 360 * N)) % N]['region'], rid, tag))

# ---- 12. loop probes (R10-transparent identity + corridor contact) ----
print('loop probes (R10-transparent owner every ~25m):')
for lp in f.au['loops']:
    seq, seen_seq = lp['sequence'], []
    last = None
    worst_res, cur_res = 0, 0
    touched = set()
    W = lp['waypoints']
    for i in range(len(W) - 1):
        ax0, az0 = W[i]
        bx0, bz0 = W[i + 1]
        L = math.hypot(bx0 - ax0, bz0 - az0)
        n = max(1, int(L / 25.0))
        for j in range(n + 1):
            if i > 0 and j == 0:
                continue
            x = ax0 + (bx0 - ax0) * j / n
            z = az0 + (bz0 - az0) * j / n
            rid = f.region_at(x, z)
            if rid == 'infra_corridors':
                rid = hinterland(x, z)[0]
            for cid in lp.get('crosses_corridors', []):
                cc = f.regions.corridors[cid]
                if cc['type'] == 'tunnel':
                    continue  # a trail over a deep bore is not a junction
                dd = ring_dist(x, z, cc['r_m']) if cc['type'] == 'ring' else poly_dist(x, z, cc['points'])
                if dd < cc['width_m'] / 2.0:
                    touched.add(cid)
            if rid == 'reserve_buffer':
                cur_res += 1
            else:
                worst_res = max(worst_res, cur_res)
                cur_res = 0
            if rid != last:
                seen_seq.append(rid)
                last = rid
    worst_res = max(worst_res, cur_res) * 25
    si, ok = 0, True
    for want in seq:
        try:
            si = seen_seq.index(want, si) + 1
        except ValueError:
            ok = False
            break
    crosses_ok = set(lp.get('crosses_corridors', [])) <= touched
    print('  %-17s seq_ok=%s crosses_ok=%s max_reserve_run=%dm' % (
        lp['id'], ok, crosses_ok, worst_res))
    print('    seen: %s' % ' > '.join(seen_seq))

# ---- 13. urban grades, variance floors, lake, geography fraction ----
urb2, urbtot, urbmax = 0, 0, 0.0
for gz in range(-60, 90):
    for gx in range(100, 270):
        x, z = gx * 8 + 4, gz * 8 + 4
        if x * x + z * z > 2000 * 2000 or f.region_at(x, z) != 'urban_core':
            continue
        urbtot += 1
        _, grade = f.slope_grade(x, z)
        urbmax = max(urbmax, grade)
        if grade <= 2.0:
            urb2 += 1
print('urban: cells=%d pct<=2%%=%.0f%% max=%.1f%%' % (
    urbtot, 100 * urb2 / max(1, urbtot), urbmax))
# per-region std (coarse 16m) + geography fraction
import random
random.seed(7)
cells = []
for _ in range(20000):
    x = random.uniform(-1900, 1900)
    z = random.uniform(-1900, 1900)
    if x * x + z * z > 2000 * 2000 or not f.is_land(x, z):
        continue
    d = f.loop.rs(CoastLoop.theta(x, z)) - math.hypot(x, z)
    if d < 150:  # hinterland only (R8 heights are coast-owned)
        continue
    cells.append((x, z))
per = {}
hg_all, hn_all = [], []
for (x, z) in cells:
    h = f.height(x, z)
    g = f.height_raw(x, z, noise=False)
    hg_all.append(h)
    hn_all.append(g)
    rid = f.region_at(x, z)
    per.setdefault(rid, []).append(h)
for rid, hs in sorted(per.items()):
    m = sum(hs) / len(hs)
    sd = (sum((v - m) ** 2 for v in hs) / len(hs)) ** 0.5
    print('  std[%-18s] = %6.1fm (n=%d)' % (rid, sd, len(hs)))
mg = sum(hg_all) / len(hg_all)
mn = sum(hn_all) / len(hn_all)
vg = sum((v - mg) ** 2 for v in hg_all) / len(hg_all)
vn = sum((v - mn) ** 2 for v in hn_all) / len(hn_all)
nv = sum((a - b) ** 2 for a, b in zip(hg_all, hn_all)) / len(hg_all)
print('  geography_fraction(var-ratio, diagnostic)=%.3f noise_share_direct=%.3f' % (vn / vg, nv / vg))
print('  geography_fraction=%.3f (floor 0.5) %s' % (1 - nv / vg, 'OK' if 1 - nv / vg >= 0.5 else '<-- FAIL'))
# lake
lk = f.au['drainage']['lakes'][0]
hc = f.height(lk['cx'], lk['cz'])
rim = min(f.height(lk['cx'] + lk['rx'] * 1.6 * math.sin(a), lk['cz'] + lk['rz'] * 1.6 * math.cos(a))
          for a in [i * TAU / 16 for i in range(16)])
print('lake %s: floor=%.1f (target %.1f) rim_min=%.1f level=%.1f %s' % (
    lk['id'], hc, lk['floor_m'], rim, lk['level_m'], 'ENCLOSED' if rim > lk['level_m'] else '<-- LEAKS'))

# ---- 14. feature spacing ----
print('feature spacing (arc distance between geometric bay centers):')
bays = f.cc['authoring']['bays']
arcs = []
for b in bays:
    i = int(round(math.radians(b['theta_deg']) / TAU * N)) % N
    arcs.append((b['id'], f.lut[i]['arc']))
arcs.sort(key=lambda e: e[1])
gaps = []
for k in range(len(arcs)):
    a0 = arcs[k][1]
    a1 = arcs[(k + 1) % len(arcs)][1]
    gap = (a1 - a0) % loop_len
    gaps.append(gap)
    print('  %-13s -> %-13s %6.0fm' % (arcs[k][0], arcs[(k + 1) % len(arcs)][0], gap))
print('  min=%.0f avg=%.0f max=%.0f' % (min(gaps), sum(gaps) / len(gaps), max(gaps)))

# ---- 15. zones finder (urban pads + highland sites) ----
print('urban pad-suitable connected areas (grade<=2%, 8m cells):')
good = set()
for gz in range(-38, 76):
    for gx in range(112, 263):
        x, z = gx * 8 + 4, gz * 8 + 4
        if x * x + z * z > 2000 * 2000 or f.region_at(x, z) != 'urban_core':
            continue
        _, grade = f.slope_grade(x, z)
        if grade <= 2.0:
            good.add((gx, gz))
seen_c, comps = set(), []
for cell in good:
    if cell in seen_c:
        continue
    stack, comp = [cell], []
    seen_c.add(cell)
    while stack:
        c0 = stack.pop()
        comp.append(c0)
        for nb in ((c0[0] + 1, c0[1]), (c0[0] - 1, c0[1]), (c0[0], c0[1] + 1), (c0[0], c0[1] - 1)):
            if nb in good and nb not in seen_c:
                seen_c.add(nb)
                stack.append(nb)
    comps.append(comp)
comps.sort(key=len, reverse=True)
for comp in comps[:6]:
    xs = [c[0] * 8 + 4 for c in comp]
    zs = [c[1] * 8 + 4 for c in comp]
    print('  n=%5d (~%5.0fx%5.0fm) x[%0.f,%0.f] z[%0.f,%0.f]' % (
        len(comp), max(xs) - min(xs), max(zs) - min(zs),
        min(xs), max(xs), min(zs), max(zs)))
print('  (%d components total, %d cells)' % (len(comps), len(good)))
print('highland zones:')
pad = next(p for p in f.au['pads'] if p['id'] == 'summit_pad')
pdd = math.hypot(peak_xy[0] - pad['cx'], peak_xy[1] - pad['cz'])
ptop = f.height(pad['cx'], pad['cz'])
pw = 0.0
for k in range(24):
    a = k * TAU / 24
    for rr in (8, 16, 24):
        deg, _ = f.slope_grade(pad['cx'] + rr * math.sin(a), pad['cz'] + rr * math.cos(a))
        pw = max(pw, deg)
print('  summit_pad: peak (%0.f,%0.f) dist=%.0fm (r %.0f) %s; top=%.1f (target %.1f) %s; max_slope=%.1fdeg (cap 8) %s' % (
    peak_xy[0], peak_xy[1], pdd, pad['r_m'], 'OK' if pdd <= pad['r_m'] else '<-- VIOLATION',
    ptop, pad['target_m'], 'OK' if abs(ptop - pad['target_m']) < 0.05 else '<-- VIOLATION',
    pw, 'OK' if pw <= 8.0 else '<-- VIOLATION'))
# north_col: a routable E-W trail path (25 m steps <= 25%) across the col.
# 25 m steps because trail switchbacks average out micro bumps (8 m steps would
# trip on locked micro noise everywhere); the trail benches micro (P05).
import heapq
col_cx, col_cz, col_rx, col_rz = 650, -1050, 200, 200
COL_CAP, COL_STEP = 25.0, 25
def col_xy(gx, gz):
    return (gx * COL_STEP, gz * COL_STEP)
def col_in(x, z):
    return ((x - col_cx) / col_rx) ** 2 + ((z - col_cz) / col_rz) ** 2 <= 1.0
g_start, g_goal = (34, -42), (18, -42)  # (850,-1050) -> (450,-1050)
cg = {}
def col_h(gx, gz):
    if (gx, gz) not in cg:
        x, z = col_xy(gx, gz)
        cg[(gx, gz)] = f.height(x, z)
    return cg[(gx, gz)]
openq, came, best = [(0, g_start)], {g_start: None}, {g_start: 0.0}
found = None
while openq:
    _, cur = heapq.heappop(openq)
    if cur == g_goal:
        found = cur
        break
    cx0, cz0 = col_xy(*cur)
    h0 = col_h(*cur)
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
        nb = (cur[0] + dx, cur[1] + dz)
        x1, z1 = col_xy(*nb)
        if not col_in(x1, z1):
            continue
        step = math.hypot(dx * COL_STEP, dz * COL_STEP)
        if abs(col_h(*nb) - h0) / step * 100.0 > COL_CAP:
            continue
        ng = best[cur] + step
        if ng < best.get(nb, 1e18):
            best[nb], came[nb] = ng, cur
            heapq.heappush(openq, (ng + math.hypot(x1 - col_xy(*g_goal)[0], z1 - col_xy(*g_goal)[1]), nb))
if found:
    plen, wg = best[found], 0.0
    n0 = found
    while came[n0]:
        x0, z0 = col_xy(*n0)
        x1, z1 = col_xy(*came[n0])
        wg = max(wg, abs(f.height(x0, z0) - f.height(x1, z1)) / math.hypot(x0 - x1, z0 - z1) * 100.0)
        n0 = came[n0]
    print('  north_col: E-W path FOUND len=%.0fm max_step=%.1f%% (cap %.0f) OK' % (plen, wg, COL_CAP))
else:
    print('  north_col: E-W path NOT FOUND (cap %.0f%%) <-- VIOLATION' % COL_CAP)
print('elapsed %.1fs' % (time.time() - t0))
