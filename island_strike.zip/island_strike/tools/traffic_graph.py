#!/usr/bin/env python3
"""ISLAND STRIKE P08 — traffic graph generator.

Derives data/derived/traffic_graph.json from LOCKED upstream sources:
  P03 roads.json + road_traffic_handoff.json (topology, lanes, movements)
  P04 road_geometry.json (connectors, junctions, roundabout, tunnel, bridges)
  P05 transport_structures.json (clearance context)
  P06 districts.json (density context)
  P07 world_stream_manifest.json (sector mapping; SectorGrid reused, never duplicated)
  P08 data/world/traffic_contract.json (policies + source pins)

Fails loudly (exit 2) when any source pin mismatches the contract.
Deterministic: canonical key order, rounded floats, no timestamps/paths.
"""
import hashlib
import json
import math
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from sector_math import SectorGrid

OUT = os.path.join(ROOT, "data/derived/traffic_graph.json")
GEN_VERSION = "p08g1"


def sha16(obj):
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()[:16]


def r4(x):
    return round(float(x) + 0.0, 4)


def r2(x):
    return round(float(x) + 0.0, 2)


def load(name):
    with open(os.path.join(ROOT, name)) as f:
        return json.load(f)


def dist3(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


def resample(pts, spacing):
    """Arc-length resample of [[x,y,z]...] at `spacing` meters. Keeps endpoints."""
    if len(pts) < 2:
        return [list(p) for p in pts]
    out = [list(pts[0])]
    carry = 0.0
    prev = pts[0]
    for cur in pts[1:]:
        seg = dist3(prev, cur)
        if seg <= 1e-9:
            continue
        d = spacing - carry
        placed = False
        while d <= seg:
            t = d / seg
            p = [prev[i] + (cur[i] - prev[i]) * t for i in range(3)]
            out.append(p)
            prev = p
            seg = dist3(prev, cur)
            d = spacing
            placed = True
        # arc-length accumulation: when nothing was placed, the path since
        # the last placed point spans carry + this segment (not just seg).
        carry = seg if placed else carry + seg
        prev = cur
    tail = dist3(out[-1], pts[-1])
    if tail > 1e-6:
        if tail < 1.0:
            out[-1] = list(pts[-1])  # merge micro-segment into endpoint
        else:
            out.append(list(pts[-1]))
    return out


def curvature_radius(p0, p1, p2):
    ax, az = p0[0] - p1[0], p0[2] - p1[2]
    bx, bz = p2[0] - p1[0], p2[2] - p1[2]
    la, lb = math.hypot(ax, az), math.hypot(bx, bz)
    if la < 1e-9 or lb < 1e-9:
        return float("inf")
    cross = abs(ax * bz - az * bx)
    if cross < 1e-12:
        return float("inf")
    # third side |p2-p0| = |(p2-p1)-(p0-p1)| (difference, not sum)
    side = math.hypot(ax - bx, az - bz)
    denom = la * lb * side
    if denom < 1e-12:
        return float("inf")
    k = 2.0 * cross / denom
    return float("inf") if k < 1e-9 else 1.0 / k


def verify_pins(tc, roads, geom, struct, manifest, handoff):
    errs = []
    pins = tc["source_pins"]

    def want(key, got):
        if pins.get(key) != got:
            errs.append("pin %s: contract=%s observed=%s" % (key, pins.get(key), got))

    want("road_checksum", roads.get("checksum"))
    want("road_version", roads.get("meta", {}).get("road_version"))
    gck = geom.get("checksum", {})
    want("geometry_checksum_geometry", gck.get("geometry"))
    want("geometry_checksum_analytic", gck.get("analytic"))
    want("geometry_checksum_mesh", gck.get("mesh"))
    want("geometry_version", geom.get("meta", {}).get("geometry_version"))
    want("structure_checksum", struct.get("checksum"))
    want("stream_manifest_checksum", manifest.get("checksum"))
    want("traffic_handoff_sha256_16", sha16(handoff))
    d = load("data/derived/districts.json")
    want("districts_checksum", d.get("checksum"))
    b = load("data/derived/buildings.json")
    want("buildings_checksum", b.get("checksum"))
    if errs:
        print("SOURCE PIN MISMATCH (stale upstream or drifted contract):", file=sys.stderr)
        for e in errs:
            print("  " + e, file=sys.stderr)
        return False
    return True


def build_lanes(tc, roads, handoff, grid):
    lanes = {}
    edges = roads["edges"]
    for edge_id in sorted(handoff["lanes"].keys()):
        edge = edges[edge_id]
        entries = handoff["lanes"][edge_id]
        by_dir = {}
        for e in entries:
            by_dir.setdefault(e["direction"], []).append(e)
        for direction in sorted(by_dir.keys()):
            group = sorted(by_dir[direction], key=lambda e: (abs(e["offset"]), e["offset"]))
            same = len(group)
            for idx, entry in enumerate(group):
                lid = "%s:%+d:%d" % (edge_id, direction, idx)
                # lane pts are [x, elev, z] == canonical [x, y, z]
                canon = [[r4(p[0]), r4(p[1]), r4(p[2])] for p in entry["pts"]]
                rs = resample(canon, tc["lane_policy"]["resample_spacing_m"])
                rs = [[r4(p[0]), r4(p[1]), r4(p[2])] for p in rs]
                n = len(rs)
                # per-sample arc length, curvature radius, grade
                s = [0.0]
                for i in range(1, n):
                    s.append(s[-1] + dist3(rs[i - 1], rs[i]))
                radii = []
                for i in range(n):
                    a = rs[max(0, i - 1)]
                    b = rs[i]
                    c = rs[min(n - 1, i + 1)]
                    radii.append(curvature_radius(a, b, c))
                grades = []
                for i in range(n):
                    a = rs[max(0, i - 1)]
                    b = rs[min(n - 1, i + 1)]
                    run = math.hypot(b[0] - a[0], b[2] - a[2])
                    grades.append((b[1] - a[1]) / run * 100.0 if run > 1e-9 else 0.0)
                # lane width from neighbor offsets, fallback to edge share
                offs = sorted(e["offset"] for e in group)
                gaps = [abs(offs[i + 1] - offs[i]) for i in range(len(offs) - 1)]
                if gaps:
                    lw = min(gaps)
                else:
                    lw = edge["width_m"] / max(1, len(entries))
                # speed profile: legal -> curve -> grade -> junction approach, accel/brake passes
                v_leg = edge["effective_speed_kph"] * 1000.0 / 3600.0
                a_lat = 2.5
                v = []
                for i in range(n):
                    R = radii[i]
                    vc = math.sqrt(a_lat * R) if R != float("inf") else v_leg
                    g = grades[i]
                    if g > 0:
                        fg = max(0.4, 1.0 - 0.008 * g)
                    else:
                        fg = 1.0  # downhill never exceeds legal
                    v.append(min(v_leg, vc) * fg)
                # junction approach factor near lane end
                b_comf = 2.5
                for i in range(n):
                    rem = s[-1] - s[i]
                    need = v[i] * v[i] / (2.0 * b_comf) + 10.0
                    if rem < need:
                        f = 0.6 + 0.4 * max(0.0, rem / need)
                        v[i] = v[i] * f
                # forward accel pass / backward brake pass (a=2.0, b=4.0)
                for i in range(1, n):
                    ds = s[i] - s[i - 1]
                    v[i] = min(v[i], math.sqrt(max(0.0, v[i - 1] ** 2 + 2 * 2.0 * ds)))
                for i in range(n - 2, -1, -1):
                    ds = s[i + 1] - s[i]
                    v[i] = min(v[i], math.sqrt(max(0.0, v[i + 1] ** 2 + 2 * 4.0 * ds)))
                # sectors crossed (P07 grid, reused)
                secs = sorted(set(
                    "SX%02dZ%02d" % grid.sector_of(p[0], p[2]) for p in rs))
                if direction > 0:
                    entry_node, exit_node = edge["from_node"], edge["to_node"]
                elif direction < 0:
                    entry_node, exit_node = edge["to_node"], edge["from_node"]
                else:
                    entry_node, exit_node = edge["from_node"], edge["to_node"]
                lanes[lid] = {
                    "lane_id": lid,
                    "edge": edge_id,
                    "direction": direction,
                    "index": idx,
                    "offset_m": r4(entry["offset"]),
                    "width_m": r2(min(lw, edge["width_m"])),
                    "class": edge["class"],
                    "access": edge["access"],
                    "speed_legal_kph": r2(edge["effective_speed_kph"]),
                    "speed_min_kph": r2(min(v) * 3.6),
                    "length_m": r2(s[-1]),
                    "entry_node": entry_node,
                    "exit_node": exit_node,
                    "sectors": secs,
                    "pts": rs,
                    "v_target_ms": [r2(x) for x in v],
                    "curve_min_radius_m": r2(min(r for r in radii if r != float("inf"))
                                            ) if any(r != float("inf") for r in radii) else None,
                    "grade_max_pct": r2(max(grades)),
                    "grade_min_pct": r2(min(grades)),
                    "source": {"handoff": "road_traffic_handoff.json",
                               "edge": edge_id, "lanes_same_dir": same},
                }
    # adjacency (same edge+dir, neighbor index)
    by_key = {}
    for lid, l in lanes.items():
        by_key.setdefault((l["edge"], l["direction"]), []).append((l["index"], lid))
    for group in by_key.values():
        group.sort()
        for k, (idx, lid) in enumerate(group):
            adj = {}
            if k > 0:
                adj["inner"] = group[k - 1][1]
            if k < len(group) - 1:
                adj["outer"] = group[k + 1][1]
            lanes[lid]["adjacent"] = adj
    return lanes


def travel_dir(edges, edge_id, at_node, arriving):
    e = edges[edge_id]
    if arriving:
        if e["to_node"] == at_node:
            return 1
        if e["from_node"] == at_node:
            return -1
    else:
        if e["from_node"] == at_node:
            return 1
        if e["to_node"] == at_node:
            return -1
    return None




def _bearing(p, q):
    return math.degrees(math.atan2(q[0] - p[0], q[2] - p[2]))


def derived_trailhead_movements(edges, lanes):
    """th_highland gap-fill: 8 handoff-level movements (see module rationale).

    Basis: P03 routes traverse radial_00->radial_01 (ring/radial continuity);
    trail legs are single-track yield entries/exits. Turn types from bearings.
    """
    j = "th_highland"
    r0, r1, tr = "E_radial_north_00", "E_radial_north_01", "E_tr_highland_00"
    legs = [(r0, 1), (r1, -1), (tr, 0)]
    out = []
    for (ie, idir) in legs:
        for (oe, odir) in legs:
            if (ie, idir) == (oe, odir):
                continue
            if ie == tr and oe == tr:
                continue  # no-op on single track
            el = lanes["%s:%+d:0" % (ie, idir)]
            xl = lanes["%s:%+d:0" % (oe, odir)]
            b_in = _bearing(el["pts"][-2], el["pts"][-1])
            b_out = _bearing(xl["pts"][0], xl["pts"][1])
            d = (b_out - b_in + 540.0) % 360.0 - 180.0
            if ie == oe:
                typ = "UTURN"
            elif abs(d) < 30.0:
                typ = "STRAIGHT"
            elif d > 0:
                typ = "RIGHT"
            else:
                typ = "LEFT"
            out.append({"junction_id": j, "incoming_edge": ie,
                        "outgoing_edge": oe, "movement": typ, "allowed": True,
                        "connector_id": None, "turn_radius": 12.0,
                        "access": "public", "priority": 3, "derived": True,
                        "basis": "topology-continuity"})
    return out


def _norm_connector_pts(pts):
    return [[r4(p[0]), r4(p[2]), r4(p[1])] for p in pts]


def build_movements(tc, roads, geom, handoff, lanes):
    edges = roads["edges"]
    connectors = geom["connectors"]
    arc_idx = {}
    for a in geom.get("roundabout", {}).get("arcs", []):
        arc_idx[(a["from_edge"], a["to_edge"])] = a
    lane_index = {}
    for lid, l in lanes.items():
        lane_index.setdefault((l["edge"], l["direction"]), []).append((l["index"], lid))
    for g in lane_index.values():
        g.sort()
    movements = {}
    seq = 0
    hmovs = list(handoff["movements"]) + derived_trailhead_movements(
        roads["edges"], lanes)
    for m in sorted(hmovs,
                    key=lambda m: (m["junction_id"] or "", m["incoming_edge"],
                                   m["outgoing_edge"], m["movement"])):
        j = m["junction_id"]
        ie, oe, typ = m["incoming_edge"], m["outgoing_edge"], m["movement"]
        if j is None:
            # structure transition (bridge/tunnel): straight through, uncontrolled
            in_dir = 1
            out_dir = 1
            control = "UNCONTROLLED_THROUGH"
        else:
            in_dir = travel_dir(edges, ie, j, True)
            out_dir = travel_dir(edges, oe, j, False)
            control = None  # assigned per junction below
        if typ == "UTURN" and j is not None:
            out_dir = -in_dir if in_dir else out_dir
        # single-track edges (dir 0): map any travel dir onto the shared lane
        if (ie, in_dir) not in lane_index and (ie, 0) in lane_index:
            in_dir = 0
        if (oe, out_dir) not in lane_index and (oe, 0) in lane_index:
            out_dir = 0
        if in_dir is None or out_dir is None:
            print("WARN: movement with unresolvable dirs skipped: %s" % (m,), file=sys.stderr)
            continue
        entries = [lid for _, lid in lane_index.get((ie, in_dir), [])]
        exits = [lid for _, lid in lane_index.get((oe, out_dir), [])]
        pairs = [(entries[k], exits[k]) for k in range(min(len(entries), len(exits)))]
        if not pairs:
            print("WARN: movement with no lane pairs skipped: %s %s->%s" % (j, ie, oe),
                  file=sys.stderr)
            continue
        for (lid_in, lid_out) in pairs:
            seq += 1
            mid = "%s:%s:%+d:%s:%+d:%s:%d" % (
                j or "NOTRANS", ie, in_dir, oe, out_dir, typ, seq)
            # stop = entry lane end; decision = braking distance upstream
            lin = lanes[lid_in]
            v_end = lin["v_target_ms"][-1]
            brake_d = v_end * v_end / (2 * 4.0) + v_end * 1.0
            stop = lin["pts"][-1]
            # walk back along pts by brake_d
            acc, dec = 0.0, stop
            for p in reversed(lin["pts"][:-1]):
                acc += dist3(p, dec if acc == 0.0 else dec)
                dec = p
                if acc >= brake_d:
                    break
            turn_pts = None
            conn_ref = m.get("connector_id")
            if isinstance(conn_ref, list):
                # roundabout ENTRY + arc + EXIT chain (P04-resolved)
                arc = arc_idx.get((ie, oe))
                chain = []
                for cid in conn_ref[:1]:
                    chain += _norm_connector_pts(connectors[cid]["pts"])
                if arc:
                    chain += _norm_connector_pts(arc["pts"])
                for cid in conn_ref[1:]:
                    chain += _norm_connector_pts(connectors[cid]["pts"])
                turn_pts = chain
                conn_ref = None
            if m.get("derived"):
                a = lanes[lid_in]["pts"][-1]
                bpts = lanes[lid_out]["pts"]
                b = bpts[min(2, len(bpts) - 1)]
                turn_pts = [[r4(a[0] + (b[0] - a[0]) * k / 5.0),
                             r4(a[1] + (b[1] - a[1]) * k / 5.0),
                             r4(a[2] + (b[2] - a[2]) * k / 5.0)] for k in range(6)]
            movements[mid] = {
                "move_id": mid,
                "derived": bool(m.get("derived")),
                "turn_pts": turn_pts,
                "junction": j,
                "from_lane": lid_in,
                "to_lane": lid_out,
                "type": typ,
                "allowed": bool(m["allowed"]),
                "connector_ref": conn_ref,
                "turn_radius_m": (r2(m["turn_radius"]) if isinstance(
                    m.get("turn_radius"), (int, float)) and math.isfinite(
                    m["turn_radius"]) else None),
                "control": control,  # filled by junction pass (None => per-junction default)
                "stop_pos": stop,
                "decision_pos": dec,
                "source": {"handoff_movement": [j, ie, oe, typ]},
            }
    return movements


def build_junctions(tc, roads, geom, handoff, movements):
    edges = roads["edges"]
    jg = geom["junctions"]
    prio = handoff.get("priority", {})
    junctions = {}
    by_j = {}
    for mid, m in movements.items():
        if m["junction"]:
            by_j.setdefault(m["junction"], []).append(mid)
    for jid in sorted(set(list(jg.keys()) + list(by_j.keys()))):
        gj = jg.get(jid, {})
        node = roads["nodes"].get(jid, {})
        deg = gj.get("degree", node.get("degree", 0))
        ntype = node.get("type", gj.get("type", "junction"))
        if ntype == "roundabout":
            control = "YIELD_ON_ENTRY"
        elif ntype == "trailhead":
            control = "TRAILHEAD"
        elif deg <= 1:
            control = "TERMINAL_UTURN"
        elif deg == 2:
            control = "MERGE_RULE"
        else:
            control = "SIGNALIZED"
        junctions[jid] = {
            "junction_id": jid,
            "type": ntype,
            "degree": deg,
            "control": control,
            "priority": prio.get(jid),
            "movements": sorted(by_j.get(jid, [])),
            "geom_ref": {"R": gj.get("R"), "kind": gj.get("kind")},
        }
    # assign movement control defaults from junction
    for m in movements.values():
        if m["control"] is None:
            jc = junctions.get(m["junction"], {}).get("control", "UNCONTROLLED")
            if jc == "SIGNALIZED":
                m["control"] = "SIGNAL"
            elif jc == "YIELD_ON_ENTRY":
                # roundabout: every entry/circulation/exit yields; no signals
                m["control"] = "YIELD"
            elif jc == "TRAILHEAD":
                if m.get("derived") and "E_tr_highland_00" in (
                        m["from_lane"], m["to_lane"]):
                    m["control"] = "YIELD"
                elif m["type"] == "UTURN":
                    m["control"] = "YIELD"
                else:
                    m["control"] = "UNCONTROLLED"
            elif jc == "TERMINAL_UTURN":
                m["control"] = "UNCONTROLLED"
            elif jc == "MERGE_RULE":
                m["control"] = "MERGE" if m["type"] == "MERGE" else "YIELD"
            else:
                m["control"] = "UNCONTROLLED"
    return junctions


def build_signals(tc, junctions, movements):
    signals = {}
    timing = tc["signal_policy"]["default_timing_ticks"]
    for jid in sorted(junctions.keys()):
        j = junctions[jid]
        if j["control"] != "SIGNALIZED":
            continue
        # one phase per incoming edge (canonical order), round-robin + yellow
        by_in = {}
        for mid in j["movements"]:
            m = movements[mid]
            if m["control"] != "SIGNAL":
                continue
            in_edge = m["source"]["handoff_movement"][1]
            prot = m["type"] == "LEFT"
            by_in.setdefault(in_edge, []).append((mid, prot))
        phases = []
        for k, in_edge in enumerate(sorted(by_in.keys())):
            members = sorted(by_in[in_edge])
            phases.append({
                "phase": k,
                "incoming_edge": in_edge,
                "green_ticks": timing["green"],
                "yellow_ticks": timing["yellow"],
                "movements": [mid for mid, _ in members],
                "protected": [mid for mid, p in members if p],
            })
        if not phases:
            continue
        signals["SIG:%s" % jid] = {
            "signal_id": "SIG:%s" % jid,
            "junction": jid,
            "phases": phases,
            "red_ticks": timing["red"],
            "cycle_ticks": sum(p["green_ticks"] + p["yellow_ticks"] for p in phases),
            "derived_from": "P03 movements + junction degree (P08-derived control; assets future-owned)",
        }
    return signals


SETTLE_ZONE = {
    "MAJOR_CITY": "CITY_CORE", "PORT_COMPLEX": "PORT",
    "AIRFIELD_COMPLEX": "AIRFIELD", "SECONDARY_TOWN": "SUBURB",
    "VILLAGE": "RURAL", "RESORT_CLUSTER": "RESORT",
    "RESTRICTED_COMPLEX": "RURAL", "RURAL_CLUSTER": "RURAL",
}


def build_zones(tc, roads, handoff, lanes, districts, grid):
    lane_by_edge_dir = {}
    for lid, l in lanes.items():
        lane_by_edge_dir.setdefault((l["edge"], l["direction"]), []).append(lid)
    for g in lane_by_edge_dir.values():
        g.sort()
    # nearest settlement per edge midpoint
    edges = roads["edges"]
    nodes = roads["nodes"]
    settles = districts["settlements"]
    spawn_zones = {}
    for (edge_id, direction), lids in sorted(lane_by_edge_dir.items()):
        l0 = lanes[lids[0]]
        p = l0["pts"][min(4, len(l0["pts"]) - 1)]
        e = edges[edge_id]
        mx = (nodes[e["from_node"]]["x"] + nodes[e["to_node"]]["x"]) / 2.0
        mz = (nodes[e["from_node"]]["z"] + nodes[e["to_node"]]["z"]) / 2.0
        best, bd = None, float("inf")
        for s in settles:
            c = s["center"]
            d = math.hypot(mx - c[0], mz - c[1])
            if d < bd:
                bd, best = d, s
        zclass = SETTLE_ZONE.get(best["class"], "RURAL")
        if e["class"] in ("service",) and "port" in best["id"]:
            class_mod = {"truck": 3.0, "bus": 2.0}
        elif e["class"] == "trail":
            class_mod = {"compact": 1.0, "motorcycle": 1.5, "sedan": 0.5,
                         "suv": 0.3, "van": 0.0, "truck": 0.0, "bus": 0.0}
        else:
            class_mod = {}
        sx, sz = grid.sector_of(p[0], p[2])
        spawn_zones["SZ:%s:%+d" % (edge_id, direction)] = {
            "zone_id": "SZ:%s:%+d" % (edge_id, direction),
            "edge": edge_id,
            "direction": direction,
            "lanes": lids,
            "pos": p,
            "sector": "SX%02dZ%02d" % (sx, sz),
            "settlement": best["id"],
            "zone_class": zclass,
            "capacity": len(lids),
            "class_modifiers": class_mod,
            "min_gap_m": tc["spawn_policy"]["min_gap_m"],
            "priority": 1 if zclass in ("CITY_CORE", "PORT") else 2,
        }
    density = {}
    pops = tc["density_policy"]["zone_classes"]
    for s in sorted(settles, key=lambda s: s["id"]):
        zc = SETTLE_ZONE.get(s["class"], "RURAL")
        density["DZ:%s" % s["id"]] = {
            "zone_id": "DZ:%s" % s["id"],
            "settlement": s["id"],
            "zone_class": zc,
            "target_population": pops[zc],
            "center": s["center"],
        }
    density["DZ:WETLAND_EDGE"] = {"zone_id": "DZ:WETLAND_EDGE", "settlement": None,
                                  "zone_class": "WETLAND_EDGE",
                                  "target_population": pops["WETLAND_EDGE"],
                                  "center": [-450.0, 1350.0],
                                  "note": "exclusion/transit only; no lanes inside water"}
    density["DZ:RURAL_DEFAULT"] = {"zone_id": "DZ:RURAL_DEFAULT", "settlement": None,
                                   "zone_class": "RURAL",
                                   "target_population": pops["RURAL"],
                                   "center": [0.0, 0.0]}
    return spawn_zones, density


def build_speed_zones(tc, lanes):
    zones = []
    for lid in sorted(lanes.keys()):
        l = lanes[lid]
        zones.append({"zone_id": "VZ:%s" % lid, "lane": lid,
                      "legal_kph": l["speed_legal_kph"],
                      "min_kph": l["speed_min_kph"],
                      "class": l["class"]})
    return zones


def build_sector_handoffs(manifest, lanes, spawn_zones):
    hand = {}
    for s in manifest["sectors"]:
        hand[s["sector_id"]] = {"sector_id": s["sector_id"], "lanes": [],
                                "spawn_zones": []}
    for lid, l in lanes.items():
        for sid in l["sectors"]:
            if sid in hand:
                hand[sid]["lanes"].append(lid)
    for zid, z in spawn_zones.items():
        if z["sector"] in hand:
            hand[z["sector"]]["spawn_zones"].append(zid)
    for h in hand.values():
        h["lanes"].sort()
        h["spawn_zones"].sort()
    return hand


POLICY_KEYS = ("lane_policy", "junction_policy", "signal_policy", "speed_policy",
               "following_policy", "lane_change_policy", "merge_policy",
               "spawn_policy", "despawn_policy", "density_policy",
               "collision_policy", "routing_policy", "simulation_policy",
               "seed_policy")


def main():
    tc = load("data/world/traffic_contract.json")
    roads = load("data/derived/roads.json")
    geom = load("data/derived/road_geometry.json")
    handoff = load("data/derived/road_traffic_handoff.json")
    struct = load("data/derived/transport_structures.json")
    districts = load("data/derived/districts.json")
    manifest = load("data/derived/world_stream_manifest.json")
    if not verify_pins(tc, roads, geom, struct, manifest, handoff):
        return 2
    grid = SectorGrid(256, -2048.0)
    lanes = build_lanes(tc, roads, handoff, grid)
    movements = build_movements(tc, roads, geom, handoff, lanes)
    junctions = build_junctions(tc, roads, geom, handoff, movements)
    signals = build_signals(tc, junctions, movements)
    spawn_zones, density = build_zones(tc, roads, handoff, lanes, districts, grid)
    speed_zones = build_speed_zones(tc, lanes)
    handoffs = build_sector_handoffs(manifest, lanes, spawn_zones)
    vp = {"classes": tc["vehicle_classes"],
          "following": tc["following_policy"]["policy_version"],
          "lane_change": tc["lane_change_policy"]["policy_version"],
          "merge": tc["merge_policy"]["policy_version"],
          "collision": tc["collision_policy"]["policy_version"],
          "simulation": tc["simulation_policy"]["policy_version"]}
    checksums = {
        "traffic_graph_checksum": sha16({"lanes": lanes, "movements": movements,
                                         "junctions": junctions, "signals": signals,
                                         "speed_zones": speed_zones,
                                         "sector_handoffs": handoffs}),
        "traffic_spawn_checksum": sha16({"spawn_zones": spawn_zones,
                                         "density_zones": density,
                                         "spawn_policy": tc["spawn_policy"]["policy_version"],
                                         "density_policy": tc["density_policy"]["policy_version"],
                                         "seed_policy": tc["seed_policy"]["policy_version"]}),
        "vehicle_policy_checksum": sha16(vp),
        "traffic_policy_checksum": sha16({k: tc[k]["policy_version"]
                                          for k in POLICY_KEYS}),
        "traffic_sector_checksum": sha16({"handoffs": handoffs,
                                          "manifest": tc["source_pins"]["stream_manifest_checksum"]}),
    }
    doc = {
        "meta": {
            "traffic_version": tc["traffic_version"],
            "traffic_graph_version": tc["traffic_graph_version"],
            "generator": "traffic_graph.py",
            "generation_version": GEN_VERSION,
            "source_pins": tc["source_pins"],
            "policy_versions": {k: tc[k]["policy_version"] for k in POLICY_KEYS},
        },
        "lanes": lanes,
        "movements": movements,
        "junctions": junctions,
        "signals": signals,
        "speed_zones": speed_zones,
        "spawn_zones": spawn_zones,
        "density_zones": density,
        "sector_handoffs": handoffs,
        "checksums": checksums,
        "stats": {"lanes": len(lanes), "movements": len(movements),
                  "junctions": len(junctions), "signals": len(signals),
                  "spawn_zones": len(spawn_zones),
                  "samples": sum(len(l["pts"]) for l in lanes.values())},
    }
    raw = json.dumps(doc, sort_keys=True, separators=(",", ":"))
    for tok in ("Infinity", "-Infinity", "NaN"):
        if tok in raw:
            print("NON-FINITE FLOAT in output: %s" % tok, file=sys.stderr)
            return 2
    with open(OUT, "w") as f:
        f.write(raw)
        f.write("\n")
    print("wrote %s lanes=%d movements=%d junctions=%d signals=%d "
          "graph=%s" % (OUT, len(lanes), len(movements), len(junctions),
                        len(signals), checksums["traffic_graph_checksum"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
