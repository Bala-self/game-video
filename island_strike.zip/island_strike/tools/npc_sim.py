#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 09 -- NPC/pedestrian/navigation/AI runtime.

Deterministic fixed-step (10 Hz) twin: registry, population, spawn/
despawn, pathfinding, movement, crossings, perception, behavior,
simulation tiers, scheduler budgets, streaming gates. Consumes P08
TrafficWorld read-only for traffic awareness. No Godot dependency.
"""
import json
import math
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sector_math import SectorGrid, sector_id  # noqa: E402
from terrain_model import Field  # noqa: E402
from traffic_sim import TrafficWorld  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DD = os.path.join(ROOT, "data/derived")
DW = os.path.join(ROOT, "data/world")
FIXED_STEP = 0.1

# P09-D13: movement/behavior machines live in
# npc_behavior_policy.json; NPCWorld loads them as data.


def fnv1a32(s):
    h = 0x811C9DC5
    for b in s.encode():
        h ^= b
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h


def rng_for(*parts):
    return random.Random(fnv1a32(":".join(str(p) for p in parts)))


class NPCWorld:
    def __init__(self, seed_tag="npc", focus=(1400.0, 150.0),
                 with_traffic=True):
        self.tick_n = 0
        self.seed_tag = seed_tag
        self.focus = [float(focus[0]), float(focus[1])]
        self.tc = json.load(open(os.path.join(DW, "npc_contract.json")))
        self.nav = json.load(open(os.path.join(
            DD, "npc_navigation_manifest.json")))
        self.pop = json.load(open(os.path.join(
            DD, "npc_population_manifest.json")))
        self.spawn_doc = json.load(open(os.path.join(
            DD, "npc_spawn_zones.json")))
        self.beh = json.load(open(os.path.join(
            DD, "npc_behavior_policy.json")))
        self.perc = json.load(open(os.path.join(
            DD, "npc_perception_policy.json")))
        self.grid = SectorGrid(256)
        self.field = None  # lazy: Field() is expensive; avoid if unused
        self.nodes = {n["id"]: n for n in self.nav["nodes"]}
        self.adj = {}
        for e in self.nav["edges"]:
            self.adj.setdefault(e["a"], []).append(e)
            self.adj.setdefault(e["b"], []).append(
                {"a": e["b"], "b": e["a"], "kind": e["kind"],
                 "length_m": e["length_m"],
                 "corridor_m": e.get("corridor_m", 2.0),
                 "sector_portal": e.get("sector_portal", False),
                 "crossing": e.get("crossing"),
                 "edge": e.get("edge"), "lane": e.get("lane")})
        self.crossings = {c["id"]: c for c in self.nav["crossings"]}
        self.comp_of = {}
        _seen = set()
        _nc = 0
        for _nid in sorted(self.nodes.keys()):
            if _nid in _seen:
                continue
            _nc += 1
            _stack = [_nid]
            while _stack:
                _u = _stack.pop()
                if _u in _seen:
                    continue
                _seen.add(_u)
                self.comp_of[_u] = _nc
                for _e in self.adj.get(_u, []):
                    _stack.append(_e["b"])
        self.comp_nodes = {}
        for _nid, _c in self.comp_of.items():
            self.comp_nodes.setdefault(_c, []).append(_nid)
        for _c in self.comp_nodes:
            self.comp_nodes[_c].sort()
        self.zones = {z["zone_id"]: z for z in self.pop["zones"]}
        self.zone_sectors = {}
        for _zid, _z in self.zones.items():
            _ss = set()
            for _aid in _z.get("areas", []):
                for _nid, _nd in self.nodes.items():
                    if _nd.get("area") == _aid:
                        _ss.add(_nd["sector"])
            if _z.get("type") == "arrival":
                for _nid, _nd in self.nodes.items():
                    if _nd["kind"] == "ARRIVAL" and \
                            _nid == "NV-" + _zid[3:]:
                        _ss.add(_nd["sector"])
            for _p in self.spawn_doc["zones"][_zid]["spawn_points"]:
                _sx, _sz = self.grid.sector_of(_p["x"], _p["z"])
                _ss.add(sector_id(_sx, _sz))
            self.zone_sectors[_zid] = sorted(_ss)
        # building footprints for LOS + spawn clearance
        bdoc = json.load(open(os.path.join(DD, "buildings.json")))
        self.footprints = [b["footprint"] for b in bdoc["buildings"]]
        self.bboxes = []
        for fp in self.footprints:
            xs = [p[0] for p in fp]
            zs = [p[1] for p in fp]
            self.bboxes.append((min(xs), min(zs), max(xs), max(zs)))
        self.traffic = TrafficWorld(seed_tag="npc-traffic-" + seed_tag) \
            if with_traffic else None
        if self.traffic is not None:
            self.traffic.focus = list(self.focus)
        # runtime state
        self.npcs = {}
        self.seq = 0
        self.events = []
        self.path_cache = {}
        self.path_queue = []
        self.perc_queue = []
        self.hearing = []
        self.sectors = {}
        self.pins = {}
        self.pin_seq = 0
        self.illegal = []
        self.counters = {
            "path_requests": 0, "path_hits": 0, "path_miss": 0,
            "path_failed": 0, "path_deferred": 0, "path_invalidated": 0,
            "perc_queued": 0, "perc_executed": 0, "perc_deferred": 0,
            "perc_coalesced": 0, "perc_cached": 0, "perc_failed": 0,
            "perc_skipped_los": 0,
            "los_queries": 0, "spawns": 0, "spawn_rejects": 0,
            "despawns": 0, "tier_changes": 0, "crossings_committed": 0,
            "crossings_cancelled": 0, "witness_events": 0,
            "recoveries": 0, "repairs_teleport": 0,
        }
        self.rng = {s: rng_for("npc", s, seed_tag)
                    for s in ("spawn", "destination", "path", "behavior",
                              "perception", "schedule")}
        self.auto_spawn = True
        # measurement ablation flags (P08-D12); always True in prod
        self.enable_paths = True
        self.enable_perc = True
        self.player = None
        self._hash = {}
        # P09-D13: machines are policy data (KeyError = corrupt policy).
        self.move_table = {
            k: set(v) for k, v in
            self.beh["movement_machine"]["states"].items()}
        self.beh_table = {
            k: set(v) for k, v in
            self.beh["behavior_machine"]["states"].items()}

    # ---------- helpers ----------
    def emit(self, typ, nid, data):
        self.events.append({"tick": self.tick_n, "type": typ,
                            "npc": nid, "data": data})

    def move_transition(self, n, to, reason):
        frm = n["move_state"]
        if to not in self.move_table.get(frm, set()):
            self.illegal.append((frm, to, reason))
            self.emit("illegal", n["id"], {"frm": frm, "to": to,
                                           "reason": reason})
            return False
        n["move_state"] = to
        self.emit("move_transition", n["id"],
                  {"frm": frm, "to": to, "reason": reason})
        return True

    def beh_transition(self, n, to, reason):
        frm = n["beh_state"]
        if to not in self.beh_table.get(frm, set()):
            self.illegal.append((frm, to, reason))
            self.emit("illegal", n["id"], {"frm": frm, "to": to,
                                           "reason": reason})
            return False
        n["beh_state"] = to
        self.emit("beh_transition", n["id"],
                  {"frm": frm, "to": to, "reason": reason})
        return True

    def sector_of(self, x, z):
        sx, sz = self.grid.sector_of(x, z)
        return sector_id(sx, sz)

    def ensure_field(self):
        if self.field is None:
            self.field = Field()
        return self.field

    # ---------- spatial hash (npcs) ----------
    def _cell(self, x, z):
        return (int(math.floor(x / 16.0)), int(math.floor(z / 16.0)))

    def _rehash(self):
        self._hash = {}
        for nid, n in self.npcs.items():
            if n["move_state"] in ("DESPAWNING", "DESPAWNED"):
                continue
            c = self._cell(n["x"], n["z"])
            self._hash.setdefault(c, []).append(nid)

    def npcs_near(self, x, z, r):
        out = []
        c0x, c0z = self._cell(x - r, z - r)
        c1x, c1z = self._cell(x + r, z + r)
        for cx in range(c0x, c1x + 1):
            for cz in range(c0z, c1z + 1):
                for nid in self._hash.get((cx, cz), []):
                    if nid not in self.npcs:
                        continue
                    n = self.npcs[nid]
                    if math.hypot(n["x"] - x, n["z"] - z) <= r:
                        out.append(n)
        return out

    # ---------- streaming (P07 consumer) ----------
    def sector_state(self, sid):
        return self.sectors.get(sid, "UNLOADED")

    def update_sectors(self):
        fx, fz = self.focus
        for sid in list(self.sectors.keys()):
            self.sectors[sid] = self._sector_next(sid)
        # discover sectors around focus
        for dx in range(-2, 3):
            for dz in range(-2, 3):
                x = fx + dx * 256.0
                z = fz + dz * 256.0
                sid = self.sector_of(x, z)
                if sid not in self.sectors:
                    d = math.hypot(x - fx, z - fz)
                    self.sectors[sid] = \
                        "READY" if d < 512.0 else "LOADING"

    def _sector_next(self, sid):
        st = self.sectors[sid]
        if st == "LOADING":
            return "READY"
        if st == "UNLOADING":
            return "UNLOADED"
        return st

    def pin(self, sid, owner, ticks=50):
        self.pin_seq += 1
        pid = "PIN-%06d" % self.pin_seq
        self.pins[pid] = {"sector": sid, "owner": owner,
                          "expires": self.tick_n + ticks}
        self.emit("pin_create", owner, {"pin": pid, "sector": sid})
        return pid

    def unpin(self, pid):
        if pid in self.pins:
            p = self.pins.pop(pid)
            self.emit("pin_release", p["owner"],
                      {"pin": pid, "sector": p["sector"]})

    def expire_pins(self):
        for pid in [p for p, d in self.pins.items()
                    if d["expires"] <= self.tick_n]:
            self.unpin(pid)

    # ---------- registry / spawn ----------
    def acquire(self, archetype, zone_id, x, z, context="spawn"):
        for n in self.npcs.values():
            if n["zone"] == zone_id and n["archetype"] == archetype and \
                    math.hypot(n["x"] - x, n["z"] - z) < 0.01 and \
                    n["move_state"] not in ("DESPAWNING", "DESPAWNED"):
                return None  # duplicate semantic placement guard
        self.seq += 1
        nid = "NPC-%06d" % self.seq
        a = self.pop["archetypes"][archetype]
        n = {"id": nid, "archetype": archetype, "zone": zone_id,
             "x": x, "z": z, "heading": 0.0, "speed": 0.0,
             "move_state": "SPAWNED", "beh_state": "IDLE",
             "tier": "T3_full", "sector": self.sector_of(x, z),
             "dest_node": None, "dest_cat": None, "path": [],
             "path_i": 0, "crossing": None, "cross_state": None,
             "wait_ticks": 0, "stuck_ticks": 0, "recoveries": 0,
             "born": self.tick_n, "seed": fnv1a32("npc:%s:%s" % (
                 self.seed_tag, nid)),
             "walk": a["walk"], "run": a["run"], "radius": a["radius"],
             "node": None, "progress": 0.0, "perceived": [],
             "pin": None, "schedule": "DAY"}
        self.npcs[nid] = n
        self.emit("spawn", nid, {"zone": zone_id, "archetype": archetype,
                                 "context": context})
        self.counters["spawns"] += 1
        return n

    def spawn_check(self, x, z, zone_id):
        """All section-10 checks. Returns (ok, reason)."""
        sp = self.tc["spawn_policy"]
        sid = self.sector_of(x, z)
        if self.sector_state(sid) != "READY":
            return False, "sector_not_ready"
        # walkable: near a nav node with valid evidence
        if not self.nodes:
            return False, "no_nav"
        best = min(self.nodes.values(),
                   key=lambda n: (n["x"] - x) ** 2 + (n["z"] - z) ** 2)
        if math.hypot(best["x"] - x, best["z"] - z) > 25.0:
            return False, "outside_nav"
        for n in self.npcs_near(x, z, sp["min_npc_spacing_m"]):
            if n["move_state"] not in ("DESPAWNING", "DESPAWNED"):
                return False, "npc_overlap"
        if self.player is not None:
            if math.hypot(self.player["x"] - x,
                           self.player["z"] - z) < \
                    sp["min_player_clearance_m"]:
                return False, "near_player"
        if self.traffic is not None:
            for v in self.traffic.vehicles.values():
                if math.hypot(v["pos"][0] - x, v["pos"][2] - z) < 2.5:
                    return False, "inside_vehicle"
        # building clearance (footprint + radius)
        for (x0, z0, x1, z1), fp in zip(self.bboxes, self.footprints):
            if x0 - 0.5 <= x <= x1 + 0.5 and z0 - 0.5 <= z <= z1 + 0.5:
                if self._point_in_poly(x, z, fp):
                    return False, "inside_building"
        return True, "ok"

    @staticmethod
    def _point_in_poly(x, z, poly):
        inside = False
        n = len(poly)
        j = n - 1
        for i in range(n):
            xi, zi = poly[i][0], poly[i][1]
            xj, zj = poly[j][0], poly[j][1]
            if ((zi > z) != (zj > z)) and \
                    (x < (xj - xi) * (z - zi) / (zj - zi + 1e-12) + xi):
                inside = not inside
            j = i
        return inside

    def request_spawns(self):
        if not self.auto_spawn:
            return
        rng = self.rng["spawn"]
        for zid in sorted(self.zones.keys()):
            z = self.zones[zid]
            if "SPAWN_BLOCKED" in z.get("restrictions", []):
                continue
            if not any(self.sector_state(s) == "READY"
                       for s in self.zone_sectors.get(zid, [])):
                continue
            active = [n for n in self.npcs.values()
                      if n["zone"] == zid and n["move_state"] not in
                      ("DESPAWNING", "DESPAWNED")]
            if len(active) >= z["target_population"]:
                continue
            pts = self.spawn_doc["zones"][zid]["spawn_points"]
            if not pts:
                continue
            _cx = sum(p["x"] for p in pts) / len(pts)
            _cz = sum(p["z"] for p in pts) / len(pts)
            _rel = self.tc["simulation_tier_policy"]["radii_m"][
                "T0_abstract"]
            if math.hypot(_cx - self.focus[0],
                           _cz - self.focus[1]) > _rel:
                continue  # abstract population covers far zones
            want = min(z["target_population"] - len(active), 4)
            weights = z.get("archetype_weights", {})
            archs = sorted(weights.keys())
            if not archs:
                continue
            for _ in range(want):
                p = pts[rng.randrange(len(pts))]
                x = p["x"] + (rng.random() - 0.5) * 2.0
                zz = p["z"] + (rng.random() - 0.5) * 2.0
                ok, reason = self.spawn_check(x, zz, zid)
                for _ in range(self.tc["spawn_policy"][
                        "candidate_attempts"] - 1):
                    if ok:
                        break
                    p = pts[rng.randrange(len(pts))]
                    x = p["x"] + (rng.random() - 0.5) * 2.0
                    zz = p["z"] + (rng.random() - 0.5) * 2.0
                    ok, reason = self.spawn_check(x, zz, zid)
                if not ok:
                    self.counters["spawn_rejects"] += 1
                    self.emit("spawn_reject", None,
                              {"zone": zid, "reason": reason})
                    continue
                total = sum(weights[a] for a in archs)
                r = rng.random() * total
                acc = 0.0
                arch = archs[-1]
                for a in archs:
                    acc += weights[a]
                    if r <= acc:
                        arch = a
                        break
                n = self.acquire(arch, zid, x, zz)
                if n is not None:
                    self.move_transition(n, "INITIALIZING", "spawn")

    def despawn_safe(self, n):
        if n.get("cross_state") == "COMMIT":
            return False
        if n["move_state"] in ("CROSSING", "INTERACTING"):
            return False
        if self.player is not None and \
                math.hypot(self.player["x"] - n["x"],
                           self.player["z"] - n["z"]) < 10.0:
            return False
        return True

    def despawn(self, n, reason):
        if n["move_state"] in ("DESPAWNING", "DESPAWNED"):
            return
        if n.get("pin") is not None:
            self.unpin(n["pin"])
            n["pin"] = None
        self.move_transition(n, "DESPAWNING", reason)
        self.beh_transition(n, "DESPAWN", reason)
        self.move_transition(n, "DESPAWNED", reason)
        self.emit("despawn", n["id"], {"reason": reason})
        del self.npcs[n["id"]]
        self.counters["despawns"] += 1

    def request_despawns(self):
        rel = self.tc["simulation_tier_policy"]["radii_m"]["T0_abstract"]
        for n in list(self.npcs.values()):
            if n["move_state"] in ("DESPAWNING", "DESPAWNED"):
                continue
            d = math.hypot(n["x"] - self.focus[0], n["z"] - self.focus[1])
            z = self.zones[n["zone"]]
            over = sum(1 for m in self.npcs.values()
                       if m["zone"] == n["zone"] and
                       m["move_state"] not in ("DESPAWNING", "DESPAWNED"))
            if d > rel * 1.5 and self.despawn_safe(n):
                self.despawn(n, "outside_relevance")
            elif over > z["peak_population"] and self.despawn_safe(n):
                self.despawn(n, "over_peak")

    # ---------- path service ----------
    def nearest_node(self, x, z, rmax=25.0):
        best = None
        for nid in sorted(self.nodes.keys()):
            n = self.nodes[nid]
            d2 = (n["x"] - x) ** 2 + (n["z"] - z) ** 2
            if d2 <= rmax * rmax and (best is None or d2 < best[0]):
                best = (d2, nid)
        return best[1] if best else None

    def astar(self, start, goal):
        import heapq
        if start == goal:
            return [start]
        if start not in self.adj or goal not in self.nodes:
            return None
        gx = {start: 0.0}
        came = {}
        G = self.nodes[goal]
        hq = [(0.0, start)]
        closed = set()
        while hq:
            _, u = heapq.heappop(hq)
            if u == goal:
                path = [u]
                while u in came:
                    u = came[u]
                    path.append(u)
                path.reverse()
                return path
            if u in closed:
                continue
            closed.add(u)
            U = self.nodes[u]
            for e in sorted(self.adj.get(u, []), key=lambda d: d["b"]):
                v = e["b"]
                if v in closed:
                    continue
                # sector gate: no path through unready sectors
                if self.sector_state(self.nodes[v]["sector"]) not in \
                        ("READY",):
                    # allow only if pinned
                    okpin = any(
                        self.pins[p]["sector"] ==
                        self.nodes[v]["sector"] for p in self.pins)
                    if not okpin:
                        continue
                w = e["length_m"] + (50.0 if e["kind"] == "CROSSING"
                                     else 0.0)
                ng = gx[u] + w
                if ng < gx.get(v, 1e18):
                    gx[v] = ng
                    came[v] = u
                    V = self.nodes[v]
                    h = math.hypot(V["x"] - G["x"], V["z"] - G["z"])
                    heapq.heappush(hq, (ng + h, v))
        return None

    def request_path(self, n, goal_node):
        self.counters["path_requests"] += 1
        start = self.nearest_node(n["x"], n["z"])
        if start is None or goal_node not in self.nodes:
            self.counters["path_failed"] += 1
            self.emit("path_fail", n["id"], {"reason": "no_node"})
            return False
        key = (self.nav["npc_navigation_checksum"], "std",
               start, goal_node,
               self.tc["movement_policy"]["policy_version"])
        # new route requested: the old route is void at once, so a
        # deferred repath never executes a stale path (P09-D14).
        n["path"] = []
        n["path_i"] = 0
        if key in self.path_cache:
            self.counters["path_hits"] += 1
            n["path"] = list(self.path_cache[key])
            n["path_i"] = 0
            n["node"] = start
            self.emit("path_ok", n["id"],
                      {"cached": True, "len": len(n["path"])})
            return True
        self.counters["path_miss"] += 1
        self.path_queue.append((n["id"], start, goal_node, key))
        return None  # deferred

    def pump_paths(self):
        budget = self.tc["performance_policy"]["gates"][
            "path_queries_per_tick"]
        done = 0
        while self.path_queue and done < budget:
            nid, start, goal, key = self.path_queue.pop(0)
            done += 1
            n = self.npcs.get(nid)
            if n is None:
                continue
            path = self.astar(start, goal)
            if path is None:
                self.counters["path_failed"] += 1
                self.emit("path_fail", nid, {"reason": "no_route"})
                self.recover(n, "no_route")
                continue
            if len(self.path_cache) > 2000:
                self.path_cache.clear()
                self.counters["path_invalidated"] += 1
            self.path_cache[key] = list(path)
            n["path"] = list(path)
            n["path_i"] = 0
            n["node"] = start
            self.emit("path_ok", nid,
                      {"cached": False, "len": len(path)})
        if self.path_queue:
            self.counters["path_deferred"] += len(self.path_queue)

    # ---------- destinations ----------
    def pick_destination(self, n):
        z = self.zones[n["zone"]]
        cls = self.beh["class_map"].get(z["class"], "default")
        key = "%s|%s" % (cls, n.get("schedule", "DAY"))
        w = self.beh["weights"][key]
        cats = sorted(w.keys())
        total = sum(w[c] for c in cats)
        r = self.rng["destination"].random() * total
        acc = 0.0
        cat = cats[-1]
        for c in cats:
            acc += w[c]
            if r <= acc:
                cat = c
                break
        node = self.dest_node_for(n, cat)
        if node is None and cat != "RANDOM_WALK":
            node = self.dest_node_for(n, "RANDOM_WALK")
        n["dest_cat"] = cat
        n["dest_node"] = node
        return node

    def dest_node_for(self, n, cat):
        rng = self.rng["destination"]
        z = self.zones[n["zone"]]
        home = self.nearest_node(n["x"], n["z"], rmax=400.0)
        comp = self.comp_of.get(home) if home else None
        if cat in ("HOME", "WORK", "SHOP"):
            cands = sorted(
                nid for nid, d in self.nodes.items()
                if d["kind"] == "ENTRY")
        elif cat in ("PARK", "OPEN_SPACE"):
            cands = sorted(
                nid for nid, d in self.nodes.items()
                if d["kind"] == "AREA_CENTROID")
        elif cat == "LANDMARK":
            cands = sorted(
                nid for nid, d in self.nodes.items()
                if d["kind"] == "LANDMARK")
        elif cat in ("ARRIVAL", "TRANSIT_HOOK"):
            cands = sorted(
                nid for nid, d in self.nodes.items()
                if d["kind"] == "ARRIVAL")
        elif cat == "RETURN":
            cands = [self.nearest_node(n["x"], n["z"], rmax=400.0)]
            cands = [c for c in cands if c]
        else:  # RANDOM_WALK
            near = self.nearest_node(n["x"], n["z"])
            cands = []
            if near is not None:
                cands = [e["b"] for e in self.adj.get(near, [])]
                cands = sorted(set(cands))
        if comp is not None:
            same = [c for c in cands if self.comp_of.get(c) == comp]
            if same:
                cands = same
            else:
                cands = list(self.comp_nodes.get(comp, []))
        if not cands:
            return None
        # prefer same-sector, then near (deterministic: sort by key)
        scored = []
        for c in cands:
            d = self.nodes[c]
            same = 0 if d["sector"] == n["sector"] else 1
            dist = math.hypot(d["x"] - n["x"], d["z"] - n["z"])
            scored.append((same, dist, c))
        scored.sort()
        pool = [c for _, _, c in scored[:12]]
        return pool[rng.randrange(len(pool))]

    # ---------- traffic awareness ----------
    def vehicles_near(self, x, z, r):
        out = []
        if self.traffic is None:
            return out
        for v in self.traffic.vehicles.values():
            d = math.hypot(v["pos"][0] - x, v["pos"][2] - z)
            if d <= r:
                out.append((d, v))
        out.sort(key=lambda t: t[0])
        return out

    def crossing_decision(self, n, c):
        """Deterministic WAIT/COMMIT/CANCEL under a fixed snapshot."""
        cx = (self.nodes[c["a"]]["x"] + self.nodes[c["b"]]["x"]) / 2.0
        cz = (self.nodes[c["a"]]["z"] + self.nodes[c["b"]]["z"]) / 2.0
        pol = self.tc["movement_policy"]["crossing"]
        width = c["width_m"]
        t_cross = width / pol["cross_speed_ms"] + pol["commit_margin_s"]
        seen = self.vehicles_near(cx, cz, 80.0)
        min_tta = 1e9
        for (d, v) in seen:
            sp = max(0.5, v.get("speed", 0.0))
            tta = d / sp
            if tta < min_tta:
                min_tta = tta
        # signal hook: conflicting P08 movements RED?
        red_ok = True
        if self.traffic is not None:
            lane = c.get("lane")
            if lane:
                for sid, s in self.traffic.sig_state.items():
                    states = s.get("states", {})
                    for mid, st in states.items():
                        if lane.split(":")[0] in mid and st != "RED":
                            red_ok = False
        if min_tta > t_cross and red_ok:
            return "COMMIT", {"tta": round(min_tta, 2),
                              "need": round(t_cross, 2)}
        if min_tta <= t_cross * 0.5:
            return "CANCEL", {"tta": round(min_tta, 2),
                              "need": round(t_cross, 2)}
        return "WAIT", {"tta": round(min_tta, 2),
                        "need": round(t_cross, 2)}

    # ---------- movement ----------
    def step_move(self, n):
        st = n["move_state"]
        if st in ("SPAWNED", "INITIALIZING"):
            if st == "SPAWNED":
                self.move_transition(n, "INITIALIZING", "activate")
            node = self.pick_destination(n)
            if node is None:
                self.recover(n, "no_destination")
                return
            r = self.request_path(n, node)
            if r is False:
                self.recover(n, "path_rejected")
                return
            self.move_transition(n, "IDLE", "ready")
            self.beh_transition(n, "TRAVEL", "depart")
            return
        if st in ("DESPAWNING", "DESPAWNED", "PAUSED", "FAILED"):
            return
        if not n["path"] or n["path_i"] >= len(n["path"]):
            if st == "WALKING":
                self.move_transition(n, "IDLE", "arrived")
                # arrival confirms idle; never self-transition (P09-D16)
                if n["beh_state"] != "IDLE":
                    self.beh_transition(n, "IDLE", "arrived")
                self.emit("arrive", n["id"],
                          {"node": n["dest_node"], "cat": n["dest_cat"]})
                # chain next leg
                node = self.pick_destination(n)
                if node is not None:
                    self.request_path(n, node)
                    self.beh_transition(n, "TRAVEL", "depart")
                else:
                    # no destination: recover (retry, then fail safe)
                    self.recover(n, "no_destination")
            return
        tgt = self.nodes[n["path"][n["path_i"]]]
        # crossing edge?
        edge = None
        if n["path_i"] > 0:
            prev = n["path"][n["path_i"] - 1]
            for e in self.adj.get(prev, []):
                if e["b"] == n["path"][n["path_i"]]:
                    edge = e
                    break
        if edge is not None and edge["kind"] == "CROSSING" and \
                n.get("cross_state") != "COMMIT":
            c = self.crossings[edge["crossing"]]
            dec, info = self.crossing_decision(n, c)
            if dec == "COMMIT":
                n["cross_state"] = "COMMIT"
                n["crossing"] = c["id"]
                self.counters["crossings_committed"] += 1
                if st not in ("WALKING", "CROSSING"):
                    self.move_transition(n, "WALKING", "step")
                self.move_transition(n, "CROSSING", "commit")
                self.emit("cross_commit", n["id"], info)
            elif dec == "CANCEL":
                n["wait_ticks"] += 1
                self.counters["crossings_cancelled"] += 1
                if st != "WAITING":
                    self.move_transition(n, "WAITING", "cancel")
                if n["wait_ticks"] > 100:
                    n["wait_ticks"] = 0
                    n["cross_state"] = None
                    self.recover(n, "crossing_blocked")
            else:
                n["wait_ticks"] += 1
                if st != "WAITING":
                    self.move_transition(n, "WAITING", "wait_gap")
                if n["wait_ticks"] > 200:
                    n["wait_ticks"] = 0
                    self.recover(n, "crossing_timeout")
            return
        # advance toward target node
        dx = tgt["x"] - n["x"]
        dz = tgt["z"] - n["z"]
        dist = math.hypot(dx, dz)
        if dist < 1.0:
            n["path_i"] += 1
            n["node"] = tgt["id"]
            if n.get("cross_state") == "COMMIT":
                n["cross_state"] = None
                n["crossing"] = None
                self.move_transition(n, "WALKING", "cross_done")
                self.emit("cross_done", n["id"], {})
            n["stuck_ticks"] = 0
            return
        sp = n["run"] if st == "RUNNING" else n["walk"]
        if edge is not None and edge["kind"] == "CROSSING":
            sp = self.tc["movement_policy"]["crossing"]["cross_speed_ms"]
        step = min(sp * FIXED_STEP, dist)
        nx = n["x"] + dx / dist * step
        nz = n["z"] + dz / dist * step
        # separation (validated, never into walls)
        sx, sz = 0.0, 0.0
        for m in self.npcs_near(n["x"], n["z"], 1.2):
            if m["id"] == n["id"]:
                continue
            d = math.hypot(n["x"] - m["x"], n["z"] - m["z"])
            if 0.01 < d < 1.2:
                sx += (n["x"] - m["x"]) / d * (1.2 - d) * 0.3
                sz += (n["z"] - m["z"]) / d * (1.2 - d) * 0.3
        if sx or sz:
            cx, cz = nx + sx * FIXED_STEP * 4.0, nz + sz * FIXED_STEP * 4.0
            # validate: must stay near corridor (<= corridor_m)
            if math.hypot(cx - nx, cz - nz) <= 2.0:
                nx, nz = cx, cz
        moved = math.hypot(nx - n["x"], nz - n["z"])
        if moved < 0.001 and dist > 1.0:
            n["stuck_ticks"] += 1
        else:
            n["stuck_ticks"] = 0
        n["x"], n["z"] = nx, nz
        n["heading"] = math.degrees(math.atan2(dx, dz))
        n["speed"] = moved / FIXED_STEP
        n["sector"] = self.sector_of(nx, nz)
        if st not in ("WALKING", "CROSSING", "RUNNING", "AVOIDING"):
            self.move_transition(n, "WALKING", "step")
        if n["stuck_ticks"] > 50:
            n["stuck_ticks"] = 0
            self.move_transition(n, "STUCK", "no_progress")
            self.recover(n, "stuck")

    def recover(self, n, reason):
        self.counters["recoveries"] += 1
        n["recoveries"] += 1
        self.emit("recover", n["id"],
                  {"reason": reason, "k": n["recoveries"]})
        if n["recoveries"] > 3:
            self.move_transition(n, "FAILED", "exhausted")
            if self.despawn_safe(n):
                self.despawn(n, "recovery_failed")
            return
        if n["move_state"] != "RECOVERING":
            self.move_transition(n, "RECOVERING", reason)
        if n["beh_state"] != "RECOVER":
            self.beh_transition(n, "RECOVER", reason)
        # order: local replan -> new destination; never teleport
        node = self.pick_destination(n)
        if node is not None:
            self.request_path(n, node)
            self.move_transition(n, "IDLE", "replanned")
            self.beh_transition(n, "TRAVEL", "replanned")

    # ---------- tiers + scheduler ----------
    def assign_tiers(self):
        radii = self.tc["simulation_tier_policy"]["radii_m"]
        for n in self.npcs.values():
            d = math.hypot(n["x"] - self.focus[0], n["z"] - self.focus[1])
            if self.sector_state(n["sector"]) != "READY":
                want = "T1_proxy"
            elif d < radii["T3_full"]:
                want = "T3_full"
            elif d < radii["T1_proxy"]:
                want = "T2_simplified"
            elif d < radii["T0_abstract"]:
                want = "T1_proxy"
            else:
                want = "T0_abstract"
            if want != n["tier"]:
                self.emit("tier_change", n["id"],
                          {"frm": n["tier"], "to": want})
                n["tier"] = want
                self.counters["tier_changes"] += 1

    def step_proxy(self, n):
        # T1: advance route progress only
        if n["path"] and n["path_i"] < len(n["path"]):
            n["progress"] += 0.02
            if n["progress"] >= 1.0:
                n["progress"] = 0.0
                n["path_i"] += 1
                tgt = self.nodes[n["path"][min(
                    n["path_i"], len(n["path"]) - 1)]]
                n["x"], n["z"] = tgt["x"], tgt["z"]
                n["node"] = tgt["id"]
                n["sector"] = self.sector_of(tgt["x"], tgt["z"])

    # ---------- perception ----------
    def los_blocked(self, ax, az, bx, bz):
        self.counters["los_queries"] += 1
        for (x0, z0, x1, z1), fp in zip(self.bboxes, self.footprints):
            if max(ax, bx) < x0 or min(ax, bx) > x1 or \
                    max(az, bz) < z0 or min(az, bz) > z1:
                continue
            # segment vs polygon edges
            for i in range(len(fp) - 1):
                if self._segs_cross(ax, az, bx, bz, fp[i][0], fp[i][1],
                                    fp[i + 1][0], fp[i + 1][1]):
                    return True
        return False

    @staticmethod
    def _segs_cross(ax, az, bx, bz, cx, cz, dx, dz):
        d1 = (dx - cx) * (az - cz) - (dz - cz) * (ax - cx)
        d2 = (dx - cx) * (bz - cz) - (dz - cz) * (bx - cx)
        d3 = (bx - ax) * (cz - az) - (bz - az) * (cx - ax)
        d4 = (bx - ax) * (dz - az) - (bz - az) * (dx - ax)
        return ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0))

    def request_perception(self, n):
        if n["tier"] != "T3_full":
            return
        # coalesce: one pending query per npc
        for (nid, _, _) in self.perc_queue:
            if nid == n["id"]:
                self.counters["perc_coalesced"] += 1
                return
        self.counters["perc_queued"] += 1
        self.perc_queue.append((n["id"], self.tick_n, "scan"))

    def pump_perception(self):
        gates = self.tc["perception_policy"]["budget"]
        budget = gates["queries_per_tick"]
        cap = gates["los_candidates_per_scan"]
        done = 0
        while self.perc_queue and done < budget:
            nid, born, kind = self.perc_queue.pop(0)
            n = self.npcs.get(nid)
            if n is None or n["tier"] != "T3_full":
                continue
            done += 1
            self.counters["perc_executed"] += 1
            ap = self.perc["archetypes"][n["archetype"]]
            cands = []
            for m in self.npcs_near(n["x"], n["z"], ap["los_m"]):
                if m["id"] == nid:
                    continue
                d = math.hypot(m["x"] - n["x"], m["z"] - n["z"])
                ang = math.degrees(math.atan2(m["x"] - n["x"],
                                              m["z"] - n["z"]))
                da = abs((ang - n["heading"] + 180.0) % 360.0 - 180.0)
                if da > ap["fov_deg"] / 2.0:
                    continue
                cands.append((d, m["id"], m["x"], m["z"]))
            cands.sort()
            seen = []
            for (d, mid, mx, mz) in cands[:cap]:
                blocked = self.los_blocked(n["x"], n["z"], mx, mz)
                if not blocked:
                    seen.append({"id": mid, "dist": round(d, 2),
                                 "los": True})
            self.counters["perc_skipped_los"] += max(
                0, len(cands) - cap)
            # player observation
            if self.player is not None:
                d = math.hypot(self.player["x"] - n["x"],
                               self.player["z"] - n["z"])
                if d <= ap["los_m"]:
                    blocked = self.los_blocked(n["x"], n["z"],
                                               self.player["x"],
                                               self.player["z"])
                    if not blocked:
                        seen.append({"id": "PLAYER",
                                     "dist": round(d, 2), "los": True})
            n["perceived"] = seen
            # hearing: pending events in radius, delivered on the
            # observer's next executed scan within the window (P09-D15)
            for ev in self.hearing:
                heard_by = ev.setdefault("heard_by", set())
                if nid not in heard_by and \
                        math.hypot(ev["x"] - n["x"],
                                   ev["z"] - n["z"]) <= ev["radius"]:
                    heard_by.add(nid)
                    self.emit("heard", nid, {"event": ev["id"]})
                    if ev["intensity"] >= 0.8 and \
                            n["beh_state"] not in ("REACT", "DESPAWN"):
                        self.beh_transition(n, "REACT", ev["id"])
        if self.perc_queue:
            self.counters["perc_deferred"] += len(self.perc_queue)

    def fire_hearing(self, x, z, intensity, etype):
        eid = "EV-%05d" % len(self.hearing)
        self.hearing.append({"id": eid, "x": x, "z": z,
                             "intensity": intensity, "type": etype,
                             "radius": 30.0 + intensity * 60.0,
                             "tick": self.tick_n})
        return eid

    def witness(self, observer, source, event_id, auditory=False):
        o = self.npcs.get(observer)
        if o is None:
            return None
        rec = {"observer": observer, "source": source,
               "event": event_id, "los": True, "auditory": auditory,
               "confidence": 0.9 if not auditory else 0.5,
               "tick": self.tick_n, "reaction": "LOOK"}
        self.counters["witness_events"] += 1
        self.emit("witness", observer, rec)
        return rec

    # ---------- tick ----------
    def set_player(self, x, z):
        self.player = {"x": x, "z": z}
        self.focus = [x, z]

    def tick(self):
        self.tick_n += 1
        if self.traffic is not None:
            self.traffic.focus = list(self.focus)
            self.traffic.tick()
        self.update_sectors()
        for n in self.npcs.values():
            st = self.sector_state(n["sector"])
            if st == "UNLOADED" and n.get("pin") is None:
                n["pin"] = self.pin(n["sector"], n["id"], ticks=30)
                self.sectors[n["sector"]] = "LOADING"
            elif st == "READY" and n.get("pin") is not None:
                self.unpin(n["pin"])
                n["pin"] = None
        self.expire_pins()
        self._rehash()
        self.request_spawns()
        self._rehash()
        self.assign_tiers()
        if self.enable_paths:
            self.pump_paths()
        for nid in sorted(self.npcs.keys()):
            if nid not in self.npcs:
                continue
            n = self.npcs[nid]
            if n["tier"] == "T3_full":
                self.step_move(n)
                if self.tick_n % 5 == 0:
                    self.request_perception(n)
            elif n["tier"] == "T2_simplified":
                if self.tick_n % 2 == 0:
                    self.step_move(n)
            elif n["tier"] == "T1_proxy":
                if self.tick_n % 10 == 0:
                    self.step_proxy(n)
            # T0: frozen, counted only
        if self.enable_perc:
            self.pump_perception()
        self.request_despawns()
        # prune old hearing events
        self.hearing = [e for e in self.hearing
                        if self.tick_n - e["tick"] < 10]

    def check_leaks(self):
        leaks = []
        for pid, p in self.pins.items():
            if p["expires"] <= self.tick_n:
                leaks.append(pid)
        return leaks

    def stats(self):
        tiers = {}
        for n in self.npcs.values():
            tiers[n["tier"]] = tiers.get(n["tier"], 0) + 1
        return {"tick": self.tick_n, "npcs": len(self.npcs),
                "tiers": tiers, "counters": dict(self.counters),
                "pins": len(self.pins),
                "path_cache": len(self.path_cache),
                "illegal": len(self.illegal)}
