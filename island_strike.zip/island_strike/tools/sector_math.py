#!/usr/bin/env python3
"""P07 authoritative sector mathematics (mirrors scripts/core/sector_service.gd).

Formula: sx = floor((x - grid_min) / size), sz = floor((z - grid_min) / size).
Intervals are LEFT-CLOSED: exact boundary values belong to the higher sector.
Mapping is EXACT (no epsilon); tolerances live in tests.

Grid: grid_min=-2048, span=4096 for every candidate size so 128/256/512
cover the identical world rectangle (32x32 / 16x16 / 8x8).
Sector id string: SX%02dZ%02d (continuity with P05/P06 sector labels).
"""
import math

GRID_MIN = -2048.0
GRID_SPAN = 4096.0
WORLD_R = 2000.0

FULLY_INSIDE = "FULLY_INSIDE"
PARTIAL = "PARTIAL"
FULLY_OUTSIDE = "FULLY_OUTSIDE"


def fnv1a32_hex(text):
    """FNV-1a 32-bit (cross-language parity with streaming_check.gd)."""
    h = 2166136261
    for b in text.encode("utf-8"):
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return "%08x" % h


def semantic_lines(sectors):
    lines = []
    for x in sorted(sectors, key=lambda s: s["sector_id"]):
        c = x["content_counts"]
        lines.append("%s|%s|%d,%d,%d,%d,%d,%d,%d,%d,%d" % (
            x["sector_id"], x["world_state"], c["districts"], c["blocks"],
            c["parcels"], c["buildings"], c["landmarks"], c["open"],
            c["fragments"], c["structures"], c["reservations"]))
    return lines


def sector_id(sx, sz):
    return "SX%02dZ%02d" % (sx, sz)


def parse_sector_id(s):
    if not (s.startswith("SX") and "Z" in s[2:]):
        raise ValueError("bad sector id: %r" % s)
    a, b = s[2:].split("Z", 1)
    return int(a), int(b)


class SectorGrid:
    def __init__(self, size_m, grid_min=GRID_MIN, span=GRID_SPAN, world_r=WORLD_R):
        if span % size_m != 0:
            raise ValueError("size %r does not divide span %r" % (size_m, span))
        self.size = float(size_m)
        self.size_m = size_m
        self.grid_min = float(grid_min)
        self.span = float(span)
        self.world_r = float(world_r)
        self.count = int(span // size_m)

    # -- core mapping --------------------------------------------------
    def sector_of(self, x, z):
        return (math.floor((x - self.grid_min) / self.size),
                math.floor((z - self.grid_min) / self.size))

    def in_grid(self, sx, sz):
        return 0 <= sx < self.count and 0 <= sz < self.count

    def bounds_min(self, sx, sz):
        return (self.grid_min + sx * self.size, self.grid_min + sz * self.size)

    def bounds_max(self, sx, sz):
        mnx, mnz = self.bounds_min(sx, sz)
        return (mnx + self.size, mnz + self.size)

    def center(self, sx, sz):
        mnx, mnz = self.bounds_min(sx, sz)
        return (mnx + self.size / 2.0, mnz + self.size / 2.0)

    def contains(self, sx, sz, x, z):
        mnx, mnz = self.bounds_min(sx, sz)
        return mnx <= x < mnx + self.size and mnz <= z < mnz + self.size

    # -- topology ------------------------------------------------------
    @staticmethod
    def neighbors_4(sx, sz):
        return [(sx + 1, sz), (sx - 1, sz), (sx, sz + 1), (sx, sz - 1)]

    @staticmethod
    def neighbors_8(sx, sz):
        return [(sx + dx, sz + dz) for dx in (-1, 0, 1) for dz in (-1, 0, 1)
                if dx or dz]

    @staticmethod
    def chebyshev(a, b):
        return max(abs(a[0] - b[0]), abs(a[1] - b[1]))

    def center_distance(self, a, b):
        ax, az = self.center(*a)
        bx, bz = self.center(*b)
        return math.hypot(ax - bx, az - bz)

    def ring(self, sx, sz, radius_cheb):
        out = []
        for dx in range(-radius_cheb, radius_cheb + 1):
            for dz in range(-radius_cheb, radius_cheb + 1):
                if max(abs(dx), abs(dz)) <= radius_cheb:
                    qx, qz = sx + dx, sz + dz
                    if self.in_grid(qx, qz):
                        out.append((qx, qz))
        return sorted(out)

    # -- world classification ------------------------------------------
    def vs_world(self, sx, sz):
        mnx, mnz = self.bounds_min(sx, sz)
        mxx, mxz = mnx + self.size, mnz + self.size
        cx = min(max(0.0, mnx), mxx)
        cz = min(max(0.0, mnz), mxz)
        if math.hypot(cx, cz) > self.world_r:
            return FULLY_OUTSIDE
        dmax = max(math.hypot(px, pz) for px in (mnx, mxx) for pz in (mnz, mxz))
        if dmax <= self.world_r:
            return FULLY_INSIDE
        return PARTIAL

    def census(self):
        inside = partial = outside = 0
        for sx in range(self.count):
            for sz in range(self.count):
                v = self.vs_world(sx, sz)
                if v == FULLY_INSIDE:
                    inside += 1
                elif v == PARTIAL:
                    partial += 1
                else:
                    outside += 1
        return {"grid_count": self.count, "total": self.count * self.count,
                "fully_inside": inside, "partial": partial,
                "fully_outside": outside,
                "intersecting": inside + partial}

    # -- geometry helpers ----------------------------------------------
    def sectors_for_aabb(self, minx, minz, maxx, maxz):
        """All in-grid sectors overlapped by a closed AABB (boundary points
        map left-closed; pad max edge inward by epsilon so touching the grid
        line does not claim the neighbor)."""
        eps = 1e-9
        s0x, s0z = self.sector_of(minx, minz)
        s1x, s1z = self.sector_of(max( maxx - eps, minx), max( maxz - eps, minz))
        out = []
        for sx in range(s0x, s1x + 1):
            for sz in range(s0z, s1z + 1):
                if self.in_grid(sx, sz):
                    out.append((sx, sz))
        return sorted(out)

    def sectors_for_disc(self, x, z, r, samples=64):
        pts = [(x, z)] + [(x + r * math.cos(a), z + r * math.sin(a))
                          for a in (2 * math.pi * i / samples for i in range(samples))]
        got = set()
        for px, pz in pts:
            s = self.sector_of(px, pz)
            if self.in_grid(*s):
                got.add(s)
        # fill: any sector whose rect intersects the disc
        for sx, sz in self.sectors_for_aabb(x - r, z - r, x + r, z + r):
            mnx, mnz = self.bounds_min(sx, sz)
            cx = min(max(x, mnx), mnx + self.size)
            cz = min(max(z, mnz), mnz + self.size)
            if math.hypot(cx - x, cz - z) <= r:
                got.add((sx, sz))
        return sorted(got)

    def sectors_for_poly(self, pts):
        xs = [p[0] for p in pts]
        zs = [p[1] for p in pts]
        return self.sectors_for_aabb(min(xs), min(zs), max(xs), max(zs))
