#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 03 — authoritative road network generator + query API.

Authoritative: data/world/road_contract.json + data/roads/authoring.json.
Consumes (never duplicates): terrain height/slope/region/coast via
tools/terrain_model.py, grade recipe via tools/validate_terrain.py
(sample_polyline + profile — the locked P02 method).

Pipeline: authoring -> centerlines (uniform 10 m, P02 resolution) ->
node splits -> edges + metrics -> bridge/tunnel candidates -> checksum ->
export (data/derived/roads.json).

Determinism: authored IDs only (no creation-order dependence), sorted
iteration, pure functions of the inputs. Same inputs -> same bytes.
"""
import heapq
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import Field, fnv1a_hex  # noqa: E402
from validate_terrain import sample_polyline, profile  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class RoadError(Exception):
    pass


def load_road_inputs(roads_au_path=None, road_cc_path=None):
    rc = json.load(open(road_cc_path or os.path.join(ROOT, "data/world/road_contract.json")))
    ra = json.load(open(roads_au_path or os.path.join(ROOT, "data/roads/authoring.json")))
    f = Field()
    return rc, ra, f


def bore_grades(hs, ds):
    """P02 profile() recipe applied to non-terrain elevations (tunnel bore).

    Same smoothing recipe as validate_terrain.profile (50 m-window boxcar
    smooth of 10 m samples; sustained = 200 m rolling mean). Kept as a
    separate function ONLY because profile() samples the terrain field and
    a bore is authored geometry, not terrain. Consistency with profile()
    is asserted by the generator self-check on every surface edge.
    """
    win = 5
    sm = [sum(hs[max(0, i - win):i + win + 1]) / len(hs[max(0, i - win):i + win + 1])
          for i in range(len(hs))]
    step = ds[1] - ds[0] if len(ds) > 1 else 10.0
    gr = [abs(sm[i + 1] - sm[i]) / step * 100.0 for i in range(len(sm) - 1)]
    w200 = max(1, int(200 / step))
    roll = [sum(gr[max(0, i - w200 + 1):i + 1]) / len(gr[max(0, i - w200 + 1):i + 1])
            for i in range(len(gr))]
    return sm, gr, roll


def deflection_deg(a, b, c):
    """Direction change at b (0 = straight). P02 'bend' uses the same sense."""
    v1 = (a[0] - b[0], a[1] - b[1])
    v2 = (c[0] - b[0], c[1] - b[1])
    n1, n2 = math.hypot(*v1), math.hypot(*v2)
    if n1 < 1e-9 or n2 < 1e-9:
        return 0.0
    cosv = max(-1.0, min(1.0, (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)))
    return 180.0 - math.degrees(math.acos(cosv))


def fillet_arc(a, b, c, radius):
    """Tangent-arc fillet at b. Returns (points, tangent_len, deviation).

    points runs from the tangent point on leg a->b to the tangent point
    on leg b->c, sampled every ~5 deg (min 3 points). Pure geometry.
    """
    v1 = (a[0] - b[0], a[1] - b[1])
    v2 = (c[0] - b[0], c[1] - b[1])
    n1, n2 = math.hypot(*v1), math.hypot(*v2)
    u1 = (v1[0] / n1, v1[1] / n1)
    u2 = (v2[0] / n2, v2[1] / n2)
    d = deflection_deg(a, b, c)
    half = math.radians(d) / 2.0
    T = radius * math.tan(half)
    t1 = (b[0] + u1[0] * T, b[1] + u1[1] * T)
    t2 = (b[0] + u2[0] * T, b[1] + u2[1] * T)
    # center: along the angle bisector at distance radius / sin(half)
    bis = (u1[0] + u2[0], u1[1] + u2[1])
    nb = math.hypot(*bis)
    bis = (bis[0] / nb, bis[1] / nb)
    ctr = (b[0] + bis[0] * radius / math.cos(half),
           b[1] + bis[1] * radius / math.cos(half))
    a0 = math.atan2(t1[1] - ctr[1], t1[0] - ctr[0])
    a1 = math.atan2(t2[1] - ctr[1], t2[0] - ctr[0])
    # sweep the short way through the bisector
    while a1 - a0 > math.pi:
        a1 -= 2 * math.pi
    while a1 - a0 < -math.pi:
        a1 += 2 * math.pi
    n = max(3, int(abs(a1 - a0) / math.radians(5.0)) + 1)
    pts = [(ctr[0] + radius * math.cos(a0 + (a1 - a0) * i / (n - 1)),
            ctr[1] + radius * math.sin(a0 + (a1 - a0) * i / (n - 1)))
           for i in range(n)]
    dev = radius * (1 / math.cos(half) - 1)
    return pts, T, dev


def _smooth_headings(pts, win=2):
    h = [math.atan2(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
         for i in range(len(pts) - 1)]
    out = []
    for i in range(len(h)):
        lo, hi = max(0, i - win), min(len(h), i + win + 1)
        sx = sum(math.sin(v) for v in h[lo:hi])
        cz = sum(math.cos(v) for v in h[lo:hi])
        out.append(math.atan2(sx, cz))
    return out


def curvature_pinches(pts, rmin, win=2):
    """Min-radius stations on the smoothed driven line + pinch groups."""
    if len(pts) < 4:
        return float("inf"), []
    hs = _smooth_headings(pts, win)
    steps = [math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
             for i in range(len(pts) - 1)]
    radii = []
    for i in range(len(hs) - 1):
        dh = abs((hs[i + 1] - hs[i] + math.pi) % (2 * math.pi) - math.pi)
        st = (steps[i] + steps[i + 1]) / 2.0
        radii.append(st / dh if dh > 1e-9 else float("inf"))
    ds = [0.0]
    for s in steps:
        ds.append(ds[-1] + s)
    pinches, cur = [], None
    for i, r in enumerate(radii):
        if r < rmin:
            if cur is None:
                cur = {"s0": ds[i], "s1": ds[i + 1], "min_r": r}
            else:
                cur["s1"] = ds[i + 1]
                cur["min_r"] = min(cur["min_r"], r)
        elif cur is not None:
            pinches.append(cur)
            cur = None
    if cur is not None:
        pinches.append(cur)
    for p in pinches:
        p["curve_factor"] = round(max(0.3, p["min_r"] / rmin), 4)
        p["min_r"] = round(p["min_r"], 2)
        p["s0"] = round(p["s0"], 1)
        p["s1"] = round(p["s1"], 1)
    finite = [r for r in radii if r != float("inf")]
    return (min(finite) if finite else float("inf")), pinches


class RoadNetwork:
    def __init__(self, rc=None, ra=None, f=None):
        self.rc, ra0, f0 = rc, ra, f
        if self.rc is None or ra0 is None or f0 is None:
            rc2, ra2, f2 = load_road_inputs()
            self.rc = self.rc or rc2
            ra0 = ra0 or ra2
            f0 = f0 or f2
        self.ra = ra0
        self.f = f0
        self.tau = self.f.au
        self.tc = self.f.tc
        self.nodes = {}
        self.edges = {}
        self.routes_built = {}
        self.bridges = []
        self.tunnels = []
        self._check_versions()

    def _check_versions(self):
        m = self.ra["meta"]
        refs = {"road_version": self.rc["road_version"],
                "terrain_version": self.rc["terrain_version_reference"],
                "coast_version": self.rc["coast_version_reference"],
                "world_version": self.rc["world_version"]}
        for k, want in refs.items():
            if m.get(k) != want:
                raise RoadError("authoring %s %s != contract %s" % (k, m.get(k), want))
        live = {"terrain_version": self.tc["terrain_version"],
                "coast_version": self.f.cc["coast_version"],
                "world_version": self.f.wc["world_version"]}
        for k, want in live.items():
            if m.get(k) != want:
                raise RoadError("authoring %s %s != live %s (stale input)" % (k, m.get(k), want))

    # ---- geometry ----
    def coast_d(self, x, z):
        r = math.hypot(x, z)
        return self.f.loop.rs(self.f.loop.theta(x, z)) - r

    def works_discs(self):
        discs = []
        for c in self.tau["corridors"]:
            if c["type"] == "tunnel":
                for pp, pr in zip(c["portals"], c["portal_works_r_m"]):
                    discs.append(((float(pp[0]), float(pp[1])), float(pr)))
        return discs

    def in_works(self, x, z):
        return any(math.hypot(x - w[0][0], z - w[0][1]) < w[1]
                   for w in self.works_discs())

    def _apply_fillets(self, route, anchors):
        """Fillet non-junction interior anchors per contract fillet_policy.

        Returns (polyline, fillet_report, skipped). polyline[0/-1] equal
        anchors[0/-1] exactly; junction anchors pass through unmodified.
        """
        cls = self.rc["road_classes"][route["class"]]
        pol = self.rc["fillet_policy"]
        nodepts = {self._node_xy(nid) for nid in route["splits"]}
        if (route["geometry_method"] == "tunnel_bore"
                or route["class"] not in pol["applies_to"]):
            return list(anchors), [], [
                {"anchor": list(anchors[j]), "reason": "class exempt",
                 "deflection_deg": round(deflection_deg(anchors[j - 1], anchors[j],
                                                        anchors[j + 1]), 1)}
                for j in range(1, len(anchors) - 1)]
        discs = self.works_discs()
        R0 = cls["min_turning_radius_m"]
        out = [anchors[0]]
        rep, skipped = [], []
        for j in range(1, len(anchors) - 1):
            a, b, c = anchors[j - 1], anchors[j], anchors[j + 1]
            d = deflection_deg(a, b, c)
            why = None
            if b in nodepts:
                why = "junction exact"
            elif any(math.hypot(b[0] - w[0][0], b[1] - w[0][1]) < w[1] for w in discs):
                why = "portal works disc"
            if why is not None:
                skipped.append({"anchor": list(b), "reason": why,
                                "deflection_deg": round(d, 1)})
                out.append(b)
                continue
            if d < 5.0:
                out.append(b)
                continue
            leg = min(math.hypot(a[0] - b[0], a[1] - b[1]),
                      math.hypot(c[0] - b[0], c[1] - b[1]))
            R = R0
            T = R * math.tan(math.radians(d) / 2.0)
            if T > pol["min_leg_fit"] * leg:
                R = pol["min_leg_fit"] * leg / math.tan(math.radians(d) / 2.0)
            if R < pol["min_radius_fraction"] * R0:
                skipped.append({"anchor": list(b), "reason": "FILLET_INFEASIBLE",
                                "deflection_deg": round(d, 1)})
                out.append(b)
                continue
            pts, T, dev = fillet_arc(a, b, c, R)
            rep.append({"anchor": list(b), "deflection_deg": round(d, 1),
                        "radius_m": round(R, 2), "reduced": R < R0 - 1e-9,
                        "tangent_m": round(T, 1), "deviation_m": round(dev, 2)})
            out.extend(pts)
        out.append(anchors[-1])
        return out, rep, skipped

    def _route_anchors(self, route):
        if route["geometry_method"] in ("migrated", "tunnel_bore"):
            cor = next(c for c in self.tau["corridors"]
                       if c["id"] == route["migrate_corridor"])
            return [tuple(p) for p in cor["points"]], True
        return [tuple(p) for p in route["anchors"]], False

    def _build_centerline(self, route):
        anchors, _ = self._route_anchors(route)
        poly, fillets, skipped = self._apply_fillets(route, anchors)
        path = sample_polyline([list(p) for p in poly], step_m=10.0)
        path = [(float(x), float(z)) for (x, z) in path]
        tunnel = route["geometry_method"] == "tunnel_bore"
        hp = [self.f.height(*self._node_xy(nid)) for nid in
              (route["splits"][0], route["splits"][-1])] if tunnel else None
        ds = [0.0]
        for i in range(1, len(path)):
            ds.append(ds[-1] + math.hypot(path[i][0] - path[i - 1][0],
                                          path[i][1] - path[i - 1][1]))
        total = ds[-1] or 1.0
        samples = []
        for i, (x, z) in enumerate(path):
            if tunnel:
                elev = hp[0] + (hp[1] - hp[0]) * ds[i] / total
                surf = self.f.height(x, z)
                samples.append({"x": x, "z": z, "elev": elev, "surface": surf,
                                "cover": surf - elev, "d": ds[i],
                                "region": self.f.region_at(x, z),
                                "coast_d": self.coast_d(x, z)})
            else:
                samples.append({"x": x, "z": z, "elev": self.f.height(x, z),
                                "d": ds[i], "region": self.f.region_at(x, z),
                                "coast_d": self.coast_d(x, z)})
        return anchors, samples, fillets, skipped

    def _node_xy(self, nid):
        n = next((q for q in self.ra["nodes"] if q["id"] == nid), None)
        if n is None:
            raise RoadError("unknown node " + nid)
        return (float(n["xy"][0]), float(n["xy"][1]))

    def _split_samples(self, route, samples):
        tol = self.rc["validation_thresholds"]["junction_snap_tol_m"]
        idxs = []
        for nid in route["splits"]:
            tx, ty = self._node_xy(nid)
            best, bi = 1e18, -1
            for i, s in enumerate(samples):
                dd = math.hypot(s["x"] - tx, s["z"] - ty)
                if dd < best:
                    best, bi = dd, i
            if best > tol:
                raise RoadError("split %s off centerline by %.2fm (route %s)"
                                % (nid, best, route["id"]))
            idxs.append(bi)
        if any(b <= a for a, b in zip(idxs, idxs[1:])):
            raise RoadError("splits not ordered along route %s" % route["id"])
        return idxs

    # ---- build ----
    def build(self):
        seen = set()
        for n in self.ra["nodes"]:
            if n["id"] in seen:
                raise RoadError("duplicate node " + n["id"])
            seen.add(n["id"])
            x, y = float(n["xy"][0]), float(n["xy"][1])
            rw = float(self.f.wc["boundary"]["r_world_m"])
            if math.hypot(x, y) > rw:
                raise RoadError("node %s off-terrain (r=%.0f > %.0f)"
                                % (n["id"], math.hypot(x, y), rw))
            self.nodes[n["id"]] = {
                "id": n["id"], "x": x, "z": y, "type": n["type"],
                "access": n["access"], "priority": n["priority"],
                "elev": self.f.height(x, y), "region": self.f.region_at(x, y),
                "radius_m": n.get("radius_m"),
                "dead_end": n.get("dead_end"),
                "degree": 0}
        rseen = set()
        for route in sorted(self.ra["routes"], key=lambda r: r["id"]):
            if route["id"] in rseen:
                raise RoadError("duplicate route " + route["id"])
            rseen.add(route["id"])
            self._build_route(route)
        for e in self.edges.values():
            self.nodes[e["from_node"]]["degree"] += 1
            self.nodes[e["to_node"]]["degree"] += 1
        self._detect_water_crossings()
        self._detect_runway()
        return self

    def _build_route(self, route):
        cls = self.rc["road_classes"][route["class"]]
        pol = self.rc["fillet_policy"]
        anchors, samples, fillets, skipped = self._build_centerline(route)
        idxs = self._split_samples(route, samples)
        tunnel = route["geometry_method"] == "tunnel_bore"
        # route-full grades (no slice-boundary smoothing artifacts; P02-identical
        # on migrated routes) + recipe self-check
        pts_all = [(s["x"], s["z"]) for s in samples]
        hs_all = [s["elev"] for s in samples]
        ds_all = [s["d"] for s in samples]
        if tunnel:
            _, gr_all, roll_all = bore_grades(hs_all, ds_all)
        else:
            _, _, gr_all, roll_all = profile(self.f, pts_all)
            _, gr2, roll2 = bore_grades(hs_all, ds_all)
            if gr_all:
                dev = max(abs(a - b) for a, b in zip(gr_all + roll_all, gr2 + roll2))
                if dev > 1e-9:
                    raise RoadError("grade recipe drift on %s" % route["id"])
        # route-full smoothed curvature (attributed per edge below)
        rmin = cls["min_turning_radius_m"]
        radii_all = []
        if not tunnel and len(pts_all) >= 4:
            hsm = _smooth_headings(pts_all, 2)
            stp = [math.hypot(pts_all[i + 1][0] - pts_all[i][0],
                              pts_all[i + 1][1] - pts_all[i][1])
                   for i in range(len(pts_all) - 1)]
            for i in range(len(hsm) - 1):
                dh = abs((hsm[i + 1] - hsm[i] + math.pi) % (2 * math.pi) - math.pi)
                st = (stp[i] + stp[i + 1]) / 2.0
                radii_all.append(st / dh if dh > 1e-9 else float("inf"))
        # residual deflections at every interior sample
        res_all = [0.0] * len(samples)
        for i in range(1, len(samples) - 1):
            a = (samples[i - 1]["x"], samples[i - 1]["z"])
            b = (samples[i]["x"], samples[i]["z"])
            c = (samples[i + 1]["x"], samples[i + 1]["z"])
            res_all[i] = deflection_deg(a, b, c)
        splitset = set(idxs)
        edges = []
        for k in range(len(idxs) - 1):
            i0, i1 = idxs[k], idxs[k + 1]
            sl = samples[i0:i1 + 1]
            eid = "E_%s_%02d" % (route["id"], k)
            pts = [(s["x"], s["z"]) for s in sl]
            # grades on slice, open-alignment excludes works-disc samples (P02)
            gr = gr_all[i0:i1]
            roll = roll_all[i0:i1]
            open_gr = [g for j, g in enumerate(gr)
                       if not self.in_works(sl[j]["x"], sl[j]["z"])]
            open_roll = [g for j, g in enumerate(roll)
                         if not self.in_works(sl[j]["x"], sl[j]["z"])]
            short_all = max(gr) if gr else 0.0
            sust_all = max(roll) if roll else 0.0
            short = max(open_gr) if open_gr else 0.0
            sust = max(open_roll) if open_roll else 0.0
            # portal approach: raw anchor-leg grades within 250 m of a portal
            approach = 0.0
            if route["id"] == "ring_hw" and k in (0, len(idxs) - 2):
                for w in self.works_discs():
                    acc = 0.0
                    legs = list(zip(anchors, anchors[1:]))
                    if k != 0:
                        legs = [(b, a) for (a, b) in reversed(legs)]
                    for a, b in legs:
                        if acc > 250.0:
                            break
                        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
                        if math.hypot(mid[0] - w[0][0], mid[1] - w[0][1]) > 250.0 + w[1]:
                            acc += math.hypot(b[0] - a[0], b[1] - a[1])
                            continue
                        L = math.hypot(b[0] - a[0], b[1] - a[1])
                        approach = max(approach, abs(self.f.height(*b) - self.f.height(*a))
                                       / max(L, 1e-6) * 100.0)
                        acc += L
            # curvature attribution + pinch grouping on slice
            pinches = []
            min_r = float("inf")
            if radii_all:
                rs = radii_all[i0:max(i0 + 1, i1 - 1)]
                finite = [r for r in rs if r != float("inf")]
                min_r = min(finite) if finite else float("inf")
                cur = None
                for j, r in enumerate(rs):
                    gi = i0 + j
                    near_j = any(abs(samples[gi]["d"] - samples[q]["d"]) < 30.0
                                 for q in splitset)
                    in_w = self.in_works(samples[gi]["x"], samples[gi]["z"])
                    if r < rmin * pol["pinch_hysteresis"]:
                        if cur is None:
                            cur = {"s0": round(samples[gi]["d"] - sl[0]["d"], 1),
                                   "s1": round(samples[gi + 1]["d"] - sl[0]["d"], 1),
                                   "min_r": r, "junction": near_j, "works": in_w}
                        else:
                            cur["s1"] = round(samples[gi + 1]["d"] - sl[0]["d"], 1)
                            cur["min_r"] = min(cur["min_r"], r)
                            cur["junction"] = cur["junction"] or near_j
                            cur["works"] = cur["works"] and in_w
                    elif cur is not None:
                        pinches.append(cur)
                        cur = None
                if cur is not None:
                    pinches.append(cur)
                for p in pinches:
                    p["curve_factor"] = round(max(0.3, p["min_r"] / rmin), 4)
                    p["min_r"] = round(p["min_r"], 2)
            # residual corners: junction-adjacent vs works-zone vs open
            res_open, res_junc, res_works = 0.0, 0.0, 0.0
            for j in range(1, len(sl) - 1):
                gi = i0 + j
                near_j = any(abs(samples[gi]["d"] - samples[q]["d"]) < 15.0
                             for q in splitset)
                if near_j:
                    res_junc = max(res_junc, res_all[gi])
                elif self.in_works(samples[gi]["x"], samples[gi]["z"]):
                    res_works = max(res_works, res_all[gi])
                else:
                    res_open = max(res_open, res_all[gi])
            # attribute fillets + skipped anchors by nearest sample station
            ef, esk = [], []
            for rep in fillets:
                ax, az = rep["anchor"]
                gi = min(range(len(samples)),
                         key=lambda i: math.hypot(samples[i]["x"] - ax,
                                                  samples[i]["z"] - az))
                if i0 <= gi <= i1:
                    ef.append(rep)
            for sk in skipped:
                if "deflection_deg" not in sk:
                    continue
                ax, az = sk["anchor"]
                gi = min(range(len(samples)),
                         key=lambda i: math.hypot(samples[i]["x"] - ax,
                                                  samples[i]["z"] - az))
                if i0 <= gi <= i1:
                    esk.append(sk)
            length = sum(math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
                         for i in range(len(pts) - 1))
            regs = {}
            for s in sl:
                regs[s["region"]] = regs.get(s["region"], 0) + 1
            dom = max(sorted(regs), key=lambda r: regs[r])
            coast_min = min(s["coast_d"] for s in sl)
            beach_idx = [j for j, s in enumerate(sl) if s["region"] == "coastal_beach"]
            beach_spans = []
            if beach_idx:
                s0, prev = beach_idx[0], beach_idx[0]
                for j in beach_idx[1:]:
                    if j == prev + 1:
                        prev = j
                    else:
                        beach_spans.append([s0, prev])
                        s0, prev = j, j
                beach_spans.append([s0, prev])
            ncf = [p for p in pinches if not p["junction"] and not p["works"]]
            cf = min([p["curve_factor"] for p in ncf]) if ncf else 1.0
            e = {
                "id": eid, "route": route["id"], "from_node": route["splits"][k],
                "to_node": route["splits"][k + 1], "class": route["class"],
                "access": route["access"], "surface": route["surface"],
                "design_speed_kph": route["design_speed_kph"],
                "curve_factor": cf,
                "effective_speed_kph": round(route["design_speed_kph"] * cf, 1),
                "width_m": route.get("width_m", cls["target_width_m"]),
                "length_m": length, "elev_start": sl[0]["elev"],
                "elev_end": sl[-1]["elev"],
                "max_grade_short": short, "max_grade_sustained": sust,
                "grade_short_all": short_all, "grade_sustained_all": sust_all,
                "works_excluded": len(gr) - len(open_gr),
                "portal_approach_max": round(approach, 2),
                "min_radius_m": min_r if min_r != float("inf") else 1e9,
                "pinches": pinches, "fillets": ef, "skipped_corners": esk,
                "residual_open_max": round(res_open, 2),
                "residual_junction_max": round(res_junc, 2),
                "residual_works_max": round(res_works, 2),
                "region": dom, "coast_min_m": coast_min,
                "beach_samples": len(beach_idx), "beach_spans": beach_spans,
                "n_samples": len(sl),
                "tunnel": tunnel, "geometry_version": 1,
                "samples": sl,
            }
            if tunnel:
                deep = [s["cover"] for s in sl
                        if 150 < s["d"] - sl[0]["d"] < (sl[-1]["d"] - sl[0]["d"]) - 150]
                e["cover_min_m"] = min(deep) if deep else 0.0
                bends = [deflection_deg(anchors[j - 1], anchors[j], anchors[j + 1])
                         for j in range(1, len(anchors) - 1)]
                e["bend_max_deg"] = max(bends) if bends else 0.0
                ringpts = [tuple(p) for p in
                           next(c["points"] for c in self.tau["corridors"]
                                if c["id"] == "ring_hw")]
                def _ang(u, v):
                    return math.degrees(math.acos(max(-1.0, min(1.0, (
                        u[0] * v[0] + u[1] * v[1]) / (math.hypot(*u) * math.hypot(*v))))))
                e_in = (ringpts[0][0] - ringpts[1][0], ringpts[0][1] - ringpts[1][1])
                e_bore = (anchors[1][0] - anchors[0][0], anchors[1][1] - anchors[0][1])
                w_in = (ringpts[-1][0] - ringpts[-2][0], ringpts[-1][1] - ringpts[-2][1])
                w_bore = (anchors[-2][0] - anchors[-1][0], anchors[-2][1] - anchors[-1][1])
                e["portal_turn_E_deg"] = round(_ang(e_in, e_bore), 1)
                e["portal_turn_W_deg"] = round(_ang(w_in, w_bore), 1)
                self.tunnels.append({
                    "id": "TN-%s" % route["id"].upper().replace("_", "-"),
                    "road_edge": eid,
                    "entry": list(route["splits"][0:1]),
                    "exit": list(route["splits"][-1:]),
                    "length_m": length,
                    "grade_pct": (abs(e["elev_end"] - e["elev_start"]) / length * 100.0
                                  if length > 0 else 0.0),
                    "surface_alternative": "none (ridge massif; ring closes only via bore)",
                    "terrain_cover_m": e["cover_min_m"],
                    "road_class": route["class"],
                    "purpose": route["purpose"],
                    "bend_max_deg": e["bend_max_deg"],
                    "portal_turn_E_deg": e["portal_turn_E_deg"],
                    "portal_turn_W_deg": e["portal_turn_W_deg"],
                    "validation": "pending"})
            edges.append(e)
            self.edges[eid] = e
        self.routes_built[route["id"]] = {"edges": [e["id"] for e in edges],
                                          "n_samples": len(samples)}

    def _detect_water_crossings(self):
        lakes = self.tau["drainage"]["lakes"]
        rivers = self.tau["drainage"]["rivers"]
        n = 0
        for eid in sorted(self.edges):
            e = self.edges[eid]
            if e["tunnel"]:
                continue
            sl = e["samples"]
            # lake ellipse + below level: grouped per lake
            for lk in lakes:
                span = [s for s in sl
                        if ((s["x"] - lk["cx"]) / lk["rx"]) ** 2
                        + ((s["z"] - lk["cz"]) / lk["rz"]) ** 2 <= 1.0
                        and s["elev"] < lk["level_m"] + 0.5]
                if span:
                    n += 1
                    e["bridge_span"] = {"lake": lk["id"], "n": len(span)}
                    self.bridges.append({
                        "id": "BC-%02d" % n, "road_edge": eid,
                        "crossing_type": "lake", "water_feature": lk["id"],
                        "length_m": span[-1]["d"] - span[0]["d"],
                        "approach_grade_pct": round(max(e["max_grade_short"],
                                                        e["max_grade_sustained"]), 1),
                        "clearance_m": None,
                        "future_asset_class": "bridge_short",
                        "validation": "candidate"})
            # river ribbon: within half width of river polyline
            for rv in rivers:
                pts = rv["points"]
                hw = rv["width_m"] / 2.0
                hits = []
                for s in sl:
                    md = 1e18
                    for i in range(len(pts) - 1):
                        ax, az = pts[i]
                        bx, bz = pts[i + 1]
                        vx, vz = bx - ax, bz - az
                        L2 = vx * vx + vz * vz or 1.0
                        t = max(0.0, min(1.0, ((s["x"] - ax) * vx + (s["z"] - az) * vz) / L2))
                        md = min(md, math.hypot(s["x"] - (ax + vx * t),
                                                s["z"] - (az + vz * t)))
                    if md <= hw:
                        hits.append(s)
                if hits:
                    n += 1
                    e["bridge_span"] = {"river": rv["id"], "n": len(hits)}
                    self.bridges.append({
                        "id": "BC-%02d" % n, "road_edge": eid,
                        "crossing_type": "river", "water_feature": rv["id"],
                        "length_m": max(rv["width_m"],
                                        hits[-1]["d"] - hits[0]["d"]),
                        "approach_grade_pct": round(max(e["max_grade_short"],
                                                        e["max_grade_sustained"]), 1),
                        "clearance_m": None,
                        "future_asset_class": "bridge_river",
                        "validation": "candidate"})

    def _detect_runway(self):
        rw = self.tau["runway"]
        x0 = rw["center"][0] - rw["length_m"] / 2 - 60
        x1 = rw["center"][0] + rw["length_m"] / 2 + 60
        z0 = rw["center"][1] - rw["width_m"] / 2 - 60
        z1 = rw["center"][1] + rw["width_m"] / 2 + 60
        self.runway_rect = [x0, z0, x1, z1]
        for e in self.edges.values():
            e["runway_inside"] = sum(1 for s in e["samples"]
                                     if x0 <= s["x"] <= x1 and z0 <= s["z"] <= z1)

    # ---- queries (future-safe API surface, §54) ----
    def allowed_access(self, access_profile):
        return self.rc["access_profiles"]["query_profiles"][access_profile]

    def find_route(self, start_node, end_node, access_profile="public"):
        allow = set(self.allowed_access(access_profile))
        adj = {}
        for e in self.edges.values():
            if e["access"] not in allow:
                continue
            w = e["length_m"] / max(1.0, e["effective_speed_kph"])
            adj.setdefault(e["from_node"], []).append((e["to_node"], w, e["id"]))
            adj.setdefault(e["to_node"], []).append((e["from_node"], w, e["id"]))
        for k in adj:
            adj[k].sort()
        if start_node not in adj or end_node not in adj:
            return None
        dist = {start_node: 0.0}
        prev = {}
        pq = [(0.0, start_node)]
        while pq:
            d, u = heapq.heappop(pq)
            if u == end_node:
                break
            if d > dist.get(u, 1e18) + 1e-12:
                continue
            for v, w, eid in adj.get(u, []):
                nd = d + w
                if nd < dist.get(v, 1e18) - 1e-12:
                    dist[v] = nd
                    prev[v] = (u, eid)
                    heapq.heappush(pq, (nd, v))
        if end_node not in prev and end_node != start_node:
            return None
        nodes, edges, u = [end_node], [], end_node
        total_len, total_t = 0.0, 0.0
        while u != start_node:
            u2, eid = prev[u]
            nodes.append(u2)
            edges.append(eid)
            e = self.edges[eid]
            total_len += e["length_m"]
            total_t += e["length_m"] / max(1.0, e["effective_speed_kph"])
            u = u2
        nodes.reverse()
        edges.reverse()
        return {"nodes": nodes, "edges": edges, "length_m": total_len,
                "time_h": total_t, "access_profile": access_profile}

    def nearest_node(self, x, z):
        return min(self.nodes.values(),
                   key=lambda n: (math.hypot(n["x"] - x, n["z"] - z), n["id"]))

    def nearest_road(self, x, z):
        best = None
        for eid in sorted(self.edges):
            e = self.edges[eid]
            for s in e["samples"]:
                d = math.hypot(s["x"] - x, s["z"] - z)
                if best is None or d < best[0]:
                    best = (d, eid, s)
        return {"dist_m": best[0], "edge": best[1], "sample": best[2]}

    def road_at(self, x, z):
        nr = self.nearest_road(x, z)
        e = self.edges[nr["edge"]]
        if nr["dist_m"] <= e["width_m"] / 2.0 + 2.0:
            return nr["edge"]
        return None

    # ---- checksum + export ----
    def checksum(self):
        # Quantization is half-AWAY-from-zero (floor/ceil), matching GDScript
        # roundf bit-for-bit. Python q() is half-even and DIVERGES on
        # exact .5 ties (interpolated midpoints hit these); never use q()
        # in canonical identity strings.
        def q(v):
            return math.floor(v + 0.5) if v >= 0.0 else math.ceil(v - 0.5)
        m = self.ra["meta"]
        parts = ["road=%s terra=%s coast=%s world=%s auth=%s" % (
            m["road_version"], m["terrain_version"], m["coast_version"],
            m["world_version"], m["road_authoring_version"])]
        for nid in sorted(self.nodes):
            n = self.nodes[nid]
            parts.append("N|%s|%d|%d|%d|%s|%s|%s|%d" % (
                nid, q(n["x"] * 1000), q(n["z"] * 1000),
                q(n["elev"] * 1000), n["region"], n["type"],
                n["access"], n["degree"]))
        for eid in sorted(self.edges):
            e = self.edges[eid]
            parts.append("E|%s|%s|%s|%s|%s|%s|%d|%d|%d|%d|%d|%d|%d|%s|%d" % (
                eid, e["from_node"], e["to_node"], e["route"], e["class"],
                e["access"], q(e["length_m"] * 1000),
                q(e["elev_start"] * 1000), q(e["elev_end"] * 1000),
                q(e["max_grade_short"] * 1000),
                q(e["max_grade_sustained"] * 1000),
                q(min(e["min_radius_m"], 1e8) * 100),
                q(e["coast_min_m"] * 1000), e["region"], e["n_samples"]))
            for s in e["samples"]:
                parts.append("S|%s|%d|%d|%d|%d|%s" % (
                    eid, q(s["x"] * 1000), q(s["z"] * 1000),
                    q(s["elev"] * 1000), q(s["coast_d"] * 1000),
                    s["region"]))
            for fl in e["fillets"]:
                parts.append("F|%s|%d|%d|%d|%d" % (
                    eid, q(fl["anchor"][0] * 1000),
                    q(fl["anchor"][1] * 1000),
                    q(fl["radius_m"] * 100), q(fl["deviation_m"] * 1000)))
        for b in sorted(self.bridges, key=lambda b: b["id"]):
            parts.append("B|%s|%s|%s|%s|%d" % (
                b["id"], b["road_edge"], b["crossing_type"],
                b["water_feature"], q(b["length_m"] * 1000)))
        return fnv1a_hex(";".join(parts) + ";")

    def export(self):
        # Full float precision: the export is machine data, and CROSS-ROAD
        # recomputes checksums from these exact decimals (rounding would
        # fork Python/GDScript quantized integers).
        nodes = {nid: dict(self.nodes[nid]) for nid in sorted(self.nodes)}
        edges = {}
        for eid in sorted(self.edges):
            e = dict(self.edges[eid])
            e["samples"] = [dict(s) for s in e["samples"]]
            edges[eid] = e
        return {
            "meta": dict(self.ra["meta"], generator="road_model.py",
                         class_gates={k: {
                             "short": v["max_grade_short_pct"],
                             "sustained": v["max_grade_sustained_pct"],
                             "rmin": v["min_turning_radius_m"],
                             "corner": v["max_corner_deg"]}
                             for k, v in self.rc["road_classes"].items()}),
            "nodes": nodes,
            "edges": edges,
            "bridges": self.bridges,
            "tunnels": self.tunnels,
            "runway_rect": [round(v, 1) for v in self.runway_rect],
            "checksum": self.checksum(),
        }


def main():
    rn = RoadNetwork().build()
    out = os.path.join(ROOT, "data/derived/roads.json")
    json.dump(rn.export(), open(out, "w"), indent=1)
    n = len(rn.nodes)
    ne = len(rn.edges)
    tot = sum(e["length_m"] for e in rn.edges.values())
    print("roads: %d nodes %d edges %.2fkm %d bridges %d tunnels -> %s" % (
        n, ne, tot / 1000, len(rn.bridges), len(rn.tunnels), out))
    print("checksum:", rn.checksum())


if __name__ == "__main__":
    main()
