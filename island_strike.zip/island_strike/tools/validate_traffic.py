#!/usr/bin/env python3
"""P08 validation: STATIC / CROSS / INJECT / REPRODUCE / SMOKE / PERF /
REGRESS / STRESS / ROUTE / JUNCTION / VEHICLE suites for traffic + vehicles.

Evidence: reports/p08/<suite>.json. Exit 0 iff every requested suite passes.
Usage: python3 tools/validate_traffic.py [suite ...] | all
       python3 tools/validate_traffic.py regress --write   (pin goldens)
"""
import copy
import json
import math
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sector_math import SectorGrid  # noqa: E402
from vehicle_model import (VehicleSpec, VehiclePool, STATES, TRANSITIONS,  # noqa: E402
                           ACTIVE, is_legal, new_vehicle, reset_vehicle,
                           transition)
from traffic_sim import TrafficWorld, Router, FIXED_STEP  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DD = os.path.join(ROOT, "data/derived")
DW = os.path.join(ROOT, "data/world")
REP = os.path.join(ROOT, "reports/p08")
GODOT = os.environ.get("GODOT_BIN", os.path.join(ROOT, "tools/.godot/godot"))


class Suite:
    def __init__(self, name):
        self.name = name
        self.checks = []
        self.ok = True

    def check(self, name, cond, detail=""):
        self.checks.append({"name": name, "pass": bool(cond),
                            "detail": str(detail)[:300]})
        if not cond:
            self.ok = False

    def report(self):
        os.makedirs(REP, exist_ok=True)
        n = sum(1 for c in self.checks if c["pass"])
        doc = {"suite": self.name, "passed": self.ok,
               "checks": "%d/%d" % (n, len(self.checks)),
               "results": self.checks}
        with open(os.path.join(REP, self.name + ".json"), "w") as f:
            json.dump(doc, f, indent=1)
        print("%-12s %s (%d/%d)" % (self.name, "PASS" if self.ok else "FAIL",
                                    n, len(self.checks)))
        for c in self.checks:
            if not c["pass"]:
                print("  FAIL %s :: %s" % (c["name"], c["detail"]))
        return self.ok


def load_all():
    D = {}
    for fn in ("traffic_graph.json", "roads.json", "road_geometry.json",
               "transport_structures.json", "districts.json",
               "world_stream_manifest.json"):
        with open(os.path.join(DD, fn)) as f:
            D[fn] = json.load(f)
    for fn in ("traffic_contract.json", "traffic_contract.schema.json",
               "sector_contract.json"):
        with open(os.path.join(DW, fn)) as f:
            D[fn] = json.load(f)
    return D


def qmm(v):
    return int(math.floor(abs(v * 1000.0) + 0.5)) * (1 if v >= 0 else -1)


def fnv_hex(text):
    h = 14695981039346656037
    for x in text.encode():
        h = ((h ^ x) * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return "%016x" % h


def lane_digest(lanes):
    rows = []
    for lid in sorted(lanes.keys()):
        l = lanes[lid]
        pts = l["pts"]
        a, b = pts[0], pts[-1]
        rows.append("%s|%d|%d|%d|%d|%d|%d|%d|%d|%d;" % (
            lid, len(pts), qmm(a[0]), qmm(a[1]), qmm(a[2]), qmm(b[0]),
            qmm(b[1]), qmm(b[2]), qmm(l["length_m"]), qmm(l["speed_min_kph"])))
    rows.sort()
    return fnv_hex("".join(rows))


def move_digest(moves):
    rows = sorted("%s|%s|%s|%s|%s;" % (mid, m["from_lane"], m["to_lane"],
                                       m["type"], m["control"])
                  for mid, m in moves.items())
    return fnv_hex("".join(rows))


# ================= STATIC =================
def suite_static():
    s = Suite("static")
    D = load_all()
    g, tc = D["traffic_graph.json"], D["traffic_contract.json"]
    # schema
    try:
        import jsonschema
        jsonschema.validate(tc, D["traffic_contract.schema.json"])
        s.check("schema-valid", True)
    except Exception as e:
        s.check("schema-valid", False, repr(e)[:200])
    # source pins
    pins = tc["source_pins"]
    s.check("pin-roads", pins["road_checksum"] == D["roads.json"]["checksum"])
    s.check("pin-geom",
            pins["geometry_checksum_geometry"] == D["road_geometry.json"]["checksum"]["geometry"])
    s.check("pin-struct",
            pins["structure_checksum"] == D["transport_structures.json"]["checksum"])
    s.check("pin-manifest",
            pins["stream_manifest_checksum"] == D["world_stream_manifest.json"]["checksum"])
    s.check("pin-districts",
            pins["districts_checksum"] == D["districts.json"]["checksum"])
    import hashlib
    h = json.load(open(os.path.join(DD, "road_traffic_handoff.json")))
    dh = hashlib.sha256(json.dumps(h, sort_keys=True,
                                   separators=(",", ":")).encode()).hexdigest()[:16]
    s.check("pin-handoff", pins["traffic_handoff_sha256_16"] == dh, dh)
    # checksum determinism: recompute == stored
    sys.path.insert(0, os.path.join(ROOT, "tools"))
    import traffic_graph as TG
    lanes, moves = g["lanes"], g["movements"]
    ck = {
        "traffic_graph_checksum": TG.sha16({"lanes": lanes, "movements": moves,
                                            "junctions": g["junctions"],
                                            "signals": g["signals"],
                                            "speed_zones": g["speed_zones"],
                                            "sector_handoffs": g["sector_handoffs"]}),
        "traffic_spawn_checksum": TG.sha16({"spawn_zones": g["spawn_zones"],
                                            "density_zones": g["density_zones"],
                                            "spawn_policy": tc["spawn_policy"]["policy_version"],
                                            "density_policy": tc["density_policy"]["policy_version"],
                                            "seed_policy": tc["seed_policy"]["policy_version"]}),
        "traffic_policy_checksum": TG.sha16({k: tc[k]["policy_version"]
                                             for k in TG.POLICY_KEYS}),
        "traffic_sector_checksum": TG.sha16({"handoffs": g["sector_handoffs"],
                                             "manifest": pins["stream_manifest_checksum"]}),
    }
    for k, v in ck.items():
        s.check("checksum-" + k, g["checksums"][k] == v, v)
    vp = {"classes": tc["vehicle_classes"],
          "following": tc["following_policy"]["policy_version"],
          "lane_change": tc["lane_change_policy"]["policy_version"],
          "merge": tc["merge_policy"]["policy_version"],
          "collision": tc["collision_policy"]["policy_version"],
          "simulation": tc["simulation_policy"]["policy_version"]}
    s.check("checksum-vehicle", g["checksums"]["vehicle_policy_checksum"] == TG.sha16(vp))
    # counts pinned
    st = g["stats"]
    s.check("count-lanes", len(lanes) == 77, len(lanes))
    s.check("count-moves", len(moves) == 223, len(moves))
    s.check("count-junctions", len(g["junctions"]) == 22)
    s.check("count-signals", len(g["signals"]) == 10)
    s.check("count-spawn", len(g["spawn_zones"]) == 49)
    # lane integrity
    grid = SectorGrid(256, -2048.0)
    nodes = D["roads.json"]["nodes"]
    bad_sp = bad_sec = bad_adj = 0
    for lid, l in lanes.items():
        pts = l["pts"]
        for i in range(len(pts) - 1):
            a, b = pts[i], pts[i + 1]
            d = math.dist((a[0], a[1], a[2]), (b[0], b[1], b[2]))
            if not 0.05 <= d <= 3.5:
                bad_sp += 1
                break
        for pi in (0, len(pts) // 2, len(pts) - 1):
            p = pts[pi]
            sid = "SX%02dZ%02d" % grid.sector_of(p[0], p[2])
            if sid not in l["sectors"]:
                bad_sec += 1
                break
        for side, other in l.get("adjacent", {}).items():
            back = lanes[other].get("adjacent", {})
            if ("inner" if side == "outer" else "outer") not in back or \
                    back["inner" if side == "outer" else "outer"] != lid:
                bad_adj += 1
        if l["entry_node"] not in nodes or l["exit_node"] not in nodes:
            bad_sec += 1000
    s.check("lane-spacing", bad_sp == 0, bad_sp)
    s.check("lane-sectors", bad_sec == 0, bad_sec)
    s.check("lane-adjacency", bad_adj == 0, bad_adj)
    s.check("lane-speed", all(l["speed_min_kph"] <= l["speed_legal_kph"] + 0.01
                               for l in lanes.values()))
    # movement legality
    ctrls = {"SIGNAL", "YIELD", "MERGE", "UNCONTROLLED",
             "UNCONTROLLED_THROUGH"}
    bad_mv = [mid for mid, m in moves.items()
              if m["from_lane"] not in lanes or m["to_lane"] not in lanes
              or m["control"] not in ctrls
              or (m["connector_ref"] is not None
                  and not isinstance(m["connector_ref"], str))
              or (m["junction"] is not None
                  and m["junction"] not in g["junctions"])]
    s.check("move-refs", not bad_mv, bad_mv[:2])
    outdeg = {}
    for m in moves.values():
        if m["allowed"]:
            outdeg.setdefault(m["from_lane"], 0)
            outdeg[m["from_lane"]] += 1
    s.check("move-outdeg", all(outdeg.get(l, 0) > 0 for l in lanes),
            [l for l in lanes if not outdeg.get(l)])
    # full reachability over movements + lane-change edges
    out = {}
    for m in moves.values():
        if m["allowed"]:
            out.setdefault(m["from_lane"], []).append(m["to_lane"])
    lc = {lid: list(l.get("adjacent", {}).values()) for lid, l in lanes.items()}
    bad_reach = []
    for start in lanes:
        seen, stack = {start}, [start]
        while stack:
            u = stack.pop()
            for v in out.get(u, []) + lc.get(u, []):
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        if len(seen) != len(lanes):
            bad_reach.append((start, len(seen)))
    s.check("reachability", not bad_reach, bad_reach[:2])
    # zones
    bad_sz = [z for z, d in g["spawn_zones"].items()
              if not d["lanes"] or any(l not in lanes for l in d["lanes"])
              or d["capacity"] <= 0]
    s.check("spawn-zones", not bad_sz, bad_sz[:2])
    s.check("speed-zones", len(g["speed_zones"]) == len(lanes))
    s.check("density-zones", len(g["density_zones"]) == 13,
            len(g["density_zones"]))
    # signals
    bad_sig = []
    for sid, sg in g["signals"].items():
        cyc = sum(p["green_ticks"] + p["yellow_ticks"] for p in sg["phases"])
        if cyc != sg["cycle_ticks"]:
            bad_sig.append(sid)
    covered, want = [], []
    for mid, m in moves.items():
        if m["control"] == "SIGNAL":
            want.append(mid)
    for sg in g["signals"].values():
        for p in sg["phases"]:
            covered += p["movements"]
    s.check("signal-cycle", not bad_sig, bad_sig[:2])
    s.check("signal-cover", sorted(covered) == sorted(want),
            "%d/%d" % (len(covered), len(want)))
    # runway exclusion
    rr = D["roads.json"]["runway_rect"]
    bad_rw = [lid for lid, l in lanes.items()
              if any(rr[0] <= p[0] <= rr[2] and rr[1] <= p[2] <= rr[3]
                     for p in l["pts"])]
    s.check("runway-exclusion", not bad_rw, bad_rw[:2])
    # roundabout island exclusion
    hub = nodes["hub_city"]
    bad_isl = []
    for mid, m in moves.items():
        if m["type"] == "ROUNDABOUT" and m.get("turn_pts"):
            if any(math.hypot(p[0] - hub["x"], p[2] - hub["z"]) < 10.0
                   for p in m["turn_pts"]):
                bad_isl.append(mid)
    s.check("roundabout-island", not bad_isl, bad_isl[:2])
    # clearance: every lane admits >=1 spawnable class
    bad_cl = []
    for lid, l in lanes.items():
        okc = [n for n, p in tc["vehicle_classes"].items()
               if p["spawn_weight"] > 0
               and p["width_m"] + 0.6 <= l["width_m"] + 2.0]
        if not okc:
            bad_cl.append(lid)
    s.check("clearance", not bad_cl, bad_cl[:2])
    # no non-finite floats in derived doc
    raw = json.dumps(g)
    s.check("finite", "Infinity" not in raw and "NaN" not in raw)
    # derived trailhead movements flagged
    der = [m for m in moves.values() if m.get("derived")]
    s.check("derived-trailhead", len(der) == 8
            and all(m["junction"] == "th_highland" for m in der), len(der))
    s.check("junction-trailhead",
            g["junctions"]["th_highland"]["control"] == "TRAILHEAD")
    return s


# ================= CROSS =================
def suite_cross():
    s = Suite("cross")
    D = load_all()
    g = D["traffic_graph.json"]
    mpath = os.path.join(ROOT, "reports/logs/p08_cross_metrics.json")
    r = subprocess.run(
        [GODOT, "--headless", "--path", ROOT, "--script",
         "res://tests/godot/tools/traffic_check.gd", "--",
         "--verify", os.path.join(DD, "traffic_graph.json"),
         "--contract", os.path.join(DW, "traffic_contract.json"),
         "--roads", os.path.join(DD, "roads.json"),
         "--metrics", mpath],
        capture_output=True, text=True, timeout=240)
    out = (r.stdout or "") + (r.stderr or "")
    s.check("engine-ok", "TRAFFIC_OK" in out, out.strip().splitlines()[-1][:200]
            if out.strip() else "no output")
    try:
        m = json.load(open(mpath))
    except Exception as e:
        s.check("engine-metrics", False, repr(e)[:150])
        return s
    s.check("x-lanes", m["lanes"] == len(g["lanes"]))
    s.check("x-moves", m["movements"] == len(g["movements"]))
    s.check("x-signals", m["signals"] == len(g["signals"]))
    s.check("x-checksum",
            m["graph_checksum"] == g["checksums"]["traffic_graph_checksum"])
    s.check("parity-lanes", lane_digest(g["lanes"]) == m["digest_lanes"],
            m["digest_lanes"])
    s.check("parity-moves", move_digest(g["movements"]) == m["digest_moves"],
            m["digest_moves"])
    return s


# ================= INJECT =================
import contextlib


@contextlib.contextmanager
def _mutate(path, fn):
    raw = open(path).read()
    try:
        doc = json.loads(raw)
        fn(doc)
        json.dump(doc, open(path, "w"), indent=1)
        yield
    finally:
        open(path, "w").write(raw)


def _run_static():
    return subprocess.run([sys.executable, "tools/validate_traffic.py",
                           "static"], capture_output=True, text=True,
                          cwd=ROOT, timeout=300)


def suite_inject():
    s = Suite("inject")
    gp = os.path.join(DD, "traffic_graph.json")

    def drop_lane(d):
        d["lanes"].pop("E_ring_hw_01:+1:0")

    def break_move(d):
        m = d["movements"][sorted(d["movements"])[0]]
        m["to_lane"] = "NOPE:+1:0"

    def stale_ck(d):
        d["checksums"]["traffic_graph_checksum"] = "0" * 16

    def bad_spawn(d):
        z = d["spawn_zones"][sorted(d["spawn_zones"])[0]]
        z["lanes"] = ["NOPE:+1:0"]

    def bad_signal(d):
        sg = d["signals"][sorted(d["signals"])[0]]
        sg["phases"][0]["movements"] = ["NOPE-MOVE"]

    for name, fn in (("missing-lane", drop_lane), ("bad-move", break_move),
                     ("stale-checksum", stale_ck), ("bad-spawn", bad_spawn),
                     ("bad-signal", bad_signal)):
        with _mutate(gp, fn):
            r = _run_static()
        s.check("inject-" + name, r.returncode != 0,
                "rc=%d" % r.returncode)
    # restore check: static green again + bytes identical
    r = _run_static()
    s.check("inject-restore", r.returncode == 0)
    # runtime-level injections (no files touched)
    w = TrafficWorld(seed_tag="inject")
    v = w.try_spawn("SZ:E_rd_urban_south_00:+1", "sedan")
    s.check("inject-spawned", v is not None)
    if v:
        ok, d = transition(v, "DESPAWNED", "inject-illegal")
        s.check("inject-illegal-transition", not ok and v["state"] == "FAILED",
                d[:150])
        w.retire(v, "inject-cleanup")
        s.check("inject-retire-clears", v["pins"] == [] and v["queue"] is None)
    # pool reset failure detection
    w2 = TrafficWorld(seed_tag="inject2")
    spec = w2.specs["sedan"]
    a = w2.pool.acquire(spec)
    a["route"] = {"fake": True}
    w2.pool.release(a)
    b = w2.pool.acquire(spec)
    s.check("inject-pool-reset", b["route"] is None and b["state"] == "SPAWNED")
    # stale route cache on congestion change
    r0 = w2.router.plan("E_rd_urban_south_00:+1:0",
                        "E_rd_urban_south_00:-1:0", spec, seed_tag="k")
    w2.router.set_congestion({"E_rd_urban_south_00:+1:0": 0.9}, 50)
    r1 = w2.router.plan("E_rd_urban_south_00:+1:0",
                        "E_rd_urban_south_00:-1:0", spec, seed_tag="k")
    s.check("inject-cache-version", r0 is not r1)
    return s




# ================= test driving helpers =================
def place_vehicle(w, cls, lane, s=8.0):
    spec = w.specs[cls]
    v = w.pool.acquire(spec)
    v["born"] = w.tick_n
    v["lane"] = lane
    v["s"] = s
    v["pos"] = w.pos_at(lane, s)
    v["heading"] = w.lane_heading(lane, s)
    sx, sz = w.grid.sector_of(v["pos"][0], v["pos"][2])
    v["sector"] = "SX%02dZ%02d" % (sx, sz)
    w.vehicles[v["id"]] = v
    w._index_add(v)
    transition(v, "INITIALIZING", "test-place")
    return v


def force_route(w, v, dest):
    res = w.router.plan(v["lane"], dest, v["spec"], seed_tag="test")
    assert res["lanes"], res["reason"]
    v["route"] = {"lanes": res["lanes"], "moves": res["moves"], "i": 0,
                  "dest": dest}
    v["route_done"] = False
    transition(v, "ROUTING", "test-route")
    return res


def drive(w, v, maxticks=3000, follow=True):
    for _ in range(maxticks):
        if follow and w.tick_n % 10 == 0 and v["id"] in w.vehicles:
            w.focus = [v["pos"][0], v["pos"][2]]
        w.tick()
        if v["id"] not in w.vehicles:
            return "retired"
        if v.get("route_done") and v["state"] in ("STOPPING", "STOPPED"):
            return "complete"
    return "timeout"


# ================= REPRODUCE =================
def run_scenario(seed_tag, ticks, focus=(1400.0, 150.0)):
    w = TrafficWorld(seed_tag=seed_tag, focus=focus)
    for _ in range(ticks):
        w.tick()
    ev = [(e["tick"], e["type"], e["vehicle"]) for e in w.events]
    vh = sorted((v["lane"], round(v["s"], 2), round(v["speed"], 2),
                 v["state"]) for v in w.vehicles.values())
    return ev, vh, w.stats()


def suite_reproduce():
    s = Suite("reproduce")
    import hashlib
    subprocess.run([sys.executable, "tools/traffic_graph.py"], cwd=ROOT,
                   capture_output=True, timeout=300)
    b1 = open(os.path.join(DD, "traffic_graph.json"), "rb").read()
    subprocess.run([sys.executable, "tools/traffic_graph.py"], cwd=ROOT,
                   capture_output=True, timeout=300)
    b2 = open(os.path.join(DD, "traffic_graph.json"), "rb").read()
    s.check("regen-identical", b1 == b2, "%d bytes" % len(b1))
    ev1, vh1, st1 = run_scenario("repro1", 600)
    ev2, vh2, st2 = run_scenario("repro1", 600)
    s.check("replay-events", ev1 == ev2, "%d events" % len(ev1))
    s.check("replay-vehicles", vh1 == vh2, "%d live" % len(vh1))
    s.check("replay-stats", st1["spawn"] == st2["spawn"] and
            st1["route_failures"] == st2["route_failures"])
    # chunking independence: 600x1 vs 6x100 with stats calls between
    w = TrafficWorld(seed_tag="repro1", focus=(1400.0, 150.0))
    for _ in range(6):
        for _ in range(100):
            w.tick()
        w.stats()
    ev3 = [(e["tick"], e["type"], e["vehicle"]) for e in w.events]
    s.check("chunking", ev3 == ev1)
    # different seed still valid (no crash, no leaks)
    w4 = TrafficWorld(seed_tag="repro-other", focus=(1400.0, 150.0))
    for _ in range(600):
        w4.tick()
    s.check("seed-valid", w4.check_leaks() == []
            and all(v["state"] != "FAILED" for v in w4.vehicles.values()),
            "%d live" % len(w4.vehicles))
    return s




# ================= SMOKE =================
SMOKE_RUNS = [
    ("city", "sedan", "E_rd_urban_south_00:+1:0", "E_art_port_00:+1:0"),
    ("roundabout", "compact", "E_radial_south_00:+1:0",
     "E_radial_west_00:-1:0"),
    ("bridge-river", "suv", "E_radial_west_01:+1:0",
     "E_radial_west_02:+1:0"),
    ("bridge-ring", "truck", "E_ring_hw_02:+1:0", "E_ring_hw_03:+1:0"),
    ("tunnel", "van", "E_ring_hw_north_tunnel_00:+1:0",
     "E_ring_hw_04:+1:0"),
    ("trail", "motorcycle", "E_tr_highland_00:+0:0",
     "E_radial_north_01:+1:0"),
    ("port", "truck", "E_art_port_01:+1:0", "E_art_port_00:-1:0"),
    ("resort", "sedan", "E_rd_resort_00:+1:0", "E_ring_hw_02:-1:0"),
    ("forest", "van", "E_rd_forest_svc_00:+1:0", "E_rd_village_00:+1:0"),
    ("airfield", "bus", "E_rd_airfield_00:+1:0",
     "E_radial_south_01:+1:0"),
    ("coast", "compact", "E_rd_urban_coll_00:+1:0",
     "E_rd_urban_south_00:+1:0"),
]


def suite_smoke():
    s = Suite("smoke")
    for name, cls, start, dest in SMOKE_RUNS:
        w = TrafficWorld(seed_tag="smoke-" + name, focus=(1400.0, 150.0))
        try:
            v = place_vehicle(w, cls, start)
            res = force_route(w, v, dest)
        except Exception as e:
            s.check("smoke-" + name, False, "setup: %r" % e)
            continue
        outcome = drive(w, v, maxticks=5000)
        ok = outcome in ("complete", "retired")
        bad = [x for x in w.vehicles.values() if x["state"] == "FAILED"]
        ww = [x for x in w.vehicles.values()
              if x["flags"].get("wrong_way")]
        leaks = w.check_leaks()
        pc, pr = {}, {}
        for e in w.events:
            if e["type"] == "pin_create":
                pc[e["vehicle"]] = pc.get(e["vehicle"], 0) + 1
            elif e["type"] == "pin_release":
                pr[e["vehicle"]] = pr.get(e["vehicle"], 0) + 1
        retired = set(e["vehicle"] for e in w.events
                      if e["type"] == "despawn")
        unbal = [vid for vid in retired
                 if pc.get(vid, 0) != pr.get(vid, 0)]
        livepins = sum(len(x["pins"]) for x in w.vehicles.values())
        held = (sum(pc.values()) - sum(pr.values())) - livepins
        detail = "%s lanes=%d failed=%d ww=%d leaks=%d unbal=%d held=%d" % (
            outcome, len(res["lanes"]), len(bad), len(ww), len(leaks),
            len(unbal), held)
        s.check("smoke-" + name,
                ok and not bad and not ww and not leaks
                and not unbal and held == 0, detail)
    return s




# ================= PERF =================
def suite_perf():
    s = Suite("perf")
    import statistics
    try:
        import resource

        def mem_kb():
            return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    except Exception:
        def mem_kb():
            return 0
    D = load_all()
    g = D["traffic_graph.json"]
    lanes = sorted(g["lanes"].keys())
    dl = sorted(g["lanes"].keys())
    levels = [10, 25, 50, 100, 200, 500, 1000]
    commit = subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                            capture_output=True, text=True,
                            cwd=ROOT).stdout.strip()
    for n in levels:
        w = TrafficWorld(seed_tag="perf-%d" % n, focus=(1400.0, 150.0))
        w.auto_spawn = False
        L = g["lanes"]
        for k in range(n):
            lid = lanes[k % len(lanes)]
            span = max(20.0, L[lid]["length_m"] - 40.0)
            sv = 8.0 + ((k * 37.0) % span)
            cls = ["sedan", "compact", "suv", "van", "truck", "bus",
                   "motorcycle"][k % 7]
            try:
                v = place_vehicle(w, cls, lid, s=sv)
            except Exception:
                continue
            dest = dl[(k * 13 + 5) % len(dl)]
            if dest == lid:
                dest = dl[(k * 13 + 6) % len(dl)]
            res = w.router.plan(lid, dest, v["spec"], seed_tag="perf")
            if res["lanes"]:
                v["route"] = {"lanes": res["lanes"], "moves": res["moves"],
                              "i": 0, "dest": dest}
                transition(v, "ROUTING", "perf")
            else:
                w.retire(v, "perf-noroute")
        m0 = mem_kb()
        tts = []
        wts = []
        for _ in range(300):
            # GATED metric is CPU time (robust to host contention on
            # shared infra); wall is recorded alongside for diagnosis.
            t0 = time.process_time()
            w0 = time.perf_counter()
            w.tick()
            tts.append((time.process_time() - t0) * 1000.0)
            wts.append((time.perf_counter() - w0) * 1000.0)
        m1 = mem_kb()
        tts.sort()
        wts.sort()
        p95 = tts[int(len(tts) * 0.95)]
        mx = tts[-1]
        mean = statistics.mean(tts)
        wp95 = wts[int(len(wts) * 0.95)]
        nv = max(1, len(w.vehicles))
        bad = sum(1 for v in w.vehicles.values() if v["state"] == "FAILED")
        leaks = w.check_leaks()
        st = w.stats()
        detail = ("n=%d ticks=300 CPU mean=%.3f p95=%.3f max=%.3f "
                  "wall-p95=%.3f ms/tick "
                  "per-veh-p95=%.4f mem-delta=%dk failed=%d leaks=%d "
                  "routes=%d/%d" % (
                      n, mean, p95, mx, wp95, p95 / nv, m1 - m0, bad,
                      len(leaks), st["router"]["queries"],
                      st["router"]["hits"]))
        s.check("perf-n%d" % n, not bad and not leaks, detail)
        tc = D["traffic_contract.json"]["budgets"]
        bok = p95 / nv <= tc["per_vehicle_p95_ms"]
        if n == 100:
            bok = bok and p95 <= tc["tick_p95_ms_100"]
        if n == 1000:
            bok = bok and p95 <= tc["tick_p95_ms_1000"]
        s.check("perf-n%d-budget" % n, bok, detail)
    # environment record
    er = subprocess.run([GODOT, "--version"], capture_output=True, text=True,
                        timeout=60)
    try:
        load = "load=%.2f" % os.getloadavg()[0]
    except Exception:
        load = "load=?"
    s.check("perf-env", True, "%s | %s | %s | commit=%s graph=%s" % (
        (er.stdout or "").strip(), sys.platform, load, commit,
        g["checksums"]["traffic_graph_checksum"]))
    return s


# ================= REGRESS (goldens) =================
GOLDENS_PATH = os.path.join(ROOT, "reports/p08_goldens.json")
GOLDEN_SCEN = [
    ("city", "SZ:E_rd_urban_south_00:+1", 600, False),
    ("port", "SZ:E_art_port_01:+1", 600, False),
    ("highland", "SZ:E_tr_highland_00:+0", 600, False),
    ("resort", "SZ:E_rd_resort_00:+1", 600, False),
    ("coast", "SZ:E_ring_hw_02:+1", 600, False),
    ("roundabout", None, 600, False),
    ("bridge", "SZ:E_radial_west_01:+1", 600, False),
    ("tunnel", "SZ:E_ring_hw_north_tunnel_00:+1", 600, False),
    ("low-density", "SZ:E_rd_forest_svc_00:+1", 300, False),
    ("dense", None, 900, False),
    ("player-traffic", "SZ:E_rd_urban_south_00:+1", 600, True),
]


def run_golden(name, zone, ticks, player):
    w = TrafficWorld(seed_tag="golden-" + name)
    if zone:
        p = w.spawn_zones[zone]["pos"]
        w.focus = [p[0], p[2]]
    else:
        w.focus = [1400.0, 150.0]
    lane = w.spawn_zones[zone]["lanes"][0] if zone else "E_radial_south_00:+1:0"
    pts = w.lanes[lane]["pts"]
    for t in range(ticks):
        if player and t % 20 == 0:
            i = min(len(pts) - 1, (t // 20) * 3)
            w.set_player(pts[i][0], pts[i][2], lane=lane, s=i * 2.0,
                         speed=8.0)
        w.tick()
    import collections
    evc = collections.Counter(e["type"] for e in w.events)
    vhc = collections.Counter(
        (v["lane"], round(v["s"]), v["state"], v["tier"])
        for v in w.vehicles.values())
    st = w.stats()
    return {"events": dict(sorted(evc.items())),
            "vehicles": {"/".join(map(str, k)): v
                         for k, v in sorted(vhc.items())},
            "spawn_accepted": st["spawn"]["accepted"],
            "despawn_retired": st["despawn"]["retired"],
            "route_failures": st["route_failures"],
            "router": st["router"], "leaks": w.check_leaks()}


def suite_regress(write=False):
    s = Suite("regress")
    D = load_all()
    g = D["traffic_graph.json"]
    if write:
        doc = {"meta": {
            "graph": g["checksums"]["traffic_graph_checksum"],
            "spawn": g["checksums"]["traffic_spawn_checksum"],
            "vehicle": g["checksums"]["vehicle_policy_checksum"],
            "policy": g["checksums"]["traffic_policy_checksum"],
            "sources": D["traffic_contract.json"]["source_pins"]},
            "scenarios": {}}
        for name, zone, ticks, player in GOLDEN_SCEN:
            doc["scenarios"][name] = run_golden(name, zone, ticks, player)
            doc["scenarios"][name]["seed"] = "golden-" + name
            doc["scenarios"][name]["ticks"] = ticks
        json.dump(doc, open(GOLDENS_PATH, "w"), indent=1, sort_keys=True)
        s.check("goldens-written", True, GOLDENS_PATH)
        return s
    if not os.path.exists(GOLDENS_PATH):
        s.check("goldens-present", False, "run regress --write first")
        return s
    gold = json.load(open(GOLDENS_PATH))
    s.check("golden-graph",
            gold["meta"]["graph"] == g["checksums"]["traffic_graph_checksum"])
    s.check("golden-policy",
            gold["meta"]["policy"] == g["checksums"]["traffic_policy_checksum"])
    for name, zone, ticks, player in GOLDEN_SCEN:
        got = run_golden(name, zone, ticks, player)
        exp = {k: v for k, v in gold["scenarios"][name].items()
               if k not in ("seed", "ticks")}
        same = got == exp
        det = "" if same else "events %d/%d veh %d/%d" % (
            sum(got["events"].values()), sum(exp["events"].values()),
            len(got["vehicles"]), len(exp["vehicles"]))
        s.check("golden-" + name, same, det)
    return s


# ================= STRESS =================
def _pin_balance(w):
    pc, pr = {}, {}
    for e in w.events:
        if e["type"] == "pin_create":
            pc[e["vehicle"]] = pc.get(e["vehicle"], 0) + 1
        elif e["type"] == "pin_release":
            pr[e["vehicle"]] = pr.get(e["vehicle"], 0) + 1
    retired = set(e["vehicle"] for e in w.events if e["type"] == "despawn")
    unbal = [v for v in retired if pc.get(v, 0) != pr.get(v, 0)]
    livepins = sum(len(x["pins"]) for x in w.vehicles.values())
    held = (sum(pc.values()) - sum(pr.values())) - livepins
    return unbal, held


def suite_stress():
    s = Suite("stress")
    # dense city soak
    w = TrafficWorld(seed_tag="stress-dense", focus=(1400.0, 150.0))
    maxq = 0
    for t in range(1500):
        w.tick()
        if t % 50 == 0:
            maxq = max(maxq, max([len(q) for q in w.queues.values()] + [0]))
    bad = sum(1 for v in w.vehicles.values() if v["state"] == "FAILED")
    recf = sum(1 for e in w.events if e["type"] == "recovery_failed")
    exh = w.despawn_stats["reasons"].get("failed-exhausted", 0)
    s.check("stress-dense", bad == 0 and recf == 0 and exh == 0
            and not w.check_leaks() and maxq < 12,
            "veh=%d maxq=%d recf=%d exh=%d" % (len(w.vehicles), maxq,
                                               recf, exh))
    # signal queue flush: 6 stacked vehicles must all pass
    w2 = TrafficWorld(seed_tag="stress-queue", focus=(1400.0, 150.0))
    w2.auto_spawn = False
    lane = "E_rd_urban_south_00:+1:0"
    dest = "E_art_port_00:+1:0"
    for k in range(6):
        v = place_vehicle(w2, "sedan", lane, s=8.0 + k * 20.0)
        force_route(w2, v, dest)
    for t in range(2500):
        if w2.tick_n % 10 == 0:
            liv = [x for x in w2.vehicles.values()]
            if liv:
                w2.focus = [liv[0]["pos"][0], liv[0]["pos"][2]]
        w2.tick()
    exits = sum(1 for e in w2.events if e["type"] == "junction_exit")
    s.check("stress-queue-flush", exits >= 6, "exits=%d" % exits)
    # rapid focus jumps
    w3 = TrafficWorld(seed_tag="stress-jump", focus=(1400.0, 150.0))
    pts = [(1400.0, 150.0), (-900.0, -300.0), (1690.0, 690.0),
           (-1120.0, 1560.0), (830.0, -1280.0), (730.0, 1100.0)]
    for t in range(1200):
        if t % 100 == 0:
            w3.focus = list(pts[(t // 100) % len(pts)])
        w3.tick()
    b3 = sum(1 for v in w3.vehicles.values() if v["state"] == "FAILED")
    tc3 = sum(1 for e in w3.events if e["type"] == "tier_change")
    s.check("stress-jump", b3 == 0 and not w3.check_leaks() and tc3 > 50,
            "failed=%d tier_changes=%d" % (b3, tc3))
    # bridge/tunnel shuttle
    w4 = TrafficWorld(seed_tag="stress-struct", focus=(1400.0, 150.0))
    bp = w4.spawn_zones["SZ:E_radial_west_01:+1"]["pos"]
    tp = w4.spawn_zones["SZ:E_ring_hw_north_tunnel_00:+1"]["pos"]
    for t in range(1200):
        if (t // 150) % 2 == 0:
            w4.focus = [bp[0], bp[2]]
        else:
            w4.focus = [tp[0], tp[2]]
        w4.tick()
    unbal, held = _pin_balance(w4)
    b4 = sum(1 for v in w4.vehicles.values() if v["state"] == "FAILED")
    s.check("stress-struct-pins", not unbal and held == 0 and b4 == 0
            and not w4.check_leaks(),
            "unbal=%d held=%d failed=%d" % (len(unbal), held, b4))
    return s


# ================= ROUTE =================
ROUTE_PAIRS = [
    ("city", "E_rd_urban_south_00:+1:0", "E_art_port_00:+1:0"),
    ("rural", "E_rd_suburban_00:+1:0", "E_rd_village_00:+1:0"),
    ("forest", "E_rd_forest_svc_00:+1:0", "E_radial_west_02:+1:0"),
    ("highland", "E_tr_highland_00:+0:0", "E_ring_hw_00:+1:0"),
    ("port", "E_art_port_01:+1:0", "E_rd_airfield_00:+1:0"),
    ("resort", "E_rd_resort_00:+1:0", "E_rd_urban_coll_00:+1:0"),
    ("coast", "E_ring_hw_02:+1:0", "E_ring_hw_04:+1:0"),
    ("bridge", "E_radial_west_00:+1:0", "E_radial_west_02:-1:0"),
    ("tunnel", "E_ring_hw_north_tunnel_00:-1:0", "E_ring_hw_03:+1:0"),
    ("roundabout", "E_radial_south_02:+1:0", "E_radial_north_00:-1:0"),
    ("terminal", "E_rd_airfield_00:+1:0", "E_rd_airfield_00:-1:0"),
    ("cross-island", "E_rd_resort_00:-1:0", "E_art_port_01:+1:0"),
]


def suite_route():
    s = Suite("route")
    w = TrafficWorld(seed_tag="route")
    spec = w.specs["sedan"]
    moves = w.movements
    for name, a, b in ROUTE_PAIRS:
        r1 = w.router.plan(a, b, spec, seed_tag="m")
        r2 = w.router.plan(a, b, spec, seed_tag="m")
        r3 = w.router.plan(a, b, spec, seed_tag="m", alt=1)
        legal = True
        if r1["lanes"]:
            for u, v in zip(r1["lanes"], r1["lanes"][1:]):
                conn = any(moves[mid]["from_lane"] == u
                           and moves[mid]["to_lane"] == v
                           for mid in w.router.out.get(u, []))
                lc = v in w.router.lc.get(u, [])
                if not (conn or lc):
                    legal = False
            if any(w.lanes[l]["access"] == "RESTRICTED"
                   for l in r1["lanes"]):
                legal = False
        det = "n=%d cost=%.0f" % (len(r1["lanes"]), r1["cost"]) if r1["lanes"] else r1["reason"]
        s.check("route-" + name, bool(r1["lanes"]) and legal
                and r1 == r2 and bool(r3["lanes"]), det)
    # clean failures + special cases
    r = w.router.plan("NOPE:+1:0", "E_art_port_00:+1:0", spec, seed_tag="m")
    s.check("route-unknown", r["reason"].startswith("ROUTE_FAILED"))
    r = w.router.plan("E_art_port_00:+1:0",
                      "E_spur_restricted_access_00:+1:0", spec, seed_tag="m")
    s.check("route-restricted", r["reason"] == "ROUTE_FAILED:restricted-destination")
    e = w.specs["emergency_hook"]
    r = w.router.plan("E_ring_hw_00:+1:0",
                      "E_spur_restricted_access_00:+1:0", e, seed_tag="m")
    s.check("route-emergency", bool(r["lanes"]), "n=%d" % len(r["lanes"]))
    r = w.router.plan("E_art_port_00:+1:0", "E_art_port_00:+1:0", spec,
                      seed_tag="m")
    s.check("route-same", r["reason"] == "already-there")
    return s


# ================= JUNCTION =================
def drive_until(w, v, want="junction_exit", maxticks=1500):
    n0 = sum(1 for e in w.events if e["type"] == want
             and e["vehicle"] == v["id"])
    for _ in range(maxticks):
        if w.tick_n % 10 == 0 and v["id"] in w.vehicles:
            w.focus = [v["pos"][0], v["pos"][2]]
        w.tick()
        if v["id"] not in w.vehicles:
            return "retired"
        n1 = sum(1 for e in w.events if e["type"] == want
                 and e["vehicle"] == v["id"])
        if n1 > n0:
            return "passed"
    return "timeout"


def run_movement(mid, extra=None, maxticks=1500, tag="j"):
    import hashlib as _hl
    stag = "%s-%s" % (tag, _hl.md5(mid.encode()).hexdigest()[:8])
    w = TrafficWorld(seed_tag=stag)
    w.auto_spawn = False
    m = w.movements[mid]
    lane = m["from_lane"]
    L = w.lanes[lane]["length_m"]
    cls = ("emergency_hook"
           if w.lanes[m["to_lane"]]["access"] == "RESTRICTED" else "sedan")
    v = place_vehicle(w, cls, lane, s=max(8.0, L - 80.0))
    force_route(w, v, m["to_lane"])
    others = []
    for (olane, odest) in (extra or []):
        oL = w.lanes[olane]["length_m"]
        o = place_vehicle(w, "compact", olane, s=max(8.0, oL - 80.0))
        force_route(w, o, odest)
        others.append(o)
    out = drive_until(w, v, maxticks=maxticks)
    return out, w, v, others


def suite_junction():
    s = Suite("junction")
    _d = load_all()
    g = _d["traffic_graph.json"]
    roads = _d["roads.json"]
    moves = g["movements"]
    # 1) every movement, empty conditions
    fails = []
    selfloops = 0
    for mid in sorted(moves.keys()):
        if moves[mid]["from_lane"] == moves[mid]["to_lane"]:
            selfloops += 1  # structure-continuity marker; see end-to-end
            continue
        out, w, v, _ = run_movement(mid)
        entry = [e for e in w.events if e["type"] == "junction_entry"
                 and e["vehicle"] == v["id"]]
        took = entry[0]["data"].get("move") == mid if entry else False
        bad = v["state"] == "FAILED" if v["id"] in w.vehicles else False
        if out != "passed" or not took or bad:
            fails.append((mid, out, took))
    s.check("junction-matrix-empty", not fails,
            "%d/%d passed selfloops=%d %s"
            % (223 - selfloops - len(fails), 223 - selfloops, selfloops,
               fails[:3]))
    # 2) conflict sampling: 2 vehicles crossing per junction
    byj = {}
    for mid, m in moves.items():
        if m["junction"]:
            byj.setdefault(m["junction"], []).append(mid)
    cfails = []
    for jid in sorted(byj.keys()):
        ms = sorted(byj[jid])
        if len(ms) < 2:
            continue
        m0, m1 = moves[ms[0]], moves[ms[1]]
        if m0["from_lane"] == m1["from_lane"]:
            continue
        out, w, v, others = run_movement(
            ms[0], extra=[(m1["from_lane"], m1["to_lane"])], maxticks=2000)
        o = others[0]
        o_out = "passed" if any(e["type"] == "junction_exit"
                                and e["vehicle"] == o["id"]
                                for e in w.events) else "timeout"
        if out != "passed" or o_out != "passed":
            cfails.append((jid, out, o_out))
    s.check("junction-matrix-conflict", not cfails,
            "%d junctions %s" % (len(byj), cfails[:3]))
    # 3) signal matrix: every phase serves its approach within 2 cycles
    sigfails = []
    for sid, sg in sorted(g["signals"].items()):
        w = TrafficWorld(seed_tag="sig-" + sid)
        w.auto_spawn = False
        nd = roads["nodes"][sg["junction"]]
        w.focus = [nd["x"], nd["z"]]
        vids = []
        for p in sg["phases"]:
            mid = sorted(p["movements"])[0]
            m = moves[mid]
            L = w.lanes[m["from_lane"]]["length_m"]
            v = place_vehicle(w, "sedan", m["from_lane"],
                              s=max(8.0, L - 80.0))
            force_route(w, v, m["to_lane"])
            vids.append(v["id"])
        for _ in range(sg["cycle_ticks"] * 2 + 200):
            w.tick()
        passed = set(e["vehicle"] for e in w.events
                     if e["type"] == "junction_exit")
        if not all(v in passed for v in vids):
            sigfails.append(sid)
    s.check("signal-matrix", not sigfails,
            "%d/10 signals %s" % (10 - len(sigfails), sigfails[:2]))
    # 4) roundabout exhaustive: every ROUNDABOUT movement + 6-arm rush
    rb = [mid for mid, m in moves.items() if m["type"] == "ROUNDABOUT"]
    rbfails = []
    for mid in sorted(rb):
        out, w, v, _ = run_movement(mid, tag="rb")
        if out != "passed":
            rbfails.append((mid, out))
    s.check("roundabout-exhaustive", not rbfails,
            "%d/%d %s" % (len(rb) - len(rbfails), len(rb), rbfails[:2]))
    w = TrafficWorld(seed_tag="rb-rush")
    w.auto_spawn = False
    arms = {}
    for mid in rb:
        arms.setdefault(moves[mid]["from_lane"], mid)
    rush = []
    for flane in sorted(arms.keys())[:6]:
        m = moves[arms[flane]]
        L = w.lanes[flane]["length_m"]
        v = place_vehicle(w, "sedan", flane, s=max(8.0, L - 80.0))
        force_route(w, v, m["to_lane"])
        rush.append(v["id"])
    for _ in range(2500):
        w.tick()
    passed = set(e["vehicle"] for e in w.events
                 if e["type"] == "junction_exit")
    ww = sum(1 for e in w.events if e["type"] == "wrong_way")
    s.check("roundabout-rush", all(v in passed for v in rush) and ww == 0,
            "passed=%d/6 ww=%d" % (sum(1 for v in rush if v in passed), ww))
    # 5) bridge/tunnel end-to-end per lane with pin balance
    stfails = []
    for edge in ("E_radial_west_01", "E_ring_hw_02",
                 "E_ring_hw_north_tunnel_00"):
        elanes = sorted(l for l, d in g["lanes"].items()
                        if d["edge"] == edge)
        for lid in elanes:
            w = TrafficWorld(seed_tag="st-" + lid)
            w.auto_spawn = False
            v = place_vehicle(w, "sedan", lid, s=8.0)
            dest = None
            for cand in sorted(g["lanes"].keys()):
                if g["lanes"][cand]["edge"] != edge:
                    r = w.router.plan(lid, cand, v["spec"],
                                      seed_tag="st")
                    if len(r["lanes"]) >= 2:
                        dest = r["lanes"][1]
                        break
            if dest is None:
                stfails.append((lid, "no-dest"))
                continue
            force_route(w, v, dest)
            out = drive(w, v, maxticks=4000, follow=True)
            unbal, held = _pin_balance(w)
            if out not in ("complete", "retired") or unbal or held:
                stfails.append((lid, out, len(unbal), held))
    s.check("struct-end-to-end", not stfails,
            "%s" % (stfails[:3],))
    return s


# ================= VEHICLE =================
def suite_vehicle():
    s = Suite("vehicle")
    g = load_all()["traffic_graph.json"]
    # 1) pool lifecycle: unique ids per generation, reset, balance
    from vehicle_model import TRANSITIONS
    w0 = TrafficWorld(seed_tag="veh-pool")
    pool = w0.pool
    spec = w0.specs["sedan"]
    got = [pool.acquire(spec) for _ in range(8)]
    ids1 = [v["id"] for v in got]
    for v in got[:4]:
        pool.release(v)
    ids2 = [pool.acquire(spec)["id"] for _ in range(4)]
    s.check("pool-unique-ids", len(set(ids1 + ids2)) == 12,
            "12 acquires 12 unique ids")
    s.check("pool-reset", pool.stats["reset_fail"] == 0,
            "reset_fail=%d" % pool.stats["reset_fail"])
    nfree = sum(len(st) for st in pool.free.values())
    bal = len(pool.live) + nfree == 8
    s.check("pool-balance", bal,
            "live=%d free=%d" % (len(pool.live), nfree))
    # 2) state legality over a long mixed scenario
    w = TrafficWorld(seed_tag="veh-long")
    for _ in range(1500):
        if w.tick_n % 25 == 0 and w.vehicles:
            k = sorted(w.vehicles.keys())[0]
            w.focus = [w.vehicles[k]["pos"][0], w.vehicles[k]["pos"][2]]
        w.tick()
    ill = [e for e in w.events if e["type"] == "illegal"]
    seen = set()
    for e in w.events:
        if e["type"] == "transition":
            seen.add((e["data"]["frm"], e["data"]["to"]))
    bad = [(a, b) for (a, b) in seen if b not in TRANSITIONS.get(a, set())]
    s.check("state-legality", not ill and not bad,
            "illegal=%d badpairs=%d pairs=%d" % (len(ill), len(bad),
                                                len(seen)))
    # 3) lane changes complete and stay sane
    w = TrafficWorld(seed_tag="veh-lc")
    w.auto_spawn = False
    multilane = [lid for lid, d in g["lanes"].items()
                 if d["index"] == 0 and d["adjacent"]
                 and d["access"] == "PUBLIC"]
    lcok, lcatt = 0, 0
    for lid in multilane[:6]:
        L = w.lanes[lid]["length_m"]
        v = place_vehicle(w, "sedan", lid, s=min(30.0, L / 3))
        r = w.router.plan(lid, lid, v["spec"], seed_tag="lc")
        v["route"] = {"lanes": [lid], "moves": [None], "i": 0,
                      "dest": lid}
        v["route_i"] = 0
        transition(v, "FOLLOWING", "lc-test")
        tgt = sorted(w.lanes[lid]["adjacent"].values())[0]
        if w.request_lane_change(v, tgt):
            lcatt += 1
            for _ in range(300):
                if w.tick_n % 10 == 0 and v["id"] in w.vehicles:
                    w.focus = [v["pos"][0], v["pos"][2]]
                w.tick()
                if v["id"] not in w.vehicles:
                    break
                if (w.vehicles[v["id"]]["state"] == "FOLLOWING"
                        and not w.vehicles[v["id"]].get("lc")):
                    lcok += 1
                    break
        if v["id"] in w.vehicles:
            vv = w.vehicles.pop(v["id"])
            w.pool.release(vv)
    ww = sum(1 for e in w.events if e["type"] == "wrong_way")
    s.check("lane-change", lcatt > 0 and lcok == lcatt and ww == 0,
            "attempted=%d completed=%d ww=%d" % (lcatt, lcok, ww))
    # 4) spawner fills, despawn balanced, no leak
    w = TrafficWorld(seed_tag="veh-spawn")
    for _ in range(600):
        w.tick()
    n = len(w.vehicles)
    inworld = len(w.pool.live)
    s.check("spawn-fill", n >= 8 and n == inworld,
            "active=%d pool=%d" % (n, inworld))
    # 5) tiers by distance + no flap
    w = TrafficWorld(seed_tag="veh-tier")
    w.auto_spawn = False
    w.focus = [1400.0, 150.0]
    lanes = sorted(g["lanes"].keys())
    tiers = {}
    for i, lid in enumerate(lanes[:8]):
        L = w.lanes[lid]["length_m"]
        v = place_vehicle(w, "sedan", lid, s=L / 2)
        v["route"] = {"lanes": [lid], "moves": [None], "i": 0,
                      "dest": lid}
        v["route_i"] = 0
        transition(v, "FOLLOWING", "tier-test")
        tiers[v["id"]] = None
    for _ in range(120):
        w.tick()
    got = set(w.vehicles[v]["tier"] for v in tiers if v in w.vehicles)
    flaps = sum(1 for e in w.events if e["type"] == "tier_change")
    s.check("tiers", len(got) >= 2 and flaps < 60,
            "tiers=%s flaps=%d" % (sorted(got), flaps))
    # 6) player coexistence
    w = TrafficWorld(seed_tag="veh-player")
    pl = "E_ring_hw_00:+1:0"
    p0 = w.pos_at(pl, 100.0)
    w.set_player(p0[0], p0[2], lane=pl, s=100.0, speed=12.0)
    for _ in range(400):
        if w.tick_n % 25 == 0 and w.vehicles:
            k = sorted(w.vehicles.keys())[0]
            w.focus = [w.vehicles[k]["pos"][0], w.vehicles[k]["pos"][2]]
        w.player["s"] += 12.0 * 0.1
        pp = w.pos_at(pl, w.player["s"])
        w.player["x"], w.player["z"] = pp[0], pp[2]
        w.tick()
    p = w.player
    alive = len(w.vehicles) > 0
    react = (w.counters["leader_queries"] > 0
             or w.counters["lane_occupancy_queries"] > 0)
    s.check("player", p is not None and alive and react,
            "player_s=%.0f veh=%d leaders=%d occ=%d"
            % (p["s"], len(w.vehicles), w.counters["leader_queries"],
               w.counters["lane_occupancy_queries"]))
    return s


SUITES = {"static": suite_static, "cross": suite_cross,
          "inject": suite_inject, "reproduce": suite_reproduce,
          "smoke": suite_smoke, "perf": suite_perf,
          "regress": suite_regress,
          "stress": suite_stress,
          "route": suite_route,
          "junction": suite_junction,
          "vehicle": suite_vehicle}


def main(argv):
    want = list(SUITES) if not argv or argv == ["all"] else argv
    if "--write" in want:
        want = [w for w in want if w != "--write"]
    ok = True
    for name in want:
        if name not in SUITES:
            print("unknown suite:", name)
            return 2
        if name == "regress" and "--write" in argv:
            ok = SUITES[name](write=True).report() and ok
        else:
            ok = SUITES[name]().report() and ok
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
