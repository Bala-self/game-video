#!/usr/bin/env python3
"""P06 Gen-F: landmarks, open space, arrival zones, view corridors, skyline.

Reads: contracts, districts, blocks, parcels, buildings, roads, geometry,
       structures, reservations, terrain.
Writes: data/derived/places.json + (if REQUIRED corridor repairs were
        needed) a deterministically repaired buildings.json with a full
        repair log. Never touches roads or terrain.
"""
import json
import math
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from districts import seed_for, q6, polyline_dist  # noqa: E402
from terrain_model import Field  # noqa: E402
from reservation_index import ReservationIndex  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P06D = os.environ.get("P06_OUT_DIR") or os.path.join(ROOT, "data/derived")

DIST_SIG = {
    "CITY_CORE": 10, "CIVIC": 8, "PORT": 8, "AIRFIELD": 8,
    "COMMERCIAL": 7, "MIXED_USE": 6, "WATERFRONT": 6, "RESTRICTED": 6,
    "RESORT": 6, "INDUSTRIAL": 5, "RESIDENTIAL_INNER": 4, "SUBURBAN": 3,
    "RESIDENTIAL_OUTER": 3, "RURAL_VILLAGE": 3, "UTILITY": 3,
    "FOREST_SETTLEMENT": 2, "HIGHLAND_SETTLEMENT": 2, "AGRICULTURAL": 2,
}
SET_IMP = {
    "MAJOR_CITY": 5, "PORT_COMPLEX": 4, "AIRFIELD_COMPLEX": 4,
    "RESORT_CLUSTER": 3, "SECONDARY_TOWN": 3, "RESTRICTED_COMPLEX": 3,
    "VILLAGE": 2, "RURAL_CLUSTER": 2,
}
ROLE_SCORE = {
    "city_hall": 5, "government": 5, "hotel": 3, "hangar": 3,
    "airport_support": 3, "port_support": 2, "warehouse": 2,
    "distribution": 2, "factory": 2, "restricted_facility": 2,
    "highrise": 4, "midrise": 2, "resort": 3, "marina_service": 2,
    "school": 1, "police": 1, "fire": 1,
}
RURAL_ANCHOR_CLASSES = {"farmhouse", "barn", "silo", "rural_service",
                        "rural_shop", "detached_lowrise"}

LANDMARK_ROLE = {
    "city_hall": "civic", "government": "civic", "school": "civic",
    "hospital": "civic", "police": "civic", "fire": "civic",
    "community_center": "civic", "hotel": "hotel/resort",
    "resort": "hotel/resort", "restaurant": "hotel/resort",
    "port_support": "port", "warehouse": "port", "distribution": "port",
    "hangar": "airport", "airport_support": "airport",
    "factory": "industrial", "workshop": "industrial",
    "maintenance": "industrial", "utility": "industrial",
    "restricted_facility": "restricted", "administration": "restricted",
    "operations": "restricted", "technical": "restricted",
    "storage": "restricted", "security": "restricted",
    "restricted_housing": "restricted", "highrise": "city identity",
    "midrise": "city identity",
}

ARRIVALS = [
    ("SET-hub", "city"), ("SET-port", "port"), ("SET-air", "airfield"),
    ("SET-resort", "resort"), ("SET-highland", "highlands"),
    ("SET-restricted", "restricted complex"), ("SET-sub", "major town"),
]


class PlacesError(Exception):
    pass


class Registry:
    def __init__(self):
        t0 = time.time()
        self.timers = {}
        dd = os.path.join(ROOT, "data/derived")
        dw = os.path.join(ROOT, "data/world")
        self.dc = json.load(open(os.path.join(dw, "district_contract.json")))
        self.bc = json.load(open(os.path.join(dw, "building_contract.json")))
        self.tc = json.load(open(os.path.join(dw, "terrain_contract.json")))
        self.dist = json.load(open(os.path.join(P06D, "districts.json")))
        self.blk = json.load(open(os.path.join(P06D, "blocks.json")))
        self.par = json.load(open(os.path.join(P06D, "parcels.json")))
        self.bld = json.load(open(os.path.join(P06D, "buildings.json")))
        self.g = json.load(open(os.path.join(dd, "road_geometry.json")))
        self.r = json.load(open(os.path.join(dd, "roads.json")))
        self.st = json.load(open(os.path.join(
            dd, "transport_structures.json")))
        self.f = Field()
        self.ri = ReservationIndex()
        self.cls_of = {d["id"]: d["class"] for d in self.dist["districts"]}
        self.set_of_d = {d["id"]: d["settlement"]
                         for d in self.dist["districts"]}
        self.settlements = {s["id"]: s for s in self.dist["settlements"]}
        self.block_of = {b["id"]: b for b in self.blk["blocks"]}
        self.parcel_of = {p["id"]: p for p in self.par["parcels"]}
        self.centerlines = {eid: [(p["x"], p["z"]) for p in E["stations"]]
                            for eid, E in self.g["edges"].items()}
        self.bridges = self._bridge_points()
        self._foot_index()
        self.landmarks = []
        self.open_spaces = []
        self.arrivals = []
        self.corridors = []
        self.repairs = []
        self.skipped_invisible = []
        self.timers["load"] = time.time() - t0

    def _t(self, name):
        if name is None:
            self.timers[self._cur] = time.time() - self._t0
        else:
            self._cur = name
            self._t0 = time.time()

    @staticmethod
    def checksum_scope(items):
        from districts import canon, fnv1a_hex
        lines = sorted(canon(it) for it in items)
        return fnv1a_hex("\n".join(lines))

    def phase_preflight(self):
        self._t("preflight")
        if self.checksum_scope(self.bld["buildings"]) != \
                self.bld["checksum"]:
            raise PlacesError("stale buildings.json")
        self._t(None)

    # ---------- spatial helpers ----------
    def _foot_index(self):
        self._cells = {}
        for b in self.bld["buildings"]:
            fp = b["footprint"][:4]
            xs = [v[0] for v in fp]
            zs = [v[1] for v in fp]
            top = b["foundation"]["base_elev"] + b["height_m"]
            rec = (b["id"], fp, top, min(xs), min(zs), max(xs), max(zs))
            for ix in range(int(min(xs) // 100), int(max(xs) // 100) + 1):
                for iz in range(int(min(zs) // 100),
                                int(max(zs) // 100) + 1):
                    self._cells.setdefault((ix, iz), []).append(rec)

    @staticmethod
    def _pip(x, z, poly):
        inside = False
        n = len(poly)
        for i in range(n):
            x0, z0 = poly[i]
            x1, z1 = poly[(i + 1) % n]
            if (z0 > z) != (z1 > z):
                xin = x0 + (x1 - x0) * (z - z0) / (z1 - z0)
                if x < xin:
                    inside = not inside
        return inside

    def los(self, ax, az, ae, bx, bz, be):
        """Line of sight. Returns (visible, blocked_by)."""
        L = math.hypot(bx - ax, bz - az)
        if L < 1.0:
            return True, None
        n = max(2, int(L / 10.0))
        for i in range(1, n):
            s = i / n
            x = ax + (bx - ax) * s
            z = az + (bz - az) * s
            line = ae + (be - ae) * s
            if self.f.height(x, z) > line + 0.5:
                return False, "terrain"
            for (bid, fp, top, x0, z0, x1, z1) in \
                    self._cells.get((int(x // 100), int(z // 100)), ()):
                if x0 <= x <= x1 and z0 <= z <= z1 and top > line + 0.5 \
                        and self._pip(x, z, fp):
                    return False, bid
        return True, None

    def building_top(self, b):
        fp = b["footprint"][:4]
        cx = sum(v[0] for v in fp) / 4
        cz = sum(v[1] for v in fp) / 4
        return cx, cz, b["foundation"]["base_elev"] + b["height_m"]

    def member(self, x, z):
        best, bestp = None, -1
        for d in self.dist["districts"]:
            b = d["bounds"]
            inside = False
            if "disc" in b:
                cx, cz, r = b["disc"]
                inside = (x - cx) ** 2 + (z - cz) ** 2 <= r * r
            else:
                cx, cz, r0, r1, a0, a1 = b["sector"]
                d2 = (x - cx) ** 2 + (z - cz) ** 2
                if r0 * r0 <= d2 <= r1 * r1:
                    if a1 - a0 >= 2 * math.pi - 1e-6:
                        inside = True
                    else:
                        a = math.atan2(z - cz, x - cx)
                        if a < 0:
                            a += 2 * math.pi
                        b0 = a0 % (2 * math.pi)
                        b1 = a1 % (2 * math.pi)
                        inside = (a >= b0 or a <= b1) if b1 <= b0 else \
                            (b0 <= a <= b1)
            if inside:
                p = self.dc["district_priority"][d["class"]]
                if p > bestp:
                    best, bestp = d["id"], p
        return best

    def _bridge_points(self):
        out = {}
        for bcid, B in self.st["bridges"].items():
            cl = self.centerlines[B["edge"]]
            # arclength table
            acc = [0.0]
            for i in range(len(cl) - 1):
                acc.append(acc[-1] + math.hypot(cl[i + 1][0] - cl[i][0],
                                                cl[i + 1][1] - cl[i][1]))

            def at(d):
                for i in range(len(cl) - 1):
                    if acc[i] <= d <= acc[i + 1]:
                        f = 0.0 if acc[i + 1] == acc[i] else \
                            (d - acc[i]) / (acc[i + 1] - acc[i])
                        return (cl[i][0] + (cl[i + 1][0] - cl[i][0]) * f,
                                cl[i][1] + (cl[i + 1][1] - cl[i][1]) * f)
                return cl[-1]

            d0, d1 = B["station_range"]
            out[bcid] = {"edge": B["edge"],
                         "mid": at((d0 + d1) / 2.0),
                         "a": at(B["approaches"]["appr0"]),
                         "b": at(B["approaches"]["appr1"]),
                         "deck": B["deck_floor"]}
        return out

    # ---------- landmarks (59) ----------
    def landmark_score(self, b):
        dcls = self.cls_of[b["district"]]
        sclass = self.settlements[b["settlement"]]["class"]
        p = self.parcel_of[b["parcel"]]
        parts = {}
        parts["height"] = min(10.0, b["height_m"] / 60.0 * 10.0)
        parts["district"] = DIST_SIG[dcls]
        rc = self.g["edges"][b["road"]]["class"]
        rv = {"primary": 4, "secondary": 3, "tertiary": 2,
              "local": 2}.get(rc, 1)
        if p["block"] is not None and \
                self.block_of[p["block"]]["junction"]["clear_m"] < 40:
            rv += 1
        parts["road"] = rv
        fp = b["footprint"][:4]
        cx = sum(v[0] for v in fp) / 4
        cz = sum(v[1] for v in fp) / 4
        coast = self.water_within(cx, cz) < 100.0
        parts["coast"] = 3.0 if coast else 0.0
        top = b["foundation"]["base_elev"] + b["height_m"]
        parts["terrain"] = 2.0 if top - self._dtops[b["district"]] > 5 \
            else 0.0
        parts["regional"] = SET_IMP[sclass]
        parts["role"] = ROLE_SCORE.get(b["class"], 0)
        for B in self.bridges.values():
            if math.hypot(cx - B["mid"][0], cz - B["mid"][1]) < 150:
                parts["role"] += 2
                break
        if b["id"] == self._tallest.get(b["settlement"]):
            parts["role"] += 3
        return parts, sum(parts.values())

    def water_within(self, x, z):
        if not self.f.is_land(x, z):
            return 0.0
        for rr in (25.0, 50.0, 100.0, 200.0):
            for k in range(8):
                a = k / 8 * 2 * math.pi
                if not self.f.is_land(x + math.cos(a) * rr,
                                      z + math.sin(a) * rr):
                    return rr
        return 999.0

    def phase_landmarks(self):
        self._t("landmarks")
        tops = {}
        for b in self.bld["buildings"]:
            tops.setdefault(b["district"], []).append(
                b["foundation"]["base_elev"] + b["height_m"])
        self._dtops = {k: sum(v) / len(v) for k, v in tops.items()}
        st_tops = {}
        for b in self.bld["buildings"]:
            t = b["foundation"]["base_elev"] + b["height_m"]
            if b["settlement"] not in st_tops or t > st_tops[
                    b["settlement"]][0]:
                st_tops[b["settlement"]] = (t, b["id"])
        self._tallest = {k: v[1] for k, v in st_tops.items()}
        scored = []
        for b in self.bld["buildings"]:
            parts, total = self.landmark_score(b)
            scored.append((total, b["id"], parts))
        scored.sort(key=lambda t: (-t[0], t[1]))
        self._scored = scored
        by_id = {b["id"]: b for b in self.bld["buildings"]}
        # arrival entries needed for visibility gating: compute first
        self._arrival_entries()
        picked = set()

        def visible_from_entry(bid):
            b = by_id[bid]
            ent = self._entries.get(b["settlement"])
            if ent is None:
                return True
            cx, cz, top = self.building_top(b)
            ex, ez, head = ent
            for back in (0.0, 40.0, 80.0):
                vx = ex - math.cos(head) * back
                vz = ez - math.sin(head) * back
                vis, _ = self.los(vx, vz, self.f.height(vx, vz) + 1.7,
                                  cx, cz, top)
                if vis:
                    return True
            return False

        # WORLD: top-1 visible
        for total, bid, parts in scored:
            if visible_from_entry(bid):
                self._add_landmark(by_id[bid], "WORLD", total, parts,
                                   "top visible score island-wide")
                picked.add(bid)
                break
            self.skipped_invisible.append(
                {"id": bid, "tier": "WORLD", "reason": "not_visible"})
        # REGIONAL: top-1 visible per major settlement
        for sid, sclass in (("SET-hub", 1), ("SET-port", 1), ("SET-air", 1),
                            ("SET-resort", 1), ("SET-sub", 1)):
            for total, bid, parts in scored:
                if bid in picked or by_id[bid]["settlement"] != sid:
                    continue
                if visible_from_entry(bid):
                    self._add_landmark(
                        by_id[bid], "REGIONAL", total, parts,
                        "top visible score in %s" % sid)
                    picked.add(bid)
                    break
                self.skipped_invisible.append(
                    {"id": bid, "tier": "REGIONAL",
                     "reason": "not_visible"})
        # DISTRICT: top-1 per district with buildings
        for d in self.dist["districts"]:
            if any(self.cls_of[by_id[x]["district"]] == d["class"] and
                   by_id[x]["district"] == d["id"] for x in picked):
                continue
            for total, bid, parts in scored:
                if bid in picked:
                    continue
                if by_id[bid]["district"] == d["id"]:
                    self._add_landmark(by_id[bid], "DISTRICT", total,
                                       parts, "top score in %s" % d["id"])
                    picked.add(bid)
                    break
        # LOCAL: spacing-constrained fill
        local_pts = [(l["at"][0], l["at"][1]) for l in self.landmarks]
        nlocal = 0
        for total, bid, parts in scored:
            if nlocal >= 12 or total < 8.0 or bid in picked:
                continue
            b = by_id[bid]
            fp = b["footprint"][:4]
            cx = sum(v[0] for v in fp) / 4
            cz = sum(v[1] for v in fp) / 4
            if any(math.hypot(cx - x, cz - z) < 150.0
                   for (x, z) in local_pts):
                continue
            self._add_landmark(b, "LOCAL", total, parts,
                               "distributed fill >= 150m spacing")
            picked.add(bid)
            local_pts.append((cx, cz))
            nlocal += 1
        self._site_landmarks()
        self._t(None)

    def _add_landmark(self, b, tier, total, parts, why):
        fp = b["footprint"][:4]
        cx = sum(v[0] for v in fp) / 4
        cz = sum(v[1] for v in fp) / 4
        role = LANDMARK_ROLE.get(
            b["class"], "rural anchor"
            if b["class"] in RURAL_ANCHOR_CLASSES else "district anchor")
        for B in self.bridges.values():
            if math.hypot(cx - B["mid"][0], cz - B["mid"][1]) < 150:
                role = "bridge-view"
        # visibility audit from settlement entry
        ent = self._entries.get(b["settlement"])
        vis_ratio = None
        if ent is not None:
            ex, ez, head = ent
            top = b["foundation"]["base_elev"] + b["height_m"]
            hits = 0
            for back in (0.0, 60.0, 120.0, 180.0, 240.0):
                vx = ex - math.cos(head) * back
                vz = ez - math.sin(head) * back
                vis, _ = self.los(vx, vz, self.f.height(vx, vz) + 1.7,
                                  cx, cz, top)
                hits += 1 if vis else 0
            vis_ratio = hits / 5.0
        self.landmarks.append({
            "id": "LM-%s" % b["id"][4:], "tier": tier, "kind": "building",
            "building": b["id"], "class": b["class"], "role": role,
            "district": b["district"], "settlement": b["settlement"],
            "at": [q6(cx), q6(cz)],
            "top_elev": q6(b["foundation"]["base_elev"] + b["height_m"]),
            "score": q6(total),
            "score_parts": {k: q6(v) for k, v in parts.items()},
            "why": why, "visibility": vis_ratio,
            "access": {"type": "via_building_entrance",
                       "entry": b["entrance"]["at"]},
            "seed": seed_for("p06-landmark", b["id"])})

    def _site_landmarks(self):
        # ridge lookout (REGIONAL for the highlands arrival)
        n = self.r["nodes"]["ridge_end"]
        lx, lz = n["x"], n["z"]
        le = self.f.height(lx, lz)
        self.landmarks.append({
            "id": "LM-ridge-lookout", "tier": "REGIONAL", "kind": "site",
            "building": None, "class": "lookout_platform",
            "role": "city identity", "district": "D-hi-look",
            "settlement": "SET-highland", "at": [q6(lx), q6(lz)],
            "top_elev": q6(le + 4.0), "score": 14.0,
            "score_parts": {"site": 14.0},
            "why": "highlands arrival focal; terrain-coded viewpoint",
            "visibility": 1.0,
            "access": {"type": "trail", "via": "ridge_end node"},
            "seed": seed_for("p06-landmark", "ridge-lookout")})
        # harbor beacon (LOCAL navigational)
        bx = None
        for x in range(1900, 2400, 25):
            if not self.f.is_land(x, 700):
                bx = x
                break
        if bx is None:
            raise PlacesError("no harbor water found")
        oc = self.tc.get("ocean_level_m", 0.0)
        self.landmarks.append({
            "id": "LM-harbor-beacon", "tier": "LOCAL", "kind": "site",
            "building": None, "class": "beacon", "role": "port",
            "district": "D-port-ops", "settlement": "SET-port",
            "at": [q6(bx), 700.0], "top_elev": q6(oc + 12.0),
            "score": 12.0, "score_parts": {"site": 12.0},
            "why": "navigational beacon at harbor mouth",
            "visibility": 1.0,
            "access": {"type": "no-access",
                       "reason": "water_structure_boat_only"},
            "seed": seed_for("p06-landmark", "harbor-beacon")})

    # ---------- arrival zones (60) ----------
    def _arrival_entries(self):
        self._entries = {}
        for sid, _ in ARRIVALS:
            s = self.settlements[sid]
            bx, bz, br = s["bounds"]
            edge = s["primary_access"]
            cl = self.centerlines[edge]
            # walk from the end farther from settlement center
            d0 = math.hypot(cl[0][0] - bx, cl[0][1] - bz)
            d1 = math.hypot(cl[-1][0] - bx, cl[-1][1] - bz)
            pts = cl if d0 > d1 else list(reversed(cl))
            entry, head = pts[-1], 0.0
            for i in range(1, len(pts)):
                if math.hypot(pts[i][0] - bx, pts[i][1] - bz) <= br and \
                        math.hypot(pts[i - 1][0] - bx,
                                   pts[i - 1][1] - bz) > br:
                    entry = pts[i]
                    dx = pts[i][0] - pts[i - 1][0]
                    dz = pts[i][1] - pts[i - 1][1]
                    head = math.atan2(dz, dx)
                    break
            else:
                dx = pts[-1][0] - pts[-2][0]
                dz = pts[-1][1] - pts[-2][1]
                head = math.atan2(dz, dx)
            self._entries[sid] = (entry[0], entry[1], head)

    def phase_arrivals(self):
        self._t("arrivals")
        for sid, label in ARRIVALS:
            s = self.settlements[sid]
            ex, ez, head = self._entries[sid]
            # first visible district walking in from 400m out
            first = None
            for back in range(400, -1, -25):
                vx = ex - math.cos(head) * back
                vz = ez - math.sin(head) * back
                m = self.member(vx, vz)
                if m is not None:
                    first = {"district": m, "at_back_m": back}
                    break
            # density transition across the entry
            before = self.member(ex - math.cos(head) * 100,
                                 ez - math.sin(head) * 100)
            after = self.member(ex, ez)
            transit = "%s -> %s" % (
                self.cls_of[before] if before else "natural",
                self.cls_of[after] if after else "natural")
            # nearest visible landmark within 600m (same settlement
            # first, then any)
            best, bd = None, 1e18
            ee = self.f.height(ex, ez) + 1.7
            for same_only in (True, False):
                # arrival experience: entry, then walking 80/160m in
                for fwd in (0.0, 80.0, 160.0):
                    vx = ex + math.cos(head) * fwd
                    vz = ez + math.sin(head) * fwd
                    ve = self.f.height(vx, vz) + 1.7
                    for l in self.landmarks:
                        if same_only and l["settlement"] != sid:
                            continue
                        lx, lz = l["at"]
                        dd = math.hypot(lx - vx, lz - vz)
                        if dd > 600 or dd < 1.0:
                            continue
                        vis, _ = self.los(vx, vz, ve, lx, lz,
                                           l["top_elev"])
                        if vis and dd < bd:
                            best, bd = l["id"], dd
                    if best is not None:
                        break
                if best is not None:
                    break
            if best is None:
                # promote nearest visible tall building (60)
                best = self._promote_focal(sid, ex, ez, ee)
            self.arrivals.append({
                "id": "ARR-%s" % sid[4:], "settlement": sid,
                "label": label, "approach_road": s["primary_access"],
                "entry": [q6(ex), q6(ez)], "heading": q6(head),
                "envelope_r": 80.0, "first_district": first,
                "transition": transit, "focal_landmark": best,
                "seed": seed_for("p06-arrival", sid)})
        self._t(None)

    def _promote_focal(self, sid, ex, ez, ee):
        cands = []
        for b in self.bld["buildings"]:
            if b["settlement"] != sid or b["height_m"] < 8.0:
                continue
            cx, cz, top = self.building_top(b)
            dd = math.hypot(cx - ex, cz - ez)
            if dd > 600 or dd < 1.0:
                continue
            vis, _ = self.los(ex, ez, ee, cx, cz, top)
            if vis:
                cands.append((dd, b))
        if not cands:
            return None
        cands.sort(key=lambda t: t[0])
        b = cands[0][1]
        fp = b["footprint"][:4]
        cx = sum(v[0] for v in fp) / 4
        cz = sum(v[1] for v in fp) / 4
        lid = "LM-%s-focal" % sid[4:]
        self.landmarks.append({
            "id": lid, "tier": "LOCAL", "kind": "building",
            "building": b["id"], "class": b["class"],
            "role": LANDMARK_ROLE.get(
                b["class"], "rural anchor"
                if b["class"] in RURAL_ANCHOR_CLASSES
                else "district anchor"),
            "district": b["district"], "settlement": sid,
            "at": [q6(cx), q6(cz)],
            "top_elev": q6(b["foundation"]["base_elev"] + b["height_m"]),
            "score": 7.0, "score_parts": {"arrival_focal": 7.0},
            "why": "promoted: arrival focal, no landmark visible",
            "visibility": 1.0,
            "access": {"type": "via_building_entrance",
                       "entry": b["entrance"]["at"]},
            "seed": seed_for("p06-landmark", lid)})
        return lid

    # ---------- open space (16/62) ----------
    def phase_open_space(self):
        self._t("open_space")
        for p in self.par["parcels"]:
            if p["role"] != "OPEN":
                continue
            kind = p["kind"]
            dcls = self.cls_of[p["district"]]
            if kind == "access_lane":
                purpose, nav = "circulation", "walkable"
            elif kind in ("rear_court", "row_remainder"):
                purpose, nav = "courtyard_green", "walkable"
            elif kind == "campus_plaza":
                purpose, nav = "plaza", "walkable"
            elif kind in ("beach_preserve", "beach_access"):
                purpose, nav = "beach_access", "walkable"
            elif kind == "runway_open":
                purpose, nav = "safety_open", "no_access"
            elif kind.startswith("campus_") and dcls in (
                    "PORT", "INDUSTRIAL", "AIRFIELD"):
                purpose, nav = "operational_open", "operational"
            elif kind.startswith("campus_") and dcls == "RESTRICTED":
                purpose, nav = "standoff_open", "restricted"
            elif kind.startswith("campus_"):
                purpose, nav = "campus_grounds", "walkable"
            else:
                purpose, nav = "green", "walkable"
            reg = p["region"]
            if reg.startswith("urban") or reg == "infra_corridors":
                veg = "street_trees"
            elif reg in ("rural_fields", "rural_pasture"):
                veg = "meadow"
            elif reg == "coastal_beach":
                veg = "dune_grass"
            elif reg == "hills_highland":
                veg = "scrub"
            elif reg == "forest":
                veg = "woodland_edge"
            elif reg == "wetland_inland_water":
                veg = "marsh_grass"
            else:
                veg = "lawn"
            self.open_spaces.append({
                "id": "OS-%s" % p["id"][4:], "parcel": p["id"],
                "district": p["district"], "settlement": p["settlement"],
                "bounds": p["polygon"], "purpose": purpose,
                "access": {"edge": p["access_edge"],
                           "type": p["access"]["type"]},
                "vegetation_policy": veg, "navigation_policy": nav})
        self._connectivity()
        self._t(None)

    def _connectivity(self):
        # every open space has road access by construction; verify the
        # special chains (62) + count public vs operational.
        pub = sum(1 for o in self.open_spaces
                  if o["navigation_policy"] == "walkable")
        chains = {}
        # resort -> beach
        r_os = [o for o in self.open_spaces
                if o["settlement"] == "SET-resort"]
        beach = [o for o in r_os if o["purpose"] == "beach_access"]
        chains["resort_beach"] = len(beach) > 0 and len(r_os) > 0
        # district core -> public plaza
        chains["core_plaza"] = any(
            o["purpose"] == "plaza" and o["district"] == "D-hub-civic"
            for o in self.open_spaces)
        # waterfront -> public access
        chains["waterfront_access"] = any(
            o["navigation_policy"] == "walkable" and
            o["district"] == "D-hub-water" for o in self.open_spaces)
        chains["school_grounds"] = "N/A_no_schools_built"
        self.connectivity = {"walkable_count": pub,
                             "total": len(self.open_spaces),
                             "chains": chains}

    # ---------- corridors (61) + repair (17) ----------
    def phase_corridors(self):
        self._t("corridors")
        by_sid = {}
        for a in self.arrivals:
            by_sid[a["settlement"]] = a
        world = [l for l in self.landmarks if l["tier"] == "WORLD"][0]
        a = by_sid[world["settlement"]]
        self.corridors.append(self._mk_corridor(
            "COR-world", "REQUIRED", 40.0, a["entry"], world, a["id"]))
        beacon = [l for l in self.landmarks
                  if l["id"] == "LM-harbor-beacon"][0]
        mouth = [beacon["at"][0] + 300.0, beacon["at"][1]]
        self.corridors.append(self._mk_corridor(
            "COR-beacon", "REQUIRED", 30.0, mouth, beacon, None))
        for l in self.landmarks:
            if l["tier"] != "REGIONAL" or l["kind"] != "building":
                continue
            aa = by_sid.get(l["settlement"])
            if aa is None:
                continue
            self.corridors.append(self._mk_corridor(
                "COR-reg-%s" % l["id"][3:], "PREFERRED", 25.0,
                aa["entry"], l, aa["id"]))
        # lookout corridor (highland arrival -> lookout)
        look = [l for l in self.landmarks
                if l["id"] == "LM-ridge-lookout"][0]
        ah = by_sid["SET-highland"]
        self.corridors.append(self._mk_corridor(
            "COR-lookout", "PREFERRED", 25.0, ah["entry"], look,
            ah["id"]))
        # skyline: port arrival -> tallest core building
        core = [b for b in self.bld["buildings"]
                if b["district"] == "D-hub-core"]
        if core:
            top = max(core, key=lambda b: b["foundation"]["base_elev"] +
                      b["height_m"])
            cx, cz, te = self.building_top(top)
            ap = by_sid["SET-port"]
            self.corridors.append({
                "id": "COR-skyline-port", "class": "PREFERRED",
                "width": 30.0, "route": [ap["entry"], [q6(cx), q6(cz)]],
                "target": {"id": top["id"], "top_elev": q6(te)},
                "arrival": ap["id"], "intrusions": [],
                "terrain_blocks": 0, "seed":
                    seed_for("p06-corridor", "skyline-port")})
        # bridge approaches
        for bcid, B in self.bridges.items():
            for side, pt in (("a", B["a"]), ("b", B["b"])):
                self.corridors.append({
                    "id": "COR-%s-%s" % (bcid, side), "class": "PREFERRED",
                    "width": 20.0,
                    "route": [[q6(pt[0]), q6(pt[1])],
                              [q6(B["mid"][0]), q6(B["mid"][1])]],
                    "target": {"id": bcid, "top_elev": q6(B["deck"] + 2)},
                    "arrival": None, "intrusions": [],
                    "terrain_blocks": 0, "seed":
                        seed_for("p06-corridor", "%s-%s" % (bcid, side))})
        # coast + mountain optionals
        wc = [d for d in self.dist["districts"]
              if d["id"] == "D-hub-water"][0]["bounds"]["disc"]
        sea = [wc[0] + 400.0, wc[1]]
        self.corridors.append({
            "id": "COR-coast-waterfront", "class": "OPTIONAL",
            "width": 15.0, "route": [[q6(wc[0]), q6(wc[1])],
                                    [q6(sea[0]), q6(sea[1])]],
            "target": {"id": "sea", "top_elev": q6(2.0)},
            "arrival": None, "intrusions": [], "terrain_blocks": 0,
            "seed": seed_for("p06-corridor", "coast-waterfront")})
        self._validate_corridors()
        self._repair_required()
        self._validate_corridors()
        self._t(None)

    def _mk_corridor(self, cid, cls, width, entry, landmark, arrival):
        return {"id": cid, "class": cls, "width": width,
                "route": [[q6(entry[0]), q6(entry[1])],
                          [q6(landmark["at"][0]),
                           q6(landmark["at"][1])]],
                "target": {"id": landmark["id"],
                           "top_elev": landmark["top_elev"]},
                "arrival": arrival, "intrusions": [], "terrain_blocks": 0,
                "seed": seed_for("p06-corridor", cid)}

    def _validate_corridors(self):
        for c in self.corridors:
            c["intrusions"] = []
            c["terrain_blocks"] = 0
            (ax, az), (bx, bz) = c["route"]
            te = c["target"]["top_elev"]
            L = math.hypot(bx - ax, bz - az)
            n = max(2, int(L / 20.0))
            seen = set()
            for i in range(n + 1):
                s = i / n
                vx = ax + (bx - ax) * s
                vz = az + (bz - az) * s
                ve = self.f.height(vx, vz) + 1.7
                vis, by = self.los(vx, vz, ve, bx, bz, te)
                if vis:
                    continue
                if by == "terrain":
                    c["terrain_blocks"] += 1
                elif by is not None and (by, i) not in seen:
                    seen.add((by, i))
                    c["intrusions"].append(
                        {"building": by, "sample": i, "of": n})

    def _repair_required(self):
        by_id = {b["id"]: b for b in self.bld["buildings"]}
        for c in self.corridors:
            if c["class"] != "REQUIRED":
                continue
            (ax, az), (bx, bz) = c["route"]
            te = c["target"]["top_elev"]
            L = math.hypot(bx - ax, bz - az)
            n = max(2, int(L / 20.0))
            for intr in c["intrusions"]:
                b = by_id.get(intr["building"])
                if b is None or b.get("pruned"):
                    continue
                fp = b["footprint"][:4]
                cx = sum(v[0] for v in fp) / 4
                cz = sum(v[1] for v in fp) / 4
                # worst sightline over blocking samples
                allowed = 1e18
                for i in range(n + 1):
                    s = i / n
                    vx = ax + (bx - ax) * s
                    vz = az + (bz - az) * s
                    ve = self.f.height(vx, vz) + 1.7
                    # project building center onto route
                    t = ((cx - vx) * (bx - vx) + (cz - vz) * (bz - vz)) / \
                        max(1.0, (bx - vx) ** 2 + (bz - vz) ** 2)
                    if 0.0 < t < 1.0:
                        allowed = min(allowed, ve + (te - ve) * t - 0.5)
                base = b["foundation"]["base_elev"]
                clsmin = self.bc["building_classes"][b["class"]][
                    "height_range_m"][0]
                new_h = allowed - base
                if new_h >= max(clsmin, 3.0):
                    old_h = b["height_m"]
                    b["height_m"] = q6(new_h)
                    fa, fb = self.bc["building_classes"][b["class"]][
                        "floor_range"]
                    b["floors"] = max(fa, min(fb, round(new_h / 3.2)))
                    b["view_corridor"] = "repaired_%s" % c["id"]
                    self.repairs.append(
                        {"building": b["id"], "corridor": c["id"],
                         "action": "height_change", "from": old_h,
                         "to": q6(new_h)})
                    self._foot_index()
                    by_id = {x["id"]: x for x in self.bld["buildings"]}
                else:
                    b["pruned"] = True
                    b["view_corridor"] = "pruned_%s" % c["id"]
                    self.repairs.append(
                        {"building": b["id"], "corridor": c["id"],
                         "action": "prune_to_open_space"})
        # drop pruned from the committed set
        pruned = [b for b in self.bld["buildings"] if b.get("pruned")]
        self.bld["buildings"] = [b for b in self.bld["buildings"]
                                 if not b.get("pruned")]
        for b in pruned:
            self.bld["parcel_states"].append(
                {"parcel": b["parcel"], "state": "OPEN_SPACE",
                 "reason": "view_corridor_required"})
        if self.repairs:
            self._foot_index()
            self._rewrite_buildings()

    def _rewrite_buildings(self):
        import copy
        dd = P06D
        old = self.bld["checksum"]
        HC = self.bc["height_classes"]
        dist = {"LOW": 0, "MID": 0, "HIGH": 0}
        for b in self.bld["buildings"]:
            h = b["height_m"]
            if h < HC["MID"]["height_m"][0]:
                dist["LOW"] += 1
            elif h < HC["HIGH"]["height_m"][0]:
                dist["MID"] += 1
            else:
                dist["HIGH"] += 1
        per_class, per_district = {}, {}
        for b in self.bld["buildings"]:
            per_class[b["class"]] = per_class.get(b["class"], 0) + 1
            per_district[b["district"]] = per_district.get(
                b["district"], 0) + 1
        self.bld["stats"] = {"count": len(self.bld["buildings"]),
                             "per_class": per_class,
                             "per_district": per_district,
                             "height_distribution": dist}
        self.bld["repaired_from"] = old
        self.bld["corridor_repairs"] = self.repairs
        self.bld["checksum"] = self.checksum_scope(self.bld["buildings"])
        json.dump(self.bld, open(os.path.join(P06D, "buildings.json"), "w"))

    # ---------- skyline (12/17) ----------
    def phase_skyline(self):
        self._t("skyline")
        hs = sorted(b["height_m"] for b in self.bld["buildings"])
        def pct(p):
            return q6(hs[min(len(hs) - 1, int(len(hs) * p / 100.0))])
        coast = []
        for b in self.bld["buildings"]:
            fp = b["footprint"][:4]
            cx = sum(v[0] for v in fp) / 4
            cz = sum(v[1] for v in fp) / 4
            if self.water_within(cx, cz) < 200.0:
                coast.append(b["height_m"])
        # mountain visibility: ridge peak from 8 points at 600m
        n = self.r["nodes"]["ridge_end"]
        px, pz = n["x"], n["z"]
        pe = self.f.height(px, pz) + 2.0
        vis = 0
        for k in range(8):
            a = k / 8 * 2 * math.pi
            vx, vz = px + math.cos(a) * 600, pz + math.sin(a) * 600
            ok, _ = self.los(vx, vz, self.f.height(vx, vz) + 1.7,
                             px, pz, pe)
            vis += 1 if ok else 0
        self.skyline = {
            "distribution": self.bld["stats"]["height_distribution"],
            "high_rise_count": self.bld["stats"][
                "height_distribution"]["HIGH"],
            "landmark_count": len(self.landmarks),
            "percentiles": {"p50": pct(50), "p90": pct(90),
                            "p99": pct(99), "max": q6(hs[-1])},
            "coastline": {"count": len(coast),
                          "max": q6(max(coast)) if coast else 0.0},
            "mountain_visibility": "%d/8" % vis}
        self._t(None)

    # ---------- placement audits (54-58) ----------
    def phase_audits(self):
        self._t("audits")
        self.audits = {}
        # 54 civic
        rows = []
        for b in self.bld["buildings"]:
            if self.bc["building_classes"][b["class"]][
                    "occupancy"] != "civic":
                continue
            fp = b["footprint"][:4]
            cx = sum(v[0] for v in fp) / 4
            cz = sum(v[1] for v in fp) / 4
            d = [x for x in self.dist["districts"]
                 if x["id"] == b["district"]][0]
            bb = d["bounds"]
            if "disc" in bb:
                bx, bz, br = bb["disc"]
            else:
                bx, bz, _, br, _, _ = bb["sector"]
            cent = max(0.0, 1.0 - math.hypot(cx - bx, cz - bz) / br)
            near_open = any(
                math.hypot(cx - o["bounds"][0][0],
                           cz - o["bounds"][0][1]) < 100.0
                for o in self.open_spaces)
            rows.append({"building": b["id"], "centrality": q6(cent),
                         "road": self.g["edges"][b["road"]]["class"],
                         "open_within_100m": near_open})
        self.audits["civic_54"] = rows
        # 55 industrial
        res_pts = []
        for p in self.par["parcels"]:
            if p["role"] == "RESIDENTIAL":
                qp = p["polygon"]
                res_pts.append((sum(v[0] for v in qp) / len(qp),
                                sum(v[1] for v in qp) / len(qp)))
        rows = []
        for b in self.bld["buildings"]:
            if b["class"] not in ("warehouse", "factory", "workshop",
                                  "distribution", "port_support",
                                  "hangar", "airport_support"):
                continue
            fp = b["footprint"][:4]
            cx = sum(v[0] for v in fp) / 4
            cz = sum(v[1] for v in fp) / 4
            sep = min((math.hypot(cx - x, cz - z) for (x, z) in res_pts),
                      default=9999.0)
            svc = b["service"]
            rows.append({"building": b["id"],
                         "road": self.g["edges"][b["road"]]["class"],
                         "yard_m": svc["yard_m"] if svc else 0.0,
                         "residential_separation_m": q6(sep)})
        self.audits["industrial_55"] = rows
        # 56 rural spacing
        rur = [b for b in self.bld["buildings"]
               if b["settlement"] in ("SET-forest", "SET-highland") or
               b["district"] in ("D-farmA", "D-farmB",
                                 "D-vil-core")]
        pts = []
        for b in rur:
            fp = b["footprint"][:4]
            pts.append((sum(v[0] for v in fp) / 4,
                        sum(v[1] for v in fp) / 4, b["id"]))
        mind = 1e18
        for i in range(len(pts)):
            for j in range(i + 1, len(pts)):
                mind = min(mind, math.hypot(pts[i][0] - pts[j][0],
                                            pts[i][1] - pts[j][1]))
        self.audits["rural_56"] = {"count": len(rur),
                                   "min_spacing_m": q6(mind)}
        # 57 resort barrier
        rb = [b for b in self.bld["buildings"]
              if b["district"] == "D-res-main"]
        xs = sorted(sum(v[0] for v in b["footprint"][:4]) / 4 for b in rb)
        gaps = [xs[i + 1] - xs[i] for i in range(len(xs) - 1)]
        beach_open = sum(
            1 for o in self.open_spaces
            if o["purpose"] == "beach_access")
        self.audits["resort_57"] = {"count": len(rb),
                                    "max_gap_m": q6(max(gaps))
                                    if gaps else 0.0,
                                    "beach_parcels_open": beach_open}
        # 58 restricted
        rs = [b for b in self.bld["buildings"]
              if b["district"] == "D-res-secure"]
        rows = []
        for b in rs:
            fp = b["footprint"][:4]
            cx = sum(v[0] for v in fp) / 4
            cz = sum(v[1] for v in fp) / 4
            pub = 0
            for o in self.bld["buildings"]:
                if o["district"] == "D-res-secure":
                    continue
                ofp = o["footprint"][:4]
                ox = sum(v[0] for v in ofp) / 4
                oz = sum(v[1] for v in ofp) / 4
                if math.hypot(cx - ox, cz - oz) < 50.0:
                    pub += 1
            rows.append({"building": b["id"], "road": b["road"],
                         "public_within_50m": pub})
        self.audits["restricted_58"] = rows
        self._t(None)

    # ---------- export ----------
    def phase_export(self):
        self._t("export")
        outdir = os.environ.get("P06_OUT_DIR",
                                os.path.join(ROOT, "data/derived"))
        doc = {"meta": {"landmark_version": self.dc["landmark_version"],
                        "open_space_version":
                            self.dc["open_space_version"],
                        "generator": "places.py"},
               "landmarks": self.landmarks,
               "open_spaces": self.open_spaces,
               "arrivals": self.arrivals,
               "corridors": self.corridors,
               "skyline": self.skyline,
               "connectivity": self.connectivity,
               "audits": self.audits,
               "skipped_invisible": self.skipped_invisible,
               "checksum": ""}
        doc["checksum"] = self.checksum_scope(
            self.landmarks + self.open_spaces + self.arrivals +
            self.corridors)
        json.dump(doc, open(os.path.join(outdir, "places.json"), "w"))
        self._t(None)


def main():
    reg = Registry()
    reg.phase_preflight()
    reg.phase_landmarks()
    reg.phase_arrivals()
    reg.phase_open_space()
    reg.phase_corridors()
    reg.phase_skyline()
    reg.phase_audits()
    reg.phase_export()
    print("gen-f ok: %d landmarks %d open %d arrivals %d corridors "
          "(%d repairs)" % (len(reg.landmarks), len(reg.open_spaces),
                            len(reg.arrivals), len(reg.corridors),
                            len(reg.repairs)))
    print("timers: %s" % " ".join("%s=%.2f" % kv for kv in
                                  sorted(reg.timers.items())))


if __name__ == "__main__":
    main()
