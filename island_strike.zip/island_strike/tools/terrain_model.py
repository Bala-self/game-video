#!/usr/bin/env python3
"""ISLAND STRIKE — independent terrain/coast model (Prompt 02).

Pure-Python implementation of the layered analytic field + star-shaped coast
loop. Used for (a) design tuning BEFORE GDScript implementation, and (b)
permanent cross-validation of the GDScript implementation (dual-implementation
agreement, same pattern as Prompt 01's FNV/checksum cross-checks).

Every numeric algorithm here MUST have a GDScript twin:
  tools/terrain_model.py  <->  scripts/terrain/terrain_field.gd (+regions/coast)
Cross-check tolerance: 1e-6 relative (libm last-ulp safety); ints/enums exact.
"""
import json, math, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MASK64 = (1 << 64) - 1

# ---------------- seeds (IS-SEED/1 twin) ----------------
def fnv1a_hex(text: str) -> str:
    h = 14695981039346656037
    for b in text.encode("utf-8"):
        h = ((h ^ b) * 1099511628211) & MASK64
    return format(h, "016x")

def derive_i64(world_version: str, master: int, domain: str, key: str) -> int:
    u = int(fnv1a_hex(f"IS-SEED/1|v={world_version}|m={master}|d={domain}|k={key}"), 16)
    return u - (1 << 64) if u >= (1 << 63) else u

def phase_of(seed_i64: int) -> float:
    u = (seed_i64 & 0x7FFFFFFFFFFFFFFF) / 9223372036854775808.0
    return u * 2.0 * math.pi

# ---------------- lattice value noise (GDScript twin) ----------------
def _arith_shift(h_u64: int, n: int) -> int:
    s = h_u64 if h_u64 < (1 << 63) else h_u64 - (1 << 64)
    return (s >> n) & MASK64

def lattice(ix: int, iz: int, salt_i64: int) -> float:
    salt = salt_i64 & MASK64
    h = (salt ^ ((ix * 374761393) & MASK64) ^ ((iz * 668265263) & MASK64)) & MASK64
    h = ((h ^ _arith_shift(h, 13)) * 1274126177) & MASK64
    h = h ^ _arith_shift(h, 16)
    return (h & 0x7FFFFFFF) / 2147483648.0

def sstep(a: float, b: float, t: float) -> float:
    if t <= a: return 0.0
    if t >= b: return 1.0
    u = (t - a) / (b - a)
    return u * u * (3.0 - 2.0 * u)

def poly_dist(x: float, z: float, pts) -> float:
    best = 1e18
    for i in range(len(pts) - 1):
        ax, az = pts[i]
        bx, bz = pts[i + 1]
        abx, abz = bx - ax, bz - az
        denom = abx * abx + abz * abz
        t = 0.0 if denom <= 0 else max(0.0, min(1.0, ((x - ax) * abx + (z - az) * abz) / denom))
        best = min(best, math.hypot(x - (ax + t * abx), z - (az + t * abz)))
    return best

def ring_dist(x: float, z: float, r_m: float) -> float:
    return abs(math.hypot(x, z) - r_m)

def vnoise(x: float, z: float, lam: float, salt: int) -> float:
    gx, gz = x / lam, z / lam
    ix0, iz0 = math.floor(gx), math.floor(gz)
    fx, fz = gx - ix0, gz - iz0
    ux, uz = fx * fx * (3 - 2 * fx), fz * fz * (3 - 2 * fz)
    a = lattice(ix0, iz0, salt); b = lattice(ix0 + 1, iz0, salt)
    c = lattice(ix0, iz0 + 1, salt); d = lattice(ix0 + 1, iz0 + 1, salt)
    return (a * (1 - ux) + b * ux) * (1 - uz) + (c * (1 - ux) + d * ux) * uz

# ---------------- data loading ----------------
def load_all():
    t = json.load(open(os.path.join(ROOT, "data/world/terrain_contract.json")))
    c = json.load(open(os.path.join(ROOT, "data/world/coast_contract.json")))
    a = json.load(open(os.path.join(ROOT, "data/terrain/authoring.json")))
    w = json.load(open(os.path.join(ROOT, "data/world/world_contract.json")))
    return t, c, a, w

# ---------------- coast loop ----------------
class CoastLoop:
    def __init__(self, coast, world_version, master):
        au = coast["authoring"]
        self.base = au["radial_base_m"]
        self.terms = [(f["k"], f["amp_m"],
                       phase_of(derive_i64(world_version, master, "coast", f"phase:{f['k']}")))
                      for f in au["fourier_terms"]]
        self.bays = au["bays"]
        self.env_max = au["envelope"]["max_m"]
        self.env_min = au["envelope"]["min_m"]
        # Envelope normalization: measure raw deviation densely, scale DOWN only.
        devs = [self._raw_dev(i * 2 * math.pi / 1440.0) for i in range(1440)]
        mx, mn = max(devs), min(devs)
        self.pos_scale = min(1.0, (self.env_max - self.base) / mx) if mx > 0 else 1.0
        self.neg_scale = min(1.0, (self.base - self.env_min) / (-mn)) if mn < 0 else 1.0

    def _raw_dev(self, th):
        d = sum(a * math.sin(k * th + p) for k, a, p in self.terms)
        for b in self.bays:
            thc = math.radians(b["theta_deg"])
            dt = (th - thc + math.pi) % (2 * math.pi) - math.pi
            arc = dt * self.base
            sig = b["width_m"]
            d += b["depth_m"] * math.exp(-0.5 * (arc / sig) ** 2)
        return d

    def dev(self, th):
        d = self._raw_dev(th)
        return d * (self.pos_scale if d >= 0 else self.neg_scale)

    def rs(self, th):
        return self.base + self.dev(th)

    def rs_meso(self, th):
        # Loop without micro terms (k>=50): meso trend for width modulation.
        # Width responds to cove/headland-scale concavity, not 80 m wiggles
        # (tuning: micro curvature drowned the meso signal in run means).
        d = sum(a * math.sin(k * th + p) for k, a, p in self.terms if k < 50)
        for b in self.bays:
            thc = math.radians(b["theta_deg"])
            dt = (th - thc + math.pi) % (2 * math.pi) - math.pi
            arc = dt * self.base
            sig = b["width_m"]
            d += b["depth_m"] * math.exp(-0.5 * (arc / sig) ** 2)
        return self.base + d * (self.pos_scale if d >= 0 else self.neg_scale)

    @staticmethod
    def theta(x, z):
        return math.atan2(x, -z) % (2 * math.pi)

    @staticmethod
    def point(rs, th):
        return (rs * math.sin(th), -rs * math.cos(th))

# ---------------- regions ----------------
class Regions:
    # Ownership order (priority): R10 corridor mask > R8 coastal band/frontage >
    # ellipse weights > reserve fallback. Sea (d<0 or r>2000) is unowned water.
    # Height BLEND uses hinterland ellipses (+reserve fallback) ONLY: R8/R10 are
    # ownership overlays with no height effect (coast owns height for d<150 via
    # beach profiles; corridors are routed through compliant terrain, §26).
    def __init__(self, authoring, loop, lut_n):
        self.regs = authoring["regions"]
        self.lakes = authoring["drainage"].get("lakes", [])
        self.loop = loop
        self.lut_n = lut_n
        self.fb_threshold = 0.15
        self.r8 = next(r for r in self.regs if r["id"] == "coastal_beach")
        self.r10 = next(r for r in self.regs if r["id"] == "infra_corridors")
        self.corridors = {c["id"]: c for c in authoring["corridors"]}
        self.r10_ids = self.r10["rule"]["corridors"]
        self.r8_depth = self.r8["rule"]["depth_m"]
        self.frontage = [(math.radians(s["from_deg"]), math.radians(s["to_deg"]), s["region"])
                         for s in self.r8["rule"]["frontage_segments"]]

    @staticmethod
    def _in_arc(th, a, b):
        if a <= b:
            return a <= th < b
        return th >= a or th < b

    def corridor_dist(self, x, z):
        best = 1e18
        for cid in self.r10_ids:
            c = self.corridors[cid]
            if c["type"] == "ring":
                dd = ring_dist(x, z, c["r_m"])
            elif c["type"] == "tunnel":
                # A tunnel bore reserves no surface (the ground above is
                # undisturbed); only the portal works discs are masked.
                dd = min(math.hypot(x - p[0], z - p[1]) - pr
                         for (p, pr) in zip(c["portals"], c["portal_works_r_m"]))
                best = min(best, dd)
                continue
            else:
                dd = poly_dist(x, z, c["points"])
            dd -= c["width_m"] / 2.0
            best = min(best, dd)
        return best

    def weights(self, x, z):
        out = []
        for r in self.regs:
            if "rule" in r or not r["shapes"]:
                continue
            wmax, base = 0.0, r["base_m"]
            tmax = ""
            for s in r["shapes"]:
                dx, dz = (x - s["cx"]) / s["rx"], (z - s["cz"]) / s["rz"]
                nd = math.hypot(dx, dz)
                w = 1.0 - sstep(0.70, 1.0, nd)
                if w > wmax:
                    wmax, base, tmax = w, s.get("base_m", r["base_m"]), s.get("tag", "")
            if wmax > 0:
                out.append({"id": r["id"], "w": wmax, "base": base,
                            "micro": r["micro_m"], "meso": r["meso_m"],
                            "pri": r["priority"], "tag": tmax})
        return out

    def classify(self, x, z):
        r = math.hypot(x, z)
        th = CoastLoop.theta(x, z)
        d = self.loop.rs(th) - r
        if d < 0 or r > 2000.0:
            return ("open_water", "", 0.0)
        if self.corridor_dist(x, z) < 0:
            return ("infra_corridors", "", 1.0)
        # Authored lake water owns R12 (strict water nd<1.0; the blend ring
        # keeps its hinterland owner as the shore). Keeps the wetland budget
        # honest: oxbow + broad = ~0.66% + marsh ellipse = ~1.9% of R12.
        for lk in self.lakes:
            if math.hypot((x - lk["cx"]) / lk["rx"], (z - lk["cz"]) / lk["rz"]) < 1.0:
                return ("wetland_inland_water", "", 1.0)
        if d < self.r8_depth:
            # Coast-grid convention: frontage resolves on the LUT theta grid
            # (same round-half-up as lut_at_theta), so owner and beach class
            # always flip at the same cell (found in tuning: exact-theta
            # frontage vs quantized class left a 4 m quay-walled sliver inside
            # the urban owner at node 104).
            idx = int(th / (2 * math.pi) * self.lut_n + 0.5) % self.lut_n
            th_q = idx / self.lut_n * 2 * math.pi
            for (a, b, rid) in self.frontage:
                if self._in_arc(th_q, a, b):
                    return (rid, "", 1.0)
            return ("coastal_beach", "", 1.0)
        ws = self.weights(x, z)
        if not ws:
            return ("reserve_buffer", "", 0.0)
        ws.sort(key=lambda e: (-e["w"], -e["pri"]))
        if ws[0]["w"] < self.fb_threshold:
            return ("reserve_buffer", "", ws[0]["w"])
        return (ws[0]["id"], ws[0]["tag"], ws[0]["w"])

    def blend(self, x, z):
        # Reserve acts as a blend member with the uncovered-fraction weight
        # (quadratic falloff: C1-smooth, full in gaps, zero under full cover).
        # Without it, normalizing by tiny tot in transition gaps amplifies
        # microscopic weight differences into wild base swings (found in tuning:
        # 97-103% phantom grades on corridors crossing reserve feathers).
        ws = self.weights(x, z)
        tot = sum(e["w"] for e in ws)
        wres = (1.0 - min(tot, 1.0)) ** 2
        tot2 = tot + wres
        base = (sum(e["w"] * e["base"] for e in ws) + wres * 20.0) / tot2
        mic = (sum(e["w"] * e["micro"] for e in ws) + wres * 2.0) / tot2
        mes = (sum(e["w"] * e["meso"] for e in ws) + wres * 5.0) / tot2
        return (base, mic, mes)

# ---------------- full field ----------------
class Field:
    def __init__(self):
        self.tc, self.cc, self.au, self.wc = load_all()
        wv, master = self.wc["world_version"], self.wc["master_seed"]
        self.loop = CoastLoop(self.cc, wv, master)
        # LUT size from the contracted sample spacing (N emergent but
        # deterministic: same loop geometry -> same pre-length -> same N).
        pre = [self.loop.point(self.loop.rs(i * 2 * math.pi / 1440.0),
                               i * 2 * math.pi / 1440.0) for i in range(1440)]
        prelen = sum(math.hypot(pre[(i + 1) % 1440][0] - pre[i][0],
                                pre[(i + 1) % 1440][1] - pre[i][1]) for i in range(1440))
        self.lut_n = max(360, int(round(prelen / self.cc["sample_spacing_m"])))
        self.regions = Regions(self.au, self.loop, self.lut_n)
        self.salt_micro = derive_i64(wv, master, "terrain", "micro")
        self.salt_meso = derive_i64(wv, master, "terrain", "meso")
        self.classes = {c["key"]: c for c in self.cc["beach_classes"]}
        # theta LUT (1440): class/width/berm per theta index (uniform theta).
        self.lut = self._build_lut()

    def _width_for(self, cls, curv):
        conc = max(-0.5, min(1.0, -curv * 300.0))
        row = self.classes[cls]
        k = self.cc["authoring"]["width_modulation"]["meso_strength"]
        w = row["base_width_m"] * (1 + k * conc)
        return max(row["width_min_m"], min(row["width_max_m"], w))

    @staticmethod
    def _seg_class(ths_rad, segments):
        for (a, b, cl) in segments:
            if a <= b:
                if a <= ths_rad < b:
                    return cl
            elif ths_rad >= a or ths_rad < b:
                return cl
        raise AssertionError("theta outside segments")

    # ----- coast classification (generation; no terrain sampling) -----
    def _build_lut(self):
        N = self.lut_n
        ths = [i * 2 * math.pi / N for i in range(N)]
        rss = [self.loop.rs(t) for t in ths]
        pts = [self.loop.point(r, t) for r, t in zip(rss, ths)]
        # arc positions
        arc = [0.0]
        for i in range(1, N + 1):
            a, b = pts[i - 1], pts[i % N]
            arc.append(arc[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
        total = arc[-1]
        # signed curvature (per meter), then smoothed. NOTE: segment lengths
        # use sqrt(x*x+y*y), NOT math.hypot: curvature is amplified ~3000x
        # into beach widths, so hypot-vs-sqrt last-ulp differences blow past
        # the 1e-6 cross tolerance. GDScript twin uses the identical form.
        curv = []
        for i in range(N):
            p0, p1, p2 = pts[(i - 1) % N], pts[i], pts[(i + 1) % N]
            t1 = (p1[0] - p0[0], p1[1] - p0[1]); t2 = (p2[0] - p1[0], p2[1] - p1[1])
            cross = t1[0] * t2[1] - t1[1] * t2[0]
            dot = t1[0] * t2[0] + t1[1] * t2[1]
            turn = math.atan2(cross, dot)
            ds = (math.sqrt(t1[0] * t1[0] + t1[1] * t1[1]) +
                math.sqrt(t2[0] * t2[0] + t2[1] * t2[1])) / 2.0
            curv.append(turn / max(ds, 1e-6))
        wc = max(2, int(round(35.0 / (total / N))))
        curv_s = [sum(curv[(i + j) % N] for j in range(-wc, wc + 1)) / (2 * wc + 1)
                  for i in range(N)]
        # meso curvature (micro-free loop): drives beach-width modulation.
        mpts = [self.loop.point(self.loop.rs_meso(t), t) for t in ths]
        mcurv = []
        for i in range(N):
            p0, p1, p2 = mpts[(i - 1) % N], mpts[i], mpts[(i + 1) % N]
            t1 = (p1[0] - p0[0], p1[1] - p0[1]); t2 = (p2[0] - p1[0], p2[1] - p1[1])
            cross = t1[0] * t2[1] - t1[1] * t2[0]
            dot = t1[0] * t2[0] + t1[1] * t2[1]
            turn = math.atan2(cross, dot)
            ds = (math.sqrt(t1[0] * t1[0] + t1[1] * t1[1]) +
                math.sqrt(t2[0] * t2[0] + t2[1] * t2[1])) / 2.0
            mcurv.append(turn / max(ds, 1e-6))
        mcurv_s = [sum(mcurv[(i + j) % N] for j in range(-wc, wc + 1)) / (2 * wc + 1)
                   for i in range(N)]
        # node-table classification (P00 section 20: class changes only at authored
        # nodes; placement rationale per segment lives in coast_contract.json).
        segments = [(math.radians(s["from_deg"]), math.radians(s["to_deg"]), s["class"])
                    for s in self.cc["class_rules"]["segments"]]
        out = []
        probe_d = self.cc["validation"]["normal_probe_m"]
        for i in range(N):
            a = arc[i]
            cls = self._seg_class(ths[i], segments)
            width = self._width_for(cls, mcurv_s[i])
            xi, zi = self.loop.point(rss[i] - probe_d, ths[i])
            owner = self.regions.classify(xi, zi)[0]
            out.append({"theta": ths[i], "rs": rss[i], "arc": a, "class": cls,
                        "width": width, "berm": self.classes[cls]["berm_m"],
                        "curv": curv_s[i], "curv_meso": mcurv_s[i], "region": owner})
        # run-length enforcement: merge runs < 150 m
        runs = self._runs(out, total)
        for (s, e, cl, ln) in runs:
            if ln >= 150.0:
                continue
            # neighbors
            ri = runs.index((s, e, cl, ln))
            prev = runs[(ri - 1) % len(runs)]
            nxt = runs[(ri + 1) % len(runs)]
            winner = prev[2] if (prev[3] > nxt[3] or
                                 (prev[3] == nxt[3] and self.classes[prev[2]]["id"] < self.classes[nxt[2]]["id"])) else nxt[2]
            j = s
            while True:
                out[j]["class"] = winner
                out[j]["width"] = self._width_for(winner, out[j]["curv_meso"])
                out[j]["berm"] = self.classes[winner]["berm_m"]
                if j == e:
                    break
                j = (j + 1) % N
        # Width smoothing (+-5 cells) AFTER run-merge: per-cell widths step
        # at class boundaries, and in the blend zone (d 60-100 m) a width
        # step becomes a blend-rate wall (up to 24 m where a wide beach
        # meets a cliff against high hinterland; found by the validator).
        # Spreading the step over 11 cells keeps adjacent-cell shear under
        # the boundary caps (a +-2 kernel still left 9.6 m at the wide/narrow
        # node against 30 m hinterland); berms stay stepped (authored faces).
        # Kernel (275 m) < min class run (375 m), < meso wavelength (600 m).
        # Authored vs render split: class width ranges are disjoint (wide
        # [80,100], narrow [30,60], cliff [0,15]), so clamping the smoothed
        # width re-pins the center pair and defeats the smoothing (validator
        # found 14.65 m surviving a +-5 kernel). LUT keeps BOTH: "width" is
        # the authored clamped width (design checks read this); "rwidth" is
        # the unclamped smoothed render width, which height() uses so the
        # ground crosses class gaps gradually (a 50 m ecotone, not a wall).
        sm_w = [sum(out[(i + j) % N]["width"] for j in range(-5, 6)) / 11.0
                for i in range(N)]
        for i in range(N):
            row = self.classes[out[i]["class"]]
            out[i]["width"] = max(row["width_min_m"], min(row["width_max_m"], sm_w[i]))
            out[i]["rwidth"] = sm_w[i]
        self.coast_length = total
        self.arc_pts = pts
        return out

    @staticmethod
    def _runs(lut, total):
        N = len(lut)
        # find run starts
        runs = []
        i = 0
        # normalize: start at a class change
        while lut[i]["class"] == lut[(i - 1) % N]["class"]:
            i = (i + 1) % N
            if i == 0:
                break
        start = i
        while True:
            j = start
            while lut[(j + 1) % N]["class"] == lut[start]["class"]:
                j = (j + 1) % N
                if j == start:
                    break
            a0, a1 = lut[start]["arc"], lut[j]["arc"]
            ln = (a1 - a0) % total
            step = total / N
            ln += step  # include last segment
            runs.append((start, j, lut[start]["class"], ln))
            start = (j + 1) % N
            if start == i:
                break
        return runs

    def lut_at_theta(self, th):
        # Round-half-up to nearest sample (NOT floor): sampling exactly at a
        # LUT theta must return that sample's cell. Floor indexing mis-assigns
        # a sliver of coast to the previous cell at class boundaries (found in
        # tuning: marina profile evaluated with the port cell). GDScript twin
        # MUST use the identical rule (cross-impl check enforces it).
        N = len(self.lut)
        return self.lut[int((th % (2 * math.pi)) / (2 * math.pi) * N + 0.5) % N]

    # ----- height field -----
    @staticmethod
    def _seabed(s, prof):
        # Piecewise-smoothstep interpolation of per-class control points.
        if s <= 0:
            return 0.0
        for i in range(len(prof) - 1):
            s0, h0 = prof[i]
            s1, h1 = prof[i + 1]
            if s <= s1:
                return h0 + (h1 - h0) * sstep(s0, s1, s)
        return prof[-1][1]

    def _play_masks(self, x, z):
        # Playability-correction masks (runway strip, lake beds). Masks are
        # evaluated early (micro suppression); absolute blends apply late (§38).
        rw = self.au["runway"]
        hd = math.radians(rw["heading_deg"])
        ax, az = math.sin(hd), -math.cos(hd)
        dx, dz = x - rw["center"][0], z - rw["center"][1]
        u, v = dx * ax + dz * az, -dx * az + dz * ax
        wstrip = ((1 - sstep(rw["length_m"] / 2, rw["length_m"] / 2 + rw["blend_m"], abs(u))) *
                  (1 - sstep(rw["width_m"] / 2, rw["width_m"] / 2 + rw["blend_m"], abs(v))))
        lakes = []
        for lk in self.au["drainage"].get("lakes", []):
            nd = math.hypot((x - lk["cx"]) / lk["rx"], (z - lk["cz"]) / lk["rz"])
            edge = 1.0 + lk["blend_m"] / ((lk["rx"] + lk["rz"]) / 2.0)
            lakes.append((1.0 - sstep(1.0, edge, nd), lk["floor_m"]))
        return wstrip, lakes

    def height_raw(self, x, z, noise=True):
        # noise=False is analysis-only (geography-fraction measurement, §58);
        # GDScript twin implements the same parameter for parity.
        # Composition order follows directive §38: base/macro/regional/landmarks (1-4) ->
        # drainage (5) -> coastal (6) -> playable corrections (8) -> clamp (9,
        # in height()). Masks (runway/lake) are inland-only, hence commute with
        # the coastal stage; they are evaluated early for micro suppression but
        # their absolute blends apply after coastal shaping.
        r = math.hypot(x, z)
        th = CoastLoop.theta(x, z)
        rs = self.loop.rs(th)
        d = rs - r
        cell = self.lut_at_theta(th)
        if d < 0:
            return self._seabed(-d, self.classes[cell["class"]]["seabed_profile"])
        base, mic_amp, mes_amp = self.regions.blend(x, z)
        h = base
        for lf in self.au["landforms"]:
            dx, dz = (x - lf["cx"]) / lf["sx"], (z - lf["cz"]) / lf["sz"]
            h += lf["amp_m"] * math.exp(-0.5 * (dx * dx + dz * dz))
        wstrip, lakes = self._play_masks(x, z)
        mic = self.au["micro"]
        n1 = vnoise(x, z, mic["lambda1_m"], self.salt_micro) - 0.5
        n2 = vnoise(x, z, mic["lambda2_m"], self.salt_micro ^ 0x9E3779B9) - 0.5
        nm = vnoise(x, z, mic["meso_lambda_m"], self.salt_meso) - 0.5
        wmax = max([wstrip] + [w for (w, _) in lakes])
        # River micro-mask: suppress micro noise inside channels so beds
        # drain (validator found 3.7 m ponding on a rough riverbed).
        for rv in self.au["drainage"]["rivers"]:
            dd = self._poly_dist(x, z, rv["points"])
            wmax = max(wmax, 1.0 - sstep(rv["width_m"] / 2.0, rv["width_m"] / 2.0 + 20.0, dd))
        if noise:
            micro = (n1 + mic["oct2_ratio"] * n2) * 2.0 * mic_amp * (1 - 0.9 * wmax)
            # Meso is suppressed by the same play masks: a wavy (meso) bed
            # ponds between crests (validator found 3.3 m of bed undulation
            # ponding the sill reach); channels/valley floors run smooth.
            meso = nm * 2.0 * mes_amp * (1 - 0.9 * wmax)
            h += meso + micro
        # drainage carve
        carve = 0.0
        for rv in self.au["drainage"]["rivers"]:
            dd = self._poly_dist(x, z, rv["points"])
            carve += rv["depth_m"] * (1 - sstep(0, rv["width_m"] / 2, dd))
        for b in self.au["drainage"]["bowls"]:
            dx, dz = (x - b["cx"]) / b["sx"], (z - b["cz"]) / b["sz"]
            carve += b["depth_m"] * math.exp(-0.5 * (dx * dx + dz * dz))
        h -= carve
        # coastal shaping
        bw, berm = cell["rwidth"], cell["berm"]
        prof = berm * sstep(0, max(bw, 6.0), d)
        if d > bw:
            h = prof * (1 - sstep(bw, 150.0, d)) + h * sstep(bw, 150.0, d)
        else:
            h = prof
        # playable corrections (absolute blends; inland-only masks)
        if wstrip > 0:
            h = h * (1 - wstrip) + self.au["runway"]["target_m"] * wstrip
        for (w, floor) in lakes:
            if w > 0:
                h = h * (1 - w) + floor * w
        # Pads flatten to an authored absolute target (same math as the runway
        # strip). An earlier blend-to-noise-free design dug a dimple at the
        # summit (the locked noise is positive there); absolute targets are
        # predictable and validator-checked (peak-inside-pad + target match).
        for pd in self.au.get("pads", []):
            nd = math.hypot((x - pd["cx"]) / pd["r_m"], (z - pd["cz"]) / pd["r_m"])
            w = 1.0 - sstep(1.0, 1.0 + pd["blend_m"] / pd["r_m"], nd)
            if w > 0:
                h = h * (1 - w) + pd["target_m"] * w
        return h

    def height(self, x, z):
        return max(-25.0, min(250.0, self.height_raw(x, z)))

    @staticmethod
    def _poly_dist(x, z, pts):
        return poly_dist(x, z, pts)

    def slope_grade(self, x, z, eps=2.0):
        gx = (self.height(x + eps, z) - self.height(x - eps, z)) / (2 * eps)
        gz = (self.height(x, z + eps) - self.height(x, z - eps)) / (2 * eps)
        g = math.hypot(gx, gz)
        return (math.degrees(math.atan(g)), g * 100.0)

    def is_land(self, x, z):
        r = math.hypot(x, z)
        if r > 2000.0 + 0.001:
            return False
        return (self.loop.rs(CoastLoop.theta(x, z)) - r) > 0

    def is_coast_band(self, x, z):
        r = math.hypot(x, z)
        d = self.loop.rs(CoastLoop.theta(x, z)) - r
        return abs(d) <= 150.0

    def region_at(self, x, z):
        return self.regions.classify(x, z)[0]
