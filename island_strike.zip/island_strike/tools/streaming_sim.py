#!/usr/bin/env python3
"""P07 deterministic world-streaming runtime simulation.

One authoritative streaming owner operating on the REAL P02-P06 derived
data via the sector manifest. Tick-based (tick = 1/60 s simulated); all
logic is deterministic (no wall-clock, no unseeded randomness, canonical
ordering). Wall-clock is used ONLY to measure real op cost (perf_counter)
and real memory (deep sizeof + tracemalloc for process RSS context).

Components: WorldSectorRegistry, SectorManifestService, SectorDependencyGraph,
StreamingManager, StreamingScheduler, SectorLoader, SectorActivator,
SectorDeactivator, SectorCache, LODPolicyManager, StreamingBudgetManager,
StreamingDiagnostics, StreamingProfiler, StreamingValidator.
"""
import copy
import json
import math
import os
import sys
import time
import tracemalloc
from collections import deque

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sector_math import SectorGrid, sector_id  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DD = os.path.join(ROOT, "data/derived")
TICK_DT = 1.0 / 60.0

BANDS = ("CRITICAL", "HIGH", "NORMAL", "BACKGROUND")
BAND_RANK = {b: i for i, b in enumerate(BANDS)}

STATES = ("UNLOADED", "REQUESTED", "QUEUED", "LOADING", "LOADED", "ACTIVATING",
          "ACTIVE", "DEACTIVATING", "UNLOADING", "CACHED", "FAILED", "CANCELLED")
LEGAL = {
    "UNLOADED": ("REQUESTED", "QUEUED"),
    "REQUESTED": ("QUEUED", "CANCELLED", "FAILED"),
    "QUEUED": ("LOADING", "CANCELLED", "FAILED"),
    "LOADING": ("LOADED", "FAILED", "CANCELLED"),
    "LOADED": ("ACTIVATING", "CACHED", "FAILED"),
    "ACTIVATING": ("ACTIVE", "FAILED", "CANCELLED"),
    "ACTIVE": ("DEACTIVATING", "FAILED"),
    "DEACTIVATING": ("UNLOADING", "FAILED"),
    "UNLOADING": ("CACHED", "UNLOADED", "FAILED"),
    "CACHED": ("QUEUED", "UNLOADED", "REQUESTED"),
    "FAILED": ("QUEUED", "UNLOADED", "REQUESTED"),
    "CANCELLED": ("UNLOADED", "REQUESTED", "QUEUED"),
}
LAYERS = ("TERRAIN", "ROAD", "STRUCTURE", "BUILDING", "DETAIL")


def deep_size(o, _seen=None):
    _seen = _seen if _seen is not None else set()
    if id(o) in _seen:
        return 0
    _seen.add(id(o))
    s = sys.getsizeof(o)
    if isinstance(o, dict):
        for k, v in o.items():
            s += deep_size(k, _seen) + deep_size(v, _seen)
    elif isinstance(o, (list, tuple, set, frozenset)):
        for v in o:
            s += deep_size(v, _seen)
    return s


def centroid(pts):
    return (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))


def stats_of(xs):
    if not xs:
        return {"n": 0}
    xs = sorted(xs)
    n = len(xs)
    q = lambda p: xs[min(n - 1, int(p * n))]
    return {"n": n, "min": xs[0], "mean": sum(xs) / n, "median": xs[n // 2],
            "p95": q(0.95), "max": xs[-1]}


# ================================================================ services
class WorldSectorRegistry:
    def __init__(self, manifest):
        self.grid = SectorGrid(manifest["meta"]["sector_size_m"])
        self.sectors = {s["sector_id"]: s for s in manifest["sectors"]}


class SectorManifestService:
    def __init__(self, manifest):
        self.manifest = manifest
        self.by_id = {s["sector_id"]: s for s in manifest["sectors"]}

    def get(self, sid):
        return self.by_id[sid]


class SectorDependencyGraph:
    def __init__(self, manifest):
        self.edges = [(e["source"], e["target"], e["dependency_type"],
                       e["required_state"], e["priority"], e["failure_policy"])
                      for e in manifest["dependency_edges"]]
        self.targets = {}
        for a, b, t, r, p, f in self.edges:
            self.targets.setdefault(b, []).append((a, t, r, p, f))
        self.cycle = self._find_cycle()

    def _find_cycle(self):
        adj = {}
        for a, b, *_ in self.edges:
            adj.setdefault(a, []).append(b)
        color = {}
        stack = []

        def visit(u):
            color[u] = 1
            stack.append(u)
            for v in adj.get(u, ()):  # noqa: B007 - adjacency may miss leaves
                if color.get(v, 0) == 1:
                    return stack[stack.index(v):] + [v]
                if color.get(v, 0) == 0:
                    c = visit(v)
                    if c:
                        return c
            stack.pop()
            color[u] = 2
            return None

        for u in sorted(adj):
            if color.get(u, 0) == 0:
                c = visit(u)
                if c:
                    return c
        return None

    def deps_of(self, node):
        return sorted(self.targets.get(node, ()))


# ================================================================== LOD
class LODPolicyManager:
    def __init__(self, policy):
        self.p = policy
        self.changes = 0
        self._cat = {}
        for kind, cat in policy["categories"].items():
            levels = cat["levels"]
            th = cat["threshold_m"]
            order = [lv for lv in levels if lv in th]
            self._cat[kind] = (levels, order, th, cat["exit_m"])

    def importance_of(self, kind, ref, manifest_refs):
        if kind == "landmark":
            tier = manifest_refs["landmark_tier"].get(ref, "LOCAL")
            return {"WORLD": "CRITICAL", "REGIONAL": "HIGH",
                    "DISTRICT": "HIGH"}.get(tier, "NORMAL")
        if kind == "road":
            cls = manifest_refs["edge_class"].get(ref.split(":")[0]
                                                  if ":" in ref else ref, "local")
            return "HIGH" if cls in ("primary", "arterial", "highway") else "NORMAL"
        if kind == "structure":
            return "HIGH"
        if kind == "building":
            return "NORMAL"
        return "LOW"

    def select(self, kind, dist, importance, current, route_pinned=False):
        levels, order, th, ex = self._cat.get(kind, self._cat["detail"])
        imp = importance
        if route_pinned and kind == "roads":
            imp = "CRITICAL"
        shift = self.p["importance"].get(imp, 0)
        # distance level (highest level whose threshold contains dist)
        base = levels[-1]
        for lv in order:
            if dist <= th[lv]:
                base = lv
                break
        bi = levels.index(base)
        bi = min(len(levels) - 1, max(0, bi - shift))
        want = levels[bi]
        # hysteresis: leaving current level requires passing exit threshold
        if current in th and want != current:
            ci, wi = levels.index(current), levels.index(want)
            if wi > ci:  # degrading: allowed only beyond exit of current
                if dist < ex[current]:
                    return current
            # upgrading is immediate
        return want


# ================================================================ sim core
class SectorCache:
    def __init__(self, max_entries, policy, key):
        assert policy in ("LRU", "DISTANCE", "PRIORITY")
        self.max = max_entries
        self.policy = policy
        self.key = key  # versioned cache key components
        self.store = {}
        self.use_tick = {}
        self.hits = 0
        self.misses = 0
        self.evictions = 0
        self.corrupt_injected = 0

    def cache_key(self, sid):
        return (sid,) + tuple(self.key)

    def get(self, sid, tick):
        k = self.cache_key(sid)
        e = self.store.get(k)
        if e is None:
            self.misses += 1
            return None
        if e.get("corrupt"):
            self.misses += 1
            del self.store[k]
            return None
        self.hits += 1
        self.use_tick[k] = tick
        return e["payload"]

    def put(self, sid, payload, tick, prio=0.0, dist=0.0):
        if len(self.store) >= self.max:
            self._evict(tick)
        k = self.cache_key(sid)
        self.store[k] = {"payload": payload, "prio": prio, "dist": dist}
        self.use_tick[k] = tick

    def _evict(self, tick):
        if not self.store:
            return
        if self.policy == "LRU":
            k = min(self.store, key=lambda k: (self.use_tick.get(k, 0), k))
        elif self.policy == "DISTANCE":
            k = max(self.store, key=lambda k: (self.store[k]["dist"], k))
        else:
            k = min(self.store, key=lambda k: (self.store[k]["prio"],
                                               self.use_tick.get(k, 0), k))
        del self.store[k]
        self.use_tick.pop(k, None)
        self.evictions += 1

    def invalidate(self):
        self.store.clear()
        self.use_tick.clear()

    def memory_bytes(self):
        return sum(deep_size(e["payload"]) for e in self.store.values())


class StreamingManager:
    REQ_SEQ = 0

    def __init__(self, manifest_path, lod_policy_path, config):
        with open(manifest_path) as f:
            manifest = json.load(f)
        with open(lod_policy_path) as f:
            lod = json.load(f)
        self.manifest_path = manifest_path
        self.manifest = manifest
        self.registry = WorldSectorRegistry(manifest)
        self.svc = SectorManifestService(manifest)
        self.graph = SectorDependencyGraph(manifest)
        self.lod = LODPolicyManager(lod)
        self.cfg = config
        self.tick_n = 0
        self.grid = self.registry.grid
        self._sid_idx = {sid: (int(sid[2:4]), int(sid[5:7]))
                         for sid in self.registry.sectors}
        self._want_cache = None
        # source docs (authoritative payloads)
        self.src = {}
        for fn in ("roads.json", "road_geometry.json", "transport_structures.json",
                   "transport_reservations.json", "districts.json", "blocks.json",
                   "parcels.json", "buildings.json", "places.json", "urban_mesh.json"):
            with open(os.path.join(DD, fn)) as f:
                self.src[fn] = json.load(f)
        self._index_sources()
        # runtime state
        self.state = {sid: "UNLOADED" for sid in self.registry.sectors}
        self.payload = {}       # sid -> loaded payload (real data slices)
        self.objects = {}       # oid -> runtime object record
        self.sector_objects = {}  # sid -> [oid]
        self.struct_state = {}  # STRUCT unit -> state
        self.struct_users = {}  # STRUCT unit -> set of active sids
        self.requests = {}      # rid -> request
        self.live_request = {}  # sid -> rid (dedup)
        self.queues = {b: deque() for b in BANDS}
        self.pins = {}          # pin_id -> pin
        self.sector_pins = {}   # sid -> set(pin_id)
        self.pin_seq = 0
        self.activation_queue = deque()  # (sid, layer, [items]) budgeted work
        self.deact_queue = deque()
        # context
        self.cam = (0.0, 0.0)
        self.vel = (0.0, 0.0)
        self.speed = 0.0
        self.route_edges = set()
        self.current_sector = None
        # cache
        ck = (manifest["meta"].get("sector_version", "?"),
              manifest["meta"]["streaming_graph_checksum"],
              str(manifest["meta"]["sector_size_m"]),
              lod.get("meta", {}).get("lod_policy_version", "?"),
              manifest["meta"].get("generation_version", "?"))
        self.cache = SectorCache(config.get("cache_entries_max", 64),
                                 config.get("cache_policy", "DISTANCE"), ck)
        # diagnostics + profiler
        self.events = deque(maxlen=config.get("event_log_max", 5000))
        self.prof = {k: [] for k in ("load", "activate", "deactivate", "unload",
                                     "lod_eval", "schedule", "manifest_query")}
        self.counters = {"requests": 0, "duplicates": 0, "cancelled": 0,
                         "stale": 0, "churn": 0, "prefetch_req": 0,
                         "prefetch_used": 0, "prefetch_wasted": 0,
                         "load_fail": 0, "activate_fail": 0, "spikes": 0}
        self.mem_peak = 0
        self.active_peak = 0
        self.prefetch_peak = 0
        self.queue_peak = 0
        self.frame_times = []
        self.fail_inject = {}  # sid -> fail mode for tests
        tracemalloc.start()

    # ------------------------------------------------------------ sources
    def _index_sources(self):
        b = self.src["buildings.json"]
        self.bld = {x["id"]: x for x in b["buildings"]}
        self.bld_pos = {i: centroid(x["footprint"]) for i, x in self.bld.items()}
        p = self.src["parcels.json"]
        self.par = {x["id"]: x for x in p["parcels"]}
        pl = self.src["places.json"]
        self.lm = {x["id"]: x for x in pl["landmarks"]}
        self.lm_pos = {i: tuple(x["at"]) for i, x in self.lm.items()}
        self.lm_tier = {i: x.get("tier", "LOCAL") for i, x in self.lm.items()}
        self.ops = {x["id"]: x for x in pl["open_spaces"]}
        g = self.src["road_geometry.json"]
        self.stations = {eid: e["stations"] for eid, e in g["edges"].items()}
        r = self.src["roads.json"]
        self.edge_class = {eid: e.get("class", "local") for eid, e in r["edges"].items()}
        self.nodes = r["nodes"]
        # fragment midpoint positions
        self.frag_pos = {}
        for s in self.manifest["sectors"]:
            for fid in s["road_fragment_ids"]:
                if fid in self.frag_pos:
                    continue
                # fid = FRAG-<edge>-<sector>
                eid = fid[len("FRAG-"):fid.rindex("-SX")]
                pts = [(x["x"], x["z"]) for x in self.stations.get(eid, [])]
                self.frag_pos[fid] = centroid(pts) if pts else s and (0.0, 0.0)
        self.refs = {"landmark_tier": self.lm_tier, "edge_class": self.edge_class}

    # ---------------------------------------------------------- diagnostics
    def emit(self, name, sid=None, rid=None, detail=""):
        self.events.append({"tick": self.tick_n, "event": name,
                            "sector": sid, "request": rid, "detail": detail})

    # ------------------------------------------------------------- states
    def transition(self, sid, to, rid=None):
        frm = self.state[sid] if sid in self.state else self.struct_state.get(sid, "?")
        legal = LEGAL.get(frm, ())
        if to not in legal:
            self.emit("ILLEGAL_TRANSITION", sid, rid,
                      "state=%s attempted=%s legal=%s" % (frm, to, list(legal)))
            raise ValueError("illegal transition %s -> %s for %s (request %s)" %
                             (frm, to, sid, rid))
        if sid in self.state:
            self.state[sid] = to
        else:
            self.struct_state[sid] = to
        return frm

    # ------------------------------------------------------------ requests
    def request_sector(self, sid, reason, band, source_context="sim"):
        if sid in self.live_request:
            rid = self.live_request[sid]
            rq = self.requests[rid]
            # merge: raise priority
            if BAND_RANK[band] < BAND_RANK[rq["band"]]:
                try:
                    self.queues[rq["band"]].remove(rid)
                except ValueError:
                    pass
                rq["band"] = band
                self.queues[band].append(rid)
            self.counters["duplicates"] += 1
            self.emit("REQUEST_MERGED", sid, rid, "dup-suppressed")
            return rid
        StreamingManager.REQ_SEQ += 1
        rid = "RQ-%06d" % StreamingManager.REQ_SEQ
        rq = {"request_id": rid, "sector_id": sid, "request_type": "LOAD_ACTIVATE",
              "priority": band, "band": band, "reason": reason,
              "source_context": source_context, "created_tick": self.tick_n,
              "world_version": "p00", "sector_version": self.manifest["meta"].get("sector_version"),
              "content_checksum": self.manifest["checksum"], "state": "OPEN"}
        self.requests[rid] = rq
        self.live_request[sid] = rid
        self.queues[band].append(rid)
        self.counters["requests"] += 1
        if reason == "PREFETCH":
            self.counters["prefetch_req"] += 1
        st = self.state[sid]
        if st in ("UNLOADED", "CANCELLED", "FAILED", "CACHED"):
            self.transition(sid, "REQUESTED", rid)
        self.emit("SECTOR_REQUEST", sid, rid, "%s/%s" % (band, reason))
        return rid

    def cancel_request(self, rid, why):
        rq = self.requests.get(rid)
        if rq is None or rq["state"] != "OPEN":
            return False
        sid = rq["sector_id"]
        for q in self.queues.values():
            try:
                q.remove(rid)
            except ValueError:
                pass
        rq["state"] = "CANCELLED"
        self.live_request.pop(sid, None)
        self.counters["cancelled"] += 1
        if self.state[sid] in ("REQUESTED", "QUEUED"):
            self.transition(sid, "CANCELLED", rid)
            self.transition(sid, "UNLOADED", rid)
        self.emit("REQUEST_CANCEL", sid, rid, why)
        return True

    # ---------------------------------------------------------------- pins
    def pin_sector(self, sid, owner, reason, ttl_ticks=None):
        self.pin_seq += 1
        pid = "PIN-%05d" % self.pin_seq
        self.pins[pid] = {"pin_id": pid, "owner": owner, "reason": reason,
                          "created": self.tick_n,
                          "temporary": ttl_ticks is not None,
                          "expiry": (self.tick_n + ttl_ticks) if ttl_ticks else None,
                          "sector": sid}
        self.sector_pins.setdefault(sid, set()).add(pid)
        self.emit("PIN_CREATE", sid, None, "%s/%s" % (owner, reason))
        return pid

    def release_pin(self, pid):
        pin = self.pins.pop(pid, None)
        if pin is None:
            return False
        s = self.sector_pins.get(pin["sector"])
        if s:
            s.discard(pid)
        self.emit("PIN_RELEASE", pin["sector"], None, pid)
        return True

    def _expire_pins(self):
        for pid, pin in sorted(self.pins.items()):
            if pin["temporary"] and pin["expiry"] is not None and self.tick_n >= pin["expiry"]:
                self.release_pin(pid)

    # -------------------------------------------------------------- context
    def set_context(self, x, z, vx=0.0, vz=0.0, route_edges=()):
        self.cam = (x, z)
        self.vel = (vx, vz)
        self.speed = math.hypot(vx, vz)
        self.route_edges = set(route_edges)
        sx, sz = self.grid.sector_of(x, z)
        self.current_sector = sector_id(sx, sz) if self.grid.in_grid(sx, sz) else None

    def _cheb_to_cam_sector(self, sid):
        if self.current_sector is None:
            return 999
        a = self.grid.sector_of(*self.cam)
        sx, sz = int(sid[2:4]), int(sid[5:7])
        return max(abs(a[0] - sx), abs(a[1] - sz))

    def desired_sets(self):
        """Independent active-set policy (also used by the reference model)."""
        if self._want_cache is not None and self._want_cache[0] == self.tick_n:
            return self._want_cache[1], self._want_cache[2], self._want_cache[3]
        R = self.cfg["streaming_radius"]
        P = self.cfg["prefetch_radius"]
        U = self.cfg["unload_radius"]
        active, prefetch, unload_ok = set(), set(), set()
        if self.current_sector is None:
            alls = set(self.registry.sectors)
            self._want_cache = (self.tick_n, active, prefetch, alls)
            return active, prefetch, alls
        cx, cz = self.grid.sector_of(*self.cam)
        sp = self.speed
        vl = math.hypot(*self.vel) or 1.0
        dx, dz = self.vel[0] / vl, self.vel[1] / vl
        idx = self._sid_idx
        pins = self.sector_pins
        for sid in self.registry.sectors:
            sx, sz = idx[sid]
            ch = max(abs(cx - sx), abs(cz - sz))
            if ch <= R:
                active.add(sid)
            elif ch <= U and self.sector_pins.get(sid):
                active.add(sid)  # pinned sectors stay
            elif ch <= max(P, R + 1) and sp > 0.5:
                # ahead cone prefetch
                mx, mz = self.grid.center(sx, sz)
                rx, rz = mx - self.cam[0], mz - self.cam[1]
                rl = math.hypot(rx, rz) or 1.0
                if (rx * dx + rz * dz) / rl > 0.3:
                    prefetch.add(sid)
            if ch > U and not self.sector_pins.get(sid):
                unload_ok.add(sid)
        self._want_cache = (self.tick_n, active, prefetch, unload_ok)
        return active, prefetch, unload_ok

    # --------------------------------------------------------------- tick
    def tick(self):
        t0 = time.perf_counter()
        self.tick_n += 1
        self._expire_pins()
        want_active, want_pref, unload_ok = self.desired_sets()
        # 1. release stale requests (not wanted, still open, unstarted)
        for sid, rid in sorted(self.live_request.items()):
            rq = self.requests[rid]
            if sid not in want_active and sid not in want_pref and \
                    self.state[sid] in ("REQUESTED", "QUEUED"):
                rq["state"] = "STALE"
                self.counters["stale"] += 1
                self.emit("REQUEST_STALE", sid, rid, "left-want-set")
                self.cancel_request(rid, "stale")
        # 2. request wanted sectors
        for sid in sorted(want_active):
            if self.state[sid] in ("UNLOADED", "CACHED", "FAILED", "CANCELLED") \
                    and sid not in self.live_request:
                band = "CRITICAL" if sid == self.current_sector else "HIGH"
                self.request_sector(sid, "PLAYER", band)
        # budgeted prefetch issue
        pf_budget = self.cfg.get("prefetch_per_tick", 2)
        for sid in sorted(want_pref):
            if pf_budget <= 0:
                break
            if self.state[sid] in ("UNLOADED", "CACHED", "FAILED", "CANCELLED") \
                    and sid not in self.live_request:
                n_pref = sum(1 for s in self.state.values() if s == "LOADED")
                if n_pref >= self.cfg.get("prefetch_sector_cap", 8):
                    break
                self.request_sector(sid, "PREFETCH", "BACKGROUND")
                pf_budget -= 1
        self.prefetch_peak = max(self.prefetch_peak, self.counters["prefetch_req"])
        # request unload for eligible ACTIVE sectors
        for sid in sorted(unload_ok):
            if self.state[sid] == "ACTIVE" and not self.sector_pins.get(sid):
                self.transition(sid, "DEACTIVATING")
                self.deact_queue.append(sid)
                self.emit("SECTOR_DEACTIVATE", sid, None, "unload-eligible")
                self.counters["churn"] += 1
        # 3. aging: promote long-waiting requests (starvation prevention)
        aging = self.cfg.get("aging_ticks", 300)
        for band in ("BACKGROUND", "NORMAL", "HIGH"):
            for rid in list(self.queues[band]):
                rq = self.requests[rid]
                if self.tick_n - rq["created_tick"] > aging:
                    nb = BANDS[BAND_RANK[band] - 1]
                    self.queues[band].remove(rid)
                    rq["band"] = nb
                    rq["priority"] = nb
                    self.queues[nb].append(rid)
                    self.emit("REQUEST_AGED", rq["sector_id"], rid,
                              "%s->%s" % (band, nb))
        # 4. dispatch + pipeline
        t0s = time.perf_counter()
        self._dispatch()
        self._advance_pipeline()
        self.prof["schedule"].append(time.perf_counter() - t0s)
        qn = sum(len(q) for q in self.queues.values())
        self.queue_peak = max(self.queue_peak, qn)
        # 5. LOD eval for active objects near camera (budgeted slice)
        self._eval_lod()
        self.active_peak = max(self.active_peak,
                               sum(1 for s in self.state.values() if s == "ACTIVE"))
        ft = time.perf_counter() - t0
        self.frame_times.append(ft)
        if ft > self.cfg.get("spike_threshold_s", 0.05):
            self.counters["spikes"] += 1
            self.spike_log = getattr(self, "spike_log", [])
            self.spike_log.append({
                "tick": self.tick_n, "frame_ms": round(ft * 1000.0, 2),
                "loading": sum(1 for s in self.state.values() if s == "LOADING"),
                "activating": sum(1 for s in self.state.values() if s == "ACTIVATING"),
                "objects": len(self.objects)})
        # memory-peak sampling AFTER the frame clock stops: deep sizeof is
        # instrumentation overhead, never modeled frame cost (P07-D: spike
        # attribution proved 131/132 spikes were this sampler).
        if self.tick_n % 500 == 0:
            self.mem_peak = max(self.mem_peak, self.memory_bytes()["total"])

    # ------------------------------------------------------------ dispatch
    def _dispatch(self):
        # start queued loads within budget
        loading = sum(1 for s in self.state.values() if s == "LOADING")
        budget = self.cfg.get("load_ops_per_tick", 2)
        while loading < budget:
            rid = None
            for band in BANDS:
                while self.queues[band]:
                    cand = self.queues[band][0]
                    rq = self.requests[cand]
                    if rq["state"] != "OPEN":
                        self.queues[band].popleft()
                        continue
                    rid = cand
                    self.queues[band].popleft()
                    break
                if rid:
                    break
            if rid is None:
                break
            rq = self.requests[rid]
            sid = rq["sector_id"]
            if self.state[sid] in ("REQUESTED", "CACHED", "FAILED", "CANCELLED", "UNLOADED"):
                if self.state[sid] == "REQUESTED":
                    self.transition(sid, "QUEUED", rid)
                elif self.state[sid] != "QUEUED":
                    self.transition(sid, "QUEUED", rid)
                self._start_loading(sid, rid)
                loading += 1
            else:
                rq["state"] = "DONE"
                self.live_request.pop(sid, None)
        # start activating loaded wanted sectors
        want, _, _ = self.desired_sets()
        for sid in sorted(want):
            if self.state[sid] == "LOADED":
                self._start_activating(sid)

    def _advance_pipeline(self):
        # LOADING -> LOADED after load_ticks
        for sid, st in sorted(self.state.items()):
            if st != "LOADING":
                continue
            self.load_ticks[sid] -= 1
            if self.load_ticks[sid] <= 0:
                self._finish_loading(sid)
        # ACTIVATING: budgeted layer work
        per = self.cfg.get("objects_per_frame", 40)
        ms_budget = self.cfg.get("activation_ms_per_tick", 4.0) / 1000.0
        spent = 0.0
        for sid in [s for s in self.activation_queue]:
            if spent >= ms_budget:
                break
            if self.state.get(sid) != "ACTIVATING":
                try:
                    self.activation_queue.remove(sid)
                except ValueError:
                    pass
                continue
            t0 = time.perf_counter()
            self._activate_slice(sid, per)
            spent += time.perf_counter() - t0
        # DEACTIVATING -> UNLOADING -> CACHED/UNLOADED
        while self.deact_queue:
            sid = self.deact_queue.popleft()
            if self.state.get(sid) == "DEACTIVATING":
                self._finish_deactivating(sid)
        for sid, st in sorted(self.state.items()):
            if st == "UNLOADING":
                self._finish_unloading(sid)

    # -------------------------------------------------------------- loader
    def _start_loading(self, sid, rid):
        self.transition(sid, "LOADING", rid)
        self.load_ticks = getattr(self, "load_ticks", {})
        self.load_ticks[sid] = self.cfg.get("load_ticks", 2)
        self.emit("SECTOR_LOAD_START", sid, rid, "")

    def _assemble_payload(self, sid):
        """REAL load work: gather referenced source records (deep copies)."""
        t0 = time.perf_counter()
        s = self.svc.get(sid)
        q0 = time.perf_counter()
        bld = [self.bld[i] for i in s["building_primary"]]
        par = [self.par[i] for i in s["parcel_primary"] if i in self.par]
        lms = [self.lm[i] for i in s["landmark_ids"]]
        ops = [self.ops[i] for i in s["open_primary"] if i in self.ops]
        frags = []
        mnx, mnz, mxx, mxz = s["bounds"]
        for fid in s["road_fragment_ids"]:
            eid = fid[len("FRAG-"):fid.rindex("-SX")]
            sts = [x for x in self.stations.get(eid, [])
                   if mnx - 1.0 <= x["x"] <= mxx + 1.0
                   and mnz - 1.0 <= x["z"] <= mxz + 1.0]
            frags.append({"id": fid, "edge": eid, "stations": sts})
        self.prof["manifest_query"].append(time.perf_counter() - q0)
        payload = {"buildings": copy.deepcopy(bld), "parcels": copy.deepcopy(par),
                   "landmarks": copy.deepcopy(lms), "open": copy.deepcopy(ops),
                   "fragments": copy.deepcopy(frags),
                   "structures": sorted(s["structure_ids"]),
                   "reservations": sorted(s["reservation_ids"]),
                   "districts": sorted(s["district_ids"])}
        self.prof["load"].append(time.perf_counter() - t0)
        return payload

    def _finish_loading(self, sid):
        rid = self.live_request.get(sid)
        if self.fail_inject.get(sid) == "LOAD_FAIL":
            self.transition(sid, "FAILED", rid)
            self.counters["load_fail"] += 1
            self.emit("LOAD_FAIL", sid, rid, "injected")
            if rid:
                self.requests[rid]["state"] = "FAILED"
                self.live_request.pop(sid, None)
            return
        cached = self.cache.get(sid, self.tick_n)
        if cached is not None:
            self.emit("CACHE_HIT", sid, rid, "")
            payload = copy.deepcopy(cached)
        else:
            self.emit("CACHE_MISS", sid, rid, "")
            payload = self._assemble_payload(sid)
        self.payload[sid] = payload
        self.transition(sid, "LOADED", rid)
        self.emit("SECTOR_LOAD_DONE", sid, rid,
                  "bytes=%d" % deep_size(payload))

    # ----------------------------------------------------------- activator
    def _start_activating(self, sid):
        rid = self.live_request.get(sid)
        self.transition(sid, "ACTIVATING", rid)
        self.emit("SECTOR_ACTIVATE_START", sid, rid, "")
        self.act_layers = getattr(self, "act_layers", {})
        s = self.svc.get(sid)
        layers = []
        if True:
            layers.append("TERRAIN")
        if s["road_fragment_ids"]:
            layers.append("ROAD")
        if s["structure_ids"]:
            layers.append("STRUCTURE")
        if s["building_primary"] or s["landmark_ids"]:
            layers.append("BUILDING")
        if s["parcel_primary"] or s["open_primary"] or s["reservation_ids"]:
            layers.append("DETAIL")
        self.act_layers[sid] = layers
        if sid not in self.activation_queue:
            self.activation_queue.append(sid)

    def _activate_slice(self, sid, per):
        rid = self.live_request.get(sid)
        if self.fail_inject.get(sid) == "ACTIVATE_FAIL":
            self.transition(sid, "FAILED", rid)
            self.counters["activate_fail"] += 1
            self.emit("ACTIVATE_FAIL", sid, rid, "injected")
            if rid:
                self.requests[rid]["state"] = "FAILED"
                self.live_request.pop(sid, None)
            try:
                self.activation_queue.remove(sid)
            except ValueError:
                pass
            return
        layers = self.act_layers.get(sid, [])
        if not layers:
            self._finish_activating(sid)
            return
        layer = layers[0]
        # dependency gate: all deps of <sid>:<layer> must be satisfied
        if not self._deps_ready(sid, layer):
            return  # wait (no busy spin cost beyond a tick re-check)
        t0 = time.perf_counter()
        self._activate_layer(sid, layer)
        self.prof["activate"].append(time.perf_counter() - t0)
        layers.pop(0)
        if not layers:
            self._finish_activating(sid)

    def _deps_ready(self, sid, layer):
        node = "%s:%s" % (sid, layer)
        for src, _typ, req, _p, _f in self.graph.deps_of(node):
            if src.startswith("STRUCT-"):
                if self.struct_state.get(src, "UNLOADED") != "ACTIVE":
                    self._activate_struct(src, sid)
                    return False
            else:
                ssid, slayer = src.split(":")
                if slayer == "TERRAIN":
                    if self.state.get(ssid) not in ("ACTIVATING", "ACTIVE"):
                        return False
                else:
                    if self.state.get(ssid) != "ACTIVE":
                        # same-sector earlier layer: satisfied by order
                        if ssid != sid:
                            return False
        return True

    def _activate_struct(self, unit, user_sid):
        if self.struct_state.get(unit) == "ACTIVE":
            self.struct_users.setdefault(unit, set()).add(user_sid)
            return
        self.struct_state[unit] = "ACTIVE"
        self.struct_users.setdefault(unit, set()).add(user_sid)
        for i in range(4):  # structural component objects (deterministic)
            oid = "%s:C%d" % (unit, i)
            if oid not in self.objects:
                self.objects[oid] = {"oid": oid, "kind": "structure",
                                     "ref": unit, "sector": user_sid,
                                     "lod": "FULL", "importance": "HIGH",
                                     "pos": self.grid.center(
                                         *self.grid.sector_of(*self.cam))}
        self.emit("STRUCT_ACTIVE", user_sid, None, unit)

    def _activate_layer(self, sid, layer):
        s = self.svc.get(sid)
        made = []
        if layer == "TERRAIN":
            made = [("terrain", "T-" + sid, self.grid.center(
                int(sid[2:4]), int(sid[5:7])))]
        elif layer == "ROAD":
            made = [("road", fid, self.frag_pos.get(fid, (0.0, 0.0)))
                    for fid in s["road_fragment_ids"]]
        elif layer == "STRUCTURE":
            for unit in s["structure_ids"]:
                self._activate_struct(unit, sid)
            made = []
        elif layer == "BUILDING":
            made = [("building", i, self.bld_pos[i]) for i in s["building_primary"]] + \
                   [("landmark", i, self.lm_pos[i]) for i in s["landmark_ids"]]
        elif layer == "DETAIL":
            made = [("parcel", i, (0.0, 0.0)) for i in s["parcel_primary"]]
        oids = self.sector_objects.setdefault(sid, [])
        for kind, ref, pos in made:
            oid = "%s:%s" % (sid, ref)
            if oid in self.objects:
                raise RuntimeError("duplicate runtime object %s" % oid)
            imp = self.lod.importance_of(kind, ref, self.refs)
            self.objects[oid] = {"oid": oid, "kind": kind, "ref": ref,
                                 "sector": sid, "lod": "FULL" if layer in (
                                     "TERRAIN", "ROAD", "STRUCTURE") else "UNLOADED",
                                 "importance": imp, "pos": pos}
            oids.append(oid)

    def _finish_activating(self, sid):
        rid = self.live_request.get(sid)
        self.transition(sid, "ACTIVE", rid)
        try:
            self.activation_queue.remove(sid)
        except ValueError:
            pass
        if rid:
            self.requests[rid]["state"] = "DONE"
            if self.requests[rid]["reason"] == "PREFETCH":
                # prefetch becomes used when its sector enters the want set
                want, _, _ = self.desired_sets()
                if sid in want:
                    self.counters["prefetch_used"] += 1
                else:
                    self.counters["prefetch_wasted"] += 1
            self.live_request.pop(sid, None)
        self.emit("SECTOR_ACTIVE", sid, rid, "")

    # --------------------------------------------------------- deactivator
    def _finish_deactivating(self, sid):
        t0 = time.perf_counter()
        for oid in self.sector_objects.pop(sid, []):
            self.objects.pop(oid, None)
        # release struct units unused by any ACTIVE sector
        for unit, users in sorted(self.struct_users.items()):
            users.discard(sid)
            if not users and self.struct_state.get(unit) == "ACTIVE":
                self.struct_state[unit] = "UNLOADED"
                for i in range(4):
                    self.objects.pop("%s:C%d" % (unit, i), None)
                self.emit("STRUCT_RELEASE", sid, None, unit)
        self.prof["deactivate"].append(time.perf_counter() - t0)
        self.transition(sid, "UNLOADING")
        self.emit("SECTOR_DEACTIVATE", sid, None, "objects-released")

    def _finish_unloading(self, sid):
        t0 = time.perf_counter()
        payload = self.payload.pop(sid, None)
        if payload is not None:
            s = self.svc.get(sid)
            self.cache.put(sid, payload, self.tick_n, prio=s["priority"],
                           dist=self._cheb_to_cam_sector(sid))
        self.prof["unload"].append(time.perf_counter() - t0)
        # retain metadata in cache, or drop fully if outside + unpinned
        want, _, unload_ok = self.desired_sets()
        if sid in unload_ok and not self.sector_pins.get(sid):
            self.transition(sid, "CACHED")
            # cached payload retained; sector record parks at CACHED
        else:
            self.transition(sid, "CACHED")
        self.emit("SECTOR_UNLOAD", sid, None, "payload-cached")

    # ----------------------------------------------------------------- LOD
    def _eval_lod(self):
        t0 = time.perf_counter()
        cx, cz = self.cam
        n = 0
        cap = self.cfg.get("lod_eval_per_tick", 2000)
        for oid, o in self.objects.items():
            if n >= cap:
                break
            if o["kind"] == "terrain":
                want0 = "FULL" if self.state.get(o["sector"]) == "ACTIVE" else "UNLOADED"
                if o["lod"] != want0:
                    o["lod"] = want0
                n += 1
                continue
            if o["kind"] == "structure":
                want0 = "FULL" if self.struct_state.get(o["ref"]) == "ACTIVE" else "UNLOADED"
                if o["lod"] != want0:
                    o["lod"] = want0
                n += 1
                continue
            if o["kind"] not in ("building", "landmark", "road", "parcel"):
                continue
            if self.state.get(o["sector"]) != "ACTIVE":
                if o["lod"] != "UNLOADED":
                    o["lod"] = "UNLOADED"
                continue
            px, pz = o["pos"]
            dist = math.hypot(px - cx, pz - cz)
            kind = {"building": "buildings", "landmark": "landmarks",
                    "road": "roads", "parcel": "detail"}[o["kind"]]
            pinned = kind == "roads" and o["ref"] in self.route_edges
            want = self.lod.select(kind, dist, o["importance"], o["lod"],
                                   route_pinned=pinned)
            if want != o["lod"]:
                o["lod"] = want
                self.lod.changes += 1
                if self.lod.changes % 50 == 0:
                    self.emit("LOD_CHANGE", o["sector"], None,
                              "%s->%s" % (oid, want))
            n += 1
        self.prof["lod_eval"].append(time.perf_counter() - t0)

    # -------------------------------------------------------------- memory
    def memory_bytes(self):
        runtime = deep_size(self.objects) + deep_size(self.payload)
        cache = self.cache.memory_bytes()
        cur, peak = tracemalloc.get_traced_memory()
        return {"runtime": runtime, "cache": cache, "total": runtime + cache,
                "process_traced_current": cur, "process_traced_peak": peak,
                "gpu_vram": None, "gpu_reason": "headless CPU sim; no GPU context"}

    # ------------------------------------------------------------ snapshot
    def snapshot(self):
        lodc = {}
        for o in self.objects.values():
            lodc[o["lod"]] = lodc.get(o["lod"], 0) + 1
        return {
            "tick": self.tick_n,
            "current_sector": self.current_sector,
            "active": sorted(s for s, st in self.state.items() if st == "ACTIVE"),
            "loaded": sorted(s for s, st in self.state.items()
                             if st in ("LOADED", "ACTIVATING")),
            "prefetch_outstanding": self.counters["prefetch_req"],
            "lod_counts": lodc,
            "lod_changes": self.lod.changes,
            "pins": sorted(self.pins),
            "queues": {b: len(q) for b, q in self.queues.items()},
            "objects": len(self.objects),
            "structs_active": sum(1 for v in self.struct_state.values()
                                  if v == "ACTIVE"),
            "memory": self.memory_bytes(),
            "counters": dict(self.counters),
            "cache": {"hits": self.cache.hits, "misses": self.cache.misses,
                      "evictions": self.cache.evictions,
                      "entries": len(self.cache.store)},
            "prof": {k: stats_of(v) for k, v in self.prof.items()},
            "frame": stats_of(self.frame_times),
            "mem_peak": self.mem_peak, "active_peak": self.active_peak,
            "queue_peak": self.queue_peak,
            "spikes": getattr(self, "spike_log", [])[-20:],
        }

    def hud(self):
        sc = {}
        for st in self.state.values():
            sc[st] = sc.get(st, 0) + 1
        lodc = {}
        for o in self.objects.values():
            lodc[o["lod"]] = lodc.get(o["lod"], 0) + 1
        mem = self.memory_bytes()
        return {"tick": self.tick_n, "current_sector": self.current_sector,
                "states": sc, "lod": lodc, "memory": mem,
                "frame_ms_last": (self.frame_times[-1] * 1000.0
                                  if self.frame_times else 0.0),
                "cache_hits": self.cache.hits, "cache_misses": self.cache.misses,
                "pins": len(self.pins)}


# ================================================================ paths
def _chain_edges(edges, start_node=None):
    """Order edge ids into a connectivity chain (deterministic)."""
    by_from = {}
    for eid, e in edges.items():
        by_from.setdefault(e["from_node"], []).append(eid)
    for v in by_from.values():
        v.sort()
    nxt = sorted(edges)[0] if start_node is None else None
    if start_node is not None:
        cands = by_from.get(start_node, [])
        nxt = cands[0] if cands else sorted(edges)[0]
    order, seen = [], set()
    while nxt and nxt not in seen:
        order.append(nxt)
        seen.add(nxt)
        to = edges[nxt]["to_node"]
        cands = [c for c in by_from.get(to, []) if c not in seen]
        nxt = cands[0] if cands else None
    rest = [e for e in sorted(edges) if e not in seen]
    return order + rest


def ring_loop_path():
    """Full ring-road loop as (x, z) waypoints from P03/P04 locked data."""
    with open(os.path.join(DD, "roads.json")) as f:
        r = json.load(f)
    with open(os.path.join(DD, "road_geometry.json")) as f:
        g = json.load(f)
    ring = {eid: e for eid, e in r["edges"].items()
            if e["route"] in ("ring_hw", "ring_hw_north_tunnel")}
    order = _chain_edges(ring)
    pts = []
    for eid in order:
        for s in g["edges"][eid]["stations"]:
            pts.append((s["x"], s["z"]))
    return pts, order


def node_path(*names):
    with open(os.path.join(DD, "roads.json")) as f:
        r = json.load(f)
    return [(r["nodes"][n]["x"], r["nodes"][n]["z"]) for n in names]


def run_traversal(sim, waypoints, speed, settle_ticks=120, max_ticks=200000,
                  route_edges=()):
    """Drive waypoints at speed m/s; returns per-leg metrics + snapshots."""
    legs = []
    total_skipped = 0
    for a, b in zip(waypoints, waypoints[1:]):
        dist = math.hypot(b[0] - a[0], b[1] - a[1])
        steps = max(1, int(dist / (speed * TICK_DT)))
        if steps > 20000:  # cap: subsample long legs deterministically
            total_skipped += steps - 20000
            steps = 20000
        leg0 = dict(sim.counters)
        for i in range(steps + 1):
            t = i / steps
            x = a[0] + (b[0] - a[0]) * t
            z = a[1] + (b[1] - a[1]) * t
            vx = (b[0] - a[0]) / dist * speed if dist else 0.0
            vz = (b[1] - a[1]) / dist * speed if dist else 0.0
            sim.set_context(x, z, vx, vz, route_edges)
            sim.tick()
            if sim.tick_n > max_ticks:
                break
        legs.append({"from": a, "to": b, "dist": dist, "ticks": steps + 1,
                     "delta": {k: sim.counters[k] - leg0.get(k, 0)
                               for k in sim.counters}})
    for _ in range(settle_ticks):
        sim.set_context(*waypoints[-1], 0.0, 0.0, route_edges)
        sim.tick()
    return {"legs": legs, "subsampled_ticks": total_skipped,
            "snapshot": sim.snapshot()}


DEFAULT_CONFIG = {
    "streaming_radius": 1, "prefetch_radius": 2, "unload_radius": 3,
    "load_ops_per_tick": 2, "load_ticks": 2,
    "objects_per_frame": 40, "activation_ms_per_tick": 4.0,
    "cache_entries_max": 64, "cache_policy": "DISTANCE",
    "prefetch_per_tick": 2, "prefetch_sector_cap": 8,
    "lod_eval_per_tick": 2000, "spike_threshold_s": 0.05,
    "aging_ticks": 300, "event_log_max": 5000,
}