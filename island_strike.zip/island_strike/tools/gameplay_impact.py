"""P10 §83 IMPACT TEST: controlled mutations, contained blast radius.

1. P10 mission policy only -> P10 checksums change, P00-P09 unchanged.
2. P09 perception fixture -> P10 witness outputs change (runtime probe),
   P09 fixture sha changes only as intended, all other inputs stable.
3. P08 traffic fixture -> affected routing outputs change, mission
   source unchanged.
Every mutation is restored; restoration verified byte-identical.
Writes reports/p10/impact.json. Exit 0 iff all expectations hold.
"""
import copy
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
os.chdir(ROOT)

from gameplay_sim import GameWorld  # noqa: E402

DD = os.path.join(ROOT, "data", "derived")
DW = os.path.join(ROOT, "data", "world")
BAK = os.path.join(ROOT, "reports", "p10", ".impact_bak")
P10F = ["gameplay_mission_index.json", "gameplay_objective_graph.json",
        "gameplay_economy.json", "gameplay_wanted.json",
        "gameplay_events.json", "gameplay_save_schema.json",
        "gameplay_manifest.json"]
CHECKS = []


def check(name, cond, detail=""):
    CHECKS.append({"name": name, "pass": bool(cond),
                   "detail": str(detail)[:250]})
    print("  [%s] %-30s %s" % ("OK" if cond else "FAIL", name,
                               str(detail)[:110]), flush=True)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha16_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()[:16]


def regen():
    r = subprocess.run([sys.executable, "tools/gameplay_gen.py"],
                       capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, r.stderr[-500:]


def manifest_checksums():
    with open(os.path.join(DD, "gameplay_manifest.json")) as f:
        m = json.load(f)
    return {k: m[k] for k in
            ("gameplay_checksum", "mission_checksum",
             "objective_graph_checksum", "economy_checksum",
             "wanted_checksum", "event_graph_checksum",
             "save_schema_checksum")}


def p10_bytes():
    out = {}
    for fn in P10F:
        with open(os.path.join(DD, fn), "rb") as f:
            out[fn] = sha(f.read())
    return out


def pin_drift():
    """Recompute the 18 STATIC source pins; return drifted names."""
    with open(os.path.join(DW, "gameplay_contract.json")) as f:
        src = json.load(f)["sources"]
    drift = []
    for k, v in sorted(src.items()):
        if k == "pin_method":
            continue
        base = DW if k.endswith("_contract") else DD
        if sha16_file(os.path.join(base, k + ".json")) != v:
            drift.append(k)
    return drift


def witness_probe():
    """Deterministic witness count: crowd ring at 30m.

    At 30m the no-LOS base conf (0.7-30/100=0.4) is below the 0.5
    report threshold; the +0.2 PLAYER-seen bonus (gated by P09
    los_m) pushes reporters over. Sensitive to los_m by design.
    """
    g = GameWorld(seed_tag="IMPACT-WIT", player_start=(1401.0, 209.0))
    g.npc.auto_spawn = False
    for _ in range(10):
        g.tick()
    px, pz = g.player["x"], g.player["z"]
    for i in range(6):
        a = math.pi * i / 3.0
        n = g.npc.acquire("CIVILIAN", "PZ-D-hub-core",
                          px + math.cos(a) * 30.0,
                          pz + math.sin(a) * 30.0, context="crowd")
        if n is not None:
            n["tier"] = "T3_full"
            n["heading"] = (math.degrees(math.atan2(
                px - n["x"], pz - n["z"])))
    g.npc._rehash()
    for _ in range(10):
        g.tick()
    ok, oid = g.commit_offense("TRESPASS", px, pz)
    assert ok, oid
    return len(g.wanted["offenses"][oid]["witness_context"])


def backup(paths):
    os.makedirs(BAK, exist_ok=True)
    for p in paths:
        shutil.copy2(p, os.path.join(BAK, os.path.basename(p)))


def restore(paths):
    for p in paths:
        shutil.copy2(os.path.join(BAK, os.path.basename(p)), p)


def main():
    os.makedirs(os.path.join(ROOT, "reports", "p10"), exist_ok=True)
    base_cs = manifest_checksums()
    base_bytes = p10_bytes()
    check("pre-green", pin_drift() == [], pin_drift())
    wit0 = witness_probe()
    print("  baseline witnesses(30m): %d" % wit0, flush=True)

    # ---- Test 1: P10 mission policy only (version marker) ----
    gc_path = os.path.join(DW, "gameplay_contract.json")
    backup([gc_path])
    try:
        with open(gc_path) as f:
            gc = json.load(f)
        gc["mission_version"] = "0.1.1-impact-test"
        with open(gc_path, "w") as f:
            json.dump(gc, f, indent=1, sort_keys=True)
        regen()
        cs1 = manifest_checksums()
        check("t1-p10-changes",
              cs1["mission_checksum"] != base_cs["mission_checksum"],
              "%s -> %s" % (base_cs["mission_checksum"],
                            cs1["mission_checksum"]))
        check("t1-upstream-stable", pin_drift() == [], pin_drift())
    finally:
        restore([gc_path])
    regen()
    check("t1-restored", p10_bytes() == base_bytes and
          manifest_checksums() == base_cs)

    # ---- Test 2: P09 perception fixture ----
    pp_path = os.path.join(DD, "npc_perception_policy.json")
    backup([pp_path])
    try:
        with open(pp_path) as f:
            pp = json.load(f)
        pp0 = copy.deepcopy(pp)
        pp["archetypes"]["CIVILIAN"]["los_m"] = 5.0
        with open(pp_path, "w") as f:
            json.dump(pp, f, indent=1, sort_keys=True)
        regen()
        check("t2-derived-stable-content",
              p10_bytes() == base_bytes,
              "perception consumed at runtime, not embedded")
        d = pin_drift()
        check("t2-drift-exactly-perception",
              d == ["npc_perception_policy"], d)
        wit1 = witness_probe()
        check("t2-witness-changes", wit1 != wit0, (wit0, wit1))
        check("t2-others-stable",
              all(k in (["npc_perception_policy"]) for k in d))
    finally:
        restore([pp_path])
    regen()
    check("t2-restored", p10_bytes() == base_bytes and
          pin_drift() == [])
    check("t2-witness-restored", witness_probe() == wit0)

    # ---- Test 3: P08 traffic fixture (spatial: flip a zone map) ----
    tg_path = os.path.join(DD, "traffic_graph.json")
    with open(os.path.join(DD, "gameplay_mission_index.json")) as f:
        midx = json.load(f)
    veh_pts = []
    for m in midx["missions"]:
        for v in m.get("vehicle_roles", []):
            veh_pts.append(
                (m["mission_id"],
                 m["start_conditions"]["player_at"]["point"],
                 v["spawn_zone"]))
    check("t3-have-veh-roles", len(veh_pts) > 0, len(veh_pts))
    with open(tg_path) as f:
        tg = json.load(f)
    zones = tg["spawn_zones"]
    # move the zone serving the first vehicle role far away
    tgt_mid, tgt_pt, tgt_zone = veh_pts[0]
    assert tgt_zone in zones, tgt_zone
    with open(os.path.join(DD, "p06_handoff_missions.json"),
              "rb") as f:
        mh0 = sha(f.read())
    backup([tg_path])
    try:
        zones[tgt_zone]["pos"] = [tgt_pt[0] + 5000.0, 0.0,
                                  tgt_pt[1] + 5000.0]
        with open(tg_path, "w") as f:
            json.dump(tg, f)
        new_sha = sha16_file(tg_path)
        with open(gc_path) as f:
            pinned = json.load(f)["sources"]["traffic_graph"]
        check("t3-fixture-sha-changes", new_sha != pinned,
              "%s -> %s" % (pinned, new_sha))
        regen()
        with open(os.path.join(DD,
                               "gameplay_mission_index.json")) as f:
            midx2 = json.load(f)
        m2 = {m["mission_id"]: m for m in midx2["missions"]}
        new_zone = m2[tgt_mid]["vehicle_roles"][0]["spawn_zone"]
        check("t3-routing-output-changes", new_zone != tgt_zone,
              "%s: %s -> %s" % (tgt_mid, tgt_zone, new_zone))
        with open(os.path.join(
                DD, "p06_handoff_missions.json"), "rb") as f:
            mh = sha(f.read())
        check("t3-mission-source-unchanged", mh == mh0, mh[:16])
        d = pin_drift()
        check("t3-drift-exactly-traffic", d == ["traffic_graph"], d)
    finally:
        restore([tg_path])
    regen()
    check("t3-restored", p10_bytes() == base_bytes and
          pin_drift() == [] and
          manifest_checksums() == base_cs)

    shutil.rmtree(BAK, ignore_errors=True)
    fails = sum(1 for c in CHECKS if not c["pass"])
    doc = {"result": "IMPACT_OK" if not fails else "IMPACT_FAIL",
           "checks": CHECKS,
           "summary": "%d/%d" % (len(CHECKS) - fails, len(CHECKS))}
    with open("reports/p10/impact.json", "w") as f:
        json.dump(doc, f, indent=1)
    print(doc["result"], doc["summary"])
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
