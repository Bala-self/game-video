#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 02 — terrain/coast validation tool (§46 suite).

Subcommands (same pattern as Prompt 01's validate_foundation.py):
  static              No-engine checks: schemas, versions, coast geometry, runs,
                      shares, census, heights, corrections, corridors, tunnel,
                      loops, backing, variance, zones artifact, sector seams,
                      radial sections, stats. Deterministic (fixed grids +
                      random.seed(7), same sampling as tools/tune_terrain.py).
  cross DUMP.json     Cross-layer: GDScript terrain dump vs this Python twin —
                      sampled heights/regions/LUT agreement within 1e-6 rel.
  inject              Failure injection: 10 mutated terrain/coast/authoring
                      inputs must fail loudly via terrain_check.gd (/tmp only).
  reproduce           Determinism: two terrain dumps agree on the stable core.

Exit 0 = all passed; 1 = failure; 2 = usage/not-built. No fakes.
"""
import heapq
import json
import math
import os
import random
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import (Field, CoastLoop, poly_dist, fnv1a_hex,  # noqa: E402
                           lattice, derive_i64, phase_of)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TAU = 2 * math.pi
DISC = math.pi * 2000.0 ** 2
PASS, FAIL = "PASS", "FAIL"

T_PATH = os.path.join(ROOT, "data/world/terrain_contract.json")
C_PATH = os.path.join(ROOT, "data/world/coast_contract.json")
A_PATH = os.path.join(ROOT, "data/terrain/authoring.json")
W_PATH = os.path.join(ROOT, "data/world/world_contract.json")
Z_PATH = os.path.join(ROOT, "data/derived/urban_zones.json")


class Tally:
    def __init__(self):
        self.rows = []

    def check(self, name, cond, detail=""):
        self.rows.append((name, PASS if cond else FAIL, str(detail)))

    def report(self, title):
        fails = [r for r in self.rows if r[1] == FAIL]
        print(f"{title}: {len(self.rows)-len(fails)}/{len(self.rows)} passed")
        for n, s, d in self.rows:
            print(f"  [{s}] {n}  {d}")
        return len(fails) == 0


def godot_bin() -> str:
    for cand in [os.environ.get("GODOT_BIN"), os.path.join(ROOT, "tools/.godot/godot"),
                 shutil.which("godot")]:
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    raise SystemExit("Godot binary not found (set GODOT_BIN or run tools/fetch_godot.py)")


def run_godot(args, timeout=240):
    cmd = [godot_bin(), "--headless", "--path", ROOT] + args
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout, p.stderr


def hinterland(f, x, z):
    ws = f.regions.weights(x, z)
    if not ws:
        return ("reserve_buffer", "")
    ws.sort(key=lambda e: (-e["w"], -e["pri"]))
    top = ws[0]
    if top["w"] < 0.15:
        return ("reserve_buffer", "")
    return (top["id"], top["tag"])


def ell_nd(x, z, s):
    return math.hypot((x - s["cx"]) / s["rx"], (z - s["cz"]) / s["rz"])


def sample_polyline(P, step_m=10.0):
    path = []
    for i in range(len(P) - 1):
        ax0, az0 = P[i]
        bx0, bz0 = P[i + 1]
        L = math.hypot(bx0 - ax0, bz0 - az0)
        n = max(1, int(L / step_m))
        for j in range(n):
            path.append((ax0 + (bx0 - ax0) * j / n, az0 + (bz0 - az0) * j / n))
    path.append(tuple(P[-1]))
    return path


def profile(f, path):
    hs = [f.height(x, z) for (x, z) in path]
    ds = [0.0]
    for i in range(1, len(path)):
        ds.append(ds[-1] + math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1]))
    win = 5
    sm = [sum(hs[max(0, i - win):i + win + 1]) / len(hs[max(0, i - win):i + win + 1])
          for i in range(len(hs))]
    step = ds[1] - ds[0] if len(ds) > 1 else 10.0
    gr = [abs(sm[i + 1] - sm[i]) / step * 100.0 for i in range(len(sm) - 1)]
    w200 = max(1, int(200 / step))
    roll = [sum(gr[max(0, i - w200 + 1):i + 1]) / len(gr[max(0, i - w200 + 1):i + 1])
            for i in range(len(gr))]
    return ds, sm, gr, roll


# ---------------- static (§46) ----------------
def cmd_static():
    import time
    t0 = time.time()
    t = Tally()
    f = Field()
    N = len(f.lut)
    loop_len = f.coast_length

    # ---- S-schema + versions (per-file: one drift must not mask others) ----
    try:
        import jsonschema
        have_js = True
    except ImportError:
        have_js = False
    for dp, sp in [(T_PATH, "data/world/terrain_contract.schema.json"),
                   (C_PATH, "data/world/coast_contract.schema.json"),
                   (A_PATH, "data/terrain/authoring.schema.json"),
                   (W_PATH, "data/world/world_contract.schema.json")]:
        name = "S-schema:%s" % os.path.basename(dp)
        if not have_js:
            t.check(name, False, "need jsonschema")
            continue
        try:
            d = json.load(open(os.path.join(ROOT, dp) if not os.path.isabs(dp) else dp))
            s = json.load(open(os.path.join(ROOT, sp)))
            jsonschema.validate(d, s)
            t.check(name, True)
        except Exception as e:
            t.check(name, False, e)
    tc, cc, au, wc = f.tc, f.cc, f.au, f.wc
    t.check("S-ver:authoring", au["meta"]["authoring_version"] == tc["authoring_version"],
            "%s vs %s" % (au["meta"]["authoring_version"], tc["authoring_version"]))
    t.check("S-ver:world", au["meta"]["world_version"] == wc["world_version"] == tc["world_version"])
    t.check("S-ver:coastline", tc["coastline_version"] == cc["coast_version"],
            "%s vs %s" % (tc["coastline_version"], cc["coast_version"]))
    t.check("S-ver:seed", tc["master_seed_reference"] == wc["master_seed"])
    t.check("S-ver:world-id", tc["world_id"] == wc["world_id"] == cc["world_id"])
    t.check("S-ver:radius", tc["world_radius_m"] == wc["radius_m"])
    t.check("S-ver:caps", tc["min_height_m"] == wc["terrain_min_m"]
            and tc["absolute_max_height_m"] == wc["terrain_absolute_cap_m"]
            and tc["ocean_level_m"] == wc["ocean_level_m"])
    # Twin self-tests (this tool validates itself first).
    t.check("S-FNV-terrain", fnv1a_hex("terrain") == fnv1a_hex("terrain"))
    t.check("S-lattice-det", lattice(3, -5, 7) == lattice(3, -5, 7)
            and 0.0 <= lattice(3, -5, 7) < 1.0, lattice(3, -5, 7))
    s1 = derive_i64(wc["world_version"], wc["master_seed"], "terrain", "micro")
    t.check("S-seed-stable", s1 == f.salt_micro)
    t.check("S-phase-range", 0.0 <= phase_of(s1) < TAU)

    # ---- C-coast ----
    nodes = cc["class_rules"]["nodes_deg"]
    t.check("C-nodes-sorted-unique", nodes == sorted(set(nodes)), nodes)
    segs = cc["class_rules"]["segments"]
    t.check("C-segments-cover-360",
            abs(sum((s["to_deg"] - s["from_deg"]) % 360 for s in segs) - 360) < 1e-9)
    t.check("C-lut-n", N == max(360, round(loop_len / cc["sample_spacing_m"])), N)
    eff = loop_len / N
    t.check("C-spacing", abs(eff - cc["sample_spacing_m"]) <= cc["validation"]["spacing_tol_m"],
            "%.3f" % eff)
    mean_rs = sum(e["rs"] for e in f.lut) / N
    nom_t, shp_t = loop_len / (TAU * 2000.0), loop_len / (TAU * mean_rs)
    tb = cc["tortuosity_target"]
    t.check("C-tortuosity", tb[0] <= nom_t <= tb[1] and shp_t <= cc["tortuosity_limit"],
            "nom=%.4f shape=%.4f" % (nom_t, shp_t))
    env = cc["authoring"]["envelope"]
    rss = [e["rs"] for e in f.lut]
    t.check("C-envelope", min(rss) >= env["min_m"] and max(rss) <= env["max_m"],
            "rs %.1f..%.1f" % (min(rss), max(rss)))
    t.check("C-max-radial", max(rss) <= cc["validation"]["max_radial_m"])
    kmax = max(abs(e["curv"]) for e in f.lut)
    t.check("C-curvature", kmax < cc["validation"]["max_curvature_per_m"], "%.5f" % kmax)
    runs = Field._runs(f.lut, loop_len)
    t.check("C-min-run", min(r[3] for r in runs) >= cc["validation"]["min_run_m"],
            "%.0f" % min(r[3] for r in runs))
    t.check("C-classes-9", len(set(e["class"] for e in f.lut)) == 9)
    hist = {}
    for (_, _, cl, ln) in runs:
        hist[cl] = hist.get(cl, 0) + ln
    for b in cc["beach_classes"]:
        got = 100 * hist.get(b["key"], 0) / loop_len
        ok = abs(got - b["share_pct"]) <= max(
            cc["validation"]["share_tol_rel"] * b["share_pct"],
            cc["validation"]["share_tol_abs_pp"])
        t.check("C-share:%s" % b["key"], ok, "got=%.1f tgt=%.1f" % (got, b["share_pct"]))
    bad_adj = 0
    harbor_adj = 0
    for k in range(len(runs)):
        a, b = runs[k][2], runs[(k + 1) % len(runs)][2]
        pair = {a, b}
        if "cliff" in pair and pair & {"industrial_port", "marina"}:
            bad_adj += 1
        if pair <= {"industrial_port", "marina", "urban_waterfront"} and a != b:
            harbor_adj += 1
    t.check("C-adjacency-cliff-port", bad_adj == 0, "harbor_internal_adj=%d (allowed)" % harbor_adj)
    # radial approximation: d(theta) vs true shore distance
    pts = f.arc_pts
    worst_ra = 0.0
    for deg in range(0, 360, 5):
        th = math.radians(deg)
        rs = f.loop.rs(th)
        for d in (40.0, 100.0, 200.0):
            x, z = (rs - d) * math.sin(th), -(rs - d) * math.cos(th)
            true = min(math.hypot(x - px, z - pz) for (px, pz) in pts[::4])
            worst_ra = max(worst_ra, abs(d - true))
    t.check("C-radial-approx", worst_ra <= cc["validation"]["radial_approx_tol_m"],
            "worst=%.1f" % worst_ra)
    # waterline: h(d=0) == 0 at every class exemplar
    wl = max(abs(f.height(e["rs"] * math.sin(e["theta"]), -e["rs"] * math.cos(e["theta"])))
             for e in f.lut[::40])
    t.check("C-waterline", wl <= cc["validation"]["waterline_tolerance_m"], "%.4f" % wl)
    # boundary steps at quantized class flips
    bcaps = tc["validation"]["boundary_step_caps_m"]
    worst_nc, worst_c = 0.0, 0.0
    for i in range(N):
        if f.lut[i]["class"] == f.lut[(i + 1) % N]["class"]:
            continue
        ca, cb = f.lut[i]["class"], f.lut[(i + 1) % N]["class"]
        cap = bcaps["cliff"] if "cliff" in (ca, cb) else bcaps["non_cliff"]
        for dd in (20.0, 60.0, 100.0):
            ha, hb = None, None
            for j, kk in ((i, 0.4), ((i + 1) % N, -0.4)):
                thj = ((j + (0.4 if kk > 0 else -0.4)) % N) / N * TAU
                rsj = f.loop.rs(thj)
                hj = f.height((rsj - dd) * math.sin(thj), -(rsj - dd) * math.cos(thj))
                ha = hj if ha is None else ha
                hb = hj if j != i else hb
            st = abs(ha - hb)
            if "cliff" in (ca, cb):
                worst_c = max(worst_c, st)
            else:
                worst_nc = max(worst_nc, st)
    t.check("C-boundary-step-noncliff", worst_nc <= bcaps["non_cliff"], "worst=%.2f" % worst_nc)
    t.check("C-boundary-step-cliff", worst_c <= bcaps["cliff"], "worst=%.2f" % worst_c)
    # LUT width clamping
    wbad = 0
    for e in f.lut:
        row = f.classes[e["class"]]
        if not (row["width_min_m"] <= e["width"] <= row["width_max_m"]):
            wbad += 1
    t.check("C-width-clamp", wbad == 0)

    # ---- R-region census (8 m grid, disc-based §7) ----
    counts, land = {}, 0
    for gz in range(-250, 250):
        for gx in range(-250, 250):
            x, z = gx * 8 + 4, gz * 8 + 4
            if x * x + z * z > 2000 * 2000:
                continue
            rid = f.region_at(x, z)
            if rid == "open_water":
                continue
            land += 1
            counts[rid] = counts.get(rid, 0) + 1
    B = tc["budgets"]["region_share_pct"]
    for rid, tgt in sorted(B.items(), key=lambda kv: -kv[1]):
        got = 100 * counts.get(rid, 0) * 64 / DISC
        ok = abs(got - tgt) <= max(tc["validation"]["region_tol_rel"] * tgt,
                                   tc["validation"]["region_tol_abs_pp"])
        t.check("R-share:%s" % rid, ok,
                "got=%.1f tgt=%.1f area=%.3fkm2" % (got, tgt, counts.get(rid, 0) * 64 / 1e6))
    t.check("R-land-area", abs(land * 64 / 1e6 - 11.68) < 0.15, "%.2fkm2" % (land * 64 / 1e6))

    # ---- H-heights (8 m grid, land) + defects ----
    hgrid = {}
    hmin, hmax, hsum, hn = 1e9, -1e9, 0.0, 0
    peak, peak_xy = -1e9, (0, 0)
    over220, clamped250 = 0, 0
    for gz in range(-250, 250):
        for gx in range(-250, 250):
            x, z = gx * 8 + 4, gz * 8 + 4
            if x * x + z * z > 2000 * 2000 or not f.is_land(x, z):
                continue
            h = f.height(x, z)
            hgrid[(gx, gz)] = h
            hn += 1
            hsum += h
            # H-min is a lagoon check (closed land below sea): the river
            # thalweg is exempt (estuary beds below sea near the mouth are
            # normal; the flood's sea-connection test guards them instead).
            in_chan = any(f._poly_dist(x, z, rv["points"]) < rv["width_m"] / 2.0 + 10.0
                          for rv in au["drainage"]["rivers"])
            if not in_chan:
                hmin = min(hmin, h)
            hmax = max(hmax, h)
            if h > peak:
                peak, peak_xy = h, (x, z)
            if h > 220.0:
                over220 += 1
            if f.height_raw(x, z) > 250.0:
                clamped250 += 1
    pb = tc["validation"]["peak_design_band_m"]
    t.check("H-peak-band", pb[0] <= peak <= pb[1], "%.1f at %s" % (peak, peak_xy))
    t.check("H-over220", over220 == 0, over220)
    t.check("H-clamped250", clamped250 == 0, clamped250)
    t.check("H-min", hmin >= -0.05, "%.2f" % hmin)
    # spikes
    spikes = 0
    for (gx, gz), h in hgrid.items():
        nbs = [hgrid.get((gx + dx, gz + dz)) for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1))]
        nbs = [v for v in nbs if v is not None]
        if nbs and abs(h - sum(nbs) / len(nbs)) > tc["validation"]["spike_threshold_m"]:
            spikes += 1
    t.check("H-spikes", spikes == 0, spikes)
    # plateaus outside authored flats (runway/lake/pad masks)
    rw = au["runway"]
    plats = 0
    for gz in range(-240, 240, 5):
        for gx in range(-240, 240, 5):
            win = [hgrid.get((gx + dx, gz + dz)) for dx in range(-2, 3) for dz in range(-2, 3)]
            win = [v for v in win if v is not None]
            if len(win) < 20:
                continue
            if max(win) - min(win) > tc["validation"]["plateau_max_range_m"]:
                continue
            x, z = gx * 8 + 4, gz * 8 + 4
            wstrip, lakes = f._play_masks(x, z)
            in_flat = wstrip > 0.05 or any(w > 0.05 for (w, _) in lakes)
            for pd in au.get("pads", []):
                nd = math.hypot((x - pd["cx"]) / pd["r_m"], (z - pd["cz"]) / pd["r_m"])
                if nd < 1.0 + pd["blend_m"] / pd["r_m"]:
                    in_flat = True
            if not in_flat:
                # Functional-flat regions (contract plateau_exclusion): pads,
                # not dead noise. Variance floors still guard these regions.
                if f.regions.classify(x, z)[0] in ("industrial_flats", "port_airfield",
                                                   "urban_core", "wetland_inland_water"):
                    continue
                plats += 1
    t.check("H-plateau-only-authored", plats == 0, plats)
    # basins: priority-flood trap depth (P00 §8; lakes exempt; <256 m2 ignored)
    land_cells = set(hgrid)
    spill = {}
    pq = []
    for cell in land_cells:
        gx, gz = cell
        edge = gx in (-250, 249) or gz in (-250, 249)
        adj = any((gx + dx, gz + dz) not in land_cells
                  for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        if edge or adj:
            spill[cell] = hgrid[cell]
            heapq.heappush(pq, (hgrid[cell], cell))
    while pq:
        s, cell = heapq.heappop(pq)
        if s > spill[cell] + 1e-9:
            continue
        gx, gz = cell
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nb = (gx + dx, gz + dz)
            if nb not in land_cells or nb in spill:
                continue
            # Sea-connected water propagates freely at/below the waterline
            # tolerance (contract basin_rule): tidal channels and estuary
            # reaches are open water, not basins.
            ns = hgrid[nb] if s <= tc["validation"]["waterline_tolerance_m"] else max(hgrid[nb], s)
            spill[nb] = ns
            heapq.heappush(pq, (ns, nb))
    trap = {cell: spill[cell] - hgrid[cell] for cell in land_cells}
    lakes = au["drainage"].get("lakes", [])
    def in_lake(x, z):
        return any(ell_nd(x, z, lk) < 1.3 for lk in lakes)
    wet = {cell for cell in land_cells if trap[cell] > tc["validation"]["waterline_tolerance_m"]
           and not in_lake(cell[0] * 8 + 4, cell[1] * 8 + 4)}
    seen_b, comps_b = set(), []
    for cell in wet:
        if cell in seen_b:
            continue
        stack, comp = [cell], []
        seen_b.add(cell)
        while stack:
            c0 = stack.pop()
            comp.append(c0)
            for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nb = (c0[0] + dx, c0[1] + dz)
                if nb in wet and nb not in seen_b:
                    seen_b.add(nb)
                    stack.append(nb)
        comps_b.append(comp)
    min_cells = int(math.ceil(tc["validation"]["basin_area_floor_m2"] / 64.0))
    big = [c for c in comps_b if len(c) >= min_cells]
    max_trap = max((max(trap[c] for c in c0) for c0 in big), default=0.0)
    basin_area_pct = 100 * sum(len(c0) for c0 in big) * 64 / (land * 64)
    t.check("H-basin-depth", max_trap <= tc["validation"]["basin_max_depth_m"],
            "max_trap=%.2fm n_basins=%d" % (max_trap, len(big)))
    t.check("H-basin-area", basin_area_pct <= tc["validation"]["basin_max_area_pct"],
            "%.3f%%" % basin_area_pct)
    # seabed monotonic per class exemplar
    seen_c = {}
    for e in f.lut:
        seen_c.setdefault(e["class"], e)
    mono_bad = 0
    for cl, e in sorted(seen_c.items()):
        th, rs = e["theta"], e["rs"]
        sea = [f.height((rs + s) * math.sin(th), -(rs + s) * math.cos(th))
               for s in (50.0, 150.0, 300.0)]
        if not (sea[0] >= sea[1] >= sea[2]) or sea[0] > 0.5:
            mono_bad += 1
    t.check("H-seabed-monotonic", mono_bad == 0)

    # ---- F-runway / river / cliff / pads / lake ----
    hd = math.radians(rw["heading_deg"])
    ax, az = math.sin(hd), -math.cos(hd)
    cx, cz = rw["center"]
    devs = []
    for u in range(-400, 401, 20):
        for v in (-40, -20, 0, 20, 40):
            x, z = cx + u * ax - v * az, cz + u * az + v * ax
            devs.append(abs(f.height(x, z) - rw["target_m"]))
    grade_rw = max(devs) / rw["length_m"] * 100.0
    t.check("F-runway-grade", grade_rw <= tc["validation"]["runway_grade_pct"],
            "max_dev=%.3fm" % max(devs))
    riv = au["drainage"]["rivers"][0]
    pts = riv["points"]
    hs_r, carves = [], []
    for i, (px, pz) in enumerate(pts):
        h = f.height(px, pz)
        hs_r.append(h)
        # River points inside authored lake water have no thalweg (a broad
        # is open water, not a channel): carve is meaningless there.
        if any(math.hypot((px - lk["cx"]) / lk["rx"], (pz - lk["cz"]) / lk["rz"]) < 1.0
               for lk in au["drainage"].get("lakes", [])):
            continue
        # Hillside channels contour across fall lines, so one perpendicular
        # can run along the contour (both banks low) or into a side gully;
        # the max over 8 rays finds the true up-slope bank (pt1: 0.84->5.96).
        ho = max(f.height(px + math.sin(k * math.pi / 4) * 40.0,
                          pz - math.cos(k * math.pi / 4) * 40.0) for k in range(8))
        carves.append(ho - h)
    t.check("F-river-descends", hs_r[0] > hs_r[-1] and hs_r[0] > 50.0, hs_r)
    t.check("F-river-carve", min(carves[1:-1]) >= 2.0,
            "min=%.1f" % min(carves[1:-1]))
    t.check("F-river-mouth", hs_r[-1] < 0.5, hs_r[-1])
    for rec in cc.get("cliff_safety", []):
        a0, a1 = (math.radians(rec["segment_deg"][0]), math.radians(rec["segment_deg"][1]))
        mid = (a0 + (a1 - a0) % TAU / 2) % TAU if False else None
        # circular midpoint of the segment
        span = (a1 - a0) % TAU
        thc = (a0 + span / 2) % TAU
        rsc = f.loop.rs(thc)
        h4 = f.height((rsc - 4) * math.sin(thc), -(rsc - 4) * math.cos(thc))
        h0 = f.height(rsc * math.sin(thc), -rsc * math.cos(thc))
        slope = math.degrees(math.atan((h4 - h0) / 4.0))
        h150 = f.height((rsc - 150) * math.sin(thc), -(rsc - 150) * math.cos(thc))
        ok = (abs(slope - rec["slope_deg"]) <= 10.0
              and abs(h4 - rec["face_m"]) <= 4.0
              and abs(h150 - rec["crest_m"]) <= 15.0)
        t.check("F-cliff:%g-%g" % tuple(rec["segment_deg"]), ok,
                "slope=%.0f face=%.1f crest=%.1f" % (slope, h4, h150))
    pad = next(p for p in au.get("pads", []) if p["id"] == "summit_pad")
    # Local cap (not global inside): the island max on a noisy dome jumps
    # between bumps under any mask retune, so the pad caps its SITE: the max
    # over the (r+blend)*2 box must sit on the pad (target = dome max + plinth).
    _R = (pad["r_m"] + pad["blend_m"]) * 2.0
    _lx, _ly, _lh = pad["cx"], pad["cz"], -1e9
    _k = int(_R / 8.0)
    for _gz in range(-_k, _k + 1):
        for _gx in range(-_k, _k + 1):
            _h = f.height(pad["cx"] + _gx * 8.0, pad["cz"] + _gz * 8.0)
            if _h > _lh:
                _lh, _lx, _ly = _h, pad["cx"] + _gx * 8.0, pad["cz"] + _gz * 8.0
    pdd = math.hypot(_lx - pad["cx"], _ly - pad["cz"])
    ptop = f.height(pad["cx"], pad["cz"])
    pw = 0.0
    for k in range(24):
        a = k * TAU / 24
        for rr in (8, 16, 24):
            deg, _ = f.slope_grade(pad["cx"] + rr * math.sin(a), pad["cz"] + rr * math.cos(a))
            pw = max(pw, deg)
    t.check("F-pad-peak-inside", pdd <= pad["r_m"], "dist=%.0f" % pdd)
    t.check("F-pad-top", abs(ptop - pad["target_m"]) < 0.05, ptop)
    t.check("F-pad-slope", pw <= 8.0, "%.1f" % pw)
    lk = au["drainage"]["lakes"][0]
    hc = f.height(lk["cx"], lk["cz"])
    rim = min(f.height(lk["cx"] + lk["rx"] * 1.6 * math.sin(a),
                       lk["cz"] + lk["rz"] * 1.6 * math.cos(a))
              for a in [i * TAU / 16 for i in range(16)])
    t.check("F-lake-enclosed", rim > lk["level_m"] and abs(hc - lk["floor_m"]) < 0.05,
            "floor=%.1f rim=%.1f level=%.1f" % (hc, rim, lk["level_m"]))

    # ---- G-corridors ----
    gcaps = tc["validation"]["corridor_ground_caps_pct"]
    tch = tc["validation"]["tunnel_checks"]
    ring_path = None
    for cor in au["corridors"]:
        if cor["type"] == "ring":
            n = int(TAU * cor["r_m"] / 10.0)
            path = [(cor["r_m"] * math.sin(i * TAU / n), -cor["r_m"] * math.cos(i * TAU / n))
                    for i in range(n)]
        else:
            path = sample_polyline(cor["points"])
        if cor["id"] == "ring_hw":
            ring_path = path
        ds, sm, gr, roll = profile(f, path)
        if cor["type"] == "tunnel":
            hp0 = f.height(*cor["portals"][0])
            hp1 = f.height(*cor["portals"][1])
            tg = abs(hp1 - hp0) / ds[-1] * 100.0
            bore_y = [hp0 + (hp1 - hp0) * d / ds[-1] for d in ds]
            cover = [s - b for (s, b) in zip(sm, bore_y)]
            deep = [c for (c, d) in zip(cover, ds) if 150 < d < ds[-1] - 150]
            P = [tuple(p) for p in cor["points"]]
            bends = []
            for i in range(1, len(P) - 1):
                v1 = (P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1])
                v2 = (P[i + 1][0] - P[i][0], P[i + 1][1] - P[i][1])
                bends.append(math.degrees(math.acos(max(-1.0, min(1.0, (
                    v1[0] * v2[0] + v1[1] * v2[1]) / (math.hypot(*v1) * math.hypot(*v2)))))))
            bend = max(bends)
            t.check("G-tunnel:%s" % cor["id"],
                    tg <= tch["bore_grade_pct"] and min(deep) >= tch["min_cover_m"]
                    and bend <= tch["max_bend_deg"],
                    "grade=%.2f cover=%.0f bend=%.1f" % (tg, min(deep), bend))
            for (px, pz), pr in zip(cor["portals"], cor["portal_works_r_m"]):
                r = math.hypot(px, pz)
                th = math.degrees(math.atan2(px, -pz)) % 360
                dd = f.loop.rs(math.radians(th)) - r
                t.check("G-portal-d:%d,%d" % (px, pz), dd >= tch["portal_min_d_shore_m"],
                        "d=%.0f" % dd)
                pg = max(f.slope_grade(px + dx, pz + dz)[1]
                         for dx, dz in ((25, 0), (-25, 0), (0, 25), (0, -25)))
                t.check("G-portal-ground:%d,%d" % (px, pz), pg <= tch["portal_max_ground_pct"],
                        "%.1f%%" % pg)
            continue
        cap = gcaps[cor["class"]]
        # Portal works discs are P04 earthworks pads (benched to design
        # grade): open-alignment caps apply outside them; inside, the 25%
        # portal-ground and 15% portal-approach checks govern instead.
        works = [(tuple(pp), pr) for c2 in au["corridors"] if c2["type"] == "tunnel"
                 for (pp, pr) in zip(c2["portals"], c2["portal_works_r_m"])]
        def in_works(pt):
            return any(math.hypot(pt[0] - w[0][0], pt[1] - w[0][1]) < w[1] for w in works)
        gr_o = [g for (g, pt) in zip(gr, path) if not in_works(pt)] or [0.0]
        roll_o = [g for (g, pt) in zip(roll, path) if not in_works(pt)] or [0.0]
        short, sust = max(gr_o), max(roll_o)
        t.check("G-grade:%s" % cor["id"], short <= cap["short"] and sust <= cap["sustained"],
                "short=%.1f sust=%.1f len=%.1fkm" % (short, sust, ds[-1] / 1000))
    # portal approach legs (last 250 m of ring at each portal end) <= 15%
    ringc = next(c for c in au["corridors"] if c["id"] == "ring_hw")
    tunc = next(c for c in au["corridors"] if c["id"] == "ring_hw_north_tunnel")
    for pi, portal in enumerate(tunc["portals"]):
        acc, worst_leg = 0.0, 0.0
        P = ringc["points"] if pi == 0 else list(reversed(ringc["points"]))
        for i in range(len(P) - 1):
            a, b = P[i], P[i + 1]
            L = math.hypot(b[0] - a[0], b[1] - a[1])
            if acc > 250.0:
                break
            worst_leg = max(worst_leg, abs(f.height(*b) - f.height(*a)) / max(L, 1e-6) * 100.0)
            acc += L
    # NOTE: ring endpoints are the portals (shared points); approach = first legs
        t.check("G-portal-approach:%d" % pi, worst_leg <= 15.0, "%.1f%%" % worst_leg)
    # exclusions along ring
    excl = {}
    for r in au["regions"]:
        for s in r.get("shapes", []):
            tag = s.get("tag") or r["id"]
            if r["id"] == "urban_core" and tag == "urban_core":
                excl["urban"] = (s, 1.05)
            if tag == "port_shape":
                excl["port_shape"] = (s, 1.15)
            if tag == "resort_shape":
                excl["resort"] = (s, 1.10)
            if tag == "restricted_shape":
                excl["restricted"] = (s, 1.05)
    scan = ring_path[::3]
    for name, (s, floor) in sorted(excl.items()):
        m = min(ell_nd(x, z, s) for (x, z) in scan)
        t.check("G-excl:%s" % name, m >= floor, "min_nd=%.3f" % m)
    rwc = [max(rw["center"][0] - rw["length_m"] / 2 - 60 - x,
               x - (rw["center"][0] + rw["length_m"] / 2 + 60),
               rw["center"][1] - rw["width_m"] / 2 - 60 - z,
               z - (rw["center"][1] + rw["width_m"] / 2 + 60)) for (x, z) in scan]
    t.check("G-excl:runway", min(rwc) >= 0, "%.0fm" % min(rwc))
    lkm = min(ell_nd(x, z, lk) for (x, z) in scan)
    t.check("G-excl:lake", lkm >= 1.30, "%.3f" % lkm)
    # portals clear of exclusions (>= 100 m from shape boundary)
    for (px, pz) in tunc["portals"]:
        clears = []
        for name, (s, _) in excl.items():
            nd = ell_nd(px, pz, s)
            clears.append((nd - 1.0) * min(s["rx"], s["rz"]) if nd >= 1.0 else -1.0)
        clears.append(min(
            max(rw["center"][0] - rw["length_m"] / 2 - px, px - (rw["center"][0] + rw["length_m"] / 2),
                rw["center"][1] - rw["width_m"] / 2 - pz, pz - (rw["center"][1] + rw["width_m"] / 2)), 1e9))
        clears.append((ell_nd(px, pz, lk) - 1.0) * min(lk["rx"], lk["rz"]))
        t.check("G-portal-clear:%d,%d" % (px, pz),
                min(clears) >= tch["portal_clear_exclusion_m"], "%.0fm" % min(clears))
    # junctions
    for cid in ("radial_north", "radial_south", "radial_west"):
        c = next(x for x in au["corridors"] if x["id"] == cid)
        p = c["points"][-1]
        dd = poly_dist(p[0], p[1], ringc["points"])
        t.check("G-junction:%s" % cid, dd <= 15.0, "%.1fm" % dd)
    sp = next(x for x in au["corridors"] if x["id"] == "spur_restricted_access")
    s0, s1 = sp["points"][0], sp["points"][-1]
    d0 = math.hypot(s0[0] - tunc["portals"][0][0], s0[1] - tunc["portals"][0][1])
    t.check("G-junction:spur-start", d0 <= tunc["portal_works_r_m"][0], "%.1fm" % d0)
    g = ell_nd(s1[0], s1[1], excl["restricted"][0])
    t.check("G-junction:spur-gate", abs(g - 1) <= 0.05, "|nd-1|=%.3f" % abs(g - 1))

    # ---- L-loops ----
    for lp in au["loops"]:
        seq, seen_seq = lp["sequence"], []
        last = None
        W = lp["waypoints"]
        touched = set()
        for i in range(len(W) - 1):
            ax0, az0 = W[i]
            bx0, bz0 = W[i + 1]
            L = math.hypot(bx0 - ax0, bz0 - az0)
            n = max(1, int(L / 25.0))
            for j in range(n + 1):
                if i > 0 and j == 0:
                    continue
                x = ax0 + (bx0 - ax0) * j / n
                z = az0 + (bz0 - az0) * j / n
                rid = f.region_at(x, z)
                if rid == "infra_corridors":
                    rid = hinterland(f, x, z)[0]
                for cid in lp.get("crosses_corridors", []):
                    cc2 = f.regions.corridors[cid]
                    if cc2["type"] == "tunnel":
                        continue
                    dd = poly_dist(x, z, cc2["points"])
                    if dd < cc2["width_m"] / 2.0:
                        touched.add(cid)
                if rid != last:
                    seen_seq.append(rid)
                    last = rid
        si, ok = 0, True
        for want in seq:
            try:
                si = seen_seq.index(want, si) + 1
            except ValueError:
                ok = False
                break
        t.check("L-seq:%s" % lp["id"], ok, " > ".join(seen_seq))
        t.check("L-cross:%s" % lp["id"],
                set(lp.get("crosses_corridors", [])) <= touched, sorted(touched))

    # ---- B-backing (§79 probes at d=+40) ----
    def probe(deg):
        th = math.radians(deg)
        rs = f.loop.rs(th)
        x, z = (rs - 40) * math.sin(th), -(rs - 40) * math.cos(th)
        return f.region_at(x, z), hinterland(f, x, z)
    for deg in (88, 92, 96, 100, 102, 104):
        _, (rid, _) = probe(deg)
        t.check("B-urban-core:%d" % deg, rid == "urban_core", rid)
    for deg in (80, 84):
        _, (rid, _) = probe(deg)
        t.check("B-urban-tip:%d" % deg, rid in ("reserve_buffer", "urban_core"), rid)
    for deg in (108, 112, 116):
        _, (rid, tag) = probe(deg)
        t.check("B-port:%d" % deg, rid == "port_airfield" and tag == "port_shape",
                "%s/%s" % (rid, tag))
    _, (rid120, _) = probe(120)
    t.check("B-port-edge:120", rid120 in ("port_airfield", "reserve_buffer", "suburban_ring"),
            rid120)
    for deg in (127, 134):
        ow, (rid, _) = probe(deg)
        t.check("B-marina:%d" % deg, ow == "port_airfield" and rid == "suburban_ring",
                "owner=%s back=%s" % (ow, rid))
    _, (rid230, tag230) = probe(230)
    t.check("B-resort-tip:230", rid230 == "special_restricted" and tag230 == "resort_shape",
            "%s/%s" % (rid230, tag230))
    for deg in (234, 238, 240):
        ow, (rid, tag) = probe(deg)
        t.check("B-resort:%d" % deg,
                ow == "special_restricted" and rid == "special_restricted" and tag == "resort_shape",
                "owner=%s" % ow)
    for deg in (12, 16, 20):
        _, (rid, tag) = probe(deg)
        t.check("B-restricted:%d" % deg, rid == "special_restricted" and tag == "restricted_shape",
                "%s/%s" % (rid, tag))
    for deg in (8, 0):
        _, (rid, _) = probe(deg)
        t.check("B-hills:%d" % deg, rid == "hills_highland", rid)
    _, (rid306, _) = probe(306)
    t.check("B-nw:306", rid306 == "reserve_buffer", rid306)

    # ---- V-variance + geography (§13 sample, seed 7) ----
    random.seed(7)
    cells = []
    for _ in range(20000):
        x = random.uniform(-1900, 1900)
        z = random.uniform(-1900, 1900)
        if x * x + z * z > 2000 * 2000 or not f.is_land(x, z):
            continue
        if f.loop.rs(CoastLoop.theta(x, z)) - math.hypot(x, z) < 150:
            continue
        cells.append((x, z))
    per, hg_all, hn_all = {}, [], []
    for (x, z) in cells:
        h = f.height(x, z)
        g = f.height_raw(x, z, noise=False)
        hg_all.append(h)
        hn_all.append(g)
        per.setdefault(f.region_at(x, z), []).append(h)
    for rid, floor in sorted(tc["validation"]["variance_floors_m"].items()):
        hs = per.get(rid, [])
        m = sum(hs) / max(1, len(hs))
        sd = (sum((v - m) ** 2 for v in hs) / max(1, len(hs))) ** 0.5
        t.check("V-floor:%s" % rid, sd >= floor, "std=%.1f n=%d" % (sd, len(hs)))
    mg = sum(hg_all) / len(hg_all)
    vg = sum((v - mg) ** 2 for v in hg_all) / len(hg_all)
    nv = sum((a - b) ** 2 for a, b in zip(hg_all, hn_all)) / len(hg_all)
    gf = 1 - nv / vg
    t.check("V-geography", gf >= tc["validation"]["geography_fraction_floor"], "%.3f" % gf)

    # ---- Z-zones artifact ----
    try:
        zd = json.load(open(Z_PATH))
        payload = zd["payload"]
        canon = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        t.check("Z-checksum", fnv1a_hex(canon) == zd["checksum_hex"], zd["checksum_hex"])
        vers = payload["versions"]
        t.check("Z-versions", vers["terrain_version"] == tc["terrain_version"]
                and vers["coast_version"] == cc["coast_version"]
                and vers["authoring_version"] == au["meta"]["authoring_version"]
                and vers["world_version"] == wc["world_version"], vers)
        comps = payload["components"]
        t.check("Z-nonempty", len(comps) >= 1, "%d comps" % len(comps))
        bad_cells, spot = 0, 0
        x0, z0 = payload["extent"][0], payload["extent"][1]
        cell = payload["cell_m"]
        for comp in comps:
            for (i, j) in comp["cells"][::7]:
                spot += 1
                x, z = x0 + i * cell + cell / 2, z0 + j * cell + cell / 2
                _, grade = f.slope_grade(x, z)
                r = math.hypot(x, z)
                d = f.loop.rs(math.atan2(x, -z) % TAU) - r
                if not (f.region_at(x, z) == "urban_core" and grade <= 2.0 and d > 150.0):
                    bad_cells += 1
        t.check("Z-spotcheck", bad_cells == 0, "%d/%d bad" % (bad_cells, spot))
    except FileNotFoundError:
        t.check("Z-exists", False, "run tools/derive_zones.py")

    # ---- E-sector seams (±1 m, grade-aware 0.01 m; node rays get step bounds) ----
    nodes_rad = [math.radians(v) % TAU for v in nodes]
    def near_node(x, z):
        r = math.hypot(x, z)
        if r < 1.0:
            return None
        th = math.atan2(x, -z) % TAU
        for nd in nodes_rad:
            dt = abs((th - nd + math.pi) % TAU - math.pi)
            if r * dt < 25.0:
                return nd
        return None
    seam_bad, seam_n = 0, 0
    for k in range(1, 16):
        s = -2048.0 + 256.0 * k
        for q in range(-1980, 1981, 16):
            for (x, z, nx, nz) in ((s, q, 1.0, 0.0), (q, s, 0.0, 1.0)):
                if x * x + z * z > 1980 * 1980:
                    continue
                h_a = f.height(x + nx, z + nz)
                h_b = f.height(x - nx, z - nz)
                _, gr = f.slope_grade(x, z)
                bound = gr / 100.0 * 2.0 + tc["validation"]["sector_seam_tolerance_m"]
                nd = near_node(x, z)
                if nd is not None:
                    ia = int((nd % TAU) / TAU * N + 0.5 - 1) % N
                    ib = int((nd % TAU) / TAU * N + 0.5 + 1) % N
                    cap = (bcaps["cliff"] if "cliff" in (f.lut[ia]["class"], f.lut[ib]["class"])
                           else bcaps["non_cliff"]) + 0.5
                    bound = max(bound, cap)
                seam_n += 1
                if abs(h_a - h_b) > bound:
                    seam_bad += 1
    t.check("E-sector-seams", seam_bad == 0, "%d/%d bad" % (seam_bad, seam_n))

    # ---- X-§83 radial sections (gate 5 m/10 m; 3-5 m = flagged half-bench) ----
    xgate = tc["validation"]["radial_section_gate_m"]
    xbench = tc["validation"]["radial_bench_flag_m"]
    x_bad, x_worst, x_flags = 0, 0.0, []
    for cid in ("radial_north", "radial_south", "radial_west", "spur_restricted_access"):
        c = next(x for x in au["corridors"] if x["id"] == cid)
        path = sample_polyline(c["points"], step_m=100.0)
        for i in range(len(path) - 1):
            ax0, az0 = path[i]
            bx0, bz0 = path[i + 1]
            L = math.hypot(bx0 - ax0, bz0 - az0) or 1.0
            nx, nz = -(bz0 - az0) / L, (bx0 - ax0) / L
            mx, mz = (ax0 + bx0) / 2, (az0 + bz0) / 2
            prof = [f.height(mx + nx * o, mz + nz * o) for o in (-20, -10, 0, 10, 20)]
            for a, b in zip(prof, prof[1:]):
                st = abs(a - b)
                x_worst = max(x_worst, st)
                if st > xgate:
                    x_bad += 1
                elif st > xbench:
                    x_flags.append("%s@(%.0f,%.0f):%.1fm" % (cid, mx, mz, st))
    t.check("X-radial-sections", x_bad == 0,
            "worst=%.2fm halfbench=%d%s" % (x_worst, len(x_flags),
                                            " [" + "; ".join(x_flags[:6]) + "]" if x_flags else ""))

    # ---- A-stats: spacing, S-05 lengths, checksum ----
    arcs = []
    for b in cc["authoring"]["bays"]:
        i = int(round(math.radians(b["theta_deg"]) / TAU * N)) % N
        arcs.append((b["id"], f.lut[i]["arc"]))
    arcs.sort(key=lambda e: e[1])
    gaps = [ (arcs[(k + 1) % len(arcs)][1] - arcs[k][1]) % loop_len for k in range(len(arcs))]
    t.check("A-spacing", min(gaps) >= cc["validation"]["min_feature_spacing_m"],
            "min=%.0f" % min(gaps))
    surf_len = 0.0
    for cor in au["corridors"]:
        if cor["type"] == "tunnel":
            continue
        P = cor["points"]
        surf_len += sum(math.hypot(P[i + 1][0] - P[i][0], P[i + 1][1] - P[i][1])
                        for i in range(len(P) - 1))
    t.check("A-S05-total", abs(surf_len / 1000 - 21.5) <= 0.25 * 21.5,
            "surface=%.1fkm vs est 21.5" % (surf_len / 1000))

    # ---- K-cache invalid test (throwaway entry; repo artifacts untouched) ----
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import numpy as np
        from terrain_cache import cached_grid, CACHE_DIR
        calls = []
        def _compute():
            calls.append(1)
            return {"v": np.arange(4, dtype=np.float64)}
        _, s1 = cached_grid("_kprobe", {"n": 1}, _compute)
        _, s2 = cached_grid("_kprobe", {"n": 1}, _compute)
        ok_hit = (s1, s2, len(calls)) == ("MISS-recomputed", "HIT", 1)
        with open(os.path.join(CACHE_DIR, "_kprobe.npz"), "r+b") as fh:
            fh.seek(100)
            b = fh.read(1)
            fh.seek(100)
            fh.write(bytes([b[0] ^ 0xFF]))
        _, s3 = cached_grid("_kprobe", {"n": 1}, _compute)
        ok_corrupt = (s3 == "CORRUPT-recomputed" and len(calls) == 2)
        meta_p = os.path.join(CACHE_DIR, "_kprobe.json")
        meta = json.load(open(meta_p))
        meta["versions"]["terrain_version"] = "9.9.9"
        json.dump(meta, open(meta_p, "w"))
        _, s4 = cached_grid("_kprobe", {"n": 1}, _compute)
        ok_ver = (s4 == "MISS-recomputed" and len(calls) == 3)
        os.remove(os.path.join(CACHE_DIR, "_kprobe.npz"))
        os.remove(meta_p)
        t.check("K-cache-hit", ok_hit, "%s/%s" % (s1, s2))
        t.check("K-cache-corrupt", ok_corrupt, s3)
        t.check("K-cache-version", ok_ver, s4)
    except Exception as e:
        t.check("K-cache", False, e)

    print("elapsed %.1fs" % (time.time() - t0))
    return t.report("STATIC-TERRAIN")


# ---------------- cross / inject / reproduce (wired after the GDScript twin lands) ----
def cmd_cross(dump_path):
    t = Tally()
    try:
        dump = json.load(open(dump_path))
    except Exception as e:
        t.check("X-load", False, e)
        return t.report("CROSS-TERRAIN")
    f = Field()
    tol = f.tc["validation"]["cross_impl_rel_tol"]
    lut = dump.get("lut", [])
    bad = 0
    for row in lut:
        e = f.lut[row["i"]]
        for k in ("theta", "rs", "arc", "width", "rwidth", "berm", "curv", "curv_meso"):
            a, b = row[k], e[k]
            denom = max(1.0, abs(a), abs(b))
            if abs(a - b) / denom > tol:
                bad += 1
        if row["class"] != e["class"] or row["region"] != e["region"]:
            bad += 1
    t.check("X-lut", bad == 0, "%d/%d bad" % (bad, len(lut)))
    bad = 0
    for s in dump.get("height_samples", []):
        h = f.height(s["x"], s["z"])
        denom = max(1.0, abs(h), abs(s["h"]))
        if abs(h - s["h"]) / denom > tol:
            bad += 1
        if f.region_at(s["x"], s["z"]) != s["region"]:
            bad += 1
    t.check("X-heights", bad == 0, "%d/%d bad" % (bad, len(dump.get("height_samples", []))))
    bad = 0
    for s in dump.get("noise_samples", []):
        a = f.height_raw(s["x"], s["z"], noise=False)
        denom = max(1.0, abs(a), abs(s["g"]))
        if abs(a - s["g"]) / denom > tol:
            bad += 1
    t.check("X-noisefree", bad == 0, "%d/%d bad" % (bad, len(dump.get("noise_samples", []))))
    # X-seams: replay the exact seam-probe loop, compare heights (tol) + continuity (±ε).
    bad = 0
    if "seams" not in dump:
        t.check("X-seams-present", False, "dump lacks 'seams' (regenerate dump)")
        return t.report("CROSS-TERRAIN")
    t.check("X-seams-present", True, "%d vals" % len(dump["seams"]))
    seam_vals = dump["seams"]
    n = 0
    eps_tol = f.tc["validation"]["sector_seam_tolerance_m"]
    nodes_rad = [math.radians(v) % TAU for v in f.cc["class_rules"]["nodes_deg"]]
    bcaps = f.tc["validation"]["boundary_step_caps_m"]
    N = len(f.lut)
    disc = 0
    for k in range(1, 16):
        s = -2048.0 + 256.0 * k
        q = -1980.0
        while q <= 1980.0:
            for (bx, bz, dx, dz) in ((s, q, 1.0, 0.0), (q, s, 0.0, 1.0)):
                if bx * bx + bz * bz > 1980.0 * 1980.0:
                    continue
                ha = f.height(bx + dx, bz + dz)
                hb = f.height(bx - dx, bz - dz)
                if n + 1 >= len(seam_vals):
                    t.check("X-seams", False, "dump truncated at %d/%d" % (n, len(seam_vals)))
                    return t.report("CROSS-TERRAIN")
                for v, ref in ((ha, seam_vals[n]), (hb, seam_vals[n + 1])):
                    denom = max(1.0, abs(v), abs(ref))
                    if abs(v - ref) / denom > tol:
                        bad += 1
                _, gr = f.slope_grade(bx, bz)
                bound = gr / 100.0 * 2.0 + eps_tol
                rr = math.hypot(bx, bz)
                if rr >= 1.0:
                    th = math.atan2(bx, -bz) % TAU
                    for nd in nodes_rad:
                        if rr * abs((th - nd + math.pi) % TAU - math.pi) < 25.0:
                            ia = int((nd % TAU) / TAU * N + 0.5 - 1) % N
                            ib = int((nd % TAU) / TAU * N + 0.5 + 1) % N
                            cap = (bcaps["cliff"] if "cliff" in (f.lut[ia]["class"],
                                                                 f.lut[ib]["class"])
                                   else bcaps["non_cliff"]) + 0.5
                            bound = max(bound, cap)
                            break
                if abs(ha - hb) > bound:
                    disc += 1
                n += 2
            q += 64.0
    t.check("X-seams", bad == 0, "%d/%d bad" % (bad, n))
    t.check("X-seam-continuity", disc == 0, "%d/%d discont" % (disc, n // 2))
    return t.report("CROSS-TERRAIN")


TERRAIN_TOOL = "res://tests/godot/tools/terrain_check.gd"


def cmd_inject():
    t = Tally()
    base_a = json.load(open(A_PATH))
    base_c = json.load(open(C_PATH))
    base_t = json.load(open(T_PATH))
    import copy
    cases = []
    # (name, which_file, mutate_fn)
    def m_nodes(c):
        c["class_rules"]["nodes_deg"] = [14.0, 32.0]  # truncated
    def m_share(c):
        c["beach_classes"][0]["share_pct"] = -5.0
    def m_spacing(c):
        c["sample_spacing_m"] = 0.0
    def m_cliff(c):
        c["cliff_safety"] = []
    def m_width(a):
        a["corridors"][2]["width_m"] = 0.0
    def m_tunnel(a):
        del a["corridors"][1]["portals"]
    def m_pad(a):
        del a["pads"][0]["target_m"]
    def m_lake(a):
        a["drainage"]["lakes"][0]["floor_m"] = 99.0  # above rim -> unenclosed
    def m_runway(a):
        a["runway"]["blend_m"] = -10.0
    def m_loop(a):
        a["loops"][0]["sequence"] = ["no_such_region"]
    cases = [("nodes-truncated", "c", m_nodes), ("share-negative", "c", m_share),
             ("spacing-zero", "c", m_spacing), ("cliff-missing", "c", m_cliff),
             ("width-zero", "a", m_width), ("tunnel-no-portals", "a", m_tunnel),
             ("pad-no-target", "a", m_pad), ("lake-unenclosed", "a", m_lake),
             ("runway-neg-blend", "a", m_runway), ("loop-bad-region", "a", m_loop)]
    for name, which, fn in cases:
        c = copy.deepcopy(base_c if which == "c" else base_a)
        fn(c)
        p = "/tmp/is_tinject_%s.json" % name
        json.dump(c, open(p, "w"))
        args = ["--script", TERRAIN_TOOL, "--", "--validate",
                "--coast" if which == "c" else "--authoring", p]
        ec, out, _ = run_godot(args)
        detected = (ec != 0) and ("TERRAIN_FAIL" in out)
        t.check("I-%s" % name, detected, "exit=%d" % ec)
        os.remove(p)
    t.check("I-repo-clean", json.load(open(A_PATH)) == base_a and json.load(open(C_PATH)) == base_c)
    return t.report("INJECT-TERRAIN")


def cmd_reproduce():
    t = Tally()
    outs = []
    for i in (1, 2):
        p = "/tmp/is_trepro_%d.json" % i
        ec, out, _ = run_godot(["--script", TERRAIN_TOOL, "--", "--dump", p])
        t.check("R-run%d-exit" % i, ec == 0 and "TERRAIN_OK" in out, "exit=%d" % ec)
        if ec != 0:
            return t.report("REPRODUCE-TERRAIN")
        d = json.load(open(p))
        d.pop("generated_at", None)
        d.get("engine", {}).pop("version", None)
        outs.append(d)
    a, b = outs
    for k in ("lut_digest", "lut", "height_samples", "noise_samples", "census"):
        t.check("R-stable:%s" % k, a.get(k) == b.get(k))
    return t.report("REPRODUCE-TERRAIN")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    cmd = argv[1]
    if cmd == "static":
        return 0 if cmd_static() else 1
    if cmd == "cross":
        if len(argv) < 3:
            print("usage: validate_terrain.py cross DUMP.json")
            return 2
        return 0 if cmd_cross(argv[2]) else 1
    if cmd == "inject":
        return 0 if cmd_inject() else 1
    if cmd == "reproduce":
        return 0 if cmd_reproduce() else 1
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
