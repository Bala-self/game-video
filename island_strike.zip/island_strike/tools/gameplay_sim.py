#!/usr/bin/env python3
"""ISLAND STRIKE P10 — deterministic gameplay runtime (reference sim).

Integrates locked P08 traffic + P09 NPC/navigation/perception under one
10 Hz fixed-step world with player context, mission engine, economy
owner, wanted/police owner, event bus, world state, and save/load.

Ownership (never bypassed):
  P08 TrafficWorld: vehicles, routes, signals (via npc.traffic).
  P09 NPCWorld: NPCs, paths, perception, witness facts, sector pins.
  P10 GameWorld: player context, missions, economy, wanted, bus, saves.
"""
import copy
import json
import math
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from npc_sim import NPCWorld, rng_for, FIXED_STEP  # noqa: E402
from gameplay_gen import (point_in_bounds, bounds_center,  # noqa: E402
                          canon, fnv1a64_hex)

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
DD = os.path.join(ROOT, "data", "derived")
DW = os.path.join(ROOT, "data", "world")
SAVE_DIR = os.path.join(ROOT, "reports", "p10", "saves")

BUS_CAP = 512
MAX_INT = 2 ** 63 - 1


def _load(fn, world=False):
    with open(os.path.join(DW if world else DD, fn)) as f:
        return json.load(f)


class GameWorld:
    def __init__(self, seed_tag="g0", player_start=(1401.0, 209.0),
                 with_traffic=True, start_money=500):
        self.seed_tag = seed_tag
        self.tick_n = 0
        self.gc = _load("gameplay_contract.json", world=True)
        self.ec = _load("economy_contract.json", world=True)
        self.wc = _load("wanted_contract.json", world=True)
        self.missions = {
            m["mission_id"]: m
            for m in _load("gameplay_mission_index.json")["missions"]}
        self.graphs = _load("gameplay_objective_graph.json")["graphs"]
        self.eco = _load("gameplay_economy.json")
        self.wtd = _load("gameplay_wanted.json")
        self.wevents = {
            e["event_id"]: dict(e, state="DORMANT")
            for e in _load("gameplay_events.json")["events"]}
        self.districts = {d["id"]: d for d in
                           _load("districts.json")["districts"]}
        self.move_m = self.gc["mission_policy"]["transitions"]
        self.obj_m = self.gc["objective_policy"]["transitions"]
        self.want_m = self.wc["wanted_policy"]["transitions"]
        self.pursuit_m = self.wc["pursuit"]["transitions"]
        self.wevt_m = self.gc["world_event_policy"]["transitions"]
        self.rng = {s: rng_for("gameplay", s, seed_tag)
                    for s in ("mission", "economy", "wanted", "event",
                              "world")}
        # world stack (P08 inside P09; P10 never bypasses either)
        self.npc = NPCWorld(seed_tag=seed_tag + ":npc",
                            focus=player_start,
                            with_traffic=with_traffic)
        self.traffic = self.npc.traffic
        # player context (§5)
        self.player = {"player_id": "PLAYER-01",
                       "x": player_start[0], "z": player_start[1],
                       "vx": 0.0, "vz": 0.0, "heading": 0.0,
                       "sector": self.npc.sector_of(*player_start),
                       "vehicle": None, "mission": None,
                       "money": start_money, "wanted_state": "NONE",
                       "interaction": "IDLE", "health": 100,
                       "move_target": None, "speed_cap": 1.4}
        self.npc.set_player(player_start[0], player_start[1])
        if self.traffic is not None:
            self.traffic.set_player(player_start[0], player_start[1])
        # economy owner (§24)
        self.wallet = {"currency": "ISC", "balance": start_money,
                       "holds": {}}
        self.txns = {}
        self.txn_seq = 0
        # mission engine (§11/§12, single-active P10-D1)
        self.mstates = {mid: "UNAVAILABLE" for mid in self.missions}
        for mid in self.missions:
            self.mstates[mid] = "AVAILABLE"
        self.active = None
        self.inst_seq = 0
        self.cooldowns = {}
        self.completed = set()
        # wanted owner (§30/§33/§37)
        self.wanted = {"level": "NONE", "chain": "NONE",
                       "offenses": {}, "off_seq": 0,
                       "last_offense_tick": -10 ** 9,
                       "pursuit": None, "inc_seq": 0}
        # event bus (§21/§22)
        self.bus = []
        self.bus_seq = 0
        self.bus_dropped = 0
        self.subs = {}
        self.consumed = {}
        # markers / triggers / world state
        self.markers = {}
        self.mark_seq = 0
        self.triggers = []
        self.world_flags = set()
        self.unlocks = set()
        self.world_state_version = 0
        # perf accumulators (process CPU per subsystem)
        self.perf = {}
        self.illegal = []
        self.save_slots = {}

    # ---------------- bus ----------------
    def publish(self, typ, producer, source, context=None):
        self.bus_seq += 1
        ev = {"event_id": "EV-%06d" % self.bus_seq, "type": typ,
              "producer": producer, "tick": self.tick_n,
              "source": source, "context": context or {},
              "payload_version": "p10evt1"}
        self.bus.append(ev)
        if len(self.bus) > BUS_CAP:
            self.bus = self.bus[-BUS_CAP:]
            self.bus_dropped += 1
        return ev

    def subscribe(self, owner, types):
        self.subs.setdefault(owner, set()).update(types)
        self.consumed.setdefault(owner, 0)

    def unsubscribe(self, owner):
        self.subs.pop(owner, None)
        self.consumed.pop(owner, None)

    def poll(self, owner):
        """New events for owner since last poll (monotone index)."""
        want = self.subs.get(owner, set())
        idx = self.consumed.get(owner, 0)
        out = [e for e in self.bus[idx:] if e["type"] in want]
        self.consumed[owner] = len(self.bus)
        return out

    # ---------------- perf ----------------
    def _timed(self, name, fn, *a):
        t0 = time.process_time_ns()
        r = fn(*a)
        dt = (time.process_time_ns() - t0) / 1e9
        p = self.perf.setdefault(name, {"cpu": 0.0, "n": 0})
        p["cpu"] += dt
        p["n"] += 1
        return r

    # ---------------- player ----------------
    def act_move(self, x, z):
        if self.player["vehicle"] is not None:
            return (False, "in_vehicle")
        self.player["move_target"] = [x, z]
        self.player["interaction"] = "MOVING"
        return (True, "moving")

    def _step_player(self):
        p = self.player
        if p["vehicle"] is not None and self.traffic is not None:
            v = self.traffic.vehicles.get(p["vehicle"])
            if v is not None and v.get("pos"):
                p["x"], p["z"] = v["pos"][0], v["pos"][2]
                p["vx"], p["vz"] = 0.0, 0.0
            else:
                p["vehicle"] = None
        elif p["move_target"] is not None:
            dx = p["move_target"][0] - p["x"]
            dz = p["move_target"][1] - p["z"]
            d = math.hypot(dx, dz)
            step = p["speed_cap"] * FIXED_STEP
            if d <= max(step, 0.5):
                p["x"], p["z"] = p["move_target"]
                p["move_target"] = None
                p["interaction"] = "IDLE"
                p["vx"], p["vz"] = 0.0, 0.0
            else:
                p["x"] += dx / d * step
                p["z"] += dz / d * step
                p["vx"], p["vz"] = dx / d * p["speed_cap"], \
                    dz / d * p["speed_cap"]
                p["heading"] = math.degrees(math.atan2(dx, dz))
        else:
            p["vx"], p["vz"] = 0.0, 0.0
        p["sector"] = self.npc.sector_of(p["x"], p["z"])
        self.npc.set_player(p["x"], p["z"])
        if self.traffic is not None:
            self.traffic.set_player(p["x"], p["z"])
        self.npc.focus = [p["x"], p["z"]]
        if self.traffic is not None:
            self.traffic.focus = [p["x"], p["z"]]

    def player_speed(self):
        p = self.player
        return math.hypot(p["vx"], p["vz"])

    def district_at(self, x, z):
        for did in sorted(self.districts.keys()):
            if point_in_bounds(x, z, self.districts[did]["bounds"]):
                return did
        return None

    # ---------------- economy ----------------
    def apply_txn(self, txn_id, actor, op, amount, reason, source,
                  allow_overdraft=False):
        if txn_id in self.txns:
            return ("DUPLICATE_NOOP", self.txns[txn_id])
        if op not in self.ec["operations"]:
            return ("REJECT", "unknown_op")
        if not isinstance(amount, (int, float)) or amount <= 0:
            return ("REJECT", "invalid_amount")
        if amount > MAX_INT or self.wallet["balance"] + amount > MAX_INT:
            return ("REJECT", "overflow")
        if source in (None, ""):
            return ("REJECT", "invalid_source")
        w = self.wallet
        avail = w["balance"] - sum(h["amount"]
                                   for h in w["holds"].values())
        if op == "CREDIT":
            before = w["balance"]
            w["balance"] += amount
        elif op == "DEBIT":
            if avail < amount and not allow_overdraft:
                return ("REJECT", "insufficient_funds")
            before = w["balance"]
            w["balance"] -= amount
        elif op == "HOLD":
            if avail < amount:
                return ("REJECT", "insufficient_funds")
            before = w["balance"]
            w["holds"][txn_id] = {"amount": amount,
                                  "expiry": self.tick_n + 600}
        elif op == "RELEASE":
            if not source.startswith("hold:"):
                return ("REJECT", "release_needs_hold_ref")
            h = w["holds"].pop(source[5:], None)
            if h is None:
                return ("REJECT", "unknown_hold")
            before = w["balance"]
            amount = h["amount"]
        elif op == "REFUND":
            if not source.startswith("orig:"):
                return ("REJECT", "refund_needs_origin")
            before = w["balance"]
            w["balance"] += amount
        rec = {"transaction_id": txn_id, "actor": actor, "op": op,
               "amount": amount, "reason": reason, "source": source,
               "balance_before": before, "balance_after": w["balance"],
               "tick": self.tick_n}
        self.txns[txn_id] = rec
        self.player["money"] = w["balance"]
        self.publish("TRANSACTION_COMPLETED", "P10", txn_id,
                     {"op": op, "amount": amount, "reason": reason})
        return ("OK", rec)

    def price_of(self, product, district):
        dcls = self.districts[district]["class"] \
            if district in self.districts else "CITY_CORE"
        for pr in self.eco["prices"]:
            if pr["product_or_service_id"] == product and \
                    pr["region"] == dcls:
                return pr["price"]
        return None

    def act_buy(self, shop_id, product):
        shop = next((s for s in self.eco["shops"]
                     if s["shop_id"] == shop_id), None)
        if shop is None:
            return (False, "unknown_shop")
        d = math.hypot(shop["point"][0] - self.player["x"],
                       shop["point"][1] - self.player["z"])
        if d > 15.0:
            return (False, "too_far")
        price = self.price_of(product, shop["district"])
        if price is None:
            return (False, "unknown_product")
        self.txn_seq += 1
        tid = "buy:%s:%d" % (shop_id, self.txn_seq)
        st, rec = self.apply_txn(tid, "PLAYER-01", "DEBIT", price,
                                 "purchase", "SHOP")
        if st != "OK":
            return (False, rec)
        self.publish("PLAYER_INTERACTION", "P10", shop_id,
                     {"kind": "BUY", "product": product})
        return (True, rec)

    def act_sell(self, shop_id, product):
        shop = next((s for s in self.eco["shops"]
                     if s["shop_id"] == shop_id), None)
        if shop is None:
            return (False, "unknown_shop")
        price = self.price_of(product, shop["district"])
        if price is None:
            return (False, "unknown_product")
        self.txn_seq += 1
        tid = "sell:%s:%d" % (shop_id, self.txn_seq)
        st, rec = self.apply_txn(tid, "PLAYER-01", "CREDIT",
                                 round(price * 0.5, 2), "sale", "SHOP")
        return (st == "OK", rec)

    def _expire_holds(self):
        for hid in [h for h, v in self.wallet["holds"].items()
                    if v["expiry"] <= self.tick_n]:
            del self.wallet["holds"][hid]
            self.publish("TRANSACTION_COMPLETED", "P10", hid,
                         {"op": "RELEASE", "reason": "hold_expired"})

    # ---------------- missions ----------------
    def _mtrans(self, mid, to, reason):
        frm = self.mstates[mid]
        if to not in self.move_m.get(frm, []):
            self.illegal.append(("mission", frm, to, reason))
            return False
        self.mstates[mid] = to
        return True

    def _otrans(self, inst, oid, to):
        frm = inst["objectives"][oid]
        if to not in self.obj_m.get(frm, []):
            self.illegal.append(("objective", frm, to, oid))
            return False
        inst["objectives"][oid] = to
        return True

    def start_reasons(self, mid):
        """All unmet start conditions with reasons (§13)."""
        m = self.missions[mid]
        bad = []
        if self.mstates[mid] not in ("AVAILABLE", "OFFERED",
                                     "ACCEPTED"):
            bad.append("bad_state:" + self.mstates[mid])
        sc = m["start_conditions"]["player_at"]
        d = math.hypot(sc["point"][0] - self.player["x"],
                       sc["point"][1] - self.player["z"])
        if d > sc["radius_m"]:
            bad.append("too_far_from_start")
        order = ["NONE", "SUSPECTED", "WANTED_1", "WANTED_2",
                 "WANTED_3", "WANTED_4", "WANTED_5"]
        if order.index(self.wanted["level"]) > order.index(
                m["start_conditions"]["wanted_max"]):
            bad.append("wanted_too_high")
        if m["start_conditions"]["sector_ready"]:
            sid = self.npc.sector_of(sc["point"][0], sc["point"][1])
            if self.npc.sector_state(sid) != "READY":
                bad.append("sector_not_ready")
        prev = m["availability"]["prev_mission"]
        if prev is not None and prev not in self.completed:
            bad.append("prev_mission_incomplete")
        if self.tick_n < self.cooldowns.get(mid, 0):
            bad.append("in_cooldown")
        return bad

    def act_offer(self, mid):
        if mid not in self.missions:
            return (False, "unknown_mission")
        if self.mstates[mid] != "AVAILABLE":
            return (False, "bad_state:" + self.mstates[mid])
        self._mtrans(mid, "OFFERED", "offer")
        return (True, "offered")

    def act_accept(self, mid):
        if mid not in self.missions:
            return (False, "unknown_mission")
        if self.active is not None:
            return (False, "second_active_rejected")
        if self.mstates[mid] != "OFFERED":
            return (False, "bad_state:" + self.mstates[mid])
        bad = self.start_reasons(mid)
        if bad:
            return (False, ";".join(bad))
        self._mtrans(mid, "ACCEPTED", "accept")
        return (True, "accepted")

    def act_decline(self, mid):
        if self.mstates.get(mid) != "OFFERED":
            return (False, "bad_state")
        self._mtrans(mid, "AVAILABLE", "decline")
        return (True, "declined")

    def act_start(self, mid, _restore=False):
        if mid not in self.missions:
            return (False, "unknown_mission")
        if self.active is not None:
            return (False, "second_active_rejected")
        if self.mstates[mid] != "ACCEPTED":
            return (False, "bad_state:" + self.mstates[mid])
        if not _restore:
            bad = self.start_reasons(mid)
            if bad:
                return (False, ";".join(bad))
        self._mtrans(mid, "STARTING", "start")
        self.inst_seq += 1
        self.attempts = getattr(self, "attempts", {})
        self.attempts[mid] = self.attempts.get(mid, 0) + 1
        inst = {"id": "MI-%04d" % self.inst_seq, "mid": mid,
                "attempt": self.attempts[mid],
                "tick_start": self.tick_n,
                "objectives": {}, "progress": {}, "npcs": {},
                "vehicles": {}, "pins": [], "markers": [],
                "timers": {}, "rewarded": False, "checkpoints": [],
                "failure": None, "rewards_sealed": False}
        for oid in self.missions[mid]["objectives"]:
            inst["objectives"][oid] = "LOCKED"
            inst["progress"][oid] = {"n": 0, "ticks": 0, "seen": []}
        self.active = inst
        self.player["mission"] = mid
        self.subscribe(inst["id"], ["MISSION_STATE", "WANTED_STATE"])
        ok, reason = self._spawn_roles(inst)
        if not ok:
            self._fail_active(reason)
            return (False, reason)
        self._unlock_objectives(inst)
        self._mtrans(mid, "ACTIVE", "roles_ready")
        self.publish("MISSION_STARTED", "P10", inst["id"],
                     {"mid": mid, "attempt": inst["attempt"],
                      "restore": _restore})
        return (True, inst["id"])

    def _spawn_roles(self, inst):
        m = self.missions[inst["mid"]]
        sc = m["start_conditions"]["player_at"]
        # NPC roles via P09: anchored at the walkable origin node
        # (P10-D2), spawn-checked; WAIT/REPLAN then fail with reason
        for i, r in enumerate(m["npc_roles"]):
            placed = None
            for k in range(16):
                ring = 6.0 + (k // 8) * 8.0
                ang = 2 * math.pi * ((i * 5 + k) % 8) / 8.0
                jx = sc["point"][0] + math.cos(ang) * ring
                jz = sc["point"][1] + math.sin(ang) * ring
                ok, why = self.npc.spawn_check(jx, jz, r["zone"])
                if ok:
                    placed = (jx, jz)
                    break
            if placed is None:
                return (False, "role_spawn_failed:" + r["role"])
            n = self.npc.acquire(r["archetype"], r["zone"],
                                 placed[0], placed[1],
                                 context=inst["id"])
            if n is None:
                return (False, "role_duplicate:" + r["role"])
            n["mission_role"] = r["role"]
            n["mission_instance"] = inst["id"]
            inst["npcs"][r["role"]] = n["id"]
            self._steer_role(inst, r["role"])
        # vehicle roles via P08 (pinned => persistent while owned)
        for i, v in enumerate(m["vehicle_roles"]):
            veh = None
            zones = [v["spawn_zone"]] + sorted(
                self.traffic.spawn_zones.keys())[:6]
            for zid in zones:
                veh = self.traffic.try_spawn(zid, v["class"])
                if veh is not None:
                    break
            if veh is None:
                return (False, "vehicle_spawn_failed")
            veh["mission_role"] = "MISSION_VEHICLE_%d" % i
            veh["mission_instance"] = inst["id"]
            pid = self.traffic.pin(veh, veh["sector"],
                                   "mission:" + inst["id"])
            inst["vehicles"][veh["mission_role"]] = veh["id"]
            inst["pins"].append(("traffic", veh["id"], pid))
            self.traffic.assign_route(veh)
        # objective sector pin (P09 interface, mission-owned)
        sid = self.npc.sector_of(sc["point"][0], sc["point"][1])
        pid = self.npc.pin(sid, "mission:" + inst["id"], ticks=36000)
        inst["pins"].append(("npc", sid, pid))
        # markers per objective
        for o in m["objective_defs"]:
            self.mark_seq += 1
            mk = "MK-%04d" % self.mark_seq
            pt = o["requirements"].get("point", sc["point"])
            self.markers[mk] = {
                "marker_id": mk, "type": o["marker"]["type"],
                "position": pt,
                "sector": self.npc.sector_of(pt[0], pt[1]),
                "owner": inst["id"],
                "priority": o["marker"]["priority"],
                "visibility": "ACTIVE", "distance": 0.0,
                "mission_instance": inst["id"],
                "objective_id": o["objective_id"]}
            inst["markers"].append(mk)
        return (True, "roles_ready")

    def _steer_role(self, inst, role):
        """Steer a role NPC through P09 path requests (no teleports)."""
        nid = inst["npcs"].get(role)
        n = self.npc.npcs.get(nid) if nid else None
        if n is None:
            return
        m = self.missions[inst["mid"]]
        if role in ("CHASE_TARGET",):
            # flee: nearest node away from player
            best, bd = None, -1.0
            for cand in sorted(self.npc.nodes.keys()):
                nd = self.npc.nodes[cand]
                d = math.hypot(nd["x"] - self.player["x"],
                               nd["z"] - self.player["z"])
                if 60.0 < d and d > bd:
                    bd, best = d, cand
            if best is not None:
                self.npc.request_path(n, best)
        elif role in ("ESCORT_TARGET", "MISSION_TARGET"):
            # drift toward a far node (targets keep moving)
            start = self.npc.nearest_node(n["x"], n["z"], rmax=400.0)
            comp = self.npc.comp_of.get(start) if start else None
            if comp:
                cands = sorted(self.npc.comp_nodes[comp])
                goal = cands[(self.tick_n // 10 + hash(role)) %
                             len(cands)]
                if goal != start:
                    self.npc.request_path(n, goal)

    def _unlock_objectives(self, inst):
        m = self.missions[inst["mid"]]
        defs = {o["objective_id"]: o for o in m["objective_defs"]}
        for oid in m["objectives"]:
            if inst["objectives"][oid] != "LOCKED":
                continue
            deps = defs[oid].get("dependencies", [])
            if all(inst["objectives"].get(d) == "COMPLETED"
                   for d in deps):
                self._otrans(inst, oid, "AVAILABLE")
                self._otrans(inst, oid, "ACTIVE")
                inst["timers"][oid] = self.tick_n

    def _eval_mission(self):
        inst = self.active
        if inst is None:
            return
        m = self.missions[inst["mid"]]
        if self.mstates[inst["mid"]] not in ("ACTIVE", "CHECKPOINT"):
            return
        # role liveness first (TARGET_LOST / NPC_LOST / vehicle loss)
        for role, nid in inst["npcs"].items():
            if nid not in self.npc.npcs:
                self._fail_active("NPC_LOST")
                return
        if self.traffic is not None:
            for role, vid in inst["vehicles"].items():
                if vid not in self.traffic.vehicles:
                    self._fail_active("VEHICLE_DESTROYED")
                    return
        # arrest policy
        if self.wanted["chain"] == "ARREST":
            pol = m["wanted_policy"]
            if pol["fails_on_arrest"]:
                self._fail_active("PLAYER_ARRESTED")
                return
            if pol["pauses_on_arrest"] and \
                    self.mstates[inst["mid"]] == "ACTIVE":
                self._mtrans(inst["mid"], "PAUSED", "arrest")
                self.publish("MISSION_STATE", "P10", inst["id"],
                             {"to": "PAUSED"})
                return
        if self.mstates[inst["mid"]] == "PAUSED" and \
                self.wanted["chain"] not in ("ARREST", "PURSUIT"):
            self._mtrans(inst["mid"], "ACTIVE", "resume")
        defs = {o["objective_id"]: o for o in m["objective_defs"]}
        for oid in m["objectives"]:
            if inst["objectives"][oid] != "ACTIVE":
                continue
            o = defs[oid]
            t0 = inst["timers"].get(oid, self.tick_n)
            if self.tick_n - t0 > o["timeout_ticks"]:
                self._otrans(inst, oid, "FAILED")
                self.publish("OBJECTIVE_FAILED", "P10", oid,
                             {"reason": "TIMEOUT"})
                self._fail_active("TIMEOUT")
                return
            done, failed = self._eval_objective(inst, o)
            if failed:
                self._otrans(inst, oid, "FAILED")
                self.publish("OBJECTIVE_FAILED", "P10", oid,
                             {"reason": failed})
                self._fail_active("OBJECTIVE_FAILED")
                return
            if done:
                self._otrans(inst, oid, "COMPLETED")
                self.publish("OBJECTIVE_COMPLETED", "P10", oid, {})
                self._checkpoint(inst, oid)
                if m["wanted_policy"]["clears_on_stage"] == oid:
                    self._clear_wanted("stage_clear")
        self._unlock_objectives(inst)
        if all(inst["objectives"][o] == "COMPLETED"
               for o in m["objectives"]):
            self._succeed_active()

    def _role_pos(self, inst, role):
        nid = inst["npcs"].get(role)
        n = self.npc.npcs.get(nid) if nid else None
        if n is None:
            return None
        return (n["x"], n["z"])

    def _eval_objective(self, inst, o):
        """Returns (done, failed_reason_or_None) from live world state."""
        r = o["requirements"]
        oid = o["objective_id"]
        pr = inst["progress"][oid]
        px, pz = self.player["x"], self.player["z"]
        t = o["type"]
        if t in ("REACH", "RETURN"):
            d = math.hypot(r["point"][0] - px, r["point"][1] - pz)
            if d <= r["radius_m"]:
                return (True, None)
            return (False, None)
        if t == "MEET":
            if r.get("role"):
                rp = self._role_pos(inst, r["role"])
                if rp is None:
                    return (False, "role_missing")
                d = math.hypot(rp[0] - px, rp[1] - pz)
            else:
                d = math.hypot(r["point"][0] - px, r["point"][1] - pz)
            if d <= r["radius_m"] and \
                    self.player["interaction"] == "INTERACTING":
                return (True, None)
            return (False, None)
        if t == "COLLECT":
            pts = self._collect_points(o)
            for i, pt in enumerate(pts):
                if i in pr["seen"]:
                    continue
                if math.hypot(pt[0] - px, pt[1] - pz) <= 6.0 and \
                        self.player["interaction"] == "INTERACTING":
                    pr["seen"].append(i)
            pr["n"] = len(pr["seen"])
            if pr["n"] >= r.get("count", len(pts)):
                return (True, None)
            return (False, None)
        if t in ("FOLLOW", "CHASE", "OBSERVE", "STATE"):
            rp = self._role_pos(inst, r.get("role", "MISSION_TARGET"))
            if rp is None:
                return (False, "role_missing")
            d = math.hypot(rp[0] - px, rp[1] - pz)
            lo, hi = r.get("band_m", [0.0, 30.0])
            ok = lo <= d <= hi
            if t == "CHASE":
                ok = d <= hi
            if t == "OBSERVE" and r.get("los_required"):
                ok = ok and not self.npc.los_blocked(px, pz, rp[0],
                                                     rp[1])
            if t == "STATE":
                ok = d <= 50.0
            pr["ticks"] = pr["ticks"] + 1 if ok else 0
            if pr["ticks"] >= r.get("ticks", 300):
                return (True, None)
            return (False, None)
        if t == "INTERCEPT":
            if self.traffic is None:
                return (False, "no_traffic")
            best = None
            for vid in inst["vehicles"].values():
                v = self.traffic.vehicles.get(vid)
                if v is None or not v.get("pos"):
                    continue
                d = math.hypot(v["pos"][0] - px, v["pos"][2] - pz)
                if best is None or d < best:
                    best = d
            if best is not None and best <= r.get("radius_m", 20.0):
                return (True, None)
            return (False, None)
        if t == "TIMER":
            pr["ticks"] += 1
            area = r.get("area_ref")
            if area is not None and area in self.districts:
                cx, cz = bounds_center(
                    self.districts[area]["bounds"])
                if math.hypot(px - cx, pz - cz) > 400.0:
                    return (False, "AREA_EXIT")
            if pr["ticks"] >= r.get("ticks", 300):
                return (True, None)
            return (False, None)
        return (False, "unknown_type")

    def _collect_points(self, o):
        r = o["requirements"]
        cx, cz = r["point"]
        n = r.get("count", 3)
        pts = []
        for i in range(n):
            ang = 2 * math.pi * i / max(n, 1)
            pts.append((cx + math.cos(ang) * 10.0,
                        cz + math.sin(ang) * 10.0))
        return pts

    def act_interact(self):
        self.player["interaction"] = "INTERACTING"
        self.publish("PLAYER_INTERACTION", "P10", "PLAYER-01",
                     {"kind": "INTERACT"})
        return (True, "interacting")

    def _checkpoint(self, inst, oid):
        m = self.missions[inst["mid"]]
        if not any(c["after_objective"] == oid
                   for c in m["checkpoints"]):
            return
        snap = {"player": [self.player["x"], self.player["z"]],
                "vehicle": self.player["vehicle"],
                "objectives": dict(inst["objectives"]),
                "progress": copy.deepcopy(inst["progress"]),
                "timer": self.tick_n - inst["tick_start"],
                "world_flags": sorted(self.world_flags)}
        inst["checkpoints"].append({"after": oid, "snapshot": snap})
        if self.mstates[inst["mid"]] == "ACTIVE":
            self._mtrans(inst["mid"], "CHECKPOINT", "checkpoint")
        self.publish("CHECKPOINT_SAVED", "P10", inst["id"],
                     {"after": oid})
        if self.mstates[inst["mid"]] == "CHECKPOINT":
            self._mtrans(inst["mid"], "ACTIVE", "resume")

    def _reward(self, inst):
        if inst["rewarded"]:
            return
        m = self.missions[inst["mid"]]
        tid = "rew:%s:%s" % (inst["mid"], inst["id"])
        st, _ = self.apply_txn(tid, "MISSION", "CREDIT",
                               m["rewards"]["money"], "mission_reward",
                               "MISSION")
        if st == "OK":
            inst["rewarded"] = True
        for fx in m["world_effects"]:
            if fx not in self.world_flags:
                self.world_flags.add(fx)
                self.world_state_version += 1

    def _succeed_active(self):
        inst = self.active
        m = self.missions[inst["mid"]]
        self._reward(inst)
        self._mtrans(inst["mid"], "SUCCEEDED", "all_objectives")
        self.publish("MISSION_SUCCEEDED", "P10", inst["id"], {})
        self.completed.add(inst["mid"])
        self.world_state_version += 1
        self._cleanup(inst, "success")
        self.cooldowns[inst["mid"]] = self.tick_n + \
            m["availability"]["cooldown_ticks"]
        self._mtrans(inst["mid"], "COOLDOWN", "cooldown")
        self.active = None
        self.player["mission"] = None

    def _fail_active(self, reason):
        inst = self.active
        if inst is None:
            return
        inst["failure"] = reason
        # stash approved checkpoints for retry-from-checkpoint (§15)
        self.last_checkpoints = getattr(self, "last_checkpoints", {})
        self.last_checkpoints[inst["mid"]] = list(
            inst["checkpoints"])
        self._mtrans(inst["mid"], "FAILED", reason)
        self.publish("MISSION_FAILED", "P10", inst["id"],
                     {"reason": reason})
        self._cleanup(inst, "failure:" + reason)
        m = self.missions[inst["mid"]]
        self.cooldowns[inst["mid"]] = self.tick_n + \
            m["availability"]["cooldown_ticks"]
        self._mtrans(inst["mid"], "COOLDOWN", "cooldown")
        self.active = None
        self.player["mission"] = None

    def act_abort(self):
        inst = self.active
        if inst is None:
            return (False, "no_active")
        # stash approved checkpoints: retry-after-abort restores them
        self.last_checkpoints = getattr(self, "last_checkpoints", {})
        self.last_checkpoints[inst["mid"]] = list(
            inst["checkpoints"])
        self._mtrans(inst["mid"], "ABORTED", "player_abort")
        self._cleanup(inst, "abort")
        m = self.missions[inst["mid"]]
        self.cooldowns[inst["mid"]] = self.tick_n + \
            m["availability"]["cooldown_ticks"]
        self._mtrans(inst["mid"], "COOLDOWN", "cooldown")
        self.active = None
        self.player["mission"] = None
        return (True, "aborted")

    def act_retry(self, mid):
        if self.active is not None:
            return (False, "second_active_rejected")
        if self.mstates.get(mid) != "COOLDOWN":
            return (False, "bad_state")
        if self.tick_n < self.cooldowns.get(mid, 0):
            return (False, "in_cooldown")
        self._mtrans(mid, "AVAILABLE", "retry_ready")
        self._mtrans(mid, "OFFERED", "retry_offer")
        ok, why = self.act_accept(mid)
        if not ok:
            return (False, why)
        ok, why = self.act_start(mid)
        if not ok:
            return (False, why)
        # restore approved checkpoint (§15): player pos, objectives,
        # progress, timer. Attempt increments via new instance.
        stash = getattr(self, "last_checkpoints", {}).get(mid, [])
        if stash:
            snap = stash[-1]["snapshot"]
            self.player["x"], self.player["z"] = snap["player"]
            for oid, st in snap["objectives"].items():
                if oid in self.active["objectives"]:
                    self.active["objectives"][oid] = st
            self.active["progress"] = copy.deepcopy(
                snap["progress"])
            self.active["tick_start"] = self.tick_n - snap["timer"]
            self.active["checkpoints"] = list(stash)
            self._step_player()
        return (True, self.active["id"])

    def _cleanup(self, inst, why):
        # role NPCs: lawful P09 despawn (never delete static content)
        for nid in list(inst["npcs"].values()):
            n = self.npc.npcs.get(nid)
            if n is not None:
                self.npc.despawn(n, "mission_cleanup")
        # role vehicles: release pins then lawful P08 retire
        if self.traffic is not None:
            for vid in list(inst["vehicles"].values()):
                v = self.traffic.vehicles.get(vid)
                if v is not None:
                    self.traffic.unpin(v)
                    if v["id"] in self.traffic.vehicles:
                        self.traffic.retire(v, "mission_cleanup")
        for kind, ref, pid in inst["pins"]:
            if kind == "npc":
                try:
                    self.npc.unpin(pid)
                except KeyError:
                    pass
        inst["pins"] = []
        for mk in inst["markers"]:
            self.markers.pop(mk, None)
        inst["markers"] = []
        self.unsubscribe(inst["id"])
        self.triggers = [t for t in self.triggers
                         if t.get("owner") != inst["id"]]
        self.publish("MISSION_CLEANUP", "P10", inst["id"],
                     {"why": why})

    # ---------------- vehicles (player) ----------------
    def nearest_vehicle(self, max_m=8.0):
        if self.traffic is None:
            return None
        best = None
        for v in self.traffic.vehicles.values():
            if not v.get("pos") or \
                    v["state"] in ("DESPAWNING", "DESPAWNED"):
                continue
            d = math.hypot(v["pos"][0] - self.player["x"],
                           v["pos"][2] - self.player["z"])
            if d <= max_m and (best is None or d < best[0]):
                best = (d, v["id"])
        return best[1] if best else None

    def act_enter_vehicle(self, vid=None):
        if self.player["vehicle"] is not None:
            return (False, "already_in_vehicle")
        vid = vid or self.nearest_vehicle()
        if vid is None:
            return (False, "no_vehicle")
        v = self.traffic.vehicles.get(vid)
        if v is None:
            return (False, "vehicle_gone")
        self.player["vehicle"] = vid
        self.player["move_target"] = None
        self.player["interaction"] = "DRIVING"
        if v.get("mission_instance") is None and \
                v.get("police_unit") is None:
            self.commit_offense("VEHICLE_THEFT", self.player["x"],
                                self.player["z"])
        return (True, vid)

    def act_exit_vehicle(self):
        if self.player["vehicle"] is None:
            return (False, "on_foot")
        self.player["vehicle"] = None
        self.player["interaction"] = "IDLE"
        return (True, "on_foot")

    # ---------------- wanted ----------------
    def _wtrans(self, to, reason):
        frm = self.wanted["chain"]
        if to not in self.want_m.get(frm, []):
            self.illegal.append(("wanted", frm, to, reason))
            return False
        self.wanted["chain"] = to
        return True

    def _ptrans(self, to, reason):
        p = self.wanted["pursuit"]
        frm = p["state"]
        if to not in self.pursuit_m.get(frm, []):
            self.illegal.append(("pursuit", frm, to, reason))
            return False
        p["state"] = to
        return True

    def commit_offense(self, cls, x, z):
        tab = {o["class"]: o for o in self.wtd["offenses"]}
        if cls not in tab or not tab[cls]["enabled"]:
            return (False, "offense_disabled:" + cls)
        self.wanted["off_seq"] += 1
        oid = "OFF-%04d" % self.wanted["off_seq"]
        self.wanted["offenses"][oid] = {
            "offense_id": oid, "actor": "PLAYER-01", "class": cls,
            "location": [x, z], "severity": tab[cls]["severity"],
            "witness_context": [], "confidence": 0.0,
            "evidence": ["location", "tick"], "tick": self.tick_n,
            "wanted_impact": tab[cls]["wanted_impact"]}
        self.wanted["last_offense_tick"] = self.tick_n
        self.publish("OFFENSE_COMMITTED", "P10", oid,
                     {"class": cls, "at": [x, z]})
        self._witness_scan(oid)
        return (True, oid)

    def _witness_scan(self, oid):
        """Consume P09 perception facts; top-3 reporters, threshold."""
        off = self.wanted["offenses"][oid]
        ox, oz = off["location"]
        cands = []
        for n in self.npc.npcs.values():
            if n["move_state"] in ("DESPAWNING", "DESPAWNED"):
                continue
            if n.get("mission_instance") is not None:
                continue
            d = math.hypot(n["x"] - ox, n["z"] - oz)
            if d > 60.0:
                continue
            blocked = self.npc.los_blocked(n["x"], n["z"], ox, oz)
            seen = any(p.get("id") == "PLAYER" for p in
                       n.get("perceived", []))
            conf = 0.0
            if not blocked:
                conf += max(0.0, 0.7 - d / 100.0)
            if seen:
                conf += 0.2
            if n["archetype"] in ("SECURITY_HOOK", "WORKER"):
                conf += 0.15
            conf += off["severity"] * 0.05
            if conf >= 0.5:
                cands.append((-conf, n["id"]))
        cands.sort()
        for _, nid in cands[:3]:
            self.npc.witness(nid, "PLAYER-01", oid)
            off["witness_context"].append(nid)
            self.publish("OFFENSE_WITNESSED", "P09", oid,
                         {"observer": nid})
        if off["witness_context"]:
            off["confidence"] = 1.0
            self._escalate(off)

    def _escalate(self, off):
        order = ["NONE", "SUSPECTED", "WANTED_1", "WANTED_2",
                 "WANTED_3", "WANTED_4", "WANTED_5"]
        cur = order.index(self.wanted["level"])
        cur_lv = cur - 1 if cur >= 2 else 0
        want = min(5, max(1, off["severity"] +
                         (1 if len(off["witness_context"]) > 1
                          else 0)))
        if cur < 1:
            self._wtrans("SUSPECTED", off["offense_id"])
            self.wanted["level"] = "SUSPECTED"
        lv = "WANTED_%d" % max(want, cur_lv)
        if lv != self.wanted["level"]:
            if self.wanted["chain"] == "SUSPECTED":
                self._wtrans("WANTED", off["offense_id"])
            self.wanted["level"] = lv
            self.publish("WANTED_CHANGED", "P10", "PLAYER-01",
                         {"level": lv})
            self.player["wanted_state"] = lv
            self._dispatch(off)
        elif self.wanted["level"].startswith("WANTED") and \
                self.wanted["pursuit"] is None:
            # fresh witnessed crime while wanted: units re-engage
            self._dispatch(off)
        elif self.wanted["level"] == "SUSPECTED":
            self.publish("WANTED_CHANGED", "P10", "PLAYER-01",
                         {"level": "SUSPECTED"})
            self.player["wanted_state"] = "SUSPECTED"

    def _clear_wanted(self, reason):
        if self.wanted["level"] == "NONE":
            return
        if self.wanted["pursuit"] is not None:
            p = self.wanted["pursuit"]
            if p["state"] not in ("COMPLETE", "ABORTED"):
                self._ptrans("ABORTED", reason)
            self._release_units(p)
            self.wanted["pursuit"] = None
        self.wanted["level"] = "NONE"
        if self.wanted["chain"] != "NONE":
            for to in ("LOST", "ESCAPED", "NONE"):
                if to in self.want_m.get(self.wanted["chain"], []):
                    self._wtrans(to, reason)
                    if to == "NONE":
                        break
            self.wanted["chain"] = "NONE"
        self.player["wanted_state"] = "NONE"
        self.publish("WANTED_CHANGED", "P10", "PLAYER-01",
                     {"level": "NONE", "reason": reason})

    def _dispatch(self, off):
        self.wanted["inc_seq"] += 1
        iid = "INC-%04d" % self.wanted["inc_seq"]
        units = self.wtd["dispatch_units"].get(
            self.wanted["level"], {"npc": 1, "vehicle": 0})
        p = {"incident": iid, "state": "DISPATCH",
             "units_npc": [], "units_veh": [],
             "tick_start": self.tick_n, "unseen": 0,
             "last_seen": [self.player["x"], self.player["z"]],
             "stop_ticks": 0}
        # NPC units: SECURITY_HOOK near player via P09
        px, pz = self.player["x"], self.player["z"]
        zone = "PZ-D-hub-core"
        for z in self.npc.zones.values():
            pass
        zid = self._zone_near(px, pz)
        made = 0
        for k in range(12):
            if made >= units["npc"]:
                break
            jx = px + ((k % 5) - 2) * 8.0
            jz = pz + ((k // 5) - 1) * 8.0
            ok, _ = self.npc.spawn_check(jx, jz, zid)
            if not ok:
                continue
            n = self.npc.acquire("SECURITY_HOOK", zid, jx, jz,
                                 context=iid)
            if n is None:
                continue
            n["police_unit"] = iid
            p["units_npc"].append(n["id"])
            made += 1
        # vehicle units: emergency_hook via P08, pinned while owned
        if self.traffic is not None:
            made_v = 0
            for zid2 in sorted(self.traffic.spawn_zones.keys()):
                if made_v >= units["vehicle"]:
                    break
                v = self.traffic.try_spawn(zid2, "emergency_hook")
                if v is None:
                    continue
                v["police_unit"] = iid
                self.traffic.pin(v, v["sector"], "police:" + iid)
                p["units_veh"].append(v["id"])
                made_v += 1
        if not p["units_npc"] and not p["units_veh"]:
            self.publish("POLICE_DISPATCHED", "P10", iid,
                         {"result": "no_units"})
            return
        self.wanted["pursuit"] = p
        self._ptrans("APPROACH", "units_rolling")
        if self.wanted["chain"] == "WANTED":
            self._wtrans("PURSUIT", iid)
        self.publish("POLICE_DISPATCHED", "P10", iid,
                     {"npc": len(p["units_npc"]),
                      "veh": len(p["units_veh"])})
        self.publish("PURSUIT_STARTED", "P10", iid, {})

    def _zone_near(self, x, z):
        sid = self.npc.sector_of(x, z)
        for zid in sorted(self.npc.zones.keys()):
            if sid in self.npc.zone_sectors.get(zid, []):
                return zid
        return "PZ-D-hub-core"

    def _release_units(self, p):
        for nid in p["units_npc"]:
            n = self.npc.npcs.get(nid)
            if n is not None:
                self.npc.despawn(n, "unit_released")
        if self.traffic is not None:
            for vid in p["units_veh"]:
                v = self.traffic.vehicles.get(vid)
                if v is not None:
                    self.traffic.unpin(v)
                    if v["id"] in self.traffic.vehicles:
                        self.traffic.retire(v, "unit_released")

    def _eval_wanted(self):
        w = self.wanted
        # decay: long quiet => step down
        if w["level"] not in ("NONE",) and w["pursuit"] is None and \
                self.tick_n - w["last_offense_tick"] > 900:
            order = ["NONE", "SUSPECTED", "WANTED_1", "WANTED_2",
                     "WANTED_3", "WANTED_4", "WANTED_5"]
            i = max(0, order.index(w["level"]) - 1)
            w["level"] = order[i]
            w["last_offense_tick"] = self.tick_n
            self.player["wanted_state"] = w["level"]
            self.publish("WANTED_CHANGED", "P10", "PLAYER-01",
                         {"level": w["level"], "reason": "decay"})
            if w["level"] == "NONE":
                w["chain"] = "NONE"
        p = w["pursuit"]
        if p is None:
            return
        # drop dead units
        p["units_npc"] = [i for i in p["units_npc"]
                          if i in self.npc.npcs]
        if self.traffic is not None:
            p["units_veh"] = [i for i in p["units_veh"]
                              if i in self.traffic.vehicles]
        if not p["units_npc"] and not p["units_veh"]:
            # units gone (culled/destroyed): trail goes cold unless
            # the suspect stayed near; cold trail => ESCAPED.
            if p.get("last_seen") is not None:
                dls = math.hypot(
                    p["last_seen"][0] - self.player["x"],
                    p["last_seen"][1] - self.player["z"])
            else:
                dls = float("inf")
            if dls < 120.0:
                self._ptrans("ABORTED", "units_lost")
                self.publish("PURSUIT_ENDED", "P10", p["incident"],
                             {"result": "ABORTED"})
                w["pursuit"] = None
                return
            p["unseen"] += 1
            if p["unseen"] > self.wtd["escape"]["unseen_ticks"]:
                self._escape_complete(p)
            return
        self._steer_units(p)
        seen, near = self._pursuit_contact(p)
        if seen:
            p["unseen"] = 0
            p["last_seen"] = [self.player["x"], self.player["z"]]
        else:
            p["unseen"] += 1
        st = p["state"]
        if st == "APPROACH" and (seen or near < 60.0):
            self._ptrans("PURSUIT", "contact")
        elif st == "APPROACH" and p["unseen"] > 100:
            self._ptrans("SEARCH", "lost_sight")
            if w["chain"] == "PURSUIT":
                self._wtrans("SEARCH", p["incident"])
        elif st == "PURSUIT":
            if self._arrest_ready(p, near):
                self._ptrans("ARREST", "intercept")
                self._wtrans("ARREST", p["incident"])
                self.publish("ARREST_STARTED", "P10", p["incident"],
                             {})
                self._arrest(p)
            elif p["unseen"] > 100:
                self._ptrans("SEARCH", "lost_sight")
                if w["chain"] == "PURSUIT":
                    self._wtrans("SEARCH", p["incident"])
        elif st == "SEARCH":
            if seen:
                self._ptrans("PURSUIT", "reacquired")
                if w["chain"] == "SEARCH":
                    self._wtrans("PURSUIT", p["incident"])
            elif self._escaped(p, near):
                self._escape_complete(p)

    def _unit_positions(self, p):
        out = []
        for nid in p["units_npc"]:
            n = self.npc.npcs.get(nid)
            if n is not None:
                out.append((n["x"], n["z"], "npc", nid))
        if self.traffic is not None:
            for vid in p["units_veh"]:
                v = self.traffic.vehicles.get(vid)
                if v is not None and v.get("pos"):
                    out.append((v["pos"][0], v["pos"][2], "veh", vid))
        return out

    def _steer_units(self, p):
        """P10 provides intercept goals; P08/P09 execute movement."""
        px, pz = self.player["x"], self.player["z"]
        goal = [px, pz] if p["unseen"] < 100 else p["last_seen"]
        if self.tick_n % 20 != 0:
            return
        for (ux, uz, kind, uid) in self._unit_positions(p):
            if kind == "npc":
                n = self.npc.npcs.get(uid)
                if n is None:
                    continue
                g = self.npc.nearest_node(goal[0], goal[1],
                                          rmax=400.0)
                if g is not None:
                    self.npc.request_path(n, g)
            else:
                v = self.traffic.vehicles.get(uid)
                if v is None:
                    continue
                dl = self._nearest_lane(goal[0], goal[1])
                if dl is not None and v.get("lane") != dl:
                    res = self.traffic.router.plan(
                        v.get("lane"), dl,
                        self.traffic.specs["emergency_hook"],
                        seed_tag="police:%s:%d" % (uid, self.tick_n))
                    if res.get("lanes"):
                        v["route"] = res["lanes"]
                        v["route_i"] = 0
                        v["route_done"] = False

    def _nearest_lane(self, x, z):
        best = None
        for lid, lane in self.traffic.lanes.items():
            for pt in lane["pts"][::4]:
                d2 = (pt[0] - x) ** 2 + (pt[2] - z) ** 2
                if best is None or d2 < best[0]:
                    best = (d2, lid)
        return best[1] if best else None

    def _pursuit_contact(self, p):
        px, pz = self.player["x"], self.player["z"]
        seen = False
        near = float("inf")
        for (ux, uz, kind, uid) in self._unit_positions(p):
            d = math.hypot(ux - px, uz - pz)
            near = min(near, d)
            if d < 120.0 and not self.npc.los_blocked(ux, uz, px, pz):
                seen = True
        return seen, near

    def _escape_complete(self, p):
        w = self.wanted
        if p["state"] == "APPROACH":
            self._ptrans("SEARCH", "lost_sight")
            if w["chain"] == "PURSUIT":
                self._wtrans("SEARCH", p["incident"])
        self._ptrans("LOST", "escape")
        if w["chain"] in ("PURSUIT", "SEARCH"):
            self._wtrans("LOST", p["incident"])
        self._ptrans("COMPLETE", "escaped")
        self._wtrans("ESCAPED", p["incident"])
        self.publish("ESCAPED", "P10", p["incident"], {})
        self.publish("PURSUIT_ENDED", "P10", p["incident"],
                     {"result": "ESCAPED"})
        self._release_units(p)
        w["pursuit"] = None
        w["level"] = "NONE"
        w["chain"] = "NONE"
        self.player["wanted_state"] = "NONE"
        self.publish("WANTED_CHANGED", "P10", "PLAYER-01",
                     {"level": "NONE", "reason": "escaped"})

    def _escaped(self, p, near):
        """Multi-factor escape: unseen time + distance + coverage."""
        esc = self.wtd["escape"]
        coverage = len(self._unit_positions(p))
        score = 0.0
        if p["unseen"] > esc["unseen_ticks"]:
            score += 0.5
        if near > esc["far_m"]:
            score += 0.3
        elif near > esc["near_m"]:
            score += 0.15
        if coverage <= 1:
            score += 0.2
        return score >= 0.7

    def _arrest_ready(self, p, near):
        if near > 6.0:
            p["stop_ticks"] = 0
            return False
        if self.player_speed() < 0.5 or \
                self.player["interaction"] == "SURRENDERING":
            p["stop_ticks"] += 1
        else:
            p["stop_ticks"] = 0
        return p["stop_ticks"] >= 20

    def _arrest(self, p):
        fine = 0
        for off in self.wanted["offenses"].values():
            fine += self.wtd["fines"].get(off["class"], 0)
        self.txn_seq += 1
        tid = "fine:%s:%d" % (p["incident"], self.txn_seq)
        self.apply_txn(tid, "POLICE", "DEBIT", max(fine, 50),
                       "arrest_fine", "POLICE", allow_overdraft=True)
        self.publish("ARRESTED", "P10", p["incident"],
                     {"fine": max(fine, 50)})
        self._ptrans("COMPLETE", "arrested")
        self._wtrans("POST_ARREST", p["incident"])
        self._release_units(p)
        self.wanted["pursuit"] = None
        self.wanted["level"] = "NONE"
        self.wanted["chain"] = "NONE"
        self.player["wanted_state"] = "NONE"
        self.respawn_hook("post_arrest")

    def act_surrender(self):
        if self.wanted["pursuit"] is None:
            return (False, "no_pursuit")
        self.player["interaction"] = "SURRENDERING"
        self.player["move_target"] = None
        return (True, "surrendering")

    def respawn_hook(self, reason):
        best = None
        for n in self.npc.nodes.values():
            if n["kind"] != "ARRIVAL":
                continue
            d = math.hypot(n["x"] - self.player["x"],
                           n["z"] - self.player["z"])
            if best is None or d < best[0]:
                best = (d, n)
        if best is not None:
            self.player["x"], self.player["z"] = best[1]["x"], \
                best[1]["z"]
            self.player["vehicle"] = None
            self.player["move_target"] = None
            self.player["interaction"] = "IDLE"
        self.publish("WORLD_STATE_CHANGED", "P10", "PLAYER-01",
                     {"kind": "RESPAWN", "reason": reason})
        return True

    # ---------------- world events + triggers ----------------
    def _wtrans_evt(self, eid, to):
        e = self.wevents[eid]
        if to not in self.wevt_m.get(e["state"], []):
            self.illegal.append(("wevent", e["state"], to, eid))
            return False
        e["state"] = to
        return True

    def arm_event(self, eid):
        if eid not in self.wevents:
            return (False, "unknown_event")
        if self.wevents[eid]["state"] != "DORMANT":
            return (False, "bad_state")
        self._wtrans_evt(eid, "ARMED")
        return (True, "armed")

    def _eval_world_events(self):
        for eid in sorted(self.wevents.keys()):
            e = self.wevents[eid]
            if e["state"] != "ARMED":
                continue
            t = e["trigger"]
            fire = False
            if t["type"] == "AREA_ENTER":
                d = math.hypot(t["point"][0] - self.player["x"],
                               t["point"][1] - self.player["z"])
                fire = d <= t["radius_m"]
            elif t["type"] == "TIMER":
                fire = (self.tick_n % max(t["ticks"], 1)) == 0 and \
                    self.tick_n > 0
            elif t["type"] == "WANTED_STATE":
                fire = self.wanted["level"] != "NONE"
            if fire:
                self._wtrans_evt(eid, "TRIGGERED")
                self._wtrans_evt(eid, "ACTIVE")
                for fx in e["effects"]:
                    if fx not in self.world_flags:
                        self.world_flags.add(fx)
                        self.world_state_version += 1
                self._wtrans_evt(eid, "COMPLETED")

    def add_trigger(self, owner, typ, params):
        self.triggers.append({"owner": owner, "type": typ,
                              "params": params, "fired": False})
        return len(self.triggers) - 1

    def _eval_triggers(self):
        for t in self.triggers:
            if t["fired"]:
                continue
            p = t["params"]
            fire = False
            if t["type"] == "AREA_ENTER":
                d = math.hypot(p["point"][0] - self.player["x"],
                               p["point"][1] - self.player["z"])
                fire = d <= p["radius_m"]
            elif t["type"] == "TIMER":
                fire = self.tick_n >= p["at_tick"]
            elif t["type"] == "WANTED_STATE":
                fire = self.wanted["level"] == p["level"]
            elif t["type"] == "MISSION_STATE":
                fire = self.mstates.get(p["mid"]) == p["state"]
            if fire:
                t["fired"] = True
                self.publish("EVENT", "P10", t["owner"],
                             {"trigger": t["type"]})

    # ---------------- save / load ----------------
    def save_game(self, slot):
        core = {
            "schema": "p10save", "save_version": 1,
            "gameplay_world_state_version": self.world_state_version,
            "player": {
                "x": round(self.player["x"], 3),
                "z": round(self.player["z"], 3),
                "sector": self.player["sector"],
                "vehicle": self.player["vehicle"],
                "mission": self.player["mission"]},
            "wallet": {"currency": "ISC",
                       "balance": self.wallet["balance"]},
            "transactions_tail": list(self.txns.values())[-50:],
            "missions_completed": sorted(self.completed),
            "active_mission": None,
            "wanted": {"level": self.wanted["level"],
                       "chain": self.wanted["chain"]},
            "unlocks": sorted(self.unlocks),
            "world_flags": sorted(self.world_flags),
            "mission_npc_ids": [],
            "mission_vehicle_ids": [],
            "seed_metadata": {"seed_tag": self.seed_tag},
            "version_metadata": {
                "gameplay": self.gc["gameplay_version"],
                "mission": self.gc["mission_version"],
                "economy": self.gc["economy_version"],
                "wanted": self.gc["wanted_version"]}}
        if self.active is not None:
            inst = self.active
            core["active_mission"] = {
                "mid": inst["mid"], "instance": inst["id"],
                "attempt": inst["attempt"],
                "objectives": dict(inst["objectives"]),
                "progress": copy.deepcopy(inst["progress"]),
                "checkpoints": copy.deepcopy(inst["checkpoints"]),
                "npc_pos": {role: [round(self.npc.npcs[nid]["x"], 3),
                                     round(self.npc.npcs[nid]["z"], 3)]
                            for role, nid in inst["npcs"].items()
                            if nid in self.npc.npcs},
                "timer": self.tick_n - inst["tick_start"]}
            core["mission_npc_ids"] = sorted(inst["npcs"].values())
            core["mission_vehicle_ids"] = sorted(
                inst["vehicles"].values())
        doc = dict(core)
        doc["checksum"] = fnv1a64_hex(canon(core))
        os.makedirs(SAVE_DIR, exist_ok=True)
        path = os.path.join(SAVE_DIR, slot + ".json")
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(doc, f, indent=1, sort_keys=True)
        os.replace(tmp, path)
        self.save_slots[slot] = path
        return (True, path)

    def _validate_save(self, doc):
        req = ["schema", "save_version", "checksum",
               "gameplay_world_state_version", "player", "wallet",
               "missions_completed", "wanted", "unlocks",
               "world_flags", "seed_metadata", "version_metadata"]
        for k in req:
            if k not in doc:
                return (False, "missing:" + k)
        if doc["schema"] != "p10save":
            return (False, "bad_schema")
        if doc["save_version"] not in (0, 1):
            return (False, "unsupported_version")
        core = {k: v for k, v in doc.items() if k != "checksum"}
        if fnv1a64_hex(canon(core)) != doc["checksum"]:
            return (False, "bad_checksum")
        if doc["save_version"] == 0:
            doc = self._migrate_v0(doc)
        p = doc["player"]
        if abs(p["x"]) > 2500 or abs(p["z"]) > 2500:
            return (False, "player_out_of_range")
        if doc["wallet"]["currency"] != "ISC":
            return (False, "bad_currency")
        if doc["wallet"]["balance"] < -10 ** 6 or \
                doc["wallet"]["balance"] > MAX_INT:
            return (False, "balance_out_of_range")
        if doc["wanted"]["level"] not in (
                "NONE", "SUSPECTED", "WANTED_1", "WANTED_2",
                "WANTED_3", "WANTED_4", "WANTED_5"):
            return (False, "bad_wanted")
        for mid in doc["missions_completed"]:
            if mid not in self.missions:
                return (False, "unknown_mission:" + mid)
        am = doc.get("active_mission")
        if am is not None and am["mid"] not in self.missions:
            return (False, "unknown_active_mission")
        return (True, doc)

    def _migrate_v0(self, doc):
        d = copy.deepcopy(doc)
        d.setdefault("unlocks", [])
        d.setdefault("world_flags", [])
        d.setdefault("transactions_tail", [])
        if "balance" not in d.get("wallet", {}):
            d["wallet"]["balance"] = 0
        if "wanted" not in d:
            d["wanted"] = {"level": "NONE", "chain": "NONE"}
        d["save_version"] = 1
        return d

    def load_game(self, slot):
        path = os.path.join(SAVE_DIR, slot + ".json")
        if not os.path.exists(path):
            return (False, "no_such_slot")
        with open(path) as f:
            doc = json.load(f)
        ok, res = self._validate_save(doc)
        if not ok:
            return (False, res)
        doc = res
        # cleanup live runtime first (no duplicates, no stale pins)
        am0 = doc.get("active_mission")
        restore_mid = am0["mid"] if am0 else None
        if self.active is not None:
            if restore_mid and self.active["mid"] == restore_mid:
                # silent teardown: same mission is rebuilt from save
                self._mtrans(restore_mid, "ABORTED", "restore_teardown")
                self._cleanup(self.active, "restore_teardown")
                self.active = None
                self.player["mission"] = None
            else:
                self.act_abort()
        if self.wanted["pursuit"] is not None:
            p = self.wanted["pursuit"]
            self._release_units(p)
            self.wanted["pursuit"] = None
        self.wanted["level"] = "NONE"
        self.wanted["chain"] = "NONE"
        # apply
        p = doc["player"]
        self.player["x"], self.player["z"] = p["x"], p["z"]
        self.player["vehicle"] = None
        self.player["move_target"] = None
        self.wallet["balance"] = doc["wallet"]["balance"]
        self.wallet["holds"] = {}
        for rec in doc.get("transactions_tail", []):
            self.txns.setdefault(rec["transaction_id"], rec)
        self.player["money"] = self.wallet["balance"]
        self.completed = set(doc["missions_completed"])
        self.unlocks = set(doc["unlocks"])
        self.world_flags = set(doc["world_flags"])
        self.world_state_version = \
            doc["gameplay_world_state_version"]
        wl = doc["wanted"]["level"]
        if wl != "NONE":
            self.wanted["level"] = wl
            self.wanted["chain"] = "WANTED" if wl.startswith(
                "WANTED") else wl
            self.player["wanted_state"] = wl
        am = doc.get("active_mission")
        if am is not None:
            mid = am["mid"]
            # restore is not a gameplay transition: place the machine
            # directly at ACCEPTED (validated legal at save time).
            self.cooldowns.pop(mid, None)
            self.mstates[mid] = "ACCEPTED"
            ok, why = self.act_start(mid, _restore=True)
            if ok:
                inst = self.active
                for oid, st in am["objectives"].items():
                    if oid in inst["objectives"] and \
                            st in ("COMPLETED", "ACTIVE",
                                   "AVAILABLE", "LOCKED"):
                        inst["objectives"][oid] = st
                inst["progress"] = am["progress"]
                for role, pos in am.get("npc_pos", {}).items():
                    nid = inst["npcs"].get(role)
                    n = self.npc.npcs.get(nid) if nid else None
                    if n is not None:
                        n["x"], n["z"] = pos
                self.npc._rehash()
                inst["checkpoints"] = am["checkpoints"]
                inst["attempt"] = am["attempt"]
                self.attempts[mid] = am["attempt"]
                inst["tick_start"] = self.tick_n - am["timer"]
        self._step_player()
        return (True, "loaded")

    # ---------------- tick ----------------
    def tick(self):
        self.tick_n += 1
        self._timed("player", self._step_player)
        self._timed("world", self.npc.tick)
        self._timed("triggers", self._eval_triggers)
        self._timed("mission", self._eval_mission)
        self._timed("wanted", self._eval_wanted)
        self._timed("events", self._eval_world_events)
        self._timed("economy", self._expire_holds)
        if self.player["interaction"] == "INTERACTING":
            self.player["interaction"] = "IDLE"

    def digest(self):
        act = None
        if self.active is not None:
            act = [self.active["mid"], self.active["attempt"],
                   {k: self.active["objectives"][k]
                    for k in sorted(self.active["objectives"])}]
        core = {
            "tick": self.tick_n,
            "player": [round(self.player["x"], 3),
                       round(self.player["z"], 3),
                       self.player["sector"], self.player["mission"]],
            "wallet": self.wallet["balance"],
            "txns": len(self.txns),
            "mstates": {k: self.mstates[k]
                        for k in sorted(self.mstates)},
            "completed": sorted(self.completed),
            "wanted": [self.wanted["level"],
                       self.wanted.get("chain", "NONE"),
                       len(self.wanted["offenses"])],
            "flags": sorted(self.world_flags),
            "world_state_version": self.world_state_version,
            "active": act,
            "npcs": len(self.npc.npcs),
            "veh": len(self.traffic.vehicles),
            "npc_pos": fnv1a64_hex(canon(sorted(
                (round(n["x"], 1), round(n["z"], 1))
                for n in self.npc.npcs.values()))),
            "veh_pos": fnv1a64_hex(canon(sorted(
                (round(v["pos"][0], 1), round(v["pos"][2], 1))
                for v in self.traffic.vehicles.values())))
            if self.traffic is not None else "none",
        }
        return fnv1a64_hex(canon(core))

    def shutdown(self):
        if self.active is not None:
            self.act_abort()
        if self.wanted["pursuit"] is not None:
            p = self.wanted["pursuit"]
            if p["state"] not in ("COMPLETE", "ABORTED"):
                self._ptrans("ABORTED", "shutdown")
            self._release_units(p)
            self.wanted["pursuit"] = None
        for owner in list(self.subs.keys()):
            self.unsubscribe(owner)
        self.triggers = []
        self.markers = {}
        return {"subs": len(self.subs), "triggers": len(self.triggers),
                "markers": len(self.markers),
                "pins_npc": len(self.npc.pins),
                "pins_traffic": sum(
                    len(v["pins"])
                    for v in self.traffic.vehicles.values())
                if self.traffic else 0}

    # ---------------- stats / hud ----------------
    def stats(self):
        return {"tick": self.tick_n, "mission": self.player["mission"],
                "mstates": dict(self.mstates),
                "active": self.active["id"] if self.active else None,
                "wanted": self.wanted["level"],
                "chain": self.wanted["chain"],
                "pursuit": self.wanted["pursuit"]["state"]
                if self.wanted["pursuit"] else None,
                "balance": self.wallet["balance"],
                "txns": len(self.txns),
                "offenses": len(self.wanted["offenses"]),
                "bus": len(self.bus), "bus_dropped": self.bus_dropped,
                "subs": len(self.subs),
                "markers": len(self.markers),
                "world_state_version": self.world_state_version,
                "flags": len(self.world_flags),
                "illegal": len(self.illegal),
                "npcs": len(self.npc.npcs),
                "vehicles": len(self.traffic.vehicles)
                if self.traffic else 0,
                "perf": {k: {"cpu_ms": round(v["cpu"] * 1000, 3),
                             "n": v["n"]}
                         for k, v in self.perf.items()}}

    def hud(self):
        p = self.player
        return {
            "mission": p["mission"],
            "objective": [o for o in
                          (self.active["objectives"].items()
                           if self.active else [])],
            "money": p["money"], "wanted": p["wanted_state"],
            "dispatch": self.wanted["pursuit"]["incident"]
            if self.wanted["pursuit"] else None,
            "pursuit": self.wanted["pursuit"]["state"]
            if self.wanted["pursuit"] else None,
            "pins": len(self.npc.pins),
            "npcs": len(self.npc.npcs),
            "traffic": len(self.traffic.vehicles)
            if self.traffic else 0,
            "sector": p["sector"],
            "txns_tail": [t["transaction_id"]
                          for t in list(self.txns.values())[-5:]]}

    def check_leaks(self):
        bad = list(self.npc.check_leaks())
        if self.traffic is not None:
            bad += list(self.traffic.check_leaks())
        return bad

    def dump_runtime(self, path):
        npc_pins = [{"pid": pid, "sector": p.get("sector"),
                     "owner": p.get("owner")}
                    for pid, p in self.npc.pins.items()]
        t_pins = []
        if self.traffic is not None:
            for v in self.traffic.vehicles.values():
                for (pid, sid, reason) in v.get("pins", []):
                    t_pins.append({"pid": pid, "sector": sid,
                                   "owner": reason,
                                   "vehicle": v["id"]})
        doc = {
            "tick": self.tick_n,
            "mission_states": dict(self.mstates),
            "active": self.active["id"] if self.active else None,
            "objectives": dict(self.active["objectives"])
            if self.active else {},
            "wanted": {"level": self.wanted["level"],
                       "chain": self.wanted["chain"],
                       "pursuit": self.wanted["pursuit"]["state"]
                       if self.wanted["pursuit"] else None},
            "world_events": {k: v["state"]
                             for k, v in self.wevents.items()},
            "npc_pins": npc_pins, "traffic_pins": t_pins,
            "subs": sorted(self.subs.keys()),
            "bus_len": len(self.bus),
            "bus_dropped": self.bus_dropped,
            "txns": list(self.txns.values()),
            "balance": self.wallet["balance"],
            "npc_ids": sorted(self.npc.npcs.keys()),
            "vehicle_ids": sorted(self.traffic.vehicles.keys())
            if self.traffic else [],
            "mission_npcs": dict(self.active["npcs"])
            if self.active else {},
            "mission_vehicles": dict(self.active["vehicles"])
            if self.active else {},
            "markers": list(self.markers.keys()),
            "illegal": [list(t) for t in self.illegal]}
        with open(path, "w") as f:
            json.dump(doc, f, indent=1, sort_keys=True)
        return path
