#!/usr/bin/env python3
"""ISLAND STRIKE — deterministic preview-mesh builder (Prompt 02, meshability gate).

Builds a triangulated preview mesh of the island from the analytic field and
validates it for the P07 handoff: no NaN/inf verts, no degenerate triangles,
bounded slope, sane waterline. Deterministic: fixed grid + locked field ->
bit-identical OBJ bytes across runs (asserted by --selftest).

Usage:
  build_preview_mesh.py --step 32 --out preview/terrain_preview.obj --report preview/terrain_preview.json
  build_preview_mesh.py --selftest   # build twice, compare bytes + run mesh checks
"""
import json, math, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from terrain_model import Field


def build(step_m):
    f = Field()
    n = int(4000 / step_m) + 1
    verts = []
    index = {}
    for j in range(n):
        z = -2000.0 + j * step_m
        for i in range(n):
            x = -2000.0 + i * step_m
            if x * x + z * z > 2000.0 * 2000.0:
                continue
            h = f.height(x, z)
            index[(i, j)] = len(verts)
            verts.append((x, h, z))
    tris = []
    for j in range(n - 1):
        for i in range(n - 1):
            q = [index.get((i, j)), index.get((i + 1, j)),
                 index.get((i + 1, j + 1)), index.get((i, j + 1))]
            if all(v is not None for v in q):
                tris.append((q[0], q[1], q[2]))
                tris.append((q[0], q[2], q[3]))
    return f, verts, tris


def check_mesh(verts, tris):
    fails = []
    for (x, y, z) in verts:
        if not (math.isfinite(x) and math.isfinite(y) and math.isfinite(z)):
            fails.append("non-finite vert")
            break
    if min(v[1] for v in verts) < -25.0 - 1e-9 or max(v[1] for v in verts) > 250.0 + 1e-9:
        fails.append("height out of clamp range")
    degen = 0
    for (a, b, c) in tris:
        ax, ay, az = verts[a]
        bx, by, bz = verts[b]
        cx, cy, cz = verts[c]
        ux, uy, uz = bx - ax, by - ay, bz - az
        vx, vy, vz = cx - ax, cy - ay, cz - az
        area2 = math.sqrt((uy * vz - uz * vy) ** 2 + (uz * vx - ux * vz) ** 2 + (ux * vy - uy * vx) ** 2)
        if area2 < 1e-9:
            degen += 1
    if degen:
        fails.append("degenerate tris: %d" % degen)
    # waterline sanity: mesh must contain both land and seabed verts
    above = sum(1 for v in verts if v[1] > 0.3)
    below = sum(1 for v in verts if v[1] < -0.3)
    if above == 0 or below == 0:
        fails.append("waterline missing (above=%d below=%d)" % (above, below))
    return fails, {"verts": len(verts), "tris": len(tris),
                   "above_wl": above, "below_wl": below,
                   "hmin": min(v[1] for v in verts), "hmax": max(v[1] for v in verts)}


def write_obj(path, verts, tris):
    with open(path, "w") as fh:
        fh.write("# ISLAND STRIKE P02 preview mesh (deterministic)\n")
        for (x, y, z) in verts:
            fh.write("v %.6f %.6f %.6f\n" % (x, y, z))
        for (a, b, c) in tris:
            fh.write("f %d %d %d\n" % (a + 1, b + 1, c + 1))


def main(argv):
    if "--selftest" in argv:
        _, v1, t1 = build(32.0)
        _, v2, t2 = build(32.0)
        assert v1 == v2 and t1 == t2, "non-deterministic mesh"
        fails, stats = check_mesh(v1, t1)
        print("selftest verts=%d tris=%d h=[%.2f, %.2f] fails=%s" %
              (stats["verts"], stats["tris"], stats["hmin"], stats["hmax"], fails))
        return 0 if not fails else 1
    step = 32.0
    out = os.path.join(ROOT, "preview/terrain_preview.obj")
    rep = os.path.join(ROOT, "preview/terrain_preview.json")
    for i, a in enumerate(argv):
        if a == "--step":
            step = float(argv[i + 1])
        if a == "--out":
            out = argv[i + 1]
        if a == "--report":
            rep = argv[i + 1]
    f, verts, tris = build(step)
    fails, stats = check_mesh(verts, tris)
    stats.update({"step_m": step, "coast_length_m": f.coast_length, "lut_n": f.lut_n,
                  "fails": fails})
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    write_obj(out, verts, tris)
    json.dump(stats, open(rep, "w"), indent=1)
    print("mesh %s verts=%d tris=%d fails=%s" % (out, stats["verts"], stats["tris"], fails))
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
