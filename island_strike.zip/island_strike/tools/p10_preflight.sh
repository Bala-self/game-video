#!/usr/bin/env bash
# P10 §2 FINAL Preflight: run P00-P09 regressions, log everything.
# Exit 0 only if every stage is GREEN.
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
GODOT_BIN="${GODOT_BIN:-$ROOT/tools/.godot/godot}"
export GODOT_BIN
LOG="reports/p10_preflight.log"
mkdir -p reports
: > "$LOG"
FAIL=0
stage() {
  echo "===== PREFLIGHT $1: $2 =====" | tee -a "$LOG"
  shift 2
  if "$@" >>"$LOG" 2>&1; then
    echo "GREEN: $1" | tee -a "$LOG"
  else
    echo "RED: $1 (exit $?)" | tee -a "$LOG"
    FAIL=1
  fi
}
tailstage() { echo "----- tail -----"; tail -6 "$LOG"; }

stage 0 "P00 world contract" python3 tools/validate_world_contract.py
tailstage
stage 1 "P01 full CI" bash tools/run_all_tests.sh
tailstage
stage 2a "P02 terrain dump" "$GODOT_BIN" --headless --path . \
  --script res://tests/godot/tools/terrain_check.gd -- --dump /tmp/p10_terrain_dump.json
tailstage
stage 2b "P02 terrain validate" python3 tools/terrain_cli.py validate all \
  --dump /tmp/p10_terrain_dump.json
tailstage
for s in static cross inject reproduce smoke perf regress; do
  stage "3-$s" "P03 roads $s" python3 tools/validate_roads.py "$s"
done
tailstage
stage 4a "P04 geometry metrics" "$GODOT_BIN" --headless --path . \
  --script res://tests/godot/tools/geometry_check.gd -- \
  --verify data/derived/road_geometry.json --metrics /tmp/p10_geo_metrics.json
for s in static reproduce inject bench regress; do
  stage "4-$s" "P04 $s" python3 tools/validate_road_geometry.py "$s"
done
stage 4x "P04 cross" python3 tools/validate_road_geometry.py cross /tmp/p10_geo_metrics.json
tailstage
stage 5a "P05 structure metrics" "$GODOT_BIN" --headless --path . \
  --script res://tests/godot/tools/structure_check.gd -- \
  --verify data/derived/transport_structures.json \
  --marks data/derived/transport_markings.json \
  --resv data/derived/transport_reservations.json \
  --metrics /tmp/p10_struct_metrics.json
for s in static inject reproduce impact bench regress safety; do
  stage "5-$s" "P05 $s" python3 tools/validate_transport_structures.py "$s"
done
stage 5x "P05 cross" python3 tools/validate_transport_structures.py cross \
  --metrics /tmp/p10_struct_metrics.json
tailstage
stage 6 "P06 all" python3 tools/validate_p06.py all
tailstage
stage 7 "P07 all" python3 tools/validate_p07.py all
tailstage
stage 8 "P08 all" python3 tools/validate_traffic.py all
tailstage
stage 9 "P09 all" python3 tools/validate_npc.py all
tailstage
echo "================ PREFLIGHT $([ "$FAIL" -eq 0 ] && echo GREEN || echo RED) ================" \
  | tee -a "$LOG"
exit "$FAIL"
