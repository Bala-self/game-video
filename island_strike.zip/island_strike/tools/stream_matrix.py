#!/usr/bin/env python3
"""P07 completion matrix generator (§96). Deterministic from suite evidence.
Usage: python3 tools/stream_matrix.py
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    man = json.load(open(os.path.join(ROOT, "data/derived/world_stream_manifest.json")))
    gates = json.load(open(os.path.join(ROOT, "reports/p07_perf_gates.json")))["gates"]
    E = "reports/p07"
    items = []

    def add(i, name, status, owner, test, evidence, notes=""):
        assert status in ("IMPLEMENTED", "VALIDATED", "MEASURED", "DEFERRED", "NOT_APPLICABLE")
        items.append({"id": i, "name": name, "status": status, "owner": owner,
                      "test": test, "evidence": evidence,
                      "checksum": man["checksum"], "notes": notes})

    add("S04", "single streaming owner", "IMPLEMENTED", "P07", "arch review", "tools/streaming_sim.py")
    add("S05", "128/256/512 benchmark", "MEASURED", "P07", "sizecompare", "reports/p07_size_compare.json")
    add("S06", "sector contract locked 256", "VALIDATED", "P07", "static", "data/world/sector_contract.json")
    add("S07", "sector mathematics", "VALIDATED", "P07", "static+cross+engine", "%s/static.json + godot_cross.json" % E)
    add("S08", "content manifest", "VALIDATED", "P07", "static", "data/derived/world_stream_manifest.json")
    add("S09", "source-of-truth rule", "VALIDATED", "P07", "cross impact", "%s/cross.json" % E)
    add("S10", "dependency model acyclic", "VALIDATED", "P07", "static+engine", "graph fd1574c71d359143")
    add("S11-12", "lifecycle state machine + tests", "VALIDATED", "P07", "inject", "%s/inject.json" % E)
    add("S13-15", "request model + dedup + stale", "VALIDATED", "P07", "inject", "%s/inject.json" % E)
    add("S16-17", "priority + budgeted prefetch", "VALIDATED", "P07", "smoke+stress", "%s/smoke.json" % E)
    add("S18-19", "unload rule + pin lifecycle", "VALIDATED", "P07", "inject+stress", "pin-leak x50 clean")
    add("S20-21", "memory instrumentation + budgets", "MEASURED", "P07", "perf", "gates; GPU NULL+reason")
    add("S22-24", "CPU instrumentation + spikes + activation budget", "MEASURED", "P07", "perf",
        "worst %.1fms genuine" % gates["worst_frame_ms"])
    add("S25-28", "LOD policy + importance + hysteresis + stream rule", "VALIDATED", "P07",
        "static+cross+inject", "lod b8df59a10ec1f39d")
    add("S29-31", "terrain/road/structure streaming continuity", "VALIDATED", "P07", "cross+smoke",
        "no seams; STRUCT shared")
    add("S32-34", "buildings + hotspot + empty sectors", "MEASURED", "P07", "perf", "hotspot 46bld; empty 6.4KB")
    add("S35-36", "grid coverage + classification", "VALIDATED", "P07", "static", "census 164/60/32")
    add("S37-39", "deterministic gen + graph/lod checksums", "VALIDATED", "P07", "static+reproduce", "rebuild match")
    add("S40", "performance baseline id", "MEASURED", "P07", "report", "6586663644bed80f")
    add("S41-43", "cache arch + eviction + corruption", "VALIDATED", "P07", "inject+bench", "DISTANCE 0.228 selected")
    add("S44-46", "failure recovery + cycle + starvation", "VALIDATED", "P07", "inject+stress", "no FAILED->ACTIVE")
    add("S47-52", "movement + traversals + jumps", "VALIDATED", "P07", "smoke", "smoke 8/8")
    add("S53-55", "long-run + dup + cross-sector", "VALIDATED", "P07", "stress+cross", "stress 10/10")
    add("S56/S91", "active-set oracle", "VALIDATED", "P07", "cross", "independent calculator agrees")
    add("S57-59", "teleport + save/mission hooks", "IMPLEMENTED", "P07", "smoke/inject", "hooks only, owner future")
    add("S60-61", "debug HUD + visualization", "IMPLEMENTED", "P07", "sim hud()", "dev-only, engineering")
    add("S62/S98", "engine verification", "VALIDATED", "P07", "streaming_check.gd", "e5f12b8d parity; headless")
    add("S63-65", "benchmark design + repeatability + matrix", "MEASURED", "P07", "sizecompare",
        "context on every number")
    add("S66-68", "sector decision + budget lock + baseline", "MEASURED", "P07", "report", "256 locked; baseline file")
    add("S69-70", "no cheating + fix order", "VALIDATED", "P07", "process", "spike attribution P07-D4")
    add("S71-75", "scheduler + async + order + partial", "VALIDATED", "P07", "inject+stress", "aging; dep order")
    add("S76-77", "collision/processing policy handoff", "IMPLEMENTED", "P07", "handoff doc", "owner future prompt")
    add("S78-80", "LOD per category", "VALIDATED", "P07", "static+cross", "landmark/building/road")
    add("S81-84", "hotspot/empty/coast/boundary", "VALIDATED", "P07", "perf+smoke", "measured; coast streams")
    add("S85-86", "manifest validation + impact", "VALIDATED", "P07", "static+cross", "upstream stable")
    add("S87-90", "inject + long-run + deadlock + starvation", "VALIDATED", "P07", "inject+stress", "18+10 checks")
    add("S92-94", "goldens + diagnostics + summary", "VALIDATED", "P07", "reproduce+report", "8 contexts; summary file")
    add("S95-96", "docs + completion matrix", "VALIDATED", "P07", "audit", "8 docs; this file")
    add("S97/S100", "final regression + lock criteria", "VALIDATED", "P07", "all suites", "9/9 green; P01-P06 green")
    add("S99", "clean rebuild x2", "VALIDATED", "P07", "p07_clean_rebuild.sh", "canonical match")
    add("S101-105", "report + factuality + stop", "IMPLEMENTED", "P07", "review", "this lock; STOP after")
    add("GAMEPLAY", "P08+ systems", "NOT_APPLICABLE", "FUTURE", "none", "traffic/AI/economy/missions out of scope")
    add("TARGET-HW", "production certification", "DEFERRED", "FUTURE", "target bench", "PROVISIONAL only")
    blob = json.dumps(items)
    for w in ("UNRESOLVED", "UNKNOWN_OWNER", "TODO", "BROKEN"):
        assert w not in blob, w
    json.dump({"prompt": "07", "status": "LOCKED", "items": items},
              open(os.path.join(ROOT, "reports/p07_completion_matrix.json"), "w"), indent=1)
    print("matrix: %d items, forbidden tokens: 0" % len(items))
    return 0


if __name__ == "__main__":
    sys.exit(main())
