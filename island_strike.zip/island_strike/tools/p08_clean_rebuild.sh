#!/usr/bin/env bash
# P08 clean rebuild: delete derived traffic artifacts, rebuild from
# locked roads + authored traffic contract, verify canonical outputs match.
# Authored P08 inputs (traffic_contract, CONTROL MODEL params) are inputs, not outputs.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
GODOT_BIN="${GODOT_BIN:-$ROOT/tools/.godot/godot}"
echo "=== P08 CLEAN REBUILD ==="
echo "--- checksums before:"
sha256sum data/derived/traffic_graph.json reports/p08_goldens.json \
  2>/dev/null | sed 's/  / /' || true
echo "--- deleting derived artifacts (goldens stay pinned):"
rm -f data/derived/traffic_graph.json
rm -rf reports/p08
rm -f reports/logs/p08_traffic_metrics.json reports/logs/p08_cross_metrics.json
mkdir -p reports/p08 reports/logs
echo "--- regenerating traffic graph:"
python3 tools/traffic_graph.py
echo "--- re-running full P08 validation (11 suites; cross re-runs engine+parity):"
export GODOT_BIN
python3 -u tools/validate_traffic.py all
echo "--- engine re-verification (canonical metrics copy):"
"$GODOT_BIN" --headless --path . --script res://tests/godot/tools/traffic_check.gd -- \
  --verify data/derived/traffic_graph.json --contract data/world/traffic_contract.json \
  --roads data/derived/roads.json --metrics reports/logs/p08_traffic_metrics.json \
  2>/dev/null | grep -E "TRAFFIC"
python3 -c "
import json
m = json.load(open('reports/logs/p08_traffic_metrics.json'))
g = json.load(open('data/derived/traffic_graph.json'))
assert m['graph_checksum'] == g['checksums']['traffic_graph_checksum'], m
assert (m['lanes'], m['movements'], m['signals']) == (77, 223, 10), m
print('engine metrics parity OK:', m['graph_checksum'])
"
echo "--- checksums after (graph must match before; goldens pinned + regress-green):"
sha256sum data/derived/traffic_graph.json reports/p08_goldens.json | sed 's/  / /'
echo "=== REBUILD COMPLETE ==="
