#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 06 -- settlement/district/building generator.

Downstream of LOCKED P03 graph + P04 geometry + P05 structures. Never
modifies upstream artifacts. Rectilinear doctrine: parcels are rectangles
in road-aligned local frames; footprints decompose to rect unions; all
clearance math is exact OBB/segment math (no fragile polygon clipping).
"""
import json
import math
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import Field, fnv1a_hex  # noqa: E402
from reservation_index import ReservationIndex  # noqa: E402
import transport_structures as TS  # noqa: E402 (shared seed/sector utils)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST_CC = os.path.join(ROOT, "data/world/district_contract.json")
BLDG_CC = os.path.join(ROOT, "data/world/building_contract.json")
GEO_JSON = os.path.join(ROOT, "data/derived/road_geometry.json")
ROADS_JSON = os.path.join(ROOT, "data/derived/roads.json")

sector_of = TS.sector_of
seed_for = TS.seed_for
q6 = TS.q6
canon = TS.canon


class DistrictsError(Exception):
    pass


# ================= 2D GEOMETRY (exact, no clipping) =================

def dot(ax, az, bx, bz):
    return ax * bx + az * bz


def sub(ax, az, bx, bz):
    return ax - bx, az - bz


def rect_corners(cx, cz, ux, uz, hw, hd):
    """OBB corners: center, unit axes (u along width, v=(-uz,ux) depth)."""
    vx, vz = -uz, ux
    return [(cx + su * ux * hw + sv * vx * hd,
             cz + su * uz * hw + sv * vz * hd)
            for su, sv in ((1, 1), (-1, 1), (-1, -1), (1, -1))]


def point_in_obb(px, pz, cx, cz, ux, uz, hw, hd, eps=0.0):
    dx, dz = px - cx, pz - cz
    return (abs(dot(dx, dz, ux, uz)) <= hw + eps and
            abs(dot(dx, dz, -uz, ux)) <= hd + eps)


def obb_overlap(a, b, tol=0.0):
    """SAT overlap of two OBBs (cx,cz,ux,uz,hw,hd). tol>0 shrinks both."""
    ca = rect_corners(*a)
    cb = rect_corners(*b)
    for ux, uz in ((a[2], a[3]), (-a[3], a[2]), (b[2], b[3]), (-b[3], b[2])):
        pa = [dot(x, z, ux, uz) for x, z in ca]
        pb = [dot(x, z, ux, uz) for x, z in cb]
        if max(pa) < min(pb) + tol or max(pb) < min(pa) + tol:
            return False
    return True


def seg_point_dist(px, pz, ax, az, bx, bz):
    abx, abz = bx - ax, bz - az
    L2 = abx * abx + abz * abz or 1e-18
    f = max(0.0, min(1.0, ((px - ax) * abx + (pz - az) * abz) / L2))
    return math.hypot(px - (ax + abx * f), pz - (az + abz * f)), f


def polyline_dist(px, pz, pts):
    return min(seg_point_dist(px, pz, pts[i][0], pts[i][1],
                              pts[i + 1][0], pts[i + 1][1])[0]
               for i in range(len(pts) - 1))


def segs_cross(p1, p2, p3, p4):
    def s(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    d1, d2 = s(p3, p4, p1), s(p3, p4, p2)
    d3, d4 = s(p1, p2, p3), s(p1, p2, p4)
    return ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0))


def obb_seg_hit(obb, ax, az, bx, bz):
    c = rect_corners(*obb)
    if point_in_obb(ax, az, *obb) or point_in_obb(bx, bz, *obb):
        return True
    for i in range(4):
        if segs_cross((ax, az), (bx, bz), c[i], c[(i + 1) % 4]):
            return True
    return False


# ================= SETTLEMENT TABLE (authored, purposeful) =================
# Each entry: id, class, center node (locked P03), districts with bounds.
# Bounds: disc (cx,cz,r) or sector (cx,cz,r0,r1,a0,a1 radians, east=0 CCW
# toward south to match x-right/z-down plan math).
SETTLEMENTS = [
    {"id": "SET-hub", "class": "MAJOR_CITY", "node": "hub_city",
     "bounds": [1400, 150, 560],
     "reason": "east urban center on the ring/radial hub; full gradient",
     "districts": [
         {"id": "D-hub-core", "class": "CITY_CORE", "disc": [1400, 150, 130]},
         {"id": "D-hub-mixed", "class": "MIXED_USE",
          "sector": [1400, 150, 130, 240, 0.0, 6.2832]},
         {"id": "D-hub-civic", "class": "CIVIC", "disc": [1230, 320, 110]},
         {"id": "D-hub-commercial", "class": "COMMERCIAL",
          "disc": [1560, 320, 110]},
         {"id": "D-hub-resin", "class": "RESIDENTIAL_INNER",
          "sector": [1400, 150, 240, 360, 0.0, 6.2832]},
         {"id": "D-hub-resout", "class": "RESIDENTIAL_OUTER",
          "sector": [1400, 150, 360, 500, 0.0, 6.2832]},
         {"id": "D-hub-water", "class": "WATERFRONT", "disc": [1740, 160, 130]},
     ]},
    {"id": "SET-port", "class": "PORT_COMPLEX", "node": "port_gate",
     "bounds": [1690, 690, 380],
     "reason": "cargo/port ops at the eastern port bulb + arterial",
     "districts": [
         {"id": "D-port-ops", "class": "PORT", "disc": [1810, 700, 170]},
         {"id": "D-port-ind", "class": "INDUSTRIAL",
          "sector": [1690, 690, 170, 330, 4.85, 9.9232]},
     ]},
    {"id": "SET-air", "class": "AIRFIELD_COMPLEX", "node": "air_gate",
     "bounds": [730, 1000, 240],
     "reason": "south airfield support; runway rect excluded by rule",
     "districts": [
         {"id": "D-air-ops", "class": "AIRFIELD", "disc": [700, 950, 160]},
     ]},
    {"id": "SET-sub", "class": "SECONDARY_TOWN", "node": "sub_center",
     "bounds": [1250, 1050, 260],
     "reason": "southern suburb town on the radial; park-rich",
     "districts": [
         {"id": "D-sub-mixed", "class": "MIXED_USE", "disc": [1250, 1050, 90]},
         {"id": "D-sub-sub", "class": "SUBURBAN",
          "sector": [1250, 1050, 90, 210, 0.0, 6.2832]},
     ]},
    {"id": "SET-village", "class": "VILLAGE", "node": "village_center",
     "bounds": [-100, 450, 200],
     "reason": "agri village on the west radial",
     "districts": [
         {"id": "D-vil-core", "class": "RURAL_VILLAGE",
          "disc": [-100, 450, 150]},
     ]},
    {"id": "SET-resort", "class": "RESORT_CLUSTER", "node": "resort_waterfront",
     "bounds": [-1120, 1500, 260],
     "reason": "SW coastal resort; beach access protected",
     "districts": [
         {"id": "D-res-main", "class": "RESORT", "disc": [-1120, 1500, 200]},
     ]},
    {"id": "SET-restricted", "class": "RESTRICTED_COMPLEX",
     "bounds": [850, -1500, 250],
     "node": "gate_restricted",
     "reason": "north secure compound on the restricted spur",
     "districts": [
         {"id": "D-res-secure", "class": "RESTRICTED", "disc": [850, -1500, 200]},
     ]},
    {"id": "SET-forest", "class": "RURAL_CLUSTER", "node": "forest_depot",
     "bounds": [-900, -300, 170],
     "reason": "forest service outpost; tiny by policy",
     "districts": [
         {"id": "D-for-svc", "class": "FOREST_SETTLEMENT",
          "disc": [-900, -300, 120]},
     ]},
    {"id": "SET-highland", "class": "RURAL_CLUSTER", "node": "ridge_end",
     "bounds": [830, -1280, 240],
     "reason": "highland lookout micro-cluster, terrain-following",
     "districts": [
         {"id": "D-hi-look", "class": "HIGHLAND_SETTLEMENT",
          "disc": [760, -1300, 130]},
     ]},
    {"id": "SET-farmA", "class": "RURAL_CLUSTER", "node": "jn_village",
     "reason": "farmstead A in south agri belt off the village road",
     "at": [-300, 900], "bounds": [-300, 900, 240], "districts": [
         {"id": "D-farmA", "class": "AGRICULTURAL", "disc": [-300, 900, 190]},
     ]},
    {"id": "SET-farmB", "class": "RURAL_CLUSTER", "node": "jn_sub",
     "reason": "farmstead B in south agri belt",
     "at": [500, 700], "bounds": [500, 700, 240], "districts": [
         {"id": "D-farmB", "class": "AGRICULTURAL", "disc": [500, 700, 190]},
     ]},
]


class Registry:
    def __init__(self):
        self.timers = {}
        self._t0 = None
        self._phase = None

    def _t(self, name):
        now = time.time()
        if self._phase is not None:
            self.timers[self._phase] = self.timers.get(self._phase, 0.0) + now - self._t0
        self._phase = name
        self._t0 = now

    # ================= PREFLIGHT =================
    def phase_preflight(self):
        self._t("preflight")
        self.dc = json.load(open(DIST_CC))
        self.bc = json.load(open(BLDG_CC))
        self.g = json.load(open(GEO_JSON))
        self.r = json.load(open(ROADS_JSON))
        pins = self.dc["pinned_checksums"]
        assert pins == self.bc["pinned_checksums"], "contract pin mismatch"
        if self.r["checksum"] != pins["road"]:
            raise DistrictsError("stale road graph")
        if self.g["checksum"]["geometry"] != pins["geometry"]:
            raise DistrictsError("stale road geometry")
        s = json.load(open(os.path.join(ROOT, "data/derived/transport_structures.json")))
        m = json.load(open(os.path.join(ROOT, "data/derived/transport_markings.json")))
        rv = json.load(open(os.path.join(ROOT, "data/derived/transport_reservations.json")))
        if s["checksum"] != pins["structures"] or m["checksum"] != pins["markings"] \
                or rv["checksum"] != pins["reservations"]:
            raise DistrictsError("stale P05 outputs")
        if self.dc["district_version"] != self.bc["district_version"]:
            raise DistrictsError("district/building version skew")
        self.f = Field()
        self.idx = ReservationIndex()
        self.runway = self.r["runway_rect"]  # [x0,z0,x1,z1]
        self._t(None)

    def checksum_scope(self, items):
        lines = sorted(canon(it) for it in items)
        return fnv1a_hex("\n".join(lines))


    # ================= GEN-B HELPERS =================
    def _disc_contains(self, disc, x, z):
        cx, cz, r = disc
        return (x - cx) ** 2 + (z - cz) ** 2 <= r * r

    def _sector_contains(self, sec, x, z):
        cx, cz, r0, r1, a0, a1 = sec
        d2 = (x - cx) ** 2 + (z - cz) ** 2
        if not (r0 * r0 <= d2 <= r1 * r1):
            return False
        if a1 - a0 >= 2 * math.pi - 1e-6:
            return True
        a = math.atan2(z - cz, x - cx)
        if a < 0:
            a += 2 * math.pi
        b0, b1 = a0 % (2 * math.pi), a1 % (2 * math.pi)
        if b1 <= b0:
            return a >= b0 or a <= b1
        return b0 <= a <= b1

    def _bounds_contains(self, b, x, z):
        if "disc" in b:
            return self._disc_contains(b["disc"], x, z)
        return self._sector_contains(b["sector"], x, z)

    def _edge_cache(self):
        if hasattr(self, "_ecache"):
            return
        self._ecache = {}
        for eid, E in self.g["edges"].items():
            pts = [(p["x"], p["z"]) for p in E["stations"]]
            xs = [p[0] for p in pts]
            zs = [p[1] for p in pts]
            self._ecache[eid] = {"pts": pts, "half": E["width_m"] / 2.0,
                                 "class": E["class"], "bbox": (min(xs), min(zs),
                                                               max(xs), max(zs))}
        self._jcache = {}
        for nid, J in self.g["junctions"].items():
            n = self.r["nodes"][nid]
            self._jcache[nid] = (n["x"], n["z"], J["R"])

    def _edges_near(self, cx, cz, r):
        self._edge_cache()
        out = []
        for eid, e in self._ecache.items():
            x0, z0, x1, z1 = e["bbox"]
            if x0 < cx + r and x1 > cx - r and z0 < cz + r and z1 > cz - r:
                out.append(eid)
        return sorted(out)

    def member_district(self, x, z):
        """Global partition: highest-priority district containing (x,z)."""
        best, bestp, tie = None, -1, False
        for d in self._dlist:
            if self._bounds_contains(d["bounds"], x, z):
                p = self.dc["district_priority"][d["class"]]
                if p > bestp:
                    best, bestp, tie = d["id"], p, False
                elif p == bestp:
                    tie = True
        return best, tie

    def _in_runway(self, x, z, margin=0.0):
        x0, z0, x1, z1 = self.runway
        return x0 - margin <= x <= x1 + margin and z0 - margin <= z <= z1 + margin

    # ================= GEN-B SETTLEMENTS =================
    def phase_settlements(self):
        self._t("settlements")
        self._edge_cache()
        self.settlements = []
        for s in SETTLEMENTS:
            n = self.r["nodes"][s["node"]]
            cx, cz = s.get("at", [n["x"], n["z"]])
            bx, bz, br = s["bounds"]
            # region = mode over land samples (centers can sit on roads)
            regs = {}
            k = 0
            r = 10.0
            while len(regs) < 1 and r < br:
                for a in range(12):
                    x, z = cx + math.cos(a / 12 * 2 * math.pi) * r, \
                        cz + math.sin(a / 12 * 2 * math.pi) * r
                    if self.f.is_land(x, z):
                        rg = self.f.region_at(x, z)
                        regs[rg] = regs.get(rg, 0) + 1
                r += 20.0
            region = max(regs, key=regs.get) if regs else "unknown"
            near = self._edges_near(bx, bz, br)
            # primary/secondary access by center distance to edge bbox
            def ed(eid):
                e = self._ecache[eid]
                x0, z0, x1, z1 = e["bbox"]
                dx = max(x0 - cx, 0, cx - x1)
                dz = max(z0 - cz, 0, cz - z1)
                return math.hypot(dx, dz)
            acc = sorted(near, key=ed)
            coast = any(self.f.is_coast_band(bx + dx, bz + dz)
                        for dx in (-br, 0, br) for dz in (-br, 0, br))
            rec = {"id": s["id"], "class": s["class"], "node": s["node"],
                   "center": [q6(cx), q6(cz)], "bounds": [bx, bz, br],
                   "region": region, "reason": s["reason"],
                   "area_m2": q6(math.pi * br * br),
                   "primary_access": acc[0] if acc else None,
                   "secondary_access": acc[1] if len(acc) > 1 else None,
                   "coastal": coast,
                   "seed": seed_for("p06-settlement", s["id"]),
                   "version": self.dc["district_version"]}
            self.settlements.append(rec)
        self._t(None)

    # ================= GEN-B DISTRICTS =================
    def phase_districts(self):
        self._t("districts")
        self._dlist = []
        for s in SETTLEMENTS:
            for d in s["districts"]:
                b = {"disc": d["disc"]} if "disc" in d else {"sector": d["sector"]}
                self._dlist.append({"id": d["id"], "class": d["class"],
                                    "settlement": s["id"], "bounds": b})
        self._dlist.sort(key=lambda d: d["id"])
        self.districts = []
        for d in self._dlist:
            cls = self.dc["district_classes"][d["class"]]
            cx = cz = 0.0
            bb = d["bounds"].get("disc") or d["bounds"]["sector"]
            cx, cz = bb[0], bb[1]
            r_out = bb[2] if "disc" in d["bounds"] else bb[3]
            near = self._edges_near(cx, cz, r_out)
            coast = any(self.f.is_coast_band(cx + dx, cz + dz)
                        for dx in (-r_out, 0, r_out)
                        for dz in (-r_out, 0, r_out))
            # runway overlap probe (dense sample of bounds)
            rw_hit = False
            x0 = min(self.runway[0], self.runway[2])
            for ix in range(21):
                for iz in range(21):
                    x = cx - r_out + 2 * r_out * ix / 20.0
                    z = cz - r_out + 2 * r_out * iz / 20.0
                    if self._bounds_contains(d["bounds"], x, z) and \
                            self._in_runway(x, z):
                        rw_hit = True
            rec = {"id": d["id"], "settlement": d["settlement"],
                   "class": d["class"], "bounds": d["bounds"],
                   "density_profile": cls["density_profile"],
                   "height_profile": cls["height_profile"],
                   "priority": self.dc["district_priority"][d["class"]],
                   "road_corridors": near, "coastal": coast,
                   "runway_overlap": rw_hit,
                   "seed": seed_for("p06-district", d["id"]),
                   "version": self.dc["district_version"]}
            self.districts.append(rec)
        self._area_closure()
        self._transitions()
        self._t(None)

    def _settle_grid(self, s):
        bx, bz, br = s["bounds"]
        step = 8.0
        pts = []
        ix = 0
        x = bx - br
        while x <= bx + br:
            z = bz - br
            iz = 0
            while z <= bz + br:
                if (x - bx) ** 2 + (z - bz) ** 2 <= br * br:
                    pts.append((x, z, ix, iz))
                z += step
                iz += 1
            x += step
            ix += 1
        return pts, step

    def _area_closure(self):
        # settlement = districts + water + infrastructure + natural; ties = ERROR
        self.closure = []
        for s in self.settlements:
            pts, step = self._settle_grid(s)
            bx, bz, br = s["bounds"]
            # rasterize road bands + junction discs onto the grid
            infra = set()
            near = self._edges_near(bx, bz, br)
            index = {(ix, iz): k for k, (x, z, ix, iz) in enumerate(pts)}
            for eid in near:
                e = self._ecache[eid]
                w = e["half"] + 2.0
                P = e["pts"]
                for i in range(len(P) - 1):
                    ax, az = P[i]
                    cx, cz = P[i + 1]
                    x0 = min(ax, cx) - w
                    x1 = max(ax, cx) + w
                    z0 = min(az, cz) - w
                    z1 = max(az, cz) + w
                    kx0 = int(math.floor((x0 - (bx - br)) / step))
                    kx1 = int(math.ceil((x1 - (bx - br)) / step))
                    kz0 = int(math.floor((z0 - (bz - br)) / step))
                    kz1 = int(math.ceil((z1 - (bz - br)) / step))
                    for kx in range(kx0, kx1 + 1):
                        for kz in range(kz0, kz1 + 1):
                            k = index.get((kx, kz))
                            if k is None:
                                continue
                            x, z = pts[k][0], pts[k][1]
                            if seg_point_dist(x, z, ax, az, cx, cz)[0] <= w:
                                infra.add(k)
            for nid, (jx, jz, jr) in self._jcache.items():
                if math.hypot(jx - bx, jz - bz) > br + jr:
                    continue
                for k, (x, z, ix, iz) in enumerate(pts):
                    if math.hypot(x - jx, z - jz) <= jr:
                        infra.add(k)
            counts = {"district_m2": 0.0, "water_m2": 0.0, "infra_m2": 0.0,
                      "natural_m2": 0.0, "ties": 0}
            by_district = {}
            win = {}
            for k, (x, z, ix, iz) in enumerate(pts):
                if not self.f.is_land(x, z):
                    counts["water_m2"] += step * step
                    win[(ix, iz)] = None
                    continue
                if k in infra:
                    counts["infra_m2"] += step * step
                    win[(ix, iz)] = "INFRA"
                    continue
                did, tie = self.member_district(x, z)
                if tie:
                    counts["ties"] += 1
                if did is None:
                    counts["natural_m2"] += step * step
                    win[(ix, iz)] = None
                else:
                    counts["district_m2"] += step * step
                    by_district[did] = by_district.get(did, 0.0) + step * step
                    win[(ix, iz)] = did
            for k in counts:
                if k != "ties":
                    counts[k] = q6(counts[k])
            self.closure.append({"settlement": s["id"], "counts": counts,
                                 "by_district": {k: q6(v) for k, v in
                                                 sorted(by_district.items())}})
            s["_win"] = win
            s["_step"] = step
        # ties are hard errors (priority table must be total)
        bad = [c for c in self.closure if c["counts"]["ties"]]
        if bad:
            raise DistrictsError("district priority ties: %s" % bad)

    def _transitions(self):
        # adjacency between winning districts; classify each pair
        GRADIENT = {tuple(sorted(p)) for p in [
            ("CITY_CORE", "MIXED_USE"), ("CITY_CORE", "CIVIC"),
            ("CITY_CORE", "COMMERCIAL"), ("MIXED_USE", "CIVIC"),
            ("MIXED_USE", "COMMERCIAL"), ("MIXED_USE", "RESIDENTIAL_INNER"),
            ("MIXED_USE", "WATERFRONT"), ("MIXED_USE", "RESORT"),
            ("RESIDENTIAL_INNER", "RESIDENTIAL_OUTER"),
            ("RESIDENTIAL_INNER", "WATERFRONT"),
            ("RESIDENTIAL_OUTER", "SUBURBAN"),
            ("RESIDENTIAL_OUTER", "WATERFRONT"), ("SUBURBAN", "MIXED_USE"),
            ("PORT", "INDUSTRIAL"), ("INDUSTRIAL", "UTILITY"),
            ("RURAL_VILLAGE", "AGRICULTURAL"), ("RESORT", "WATERFRONT")]}
        GRADIENT.add(tuple(sorted(("COMMERCIAL", "WATERFRONT"))))
        SHARP_BUFFER = {
            ("HIGHLAND_SETTLEMENT", "RESTRICTED"): "highland_terrain+spur_corridor"}
        VALID_SHARP = {tuple(sorted(p)) for p in [
            ("HIGHLAND_SETTLEMENT", "RESTRICTED"),
            ("RESIDENTIAL_OUTER", "AGRICULTURAL"),
            ("SUBURBAN", "AGRICULTURAL"),
            ("INDUSTRIAL", "RESIDENTIAL_OUTER"),
            ("COMMERCIAL", "RESIDENTIAL_INNER"),
            ("CIVIC", "RESIDENTIAL_INNER"),
            ("WATERFRONT", "RESIDENTIAL_OUTER"),
            ("AIRFIELD", "AGRICULTURAL"), ("AIRFIELD", "SUBURBAN"),
            ("RESTRICTED", "AGRICULTURAL"), ("RESTRICTED", "FOREST_SETTLEMENT"),
            ("RESORT", "AGRICULTURAL"), ("RESORT", "FOREST_SETTLEMENT")]}
        cls_of = {d["id"]: d["class"] for d in self._dlist}
        set_of = {d["id"]: d["settlement"] for d in self._dlist}
        pairs = {}
        for s in self.settlements:
            win = s["_win"]
            for (ix, iz), a in win.items():
                for nb in ((ix + 1, iz), (ix, iz + 1)):
                    b = win.get(nb, "EDGE")
                    if a == b or a in (None, "INFRA", "EDGE") or \
                            b in (None, "INFRA", "EDGE"):
                        continue
                    key = tuple(sorted((a, b)))
                    pairs[key] = pairs.get(key, 0) + 1
        self.transitions = []
        for (a, b), n in sorted(pairs.items()):
            ca, cb = cls_of[a], cls_of[b]
            key = tuple(sorted((ca, cb)))
            if set_of[a] == set_of[b] and key in GRADIENT:
                verdict = "VALID_GRADIENT"
            elif key in GRADIENT or key in VALID_SHARP:
                verdict = "VALID_SHARP_TRANSITION"
            else:
                verdict = "UNEXPLAINED_TRANSITION"
            rec = {"a": a, "b": b, "classes": [ca, cb],
                   "samples": n, "verdict": verdict}
            if verdict == "VALID_SHARP_TRANSITION" and key in SHARP_BUFFER:
                rec["buffer"] = SHARP_BUFFER[key]
            self.transitions.append(rec)
        bad = [t for t in self.transitions if t["verdict"] == "UNEXPLAINED_TRANSITION"]
        if bad:
            raise DistrictsError("unexplained transitions: %s" % bad)

    # ================= GEN-B EXPORT =================
    def phase_export_districts(self):
        self._t("export")
        for s in self.settlements:
            s.pop("_win", None)
            s.pop("_step", None)
        outdir = os.environ.get("P06_OUT_DIR", os.path.join(ROOT, "data/derived"))
        doc = {"meta": {"district_version": self.dc["district_version"],
                        "parcel_version": self.dc["parcel_version"],
                        "road_version": "0.1.0",
                        "road_checksum": self.dc["pinned_checksums"]["road"],
                        "geometry_version": "0.1.0",
                        "geometry_checksum": self.dc["pinned_checksums"]["geometry"],
                        "generator": "districts.py"},
               "settlements": self.settlements, "districts": self.districts,
               "area_closure": self.closure, "transitions": self.transitions,
               "checksum": ""}
        doc["checksum"] = self.checksum_scope(
            self.settlements + self.districts + self.closure + self.transitions)
        json.dump(doc, open(os.path.join(outdir, "districts.json"), "w"))
        self._t(None)

    # ================= GEN-C ROAD-BAND BLOCKS =================
    # Convex-quad OBB blocks marching along road runs. Frames derive ONLY
    # from road centerline stations (centroid + chord tangent). Runs split
    # at junction discs and the runway. Blocks are NOT subdivided here.
    BLOCK_DEPTH = {"primary": 70.0, "secondary": 60.0, "tertiary": 55.0,
                   "local": 50.0, "rural": 45.0, "service": 35.0,
                   "trail": 30.0}
    BLOCK_TOL_DEG = 2.0   # OBB edge-vs-frame exactness (validation)
    BLOCK_BREAK_DEG = 12.0  # tangent break that splits a block (marching)
    BLOCK_TARGET_LEN = 120.0  # allocation cap: close window past this
    CAMPUS_CLASSES = {"PORT", "INDUSTRIAL", "AIRFIELD", "RESTRICTED",
                      "CIVIC", "RESORT"}

    def phase_blocks(self):
        self._t("blocks")
        self._edge_cache()
        self.blocks = []
        self.blocks_dropped = []
        tol = math.radians(self.BLOCK_TOL_DEG)
        for eid in sorted(self.g["edges"]):
            E = self.g["edges"][eid]
            pts = [(p["x"], p["z"]) for p in E["stations"]]
            half = E["width_m"] / 2.0
            depth = self.BLOCK_DEPTH.get(E["class"], 45.0)
            bad = [self._station_blocked(x, z) for x, z in pts]
            # maximal good runs (>= 2 stations)
            runs = []
            a = None
            for i, b in enumerate(bad):
                if not b and a is None:
                    a = i
                if b and a is not None:
                    if i - a >= 1:
                        runs.append((a, i - 1))
                    a = None
            if a is not None and len(pts) - 1 - a >= 1:
                runs.append((a, len(pts) - 1))
            for (ra, rb) in runs:
                for (wa, wb) in self._march_windows(
                        pts, ra, rb, math.radians(self.BLOCK_BREAK_DEG)):
                    for side in (-1, 1):
                        self._emit_block(eid, E, pts, wa, wb, side,
                                         half, depth)
        self._validate_blocks()
        self._t(None)

    def _station_blocked(self, x, z):
        for (jx, jz, jr) in self._jcache.values():
            if math.hypot(x - jx, z - jz) <= jr + 4.0:
                return True
        return self._in_runway(x, z, margin=20.0)

    def _march_windows(self, pts, ra, rb, tol):
        # tangent of segment i (ra <= i < rb); skip degenerate segs
        def tang(i):
            ax, az = pts[i]
            bx, bz = pts[i + 1]
            d = math.hypot(bx - ax, bz - az)
            if d < 0.5:
                return None
            return math.atan2(bz - az, bx - ax)
        wins = []
        a = ra
        while a < rb:
            t0 = None
            j = a
            while j <= rb - 1:
                t = tang(j)
                if t is None:
                    j += 1
                    continue
                if t0 is None:
                    t0 = t
                d = abs((t - t0 + math.pi) % (2 * math.pi) - math.pi)
                if d > tol:
                    break
                j += 1
                cx0, cz0 = pts[a]
                cx1, cz1 = pts[min(j, rb)]
                if math.hypot(cx1 - cx0, cz1 - cz0) >= self.BLOCK_TARGET_LEN:
                    break
            b = min(j, rb)
            if b <= a:
                b = a + 1
            wins.append((a, b))
            a = b
        return wins

    def _emit_block(self, eid, E, pts, wa, wb, side, half, depth):
        wpts = pts[wa:wb + 1]
        cx = sum(p[0] for p in wpts) / len(wpts)
        cz = sum(p[1] for p in wpts) / len(wpts)
        ax, az = pts[wa]
        bx, bz = pts[wb]
        L = math.hypot(bx - ax, bz - az)
        if L < 0.5:  # degenerate window: use neighbor direction or drop
            self.blocks_dropped.append({"edge": eid, "stations": [wa, wb],
                                        "side": side,
                                        "reason": "degenerate_window"})
            return
        tx, tz = (bx - ax) / L, (bz - az) / L
        nx, nz = -tz, tx
        tmin = min((p[0] - cx) * tx + (p[1] - cz) * tz for p in wpts)
        tmax = max((p[0] - cx) * tx + (p[1] - cz) * tz for p in wpts)
        # inter-block alley gap: adjacent windows share a station with
        # different tangents (wedge overlap); inset ends by 2m each.
        if tmax - tmin > 10.0:
            tmin += 3.0
            tmax -= 3.0
        # road band as barrier: clear the chord deviation toward this side
        offs = [(p[0] - cx) * nx + (p[1] - cz) * nz for p in wpts]
        extra = max(offs) if side > 0 else -min(offs)
        extra = max(0.0, extra)
        n0 = side * (half + 1.0 + extra)
        n1 = side * (half + depth + extra)
        corners = []
        for (t, n) in ((tmin, n0), (tmax, n0), (tmax, n1), (tmin, n1)):
            corners.append([q6(cx + tx * t + nx * n),
                            q6(cz + tz * t + nz * n)])
        k = len([b for b in self.blocks if b["edge"] == eid and
                 b["side"] == side])
        tag = "L" if side < 0 else "R"
        self.blocks.append({"id": "BLK-%s-%s%d" % (eid, tag, k),
                            "edge": eid, "class": E["class"], "side": side,
                            "stations": [wa, wb],
                            "frame": {"center": [q6(cx), q6(cz)],
                                      "tangent": [q6(tx), q6(tz)],
                                      "half_width": half, "depth": depth},
                            "corners": corners,
                            "length": q6(tmax - tmin)})

    def _quad_samples(self, corners, nt=5, nn=3):
        (ax, az), (bx, bz), (cx, cz), (dx, dz) = corners
        for i in range(nt):
            s = i / (nt - 1.0)
            for j in range(nn):
                t = j / (nn - 1.0)
                # bilinear
                x = ax * (1 - s) * (1 - t) + bx * s * (1 - t) + \
                    cx * s * t + dx * (1 - s) * t
                z = az * (1 - s) * (1 - t) + bz * s * (1 - t) + \
                    cz * s * t + dz * (1 - s) * t
                yield x, z

    def _validate_blocks(self):
        # exactness + road/junction/runway clearance + district intersection
        keep = []
        for b in self.blocks:
            E = self.g["edges"][b["edge"]]
            pts = [(p["x"], p["z"]) for p in E["stations"]]
            wa, wb = b["stations"]
            half = E["width_m"] / 2.0
            ok, reason = True, ""
            # (1) frame exactness: corners rebuild from frame
            wpts = pts[wa:wb + 1]
            cx = sum(p[0] for p in wpts) / len(wpts)
            cz = sum(p[1] for p in wpts) / len(wpts)
            fx, fz = b["frame"]["center"]
            if abs(fx - cx) > 0.01 or abs(fz - cz) > 0.01:
                ok, reason = False, "frame_center_mismatch"
            # (2) long-edge alignment with road tangent within tol
            if ok:
                (ax, az), (bx2, bz2) = b["corners"][0], b["corners"][1]
                ang_b = math.atan2(bz2 - az, bx2 - ax)
                tx, tz = b["frame"]["tangent"]
                ang_t = math.atan2(tz, tx)
                d = abs((ang_b - ang_t + math.pi) % (2 * math.pi) - math.pi)
                if d > math.radians(self.BLOCK_TOL_DEG) + 1e-6:
                    ok, reason = False, "edge_misaligned"
            # (3) clearance: samples off road surface, junctions, runway
            if ok:
                for (x, z) in self._quad_samples(b["corners"]):
                    if polyline_dist(x, z, pts[wa:wb + 1]) < half + 0.4:
                        ok, reason = False, "road_overlap"
                        break
                    for (jx, jz, jr) in self._jcache.values():
                        if math.hypot(x - jx, z - jz) < jr + 1.0:
                            ok, reason = False, "junction_overlap"
                            break
                    if not ok:
                        break
                    if self._in_runway(x, z, margin=10.0):
                        ok, reason = False, "runway_overlap"
                        break
            # (4) district intersection (centroid or any corner wins)
            win = None
            if ok:
                pts4 = [b["frame"]["center"]] + b["corners"]
                for (x, z) in pts4:
                    w, _ = self.member_district(x, z)
                    if w is not None:
                        win = w
                        break
                if win is None:
                    ok, reason = False, "outside_districts"
            # (5) water share (mostly-water quads are not blocks)
            if ok:
                samp = list(self._quad_samples(b["corners"], nt=8, nn=4))
                wet = sum(1 for (x, z) in samp if not self.f.is_land(x, z))
                if wet / len(samp) > 0.8:
                    ok, reason = False, "water_block"
            if ok:
                self._finalize_block(b, win)
                keep.append(b)
            else:
                self.blocks_dropped.append({"id": b["id"], "edge": b["edge"],
                                            "side": b["side"],
                                            "reason": reason})
        self.blocks = keep

    def _finalize_block(self, b, win):
        cx, cz = b["frame"]["center"]
        dcls = next(d["class"] for d in self._dlist if d["id"] == win)
        b["district_id"] = win
        b["district_hint"] = win
        try:
            b["region_id"] = self.f.region_at(cx, cz)
        except Exception:
            b["region_id"] = "unknown"
        dep = abs(b["frame"]["depth"] - 1.0)
        b["area"] = q6(b["length"] * dep)
        b["frontage"] = b["length"]
        nj, nd = None, 1e18
        for nid, (jx, jz, jr) in self._jcache.items():
            dd = math.hypot(cx - jx, cz - jz) - jr
            if dd < nd:
                nj, nd = nid, dd
        b["junction"] = {"nearest": nj, "clear_m": q6(nd)}
        b["access"] = {"edge": b["edge"], "side": b["side"]}
        samp = list(self._quad_samples(b["corners"], nt=8, nn=4))
        good = 0
        for (x, z) in samp:
            if not self.f.is_land(x, z):
                continue
            _, pct = self.f.slope_grade(x, z)
            if pct / 100.0 <= 0.25:
                good += 1
        r = good / len(samp)
        b["buildability"] = {"land_ok_ratio": q6(r),
                             "verdict": "BUILDABLE" if r >= 0.7 else
                             ("MARGINAL" if r >= 0.3 else "NON_BUILDABLE")}
        b["campus"] = dcls in self.CAMPUS_CLASSES
        b["seed"] = seed_for("p06-block", b["id"])

    def phase_export_blocks(self):
        self._t("export_blocks")
        outdir = os.environ.get("P06_OUT_DIR", os.path.join(ROOT, "data/derived"))
        doc = {"meta": {"district_version": self.dc["district_version"],
                        "parcel_version": self.dc["parcel_version"],
                        "generator": "districts.py"},
               "blocks": self.blocks, "dropped": self.blocks_dropped,
               "checksum": ""}
        doc["checksum"] = self.checksum_scope(self.blocks)
        json.dump(doc, open(os.path.join(outdir, "blocks.json"), "w"))
        self._t(None)

def main():
    reg = Registry()
    reg.phase_preflight()
    reg.phase_settlements()
    reg.phase_districts()
    reg.phase_export_districts()
    print("gen-b ok: %d settlements %d districts" % (len(reg.settlements),
                                                     len(reg.districts)))
    reg.phase_blocks()
    reg.phase_export_blocks()
    print("gen-c ok: %d blocks (%d dropped)" % (len(reg.blocks),
                                                len(reg.blocks_dropped)))
    print("timers: %s" % " ".join("%s=%.2f" % kv for kv in sorted(reg.timers.items())))


if __name__ == "__main__":
    main()

