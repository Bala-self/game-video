#!/usr/bin/env python3
"""P05 reservation spatial queries (authoritative API for future systems).

Future building/vegetation/gameplay systems must query THIS module instead
of ad-hoc distance tests. Backed by data/derived/transport_reservations.json
+ locked P04 station chainage (no P04 rebuild, read-only reference).

API: is_reserved(x, z) -> [records...]
     reservation_types_at(x, z) -> sorted [layer...]
     nearest_reservation(x, z) -> record + distance
     is_vegetation_excluded(x, z) / is_building_excluded(x, z) /
     is_junction_excluded(x, z) -> bool + reason records
"""
import json
import math
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESV_JSON = os.path.join(ROOT, "data/derived/transport_reservations.json")
GEO_JSON = os.path.join(ROOT, "data/derived/road_geometry.json")

VEG_SOURCES = ("vegetation_exclusion", "road_safety", "junction",
               "visibility", "bridge_exclusion", "tunnel_exclusion",
               "retaining_footprint", "maintenance", "pulloff")
BUILD_SOURCES = ("building_setback", "junction", "visibility",
                 "bridge_exclusion", "tunnel_exclusion",
                 "retaining_footprint", "maintenance", "pulloff",
                 "road_safety")


class ReservationIndex:
    def __init__(self, resv_path=None, geo_path=None):
        self.r = json.load(open(resv_path or RESV_JSON))
        self.g = json.load(open(geo_path or GEO_JSON))
        self.cell = self.r["index_cell_m"]
        self.by_id = {}
        for layer, items in self.r["layers"].items():
            for it in items:
                self.by_id[it["id"]] = (layer, it)

    # ---- geometry predicates ----
    def _edge_dist(self, eid, d0, d1, x, z):
        st = self.g["edges"][eid]["stations"]
        best = 1e300
        for i in range(len(st) - 1):
            if st[i + 1]["d"] < d0 or st[i]["d"] > d1:
                continue
            ax, az = st[i]["x"], st[i]["z"]
            bx, bz = st[i + 1]["x"], st[i + 1]["z"]
            abx, abz = bx - ax, bz - az
            L2 = abx * abx + abz * abz or 1e-18
            t = max(0.0, min(1.0, ((x - ax) * abx + (z - az) * abz) / L2))
            best = min(best, math.hypot(x - (ax + abx * t), z - (az + abz * t)))
        return best

    @staticmethod
    def _in_tri(tri, x, z):
        (ax, az), (bx, bz), (cx, cz) = tri
        d = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz)
        if abs(d) < 1e-12:
            return False
        la = ((bz - cz) * (x - cx) + (cx - bx) * (z - cz)) / d
        lb = ((cz - az) * (x - cx) + (ax - cx) * (z - cz)) / d
        return la >= 0 and lb >= 0 and la + lb <= 1

    def _match(self, layer, it, x, z):
        if "x" in it and "z" in it and "R" in it:
            inside = math.hypot(x - it["x"], z - it["z"]) <= it["R"]
            return inside, abs(math.hypot(x - it["x"], z - it["z"]) - it["R"])
        if "pos" in it and layer in ("sign_anchor", "street_light"):
            d = math.hypot(x - it["pos"][0], z - it["pos"][1])
            return d <= 1.0, d
        if "tri" in it:
            inside = self._in_tri(it["tri"], x, z)
            cx = sum(p[0] for p in it["tri"]) / 3.0
            cz = sum(p[1] for p in it["tri"]) / 3.0
            return inside, math.hypot(x - cx, z - cz)
        if "bbox" in it:
            x0, z0, x1, z1 = it["bbox"]
            inside = x0 <= x <= x1 and z0 <= z <= z1
            dx = max(x0 - x, 0.0, x - x1)
            dz = max(z0 - z, 0.0, z - z1)
            return inside, math.hypot(dx, dz)
        if "edge" in it and "offset" in it:
            d = self._edge_dist(it["edge"], it["d0"], it["d1"], x, z)
            inner = it.get("inner_off", 0.0)
            return inner <= d <= it["offset"], abs(d - it["offset"])
        if "size" in it:
            w, h = it["size"]
            inside = abs(x - it["x"]) <= w / 2.0 and abs(z - it["z"]) <= h / 2.0
            return inside, math.hypot(x - it["x"], z - it["z"])
        return False, 1e300

    def _candidates(self, x, z):
        key = "%d,%d" % (math.floor((x + 2048.0) / self.cell),
                         math.floor((z + 2048.0) / self.cell))
        ids = set(self.r["index"].get(key, []))
        # neighbor cells: reservations wider than a cell register multi-cells
        # at build; single-cell lookup suffices by construction.
        return [self.by_id[i] for i in sorted(ids) if i in self.by_id]

    # ---- public API ----
    def is_reserved(self, x, z):
        out = []
        for layer, it in self._candidates(x, z):
            inside, _ = self._match(layer, it, x, z)
            if inside:
                out.append({"layer": layer, "id": it["id"],
                            "source": {k: it[k] for k in
                                       ("edge", "node", "bridge", "structure")
                                       if k in it}})
        return sorted(out, key=lambda r: (r["layer"], r["id"]))

    def reservation_types_at(self, x, z):
        return sorted(set(r["layer"] for r in self.is_reserved(x, z)))

    def nearest_reservation(self, x, z):
        best, bd = None, 1e300
        for layer, items in self.r["layers"].items():
            for it in items:
                _, d = self._match(layer, it, x, z)
                if d < bd:
                    bd, best = d, {"layer": layer, "id": it["id"]}
        return best, bd

    def _excluded(self, x, z, sources):
        hits = [r for r in self.is_reserved(x, z) if r["layer"] in sources]
        return (len(hits) > 0), hits

    def is_vegetation_excluded(self, x, z):
        return self._excluded(x, z, VEG_SOURCES)

    def is_building_excluded(self, x, z):
        return self._excluded(x, z, BUILD_SOURCES)

    def is_junction_excluded(self, x, z):
        return self._excluded(x, z, ("junction",))
