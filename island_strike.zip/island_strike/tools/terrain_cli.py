#!/usr/bin/env python3
"""ISLAND STRIKE — unified terrain CLI (Prompt 02).

  terrain_cli.py generate [--mesh] [--dump PATH] [--zones]
      Regenerate derived artifacts (preview mesh, Godot field dump, urban zones).
  terrain_cli.py validate [static|cross|inject|reproduce|all] [--dump PATH]
      Run validator suites (cross needs a --dump file; use generate --dump first).
  terrain_cli.py checksum
      Print the field checksum (FNV over LUT + fixed samples; engine-free).
  terrain_cli.py report [--out PATH]
      Machine-readable summary (versions, checksums, stats) as JSON.

Exit codes: 0 ok, 1 validation failed, 2 usage/tool error.
"""
import json, math, os, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from terrain_model import Field, fnv1a_hex  # noqa: E402


def godot_bin():
    for cand in [os.environ.get("GODOT_BIN"), os.path.join(ROOT, "tools/.godot/godot")]:
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    raise SystemExit("Godot binary not found (run tools/fetch_godot.py)")


def checksum_field():
    f = Field()
    canon = ""
    for e in f.lut:
        canon += "%s|%d|%d|%d|%d|%d|%s|%s;" % (
            e["class"], round(e["width"] * 1e6), round(e["rwidth"] * 1e6),
            round(e["berm"] * 1e6), round(e["rs"] * 1e6), round(e["arc"] * 1e6),
            e["region"], e["class"])
    lut_digest = fnv1a_hex(canon)
    hs = []
    g = -2000
    while g <= 2000:
        h = -2000
        while h <= 2000:
            if g * g + h * h <= 2000 * 2000:
                hs.append("%d:%s" % (round(f.height(float(g), float(h)) * 1e6),
                                     f.region_at(float(g), float(h))))
            h += 300
        g += 300
    return {"lut_digest": lut_digest, "sample_digest": fnv1a_hex("|".join(hs)),
            "lut_n": f.lut_n, "coast_length_m": round(f.coast_length, 3)}


def cmd_generate(argv):
    do_mesh = "--mesh" in argv
    do_zones = "--zones" in argv
    dump = None
    for i, a in enumerate(argv):
        if a == "--dump":
            dump = argv[i + 1]
    if not (do_mesh or do_zones or dump):
        do_mesh = do_zones = True
        dump = os.path.join(ROOT, "preview/terrain_dump.json")
    if do_mesh:
        r = subprocess.run([sys.executable, os.path.join(ROOT, "tools/build_preview_mesh.py"),
                            "--step", "32"], capture_output=True, text=True)
        print(r.stdout.strip())
        if r.returncode != 0:
            print(r.stderr[-2000:], file=sys.stderr)
            return 1
    if do_zones:
        r = subprocess.run([sys.executable, os.path.join(ROOT, "tools/derive_zones.py")],
                           capture_output=True, text=True)
        print(r.stdout.strip() or "(zones ok)")
        if r.returncode != 0:
            print(r.stderr[-2000:], file=sys.stderr)
            return 1
    if dump:
        cmd = [godot_bin(), "--headless", "--path", ROOT, "--script",
               "res://tests/godot/tools/terrain_check.gd", "--", "--dump", dump]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
        print(r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "(no output)")
        if r.returncode != 0:
            print(r.stdout[-2000:], file=sys.stderr)
            print(r.stderr[-2000:], file=sys.stderr)
            return 1
    return 0


def cmd_validate(argv):
    suite = argv[0] if argv and argv[0] in ("static", "cross", "inject", "reproduce", "all") else "all"
    dump = None
    for i, a in enumerate(argv):
        if a == "--dump":
            dump = argv[i + 1]
    suites = ["static", "inject", "reproduce"] if suite == "all" else [suite]
    if suite in ("all", "cross") and dump is None and suite == "cross":
        print("cross needs --dump PATH (run generate --dump first)", file=sys.stderr)
        return 2
    rc = 0
    if suite == "all":
        # cross needs a fresh dump; produce one alongside
        dump = "/tmp/is_tcli_dump.json"
        cmd = [godot_bin(), "--headless", "--path", ROOT, "--script",
               "res://tests/godot/tools/terrain_check.gd", "--", "--dump", dump]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
        if r.returncode != 0:
            print("dump failed", file=sys.stderr)
            return 1
        suites = ["static", "cross", "inject", "reproduce"]
    for s in suites:
        args = [sys.executable, os.path.join(ROOT, "tools/validate_terrain.py"), s]
        if s == "cross":
            args.append(dump)
        r = subprocess.run(args, capture_output=True, text=True, timeout=600)
        tail = [ln for ln in r.stdout.strip().splitlines()
                if ln.startswith(("STATIC", "CROSS", "INJECT", "REPRODUCE")) or "FAIL" in ln]
        print("\n".join(tail) if tail else r.stdout.strip()[-500:])
        if r.returncode != 0:
            rc = 1
    return rc


def cmd_report(argv):
    out = None
    for i, a in enumerate(argv):
        if a == "--out":
            out = argv[i + 1]
    f = Field()
    cs = checksum_field()
    surf = 0.0
    for cor in f.au["corridors"]:
        if cor["type"] == "tunnel":
            continue
        P = cor["points"]
        surf += sum(math.hypot(P[i + 1][0] - P[i][0], P[i + 1][1] - P[i][1])
                    for i in range(len(P) - 1))
    water = sum(math.pi * lk["rx"] * lk["rz"] for lk in f.au["drainage"]["lakes"]) / 1e6
    rep = {
        "prompt": "P02-terrain-coast", "status": "see LOCK file",
        "versions": {k: f.wc[k] for k in ("world_version",) },
        "terrain_version": f.tc.get("terrain_version", "?"),
        "coast_version": f.cc.get("coast_version", "?"),
        "authoring_version": f.au.get("meta", {}).get("authoring_version", "?"),
        "checksums": cs,
        "stats": {
            "coast_length_m": round(f.coast_length, 1),
            "surface_corridors_km": round(surf / 1000, 2),
            "inland_water_km2": round(water, 4),
            "lakes": len(f.au["drainage"]["lakes"]),
            "landforms": len(f.au["landforms"]),
            "corridors": len(f.au["corridors"]),
        },
    }
    txt = json.dumps(rep, indent=1)
    if out:
        open(out, "w").write(txt)
        print("wrote %s" % out)
    else:
        print(txt)
    return 0


def main(argv):
    if len(argv) < 2 or argv[1] not in ("generate", "validate", "checksum", "report"):
        print(__doc__)
        return 2
    if argv[1] == "generate":
        return cmd_generate(argv[2:])
    if argv[1] == "validate":
        return cmd_validate(argv[2:])
    if argv[1] == "checksum":
        print(json.dumps(checksum_field(), indent=1))
        return 0
    return cmd_report(argv[2:])


if __name__ == "__main__":
    sys.exit(main(sys.argv))
