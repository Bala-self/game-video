#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 09 -- NPC/navigation/AI validator.

Usage: python3 tools/validate_npc.py [all|suite...]
Suites: static cross inject reproduce smoke perf regress stress
        navigation perception behavior population
Reports: reports/p09/<suite>.json
"""
import json
import hashlib
import math
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from npc_sim import NPCWorld  # noqa: E402
from npc_gen import canon, fnv1a64_hex  # noqa: E402
from sector_math import SectorGrid, sector_id  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DD = os.path.join(ROOT, "data/derived")
DW = os.path.join(ROOT, "data/world")
GODOT = os.environ.get("GODOT_BIN", os.path.join(ROOT, "tools/.godot/godot"))
NAV_PIN = "3f9a234fcffe672a"
POP_PIN = "fd1f5bdeeb7e95e7"
POL_PIN = "5b59d290bb0de76b"
BEH_PIN = "0f3fde2cdb1da2c8"
PERC_PIN = "71e6e20d666e14df"


class Suite:
    def __init__(self, name):
        self.name = name
        self.checks = []
        self.ok = True

    def check(self, name, cond, detail=""):
        self.checks.append({"name": name, "pass": bool(cond),
                            "detail": str(detail)[:300]})
        if not cond:
            self.ok = False

    def report(self):
        os.makedirs(os.path.join(ROOT, "reports/p09"), exist_ok=True)
        doc = {"suite": self.name, "passed": self.ok,
               "checks": "%d/%d" % (
                   sum(1 for c in self.checks if c["pass"]),
                   len(self.checks)),
               "results": self.checks}
        if getattr(self, "evidence", None) is not None:
            doc["evidence"] = self.evidence
        with open(os.path.join(ROOT, "reports/p09/%s.json" % self.name),
                  "w") as f:
            json.dump(doc, f, indent=1)
        print("%-10s %s (%s)" % (self.name,
                                 "PASS" if self.ok else "FAIL",
                                 doc["checks"]))
        for c in self.checks:
            if not c["pass"]:
                print("  FAIL %s :: %s" % (c["name"], c["detail"]))
        return self.ok


def load_all():
    D = {}
    for fn in ("npc_navigation_manifest.json",
               "npc_population_manifest.json", "npc_spawn_zones.json",
               "npc_behavior_policy.json", "npc_perception_policy.json",
               "traffic_graph.json", "roads.json", "places.json",
               "buildings.json", "districts.json",
               "p06_handoff_nav.json", "world_stream_manifest.json",
               "transport_structures.json"):
        with open(os.path.join(DD, fn)) as f:
            D[fn] = json.load(f)
    for fn in ("npc_contract.json", "npc_contract.schema.json",
               "traffic_contract.json", "sector_contract.json"):
        with open(os.path.join(DW, fn)) as f:
            D[fn] = json.load(f)
    return D


# ================= STATIC =================
def suite_static():
    s = Suite("static")
    D = load_all()
    tc = D["npc_contract.json"]
    sch = D["npc_contract.schema.json"]
    nav = D["npc_navigation_manifest.json"]
    pop = D["npc_population_manifest.json"]
    # 1) schema keys
    missing = [k for k in sch["required"] if k not in tc]
    s.check("schema-keys", not missing, str(missing))
    # 2) policy versions
    nov = [k for k in ("seed_policy", "spawn_policy", "movement_policy",
                       "perception_policy", "behavior_policy",
                       "interaction_policy", "simulation_tier_policy",
                       "lod_policy", "performance_policy",
                       "validation_policy", "walkability")
           if "policy_version" not in tc.get(k, {})]
    s.check("policy-versions", not nov, str(nov))
    # 3) sources pinned
    want = {"roads_checksum": "0e28622c1bb2185b",
            "geometry_checksum": "69ca624214ee76fe",
            "structures_checksum": "656214306d5855e4",
            "districts_checksum": "161574ec12f6d831",
            "buildings_checksum": "55e11fbec4acea23",
            "places_checksum": "2b4df3e668269084",
            "nav_handoff_checksum": "54ad0d36ee0b785a",
            "p06_ai_handoff_checksum": "1825b8090aa16d6b",
            "world_stream_manifest_checksum": "3970e8e7e96b4e17",
            "streaming_graph_checksum": "fd1574c71d359143",
            "traffic_checksum": "dda8657c55ae8b47"}
    bad = [k for k, v in want.items()
           if tc["sources"].get(k) != v]
    s.check("sources-pinned", not bad, str(bad))
    # 4) checksum recompute + pins
    nav_core = {"areas": nav["areas"], "nodes": nav["nodes"],
                "edges": nav["edges"], "crossings": nav["crossings"],
                "settings": nav["settings"], "sources": nav["sources"]}
    s.check("nav-checksum",
            fnv1a64_hex(canon(nav_core)) ==
            nav["npc_navigation_checksum"] == NAV_PIN,
            nav["npc_navigation_checksum"])
    pop_core = {"zones": pop["zones"], "archetypes": pop["archetypes"],
                "population_version": pop["population_version"],
                "sources": pop["sources"]}
    s.check("pop-checksum",
            fnv1a64_hex(canon(pop_core)) ==
            pop["npc_population_checksum"] == POP_PIN,
            pop["npc_population_checksum"])
    pol_core = {"movement": tc["movement_policy"],
                "perception": tc["perception_policy"],
                "behavior": tc["behavior_policy"],
                "tiers": tc["simulation_tier_policy"],
                "lod": tc["lod_policy"],
                "performance": tc["performance_policy"]}
    s.check("policy-checksum",
            fnv1a64_hex(canon(pol_core)) ==
            pop["npc_policy_checksum"] == POL_PIN,
            pop["npc_policy_checksum"])
    # 5) census pins
    s.check("census", (len(nav["areas"]), len(nav["nodes"]),
                       len(nav["edges"]), len(nav["crossings"]),
                       len(pop["zones"])) == (127, 1087, 2348, 34, 26),
            "%d/%d/%d/%d/%d" % (len(nav["areas"]), len(nav["nodes"]),
                                len(nav["edges"]), len(nav["crossings"]),
                                len(pop["zones"])))
    s.check("targets", sum(z["target_population"]
                           for z in pop["zones"]) == 1263,
            sum(z["target_population"] for z in pop["zones"]))
    # 6) graph integrity
    ids = set(n["id"] for n in nav["nodes"])
    s.check("node-unique", len(ids) == len(nav["nodes"]))
    dangle = [e for e in nav["edges"]
              if e["a"] not in ids or e["b"] not in ids]
    s.check("edge-resolve", not dangle, str(dangle[:2]))
    cdangle = [c for c in nav["crossings"]
               if c["a"] not in ids or c["b"] not in ids]
    s.check("crossing-resolve", not cdangle, str(cdangle[:2]))
    # 7) node evidence thresholds
    mx = tc["walkability"]["max_slope_grade"]
    blk = set(tc["walkability"]["blocked_regions"])
    bad_ev = [n["id"] for n in nav["nodes"]
              if n.get("slope_grade", 0) > mx + 1e-9 or
              n.get("region") in blk]
    s.check("node-evidence", not bad_ev, str(bad_ev[:3]))
    # 8) zones sane
    neg = [z["zone_id"] for z in pop["zones"]
           if z["target_population"] < 0]
    s.check("zone-targets", not neg, str(neg))
    restr = [z for z in pop["zones"] if z["class"] == "RESTRICTED"]
    s.check("restricted-blocked",
            all("POPULATION_BLOCKED" in z["restrictions"] and
                z["target_population"] == 0 for z in restr),
            "%d restricted zones" % len(restr))
    # 9) archetypes
    archs = pop["archetypes"]
    need = {"CIVILIAN", "WORKER", "COMMUTER", "SHOPPER", "TOURIST",
            "RESIDENT", "SERVICE_HOOK", "SECURITY_HOOK",
            "EMERGENCY_HOOK"}
    s.check("archetype-roster", set(archs.keys()) == need,
            str(sorted(set(archs.keys()) ^ need)))
    af = ["walk", "run", "turn", "radius", "los", "fov", "prox",
          "react", "traffic", "despawn"]
    bad_a = [k for k, v in archs.items()
             if any(f not in v for f in af)]
    s.check("archetype-fields", not bad_a, str(bad_a))
    # 10) spawn zones
    sp = D["npc_spawn_zones.json"]["zones"]
    empty = [z["zone_id"] for z in pop["zones"]
             if not z["restrictions"] and
             not sp.get(z["zone_id"], {}).get("spawn_points")]
    s.check("spawn-coverage", not empty, str(empty[:3]))
    nsp = sum(len(v["spawn_points"]) for v in sp.values())
    s.check("spawn-count", nsp > 200, nsp)
    # 11) behavior/perception policies
    beh = D["npc_behavior_policy.json"]
    expect = set()
    for cl in set(beh["class_map"].values()) | {"default"}:
        for sc in ("MORNING", "DAY", "EVENING", "NIGHT"):
            expect.add("%s|%s" % (cl, sc))
    s.check("beh-weights", set(beh["weights"].keys()) == expect,
            str(len(beh["weights"])))
    perc = D["npc_perception_policy.json"]
    s.check("perc-roster", set(perc["archetypes"].keys()) == need)
    # 12) transition tables are POLICY DATA (P09-D13)
    mm = beh["movement_machine"]["states"]
    bm = beh["behavior_machine"]["states"]
    dead = [k for k, v in mm.items() if not v and k != "DESPAWNED"]
    s.check("move-table", not dead and
            "RECOVERING" in mm["FAILED"] and
            "RECOVERING" in mm["STUCK"] and
            "DESPAWNING" in mm["FAILED"] and
            "CROSSING" in mm["WAITING"] and
            "IDLE" in mm["CROSSING"], str(dead))
    s.check("beh-table", bm["DESPAWN"] == [] and
            "DESPAWN" in bm["RECOVER"] and
            "REACT" not in bm["REACT"])
    s.check("beh-pin", beh["npc_behavior_checksum"] == BEH_PIN)
    s.check("perc-pin", perc["npc_perception_checksum"] == PERC_PIN)
    w0 = NPCWorld(seed_tag="static0", with_traffic=False)
    s.check("sim-loads-policy",
            w0.move_table == {k: set(v) for k, v in mm.items()} and
            w0.beh_table == {k: set(v) for k, v in bm.items()})
    # 13) engine script parses
    r = subprocess.run(
        [GODOT, "--headless", "--path", ROOT, "--check-only", "--script",
         "res://tests/godot/tools/npc_check.gd"],
        capture_output=True, text=True, timeout=120)
    s.check("engine-parse", r.returncode == 0,
            (r.stderr or "")[-200:])
    return s


# ================= CROSS =================
def suite_cross():
    s = Suite("cross")
    D = load_all()
    tc = D["npc_contract.json"]
    nav = D["npc_navigation_manifest.json"]
    pop = D["npc_population_manifest.json"]
    # 1) engine NPC_OK + metrics agree
    mpath = os.path.join(ROOT, "reports/logs/p09_cross_metrics.json")
    r = subprocess.run(
        [GODOT, "--headless", "--path", ROOT, "--script",
         "res://tests/godot/tools/npc_check.gd", "--",
         "--verify", os.path.join(DD, "npc_navigation_manifest.json"),
         "--population", os.path.join(DD, "npc_population_manifest.json"),
         "--contract", os.path.join(DW, "npc_contract.json"),
         "--metrics", mpath],
        capture_output=True, text=True, timeout=240)
    out = (r.stdout or "") + (r.stderr or "")
    s.check("engine-ok", "NPC_OK" in out,
            out.strip().splitlines()[-1][:200] if out.strip()
            else "no output")
    try:
        m = json.load(open(mpath))
    except Exception as e:
        s.check("engine-metrics", False, repr(e)[:150])
        return s
    s.check("x-nav", m["npc_navigation_checksum"] ==
            nav["npc_navigation_checksum"])
    s.check("x-pop", m["npc_population_checksum"] ==
            pop["npc_population_checksum"])
    s.check("x-pol", m["npc_policy_checksum"] ==
            pop["npc_policy_checksum"])
    s.check("x-counts", (m["areas"], m["nodes"], m["edges"],
                         m["crossings"], m["zones"], m["targets"]) ==
            (127, 1087, 2348, 34, 26, 1263), str(m))
    # 2) areas ref walkable open spaces
    osmap = {o["id"]: o for o in D["places.json"]["open_spaces"]}
    bad_a = [a["id"] for a in nav["areas"]
             if a["open_space"] not in osmap or
             osmap[a["open_space"]]["navigation_policy"] != "walkable"]
    s.check("areas-walkable", not bad_a, str(bad_a[:3]))
    # 3) entries ref real buildings, snap bounded
    blds = set(b["id"] for b in D["buildings.json"]["buildings"])
    bad_e = [n["id"] for n in nav["nodes"] if n["kind"] == "ENTRY" and
             (n["building"] not in blds or n.get("snap_m", 0) > 30.0)]
    s.check("entries-real", not bad_e, str(bad_e[:3]))
    # 4) landmarks/arrivals real
    lms = set(L["id"] for L in D["places.json"]["landmarks"])
    bad_l = [n["id"] for n in nav["nodes"] if n["kind"] == "LANDMARK" and
             n["landmark"] not in lms]
    avs = set(a["id"] for a in D["places.json"]["arrivals"])
    bad_v = [n["id"] for n in nav["nodes"] if n["kind"] == "ARRIVAL" and
             n["arrival"] not in avs]
    s.check("poi-real", not bad_l and not bad_v,
            str((bad_l[:2], bad_v[:2])))
    # 5) sectors recompute
    grid = SectorGrid(256)
    bad_s = []
    for n in nav["nodes"]:
        sx, sz = grid.sector_of(n["x"], n["z"])
        if sector_id(sx, sz) != n["sector"]:
            bad_s.append(n["id"])
    s.check("sectors", not bad_s, str(bad_s[:3]))
    # 6) crossings ref PUBLIC slow lanes
    lanes = D["traffic_graph.json"]["lanes"]
    bad_c = [c["id"] for c in nav["crossings"]
             if c["lane"] not in lanes or
             lanes[c["lane"]]["access"] != "PUBLIC" or
             lanes[c["lane"]]["speed_legal_kph"] > 50]
    s.check("crossings-public-slow", not bad_c, str(bad_c[:3]))
    # 7) upstream untouched
    s.check("p08-untouched",
            D["traffic_graph.json"]["checksums"][
                "traffic_graph_checksum"] == "dda8657c55ae8b47")
    s.check("p07-untouched",
            D["world_stream_manifest.json"]["checksum"] ==
            "3970e8e7e96b4e17")
    s.check("p06-untouched",
            D["districts.json"]["checksum"] == "161574ec12f6d831" and
            D["buildings.json"]["checksum"] == "55e11fbec4acea23" and
            D["places.json"]["checksum"] == "2b4df3e668269084")
    return s


# ================= REGRESS =================
GOLDEN_PATH = os.path.join(ROOT, "reports/p09_npc_golden.json")

REGRESS_SCENARIOS = [
    ("city", (1401.0, 209.0), False),
    ("port", None, False),       # resolved to first PORT zone focus
    ("resort", None, False),     # resolved to first RESORT zone focus
    ("coast", None, False),      # resolved to beach_access area
    ("rural", None, False),      # resolved to first RURAL zone focus
    ("dense", (1081.952, -136.093), False),
    ("city-traffic", (1401.0, 209.0), True),
]


def regress_focus(D, name):
    pop = D["npc_population_manifest.json"]
    if name == "port":
        z = sorted(z["zone_id"] for z in pop["zones"]
                   if z["class"] == "PORT")[0]
        pts = D["npc_spawn_zones.json"]["zones"][z]["spawn_points"]
        return (pts[0]["x"], pts[0]["z"])
    if name == "resort":
        z = sorted(z["zone_id"] for z in pop["zones"]
                   if z["class"] == "RESORT")[0]
        pts = D["npc_spawn_zones.json"]["zones"][z]["spawn_points"]
        return (pts[0]["x"], pts[0]["z"])
    if name == "coast":
        a = next(a for a in D["npc_navigation_manifest.json"]["areas"]
                 if a.get("purpose") == "beach_access")
        nid = "NC-" + a["id"]
        n = next(n for n in D["npc_navigation_manifest.json"]["nodes"]
                 if n["id"] == nid)
        return (n["x"], n["z"])
    if name == "rural":
        z = sorted(z["zone_id"] for z in pop["zones"]
                   if z["class"] in ("RURAL_VILLAGE", "AGRICULTURAL",
                                     "FOREST_SETTLEMENT"))[0]
        pts = D["npc_spawn_zones.json"]["zones"][z]["spawn_points"]
        return (pts[0]["x"], pts[0]["z"])
    raise KeyError(name)


def regress_run(D, name, focus, traffic, ticks=400):
    w = NPCWorld(seed_tag="gold-" + name, focus=focus,
                 with_traffic=traffic)
    for _ in range(ticks):
        w.tick()
    tiers = {}
    for m in w.npcs.values():
        tiers[m["tier"]] = tiers.get(m["tier"], 0) + 1
    kinds = {}
    for e in w.events:
        kinds[e["type"]] = kinds.get(e["type"], 0) + 1
    return {"npcs": len(w.npcs), "tiers": tiers,
            "events": kinds,
            "counters": {k: w.counters[k] for k in
                         ("spawns", "despawns", "path_requests",
                          "path_failed", "path_hits",
                          "crossings_committed", "crossings_cancelled",
                          "recoveries", "tier_changes")},
            "illegal": len(w.illegal)}


def suite_regress():
    s = Suite("regress")
    D = load_all()
    gold = None
    if os.path.exists(GOLDEN_PATH):
        with open(GOLDEN_PATH) as f:
            gold = json.load(f)
    elif os.environ.get("NPC_WRITE_GOLDEN") != "1":
        s.check("golden-present", False,
                "set NPC_WRITE_GOLDEN=1 to pin goldens")
        return s
    results = {}
    for (name, focus, traffic) in REGRESS_SCENARIOS:
        if focus is None:
            focus = regress_focus(D, name)
        results[name] = regress_run(D, name, focus, traffic)
    if gold is None:
        doc = {"pins": {"nav": NAV_PIN, "pop": POP_PIN,
                        "pol": POL_PIN, "beh": BEH_PIN,
                        "perc": PERC_PIN},
               "scenarios": results}
        with open(GOLDEN_PATH, "w") as f:
            json.dump(doc, f, indent=1, sort_keys=True)
        s.check("golden-write", True,
                "%d scenarios pinned" % len(results))
    else:
        ok = results == gold["scenarios"]
        bad = [k for k in results
               if results[k] != gold["scenarios"].get(k)]
        pins_ok = gold["pins"] == {"nav": NAV_PIN, "pop": POP_PIN,
                                   "pol": POL_PIN, "beh": BEH_PIN,
                                   "perc": PERC_PIN}
        s.check("golden-match", ok and pins_ok, str(bad[:3]))
    # upstream drift: P00-P08 pinned files unchanged
    ups = {}
    upath = os.path.join(DD, "upstream_pins.json")
    if os.path.exists(upath):
        with open(upath) as f:
            ups = json.load(f)["pins"]
    drift = []
    for fn, pin in sorted(ups.items()):
        with open(os.path.join(DD, fn), "rb") as f:
            h = hashlib.sha256(f.read()).hexdigest()[:16]
        if h != pin:
            drift.append(fn)
    if not ups:
        s.check("upstream-clean", False, "upstream_pins.json missing")
    else:
        s.check("upstream-clean", not drift, str(drift[:3]))
    return s


# ================= STRESS =================
def suite_stress():
    s = Suite("stress")
    import resource
    D = load_all()
    ev = {}
    # 1) urban hotspot: densest district at peak + landmark movement
    w = NPCWorld(seed_tag="stress-urban", focus=(1401.0, 209.0),
                 with_traffic=True)
    for _ in range(600):
        w.tick()
    w.fire_hearing(1401.0, 209.0, 1.0, "crowd_hook")
    t0 = time.process_time_ns()
    for _ in range(300):
        w.tick()
    cpu = (time.process_time_ns() - t0) / 1e6 / 300.0
    ev["urban"] = {"npcs": len(w.npcs),
                   "cpu_ms": round(cpu, 3),
                   "illegal": len(w.illegal),
                   "leaks": len(w.check_leaks()),
                   "heard": sum(1 for e in w.events
                                if e["type"] == "heard")}
    s.check("stress-urban", not w.illegal and
            not w.check_leaks(), str(ev["urban"]))
    # 2) nav hotspot: force repath of everyone every 20 ticks
    w2 = NPCWorld(seed_tag="stress-nav", focus=(1401.0, 209.0),
                  with_traffic=False)
    for _ in range(200):
        w2.tick()
    lat = []
    for i in range(200):
        if i % 20 == 0:
            for m in w2.npcs.values():
                if m["move_state"] not in ("DESPAWNING", "DESPAWNED",
                                           "FAILED"):
                    g = w2.dest_node_for(m, "RANDOM_WALK")
                    if g is not None:
                        w2.request_path(m, g)
        t0 = time.process_time_ns()
        w2.tick()
        lat.append((time.process_time_ns() - t0) / 1e6)
    lat.sort()
    ev["nav"] = {"p50": round(lat[100], 3),
                 "p99": round(lat[198], 3),
                 "cache": len(w2.path_cache),
                 "invalidated": w2.counters["path_invalidated"],
                 "illegal": len(w2.illegal)}
    s.check("stress-nav", not w2.illegal and
            w2.counters["path_invalidated"] >= 0, str(ev["nav"]))
    # 3) perception hotspot: loud event amid a crowd
    w3 = NPCWorld(seed_tag="stress-perc", focus=(1081.952, -136.093),
                  with_traffic=False)
    w3.auto_spawn = False
    pool = perf_pool(D)
    big = perf_zones(D)
    perf_place(w3, pool, big, 200, 1081.952, -136.093, "nodes",
               "stress")
    for _ in range(60):
        w3.tick()
    w3.fire_hearing(1081.952, -136.093, 1.0, "alarm_hook")
    for _ in range(30):
        w3.tick()
    heard = sum(1 for e in w3.events if e["type"] == "heard")
    ev["perc"] = {"heard": heard,
                  "exec": w3.counters["perc_executed"],
                  "deferred": w3.counters["perc_deferred"],
                  "skipped_los": w3.counters["perc_skipped_los"],
                  "illegal": len(w3.illegal)}
    s.check("stress-perc", heard > 0 and not w3.illegal,
            str(ev["perc"]))
    # 4) streaming hotspot: focus sweeps across the island
    w4 = NPCWorld(seed_tag="stress-stream", focus=(1401.0, 209.0),
                  with_traffic=False)
    mem0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    stops = [(1401.0, 209.0), (1081.0, -136.0), (900.0, 400.0),
             (300.0, -600.0), (1401.0, 209.0)]
    for (sx, sz) in stops:
        w4.focus = [sx, sz]
        for _ in range(120):
            w4.tick()
    mem1 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    stale = sum(1 for m in w4.npcs.values()
                if m["sector"] != w4.sector_of(m["x"], m["z"]))
    ev["stream"] = {"npcs": len(w4.npcs),
                    "tier_changes": w4.counters["tier_changes"],
                    "stale": stale,
                    "leaks": len(w4.check_leaks()),
                    "mem_kb": mem1 - mem0,
                    "illegal": len(w4.illegal)}
    s.check("stress-stream", stale == 0 and
            not w4.check_leaks() and not w4.illegal,
            str(ev["stream"]))
    # 5) long-run: 2000 uninterrupted ticks, city focus (section 90)
    w5 = NPCWorld(seed_tag="stress-long", focus=(1401.0, 209.0),
                  with_traffic=False)
    pop_samples = []
    for i in range(2000):
        w5.tick()
        if i % 200 == 0:
            pop_samples.append(len(w5.npcs))
    arrives = sum(1 for e in w5.events if e["type"] == "arrive")
    hub_peak = w5.zones["PZ-D-hub-core"]["peak_population"]
    hub_over = sum(1 for m in w5.npcs.values()
                   if m["zone"] == "PZ-D-hub-core") > hub_peak + 5
    ev["long"] = {"ticks": 2000, "npcs": len(w5.npcs),
                  "pop_samples": pop_samples, "arrivals": arrives,
                  "illegal": len(w5.illegal),
                  "leaks": len(w5.check_leaks()),
                  "recoveries": w5.counters["recoveries"]}
    s.check("stress-long", not w5.illegal and
            not w5.check_leaks() and arrives > 0 and not hub_over,
            str(ev["long"]))
    s.evidence = ev
    return s



# ================= PERF =================
# P08-D12 measurement discipline: CPU time (process_time_ns), fixed
# tick counts, warmup excluded, env+pins recorded in evidence.
PERF_FOCUS = (1081.952, -136.093)  # densest nav region (evidence)


def perf_pool(D):
    nodes = [n for n in D["npc_navigation_manifest.json"]["nodes"]
             if n["kind"] in ("ENTRY", "AREA_CENTROID", "AREA_MID") and
             math.hypot(n["x"] - PERF_FOCUS[0],
                        n["z"] - PERF_FOCUS[1]) < 500.0]
    return sorted(nodes, key=lambda n: n["id"])


def perf_zones(D):
    big = sorted(
        (z["peak_population"], z["zone_id"])
        for z in D["npc_population_manifest.json"]["zones"]
        if z["peak_population"] >= 40)
    return big  # (peak, zid), ascending


def perf_place(w, pool, big, n, cx, cz, spread, tag):
    counts = {zid: 0 for _, zid in big}
    order = [zid for _, zid in sorted(big, reverse=True)]
    for i in range(n):
        nd = pool[i % len(pool)]
        if spread == "crowd":
            # dense T3 crowd: 625 distinct spots within ~24m of focus
            jx = cx + ((i % 25) - 12) * 1.4
            jz = cz + (((i // 25) % 25) - 12) * 1.4
        else:
            k = i // len(pool)
            ox = ((k % 5) - 2) * 3.0
            oz = (((k // 5) % 5) - 2) * 3.0
            jx = nd["x"] + ox
            jz = nd["z"] + oz
        zid = None
        for cand in order:
            pk = next(p for p, z in big if z == cand)
            if counts[cand] < pk - 5:
                zid = cand
                break
        assert zid is not None, (tag, i)
        counts[zid] += 1
        m = w.acquire("CIVILIAN", zid, jx, jz, context=tag)
        assert m is not None, (tag, i)
    return counts


def perf_run(w, ticks=300, warmup=30):
    for _ in range(warmup):
        w.tick()
    w.counters["path_deferred"] = 0
    w.counters["perc_deferred"] = 0
    t0 = time.process_time_ns()
    for _ in range(ticks):
        w.tick()
    return (time.process_time_ns() - t0) / 1e6 / ticks


def suite_perf():
    s = Suite("perf")
    import resource
    D = load_all()
    gates = D["npc_contract.json"]["performance_policy"]["gates"]
    pool = perf_pool(D)
    big = perf_zones(D)
    assert len(pool) >= 400 and sum(p for p, _ in big) >= 1000
    cx, cz = PERF_FOCUS
    ev = {"ladder": [], "env": perf_env(), "focus": list(PERF_FOCUS)}
    for n in (25, 50, 100, 200, 500, 1000):
        w = NPCWorld(seed_tag="perf-%d" % n, focus=(cx, cz),
                     with_traffic=False)
        w.auto_spawn = False
        for sid in w.sectors:
            w.sectors[sid] = "READY"
        perf_place(w, pool, big, n, cx, cz, "nodes", "perf")
        cpu_ms = perf_run(w)
        peak_kb = resource.getrusage(
            resource.RUSAGE_SELF).ru_maxrss
        assert len(w.npcs) == n, (n, len(w.npcs))
        arrived = sum(1 for e in w.events if e["type"] == "arrive")
        ev["ladder"].append({
            "npcs": n, "active": len(w.npcs),
            "cpu_ms_per_tick": round(cpu_ms, 3),
            "peak_rss_kb": peak_kb,
            "arrivals": arrived,
            "path_deferred": w.counters["path_deferred"],
            "perc_deferred": w.counters["perc_deferred"],
            "illegal": len(w.illegal)})
    s.check("perf-held", all(r["active"] == r["npcs"]
                             for r in ev["ladder"]))
    s.check("perf-moving", all(r["arrivals"] > 0 for r in ev["ladder"]),
            str([r["arrivals"] for r in ev["ladder"]]))
    s.check("perf-clean", all(r["illegal"] == 0 for r in ev["ladder"]))

    def run100(seed, paths=True, perc=True):
        w = NPCWorld(seed_tag=seed, focus=(cx, cz),
                     with_traffic=False)
        w.auto_spawn = False
        w.enable_paths = paths
        w.enable_perc = perc
        for sid in w.sectors:
            w.sectors[sid] = "READY"
        perf_place(w, pool, big, 100, cx, cz, "nodes", "abl")
        return perf_run(w)
    # median-of-3 per arm: same seed (same scenario), machine noise
    # smoothed; paired full/ablated runs share thermal state.
    import statistics
    fulls, navs, percs = [], [], []
    for rep in range(3):
        f = run100("perf-a0")
        fulls.append(f)
        navs.append(max(0.0, f - run100("perf-a0", paths=False)))
        percs.append(max(0.0, f - run100("perf-a0", perc=False)))
    full100 = statistics.median(fulls)
    nav100 = statistics.median(navs)
    perc100 = statistics.median(percs)
    ev["ablation_100"] = {"full": round(full100, 3),
                          "nav": round(nav100, 3),
                          "perc": round(perc100, 3),
                          "repeats": {"full": [round(v, 3)
                                               for v in fulls],
                                      "nav": [round(v, 3)
                                              for v in navs],
                                      "perc": [round(v, 3)
                                               for v in percs]}}
    mem1000 = max(r["peak_rss_kb"] for r in ev["ladder"]) / 1024.0
    for key, val in (("ai_cpu_ms_100", full100),
                     ("nav_cpu_ms_100", nav100),
                     ("perception_cpu_ms_100", perc100),
                     ("memory_mb_1000", mem1000)):
        gate = gates[key]
        if isinstance(gate, (int, float)):
            s.check("gate-" + key, val <= gate,
                    "%.2f vs %s" % (val, gate))
        else:
            s.check("report-" + key, True,
                    "%.2f (gate TBD)" % val)
    # worst-case T3 crowd: 250 within 40m, all full-AI
    w = NPCWorld(seed_tag="perf-crowd", focus=(cx, cz),
                 with_traffic=False)
    w.auto_spawn = False
    for sid in w.sectors:
        w.sectors[sid] = "READY"
    perf_place(w, pool, big, 250, cx, cz, "crowd", "crowd")
    crowd_ms = perf_run(w)
    t3 = sum(1 for m in w.npcs.values() if m["tier"] == "T3_full")
    arrived = sum(1 for e in w.events if e["type"] == "arrive")
    ev["crowd_250"] = {"cpu_ms_per_tick": round(crowd_ms, 3),
                       "t3": t3, "arrivals": arrived,
                       "active": len(w.npcs)}
    s.check("perf-crowd", t3 == 250 and arrived > 0 and
            len(w.npcs) == 250, str(ev["crowd_250"]))
    s.evidence = ev
    return s



def perf_env():
    import platform
    D = load_all()
    return {
        "method": "process_time_ns CPU time per tick, 300 measured "
                  "ticks after 30 warmup; wall time excluded "
                  "(P08-D12 comparability)",
        "python": platform.python_version(),
        "godot": "4.7.2-stable",
        "nav": D["npc_navigation_manifest.json"][
            "npc_navigation_checksum"],
        "pop": D["npc_population_manifest.json"][
            "npc_population_checksum"],
    }



# ================= SMOKE =================
SCEN_CLASS = {
    "URBAN": "CITY_CORE", "SUBURBAN": "SUBURBAN",
    "INDUSTRIAL": "INDUSTRIAL", "PORT": "PORT", "RESORT": "RESORT",
    "HIGHLAND": "HIGHLAND_SETTLEMENT", "FOREST": "FOREST_SETTLEMENT",
    "WETLAND": "AGRICULTURAL", "COAST": "WATERFRONT",
    "ARRIVAL": "ARRIVAL",
}


def zone_focus(w, zid):
    pts = w.spawn_doc["zones"][zid]["spawn_points"]
    return pts[0]["x"], pts[0]["z"]


def suite_smoke():
    s = Suite("smoke")
    D = load_all()
    pop = D["npc_population_manifest.json"]
    byclass = {}
    for z in pop["zones"]:
        byclass.setdefault(z["class"], []).append(z["zone_id"])
    # 12 world scenarios (10 class + landmark + open-space)
    scen = dict(SCEN_CLASS)
    lmz = None
    for n in D["npc_navigation_manifest.json"]["nodes"]:
        if n["kind"] == "LANDMARK":
            lmz = "PZ-D-hub-core"
            break
    fails = []
    for name, cls in sorted(scen.items()):
        zids = byclass.get(cls, [])
        if not zids:
            fails.append((name, "no-zone"))
            continue
        zid = sorted(zids)[0]
        w = NPCWorld(seed_tag="smoke-" + name, with_traffic=False)
        w.auto_spawn = True
        pts = w.spawn_doc["zones"][zid]["spawn_points"]
        if not pts:
            fails.append((name, "no-spawn-pts"))
            continue
        fx, fz = zone_focus(w, zid)
        w.focus = [fx, fz]
        for _ in range(120):
            w.tick()
        act = [n for n in w.npcs.values() if n["zone"] == zid]
        walk = any(e["type"] == "move_transition" and
                   e["data"]["to"] == "WALKING" for e in w.events)
        sim = sum(1 for n in w.npcs.values()
                    if n["tier"] in ("T3_full", "T2_simplified"))
        ok = len(act) > 0 and walk and not w.illegal and sim > 0
        if not ok:
            fails.append((name, "act=%d walk=%s ill=%d sim=%d" %
                          (len(act), walk, len(w.illegal), sim)))
    # LANDMARK + OPEN_SPACE scenarios: attached dests reachable
    w = NPCWorld(seed_tag="smoke-poi", with_traffic=False)
    w.auto_spawn = False
    for n in w.nodes.values():
        w.sectors[n["sector"]] = "READY"
    attached_lm = [n for n in w.nodes.values()
                   if n["kind"] == "LANDMARK" and n["id"] in w.adj]
    ok_lm = 0
    for n in attached_lm[:6]:
        e = w.adj[n["id"]][0]
        p = w.astar(e["b"], n["id"])
        if p is not None:
            ok_lm += 1
    if ok_lm < min(6, len(attached_lm)):
        fails.append(("LANDMARK", "%d/%d" % (ok_lm, len(attached_lm))))
    cents = [n["id"] for n in w.nodes.values()
             if n["kind"] == "AREA_CENTROID" and n["id"] in w.adj]
    ok_os = 0
    for cid in cents[:10]:
        e = w.adj[cid][0]
        if w.astar(e["b"], cid) is not None:
            ok_os += 1
    if ok_os < min(10, len(cents)):
        fails.append(("OPEN_SPACE", "%d/10" % ok_os))
    s.check("world-scenarios", not fails,
            "%d scenarios %s" % (len(scen) + 2, fails[:3]))
    # ---- integrated 28-step gameplay (section 88) ----
    g = NPCWorld(seed_tag="gameplay", focus=(1401.0, 209.0),
                 with_traffic=False)
    steps = []
    evd = {}

    def step(name, cond, detail=""):
        steps.append((name, bool(cond)))
        if not cond:
            evd[name] = detail

    hub_tgt = g.zones["PZ-D-hub-core"]["target_population"]
    step("01-dense-city", hub_tgt >= 100, hub_tgt)
    for _ in range(60):
        g.tick()
    step("02-ped-spawn", len(g.npcs) > 5, len(g.npcs))
    g.set_player(1401.0, 209.0)
    for _ in range(30):
        g.player["x"] += 1.0
        g.focus = [g.player["x"], g.player["z"]]
        g.tick()
    step("03-player-walk", g.player["x"] > 1425.0, g.player["x"])
    step("04-navigate", any(e["type"] == "path_ok" for e in g.events))
    cr = g.crossings[sorted(g.crossings.keys())[0]]
    A = g.nodes[cr["a"]]
    p = g.acquire("CIVILIAN", "PZ-D-hub-core", A["x"], A["z"],
                  context="gx")
    step("05-approach", p is not None)
    # traffic world for wait behavior
    gt = NPCWorld(seed_tag="gameplay-t", focus=(1401.0, 209.0),
                  with_traffic=True)
    for _ in range(60):
        gt.tick()
    nveh = len(gt.traffic.vehicles) if gt.traffic else 0
    step("06-traffic", nveh > 0, nveh)
    qt = gt.acquire("CIVILIAN", "PZ-D-hub-core", A["x"], A["z"],
                    context="gt")
    if qt is not None:
        gt.move_transition(qt, "INITIALIZING", "gt")
        qt["path"] = [cr["a"], cr["b"]]
        qt["path_i"] = 1
        qt["node"] = cr["a"]
        qt["tier"] = "T3_full"
        gt.move_transition(qt, "IDLE", "gt")
        gt.move_transition(qt, "WALKING", "gt")
        for _ in range(120):
            gt.tick()
            if qt["id"] not in gt.npcs:
                break
        waited = any(e["type"] == "move_transition" and
                     e["data"]["to"] == "WAITING" and
                     e["npc"] == qt["id"] for e in gt.events)
        step("07-wait", waited or
             gt.counters["crossings_cancelled"] > 0,
             "cancel=%d" % gt.counters["crossings_cancelled"])
    else:
        step("07-wait", False, "no-place")
    g.move_transition(p, "INITIALIZING", "gx")
    p["path"] = [cr["a"], cr["b"]]
    p["path_i"] = 1
    p["node"] = cr["a"]
    p["tier"] = "T3_full"
    g.move_transition(p, "IDLE", "gx")
    g.move_transition(p, "WALKING", "gx")
    for _ in range(400):
        g.tick()
        if p["id"] not in g.npcs:
            break
    dones = [e for e in g.events if e["type"] == "cross_done"]
    step("08-safe-cross", len(dones) >= 1, len(dones))
    if attached_lm:
        tgt = attached_lm[0]["id"]
        tn = g.nodes[tgt]
        g.focus = [tn["x"], tn["z"]]
        step("09-approach-landmark", True)
        arr0 = sum(1 for e in g.events if e["type"] == "arrive")
        for i in range(3):
            q = g.acquire("TOURIST", "PZ-D-hub-core",
                          tn["x"] + i * 3.0, tn["z"], context="glm")
            if q is None:
                continue
            g.move_transition(q, "INITIALIZING", "glm")
            g.request_path(q, tgt)
        for _ in range(200):
            g.tick()
        arr1 = sum(1 for e in g.events if e["type"] == "arrive")
        step("10-landmark-nav", arr1 > arr0, "%d->%d" % (arr0, arr1))
    else:
        step("09-approach-landmark", False, "no-attached-lm")
        step("10-landmark-nav", False, "no-attached-lm")
    pz = sorted(byclass.get("PORT", []))
    if pz:
        fx, fz = zone_focus(g, pz[0])
        g.focus = [fx, fz]
        step("11-to-port", True)
        for _ in range(150):
            g.tick()
        port_act = [n for n in g.npcs.values() if n["zone"] == pz[0]]
        step("12-profile-change", len(port_act) > 0, len(port_act))
        workers = [n for n in g.npcs.values()
                   if n["archetype"] == "WORKER"]
        step("13-workers", len(workers) > 0, len(workers))
    else:
        step("11-to-port", False, "no-port")
        step("12-profile-change", False, "no-port")
        step("13-workers", False, "no-port")
    # 14/16: no valid ped bridge/tunnel route exists in source data
    # (P09-D2); the correct evidence is documented rejection.
    st = D["transport_structures.json"]
    br_edges = {st["bridges"]["BC-01"]["edge"],
                st["bridges"]["BC-02"]["edge"]}
    tun_edge = st["tunnel"]["edge"]
    bad_br = [c for c in g.crossings.values()
              if c["edge"] in br_edges]
    bad_tn = [c for c in g.crossings.values()
              if c["edge"] == tun_edge]
    step("14-bridge-reject", not bad_br, str(bad_br[:2]))
    tc0 = g.counters["tier_changes"]
    for (jx, jz) in ((900.0, 400.0), (1401.0, 209.0)):
        g.focus = [jx, jz]
        for _ in range(40):
            g.tick()
    step("15-streaming", g.counters["tier_changes"] > tc0,
         g.counters["tier_changes"] - tc0)
    step("16-tunnel-reject", not bad_tn, str(bad_tn[:2]))
    rur = [z for z in pop["zones"]
           if z["class"] in ("RURAL_VILLAGE", "AGRICULTURAL",
                             "FOREST_SETTLEMENT") and
           z["target_population"] > 0]
    if rur:
        fx, fz = zone_focus(g, rur[0]["zone_id"])
        g.focus = [fx, fz]
        for _ in range(60):
            g.tick()
        step("17-rural", True)
        step("18-sparser", all(
            z["target_population"] < hub_tgt for z in rur))
    else:
        step("17-rural", False, "none")
        step("18-sparser", False, "none")
    rz = sorted(byclass.get("RESORT", []))
    if rz:
        fx, fz = zone_focus(g, rz[0])
        g.focus = [fx, fz]
        step("19-resort", True)
        for _ in range(150):
            g.tick()
        tour = [n for n in g.npcs.values()
                if n["archetype"] == "TOURIST"]
        step("20-tourists", len(tour) > 0, len(tour))
    else:
        step("19-resort", False, "none")
        step("20-tourists", False, "none")
    beach = [a for a in D["npc_navigation_manifest.json"]["areas"]
             if a.get("purpose") == "beach_access"]
    step("21-coast", len(beach) > 0, len(beach))
    near = [n for n in g.npcs.values() if n["tier"] == "T3_full"]
    if near:
        n0 = near[0]
        g.fire_hearing(n0["x"], n0["z"], 1.0, "shout_hook")
        step("22-loud-event", True)
        for _ in range(10):
            g.tick()
        heard = [e for e in g.events if e["type"] == "heard"]
        step("23-near-hear", len(heard) > 0, len(heard))
        far = [n for n in g.npcs.values()
               if math.hypot(n["x"] - n0["x"], n["z"] - n0["z"]) > 200.0]
        far_low = all(n["tier"] != "T3_full" for n in far)
        step("24-far-low-tier", far_low,
             "%d far" % len(far))
    else:
        step("22-loud-event", False, "no-T3")
        step("23-near-hear", False, "no-T3")
        step("24-far-low-tier", False, "no-T3")
    for (jx, jz) in ((1401.0, 209.0), (900.0, 400.0), (1401.0, 209.0)):
        g.focus = [jx, jz]
        for _ in range(40):
            g.tick()
    step("25-multi-sector", True)
    stale = 0
    for n in g.npcs.values():
        if n["sector"] != g.sector_of(n["x"], n["z"]):
            stale += 1
        for u in n["path"]:
            if u not in g.nodes:
                stale += 1
    step("26-no-stale", stale == 0, stale)
    for _ in range(300):
        g.tick()
    step("27-long-run", not g.illegal and not g.check_leaks(),
         "ill=%s leaks=%s" % (g.illegal[:2], g.check_leaks()))
    step("28-shutdown", not g.check_leaks(),
         "pins=%d" % len(g.pins))
    bad_steps = [name for (name, ok) in steps if not ok]
    s.check("gameplay-28", len(steps) == 28 and not bad_steps,
            "%d/28 %s %s" % (len(steps) - len(bad_steps),
                              bad_steps[:4],
                              str(evd)[:150]))
    return s


# ================= INJECT =================
def suite_inject():
    s = Suite("inject")

    def fresh(tag):
        w = NPCWorld(seed_tag=tag, with_traffic=False)
        w.auto_spawn = False
        for n in w.nodes.values():
            w.sectors[n["sector"]] = "READY"
        return w

    # 1) broken link: remove all edges of a node -> routes avoid/fail
    w = fresh("inj0")
    ids = w.comp_nodes[sorted(w.comp_nodes.keys())[0]]
    a, b = ids[0], ids[-1]
    p0 = w.astar(a, b)
    keep = [e for e in w.adj.get(a, [])]
    w.adj[a] = []
    p1 = w.astar(a, b)
    s.check("inj-broken-link", p0 is not None and p1 is None,
            "before=%s after=%s" % (p0 is not None, p1))
    # 2) invalid destination
    w = fresh("inj1")
    n = place_npc(w, "CIVILIAN", 1401.0, 209.0, "PZ-D-hub-core")
    r = w.request_path(n, "NO-SUCH-NODE")
    s.check("inj-bad-dest", r is False and
            w.counters["path_failed"] >= 1)
    # 3) stale path: node removed mid-route -> recover, no crash
    w = fresh("inj2")
    n = place_npc(w, "CIVILIAN", 1401.0, 209.0, "PZ-D-hub-core")
    tgt = w.dest_node_for(n, "RANDOM_WALK")
    w.request_path(n, tgt)
    pump_all(w)
    if len(n["path"]) > 1:
        del w.nodes[n["path"][1]]
    x0 = (n["x"], n["z"])
    for _ in range(30):
        try:
            w.tick()
        except KeyError:
            s.check("inj-stale-path", False, "KeyError escaped")
            break
    else:
        moved = math.hypot(n["x"] - x0[0], n["z"] - x0[1]) \
            if n["id"] in w.npcs else 0.0
        s.check("inj-stale-path", moved < 200.0, "moved=%.1f" % moved)
    # 4) sector unload during route -> astar gates it
    w = fresh("inj3")
    ids = sorted(w.nodes.keys())
    n0 = w.nodes[ids[0]]
    w.sectors[n0["sector"]] = "UNLOADED"
    p = w.astar(ids[1], ids[0])
    s.check("inj-sector-unload", p is None or
            all(w.nodes[u]["sector"] != n0["sector"] or
                u == ids[1] for u in (p or [ids[1]])))
    # 5) spawn overlap rejected
    w = fresh("inj4")
    w.focus = [1401.0, 209.0]
    w.update_sectors()
    a = w.acquire("CIVILIAN", "PZ-D-hub-core", 1401.0, 209.0,
                  context="t")
    w._rehash()
    ok, reason = w.spawn_check(1401.0, 209.0, "PZ-D-hub-core")
    b = w.acquire("CIVILIAN", "PZ-D-hub-core", 1401.0, 209.0,
                  context="t")
    s.check("inj-overlap", (not ok and reason == "npc_overlap") or
            b is None, reason)
    # 6) invalid spawn areas rejected with reasons
    w = fresh("inj5")
    w.focus = [0.0, -1500.0]
    w.update_sectors()
    ok1, r1 = w.spawn_check(0.0, -1500.0, "PZ-D-hub-core")
    # a building centroid (must reject as inside_building or overlap)
    fp = w.footprints[0]
    cx = sum(p[0] for p in fp) / len(fp)
    cz = sum(p[1] for p in fp) / len(fp)
    w.focus = [cx, cz]
    w.update_sectors()
    for sid in list(w.sectors.keys()):
        w.sectors[sid] = "READY"
    w._rehash()
    ok2, r2 = w.spawn_check(cx, cz, "PZ-D-hub-core")
    s.check("inj-bad-areas", (not ok1) and (not ok2),
            "%s/%s" % (r1, r2))
    # 7) illegal transition rejected + recorded
    w = fresh("inj6")
    m = w.acquire("CIVILIAN", "PZ-D-hub-core", 1401.0, 209.0,
                  context="t")
    w.move_transition(m, "INITIALIZING", "t")
    ok = w.move_transition(m, "CROSSING", "hack")
    s.check("inj-illegal", ok is False and len(w.illegal) == 1)
    # 8) duplicate NPC request blocked
    w = fresh("inj7")
    a = w.acquire("WORKER", "PZ-D-hub-core", 1405.0, 210.0,
                  context="t")
    b = w.acquire("WORKER", "PZ-D-hub-core", 1405.0, 210.0,
                  context="t")
    s.check("inj-duplicate", a is not None and b is None)
    # 9) perception overload -> deferred observable
    w = fresh("inj8")
    made = []
    for i in range(100):
        m = w.acquire("CIVILIAN", "PZ-D-hub-core",
                      1401.0 + i * 2.0, 209.0, context="q")
        m["tier"] = "T3_full"
        w.request_perception(m)
        made.append(m)
    w.pump_perception()
    s.check("inj-perc-overload", w.counters["perc_executed"] == 64 and
            w.counters["perc_deferred"] == 36,
            "exec=%d def=%d" %
            (w.counters["perc_executed"],
             w.counters["perc_deferred"]))
    # 10) pin leak detected
    w = fresh("inj9")
    pid = w.pin("SX13Z08", "test", ticks=5)
    for _ in range(10):
        w.tick()
    leaked = w.check_leaks()
    s.check("inj-pin", pid not in w.pins and not leaked,
            "pins=%d leaks=%d" % (len(w.pins), len(leaked)))
    # 11) traffic unavailable -> crossing still deterministic
    w = fresh("inj10")
    c = next(iter(sorted(w.crossings.keys())))
    n = place_npc(w, "CIVILIAN", 1401.0, 209.0, "PZ-D-hub-core")
    d1, i1 = w.crossing_decision(n, w.crossings[c])
    d2, i2 = w.crossing_decision(n, w.crossings[c])
    s.check("inj-no-traffic", d1 == d2 == "COMMIT",
            "%s %s" % (d1, i1))
    # 12) checksum mismatch detected (tampered copy)
    D = load_all()
    nav = json.loads(json.dumps(D["npc_navigation_manifest.json"]))
    nav["nodes"][0]["x"] += 1.0
    core = {"areas": nav["areas"], "nodes": nav["nodes"],
            "edges": nav["edges"], "crossings": nav["crossings"],
            "settings": nav["settings"], "sources": nav["sources"]}
    s.check("inj-checksum", fnv1a64_hex(canon(core)) !=
            nav["npc_navigation_checksum"])
    return s


# ================= REPRODUCE =================
def run_replay(seed, ticks=200, sleep_ms=0):
    w = NPCWorld(seed_tag=seed, focus=(1401.0, 209.0),
                 with_traffic=False)
    for _ in range(ticks):
        w.tick()
        if sleep_ms:
            time.sleep(sleep_ms / 1000.0)
    core = [(e["tick"], e["type"], e["npc"],
             json.dumps(e["data"], sort_keys=True))
            for e in w.events]
    return core, w.stats()


def suite_reproduce():
    s = Suite("reproduce")
    c1, st1 = run_replay("replay0")
    c2, st2 = run_replay("replay0")
    s.check("replay-identical", c1 == c2 and len(c1) > 100,
            "events=%d" % len(c1))
    s.check("replay-stats", st1["npcs"] == st2["npcs"] and
            st1["tiers"] == st2["tiers"] and
            st1["counters"] == st2["counters"],
            str(st1["tiers"]))
    # fixed-step: wall timing must not affect logic
    c3, st3 = run_replay("replay0", sleep_ms=2)
    s.check("fixed-step", c1 == c3, "events=%d" % len(c3))
    # different seed -> different (but valid) outcomes
    c4, st4 = run_replay("replayX")
    s.check("seed-matters", c1 != c4 and len(c4) > 100,
            "events=%d" % len(c4))
    # determinism across fresh generator runs (checksums stable)
    D = load_all()
    s.check("gen-stable",
            D["npc_navigation_manifest.json"][
                "npc_navigation_checksum"] == NAV_PIN and
            D["npc_population_manifest.json"][
                "npc_population_checksum"] == POP_PIN,
            "regen-match")
    return s



# ================= helpers =================
def place_npc(w, arch, x, z, zone):
    n = w.acquire(arch, zone, x, z, context="test")
    assert n is not None
    w.move_transition(n, "INITIALIZING", "test")
    # ready all sectors for pure-nav tests
    for sid in w.zone_sectors.get(zone, []):
        w.sectors[sid] = "READY"
    for _ in range(3):
        w.tick()
    return n


def pump_all(w):
    for _ in range(20):
        if not w.path_queue:
            break
        w.pump_paths()


# ================= NAVIGATION =================
def suite_navigation():
    s = Suite("navigation")
    D = load_all()
    nav = D["npc_navigation_manifest.json"]
    # 1) attached-node reachability within components
    w = NPCWorld(seed_tag="nav0", with_traffic=False)
    w.auto_spawn = False
    for sid in list(w.sectors.keys()):
        w.sectors[sid] = "READY"
    # ready every sector mentioned by nodes
    for n in w.nodes.values():
        w.sectors[n["sector"]] = "READY"
    pairs_ok = pairs = 0
    for c in sorted(w.comp_nodes.keys()):
        ids = w.comp_nodes[c]
        if len(ids) < 4:
            continue
        for a, b in ((ids[0], ids[-1]), (ids[1], ids[-2])):
            pairs += 1
            p = w.astar(a, b)
            if p is not None and p[0] == a and p[-1] == b:
                # every hop is a real edge
                good = True
                for i in range(len(p) - 1):
                    if not any(e["b"] == p[i + 1]
                               for e in w.adj.get(p[i], [])):
                        good = False
                if good:
                    pairs_ok += 1
    s.check("attached-reach", pairs_ok == pairs and pairs > 50,
            "%d/%d" % (pairs_ok, pairs))
    # 2) invalid routes fail cleanly
    comps = sorted(w.comp_nodes.keys())
    p = w.astar(w.comp_nodes[comps[0]][0],
                w.comp_nodes[comps[-1]][0])
    s.check("invalid-route", p is None or
            comps[0] == comps[-1], "cross-component")
    s.check("unknown-node", w.astar("NOPE", "NOPE2") is None)
    # 3) edge kinds + refs
    kinds = set(e["kind"] for e in nav["edges"])
    s.check("edge-kinds", kinds <= {"AREA_STAR", "AREA_ADJ", "ENTRY_LINK",
                                    "POI_LINK", "CROSSING",
                                    "CROSSING_APPROACH"}, str(kinds))
    xids = set(c["id"] for c in nav["crossings"])
    bad_x = [e for e in nav["edges"] if e["kind"] == "CROSSING" and
             e.get("crossing") not in xids]
    s.check("crossing-refs", not bad_x, str(len(bad_x)))
    # 4) no ped route on bridge decks / tunnel bore
    st = D["transport_structures.json"]
    br = [(st["bridges"]["BC-01"]["edge"],
           st["bridges"]["BC-01"]["station_range"]),
          (st["bridges"]["BC-02"]["edge"],
           st["bridges"]["BC-02"]["station_range"])]
    tn = (st["tunnel"]["edge"], st["tunnel"]["bore_range"])
    g = D["traffic_graph.json"]
    bad_s = []
    for c in nav["crossings"]:
        L = g["lanes"][c["lane"]]
        for (edge, (s0, s1)) in br + [tn]:
            if c["edge"] != edge:
                continue
            # station of crossing mid along lane pts
            mx, mz = c["mid"]
            acc = 0.0
            for i in range(len(L["pts"]) - 1):
                p0, p1 = L["pts"][i], L["pts"][i + 1]
                sl = math.hypot(p1[0] - p0[0], p1[2] - p0[2])
                d = abs((p1[0] - p0[0]) * (p0[2] - mz) -
                        (p0[0] - mx) * (p1[2] - p0[2])) / max(sl, 1e-9)
                if d < 3.0 and s0 <= acc <= s1:
                    bad_s.append(c["id"])
                acc += sl
    s.check("structures-rejected", not bad_s, str(bad_s[:3]))
    # 5) independent evidence re-validation (sample)
    from terrain_model import Field
    field = Field()
    tc = D["npc_contract.json"]
    mx = tc["walkability"]["max_slope_grade"]
    blk = set(tc["walkability"]["blocked_regions"])
    sample = [n for n in nav["nodes"]][::25]
    mism = []
    for n in sample:
        reg = field.region_at(n["x"], n["z"])
        _d, pct = field.slope_grade(n["x"], n["z"])
        if reg != n["region"] or abs(pct / 100.0 - n["slope_grade"]) > 0.02 \
                or reg in blk or pct / 100.0 > mx + 1e-9:
            mism.append(n["id"])
    s.check("evidence-revalidate", not mism,
            "%d sampled %s" % (len(sample), mism[:3]))
    # 6) sector-portal flags
    bad_p = [e for e in nav["edges"]
             if e["sector_portal"] !=
             (w.nodes[e["a"]]["sector"] != w.nodes[e["b"]]["sector"])]
    s.check("portal-flags", not bad_p, str(len(bad_p)))
    # 7) path service: deliver + cache + budget
    w2 = NPCWorld(seed_tag="nav1", with_traffic=False)
    w2.auto_spawn = False
    for n in w2.nodes.values():
        w2.sectors[n["sector"]] = "READY"
    n = place_npc(w2, "CIVILIAN", 1401.0, 209.0, "PZ-D-hub-core")
    tgt = w2.dest_node_for(n, "RANDOM_WALK")
    r = w2.request_path(n, tgt)
    pump_all(w2)
    s.check("path-deliver", len(n["path"]) >= 1,
            "len=%d" % len(n["path"]))
    r2 = w2.request_path(n, tgt)
    s.check("path-cache", r2 is True and
            w2.counters["path_hits"] >= 1,
            "hits=%d" % w2.counters["path_hits"])
    goals = sorted(nid for nid, d in w2.nodes.items()
                   if d["kind"] == "AREA_CENTROID")[:12]
    for i in range(12):
        m = w2.acquire("CIVILIAN", "PZ-D-hub-core", 1401.0 + i * 1.5,
                       209.0, context="q")
        w2.request_path(m, goals[i])
    w2.pump_paths()
    s.check("path-budget", w2.counters["path_deferred"] > 0,
            "deferred=%d" % w2.counters["path_deferred"])
    return s


# ================= PERCEPTION =================
def suite_perception():
    s = Suite("perception")
    w = NPCWorld(seed_tag="perc0", with_traffic=False)
    w.auto_spawn = False
    w.focus = [1401.0, 209.0]
    for n in w.nodes.values():
        w.sectors[n["sector"]] = "READY"
    # open plaza: two NPCs 10 m apart, facing each other
    a = w.acquire("CIVILIAN", "PZ-D-hub-core", 1401.0, 209.0,
                  context="t")
    b = w.acquire("CIVILIAN", "PZ-D-hub-core", 1411.0, 209.0,
                  context="t")
    a["heading"] = 90.0
    b["heading"] = -90.0
    a["tier"] = b["tier"] = "T3_full"
    w.move_transition(a, "INITIALIZING", "t")
    w.move_transition(a, "IDLE", "t")
    w.move_transition(b, "INITIALIZING", "t")
    w.move_transition(b, "IDLE", "t")
    w._rehash()
    w.request_perception(a)
    w.request_perception(b)
    w.pump_perception()
    sa = [t["id"] for t in a["perceived"]]
    sb = [t["id"] for t in b["perceived"]]
    s.check("los-open", b["id"] in sa and a["id"] in sb,
            "%s %s" % (sa, sb))
    # facing away: no see
    a["heading"] = -90.0
    a["perceived"] = []
    w.request_perception(a)
    w.pump_perception()
    s.check("los-fov", all(t["id"] != b["id"] for t in a["perceived"]),
            str([t["id"] for t in a["perceived"]]))
    # hearing event
    eid = w.fire_hearing(1406.0, 209.0, 0.9, "shout_hook")
    w.request_perception(a)
    w.pump_perception()
    heard = [e for e in w.events if e["type"] == "heard" and
             e["npc"] == a["id"]]
    s.check("hearing", len(heard) == 1 and
            heard[0]["data"]["event"] == eid,
            str(heard[:1]))
    s.check("react", a["beh_state"] == "REACT", a["beh_state"])
    # witness record
    rec = w.witness(a["id"], b["id"], eid)
    s.check("witness", rec is not None and rec["observer"] == a["id"]
            and rec["confidence"] == 0.9, str(rec))
    # budget: queue 70 scans, only 64 execute
    w2 = NPCWorld(seed_tag="perc1", with_traffic=False)
    w2.auto_spawn = False
    for n in w2.nodes.values():
        w2.sectors[n["sector"]] = "READY"
    made = []
    for i in range(70):
        m = w2.acquire("CIVILIAN", "PZ-D-hub-core", 1401.0 + i * 30.0,
                       209.0, context="q")
        m["heading"] = 90.0
        m["tier"] = "T3_full"
        w2.request_perception(m)
        made.append(m)
    w2._rehash()
    los0 = w2.counters["los_queries"]
    w2.pump_perception()
    s.check("perc-budget", w2.counters["perc_executed"] == 64 and
            w2.counters["perc_deferred"] == 6 and
            w2.counters["los_queries"] - los0 <= 512,
            "exec=%d def=%d rays=%d" %
            (w2.counters["perc_executed"],
             w2.counters["perc_deferred"],
             w2.counters["los_queries"] - los0))
    # coalescing: double request, single queue entry
    w2.perc_queue.clear()
    w2.request_perception(made[0])
    w2.request_perception(made[0])
    s.check("perc-coalesce", w2.counters["perc_coalesced"] >= 1,
            "coal=%d" % w2.counters["perc_coalesced"])
    # occlusion: NPC behind a building is not seen (find any pair)
    w3 = NPCWorld(seed_tag="perc2", with_traffic=False)
    found = None
    for (x0, z0, x1, z1), fp in zip(w3.bboxes[:60], w3.footprints[:60]):
        cx, cz = (x0 + x1) / 2.0, (z0 + z1) / 2.0
        wdt = max(x1 - x0, z1 - z0)
        if w3.los_blocked(cx - wdt, cz, cx + wdt, cz):
            found = (cx - wdt, cz, cx + wdt, cz)
            break
    s.check("los-occluded", found is not None, str(found))
    return s


# ================= BEHAVIOR =================
def suite_behavior():
    s = Suite("behavior")
    w = NPCWorld(seed_tag="beh0", with_traffic=False)
    w.auto_spawn = False
    for n in w.nodes.values():
        w.sectors[n["sector"]] = "READY"
    n = place_npc(w, "TOURIST", 1401.0, 209.0, "PZ-D-hub-core")
    # legal walk: INITIALIZING -> IDLE -> (path) -> WALKING -> IDLE
    states = set()
    for _ in range(120):
        w.tick()
        if n["id"] in w.npcs:
            states.add(w.npcs[n["id"]]["move_state"])
    s.check("walk-cycle", {"WALKING", "IDLE"} <= states,
            str(sorted(states)))
    s.check("no-illegal", not w.illegal, str(w.illegal[:2]))
    # illegal rejected: DESPAWNED -> WALKING
    m = w.acquire("CIVILIAN", "PZ-D-hub-core", 1401.0, 209.0,
                  context="t")
    w.move_transition(m, "INITIALIZING", "t")
    w.move_transition(m, "DESPAWNING", "t")
    w.move_transition(m, "DESPAWNED", "t")
    ok = w.move_transition(m, "WALKING", "hack")
    s.check("illegal-rejected", ok is False and
            ("DESPAWNED", "WALKING", "hack") in
            [(a, b, c) for (a, b, c) in w.illegal])
    # recovery order: force no-route -> recover -> replan (no teleport)
    w2 = NPCWorld(seed_tag="beh1", with_traffic=False)
    w2.auto_spawn = False
    for nn in w2.nodes.values():
        w2.sectors[nn["sector"]] = "READY"
    r = place_npc(w2, "WORKER", 1401.0, 209.0, "PZ-D-hub-core")
    x0, z0 = r["x"], r["z"]
    # break: isolate by clearing adjacency temporarily
    keep = dict(w2.adj)
    w2.adj = {}
    w2.request_path(r, "NC-AR-OS-BLK-E_art_port_00-R0-0")
    pump_all(w2)
    w2.adj = keep
    for _ in range(30):
        w2.tick()
    moved = math.hypot(r["x"] - x0, r["z"] - z0)
    recs = [e for e in w2.events if e["type"] == "recover" and
            e["npc"] == r["id"]]
    s.check("recovery", len(recs) >= 1 and moved < 50.0 and
            w2.counters["repairs_teleport"] == 0,
            "recs=%d moved=%.1f" % (len(recs), moved))
    # stuck -> STUCK -> RECOVERING via blocked progress
    w3 = NPCWorld(seed_tag="beh2", with_traffic=False)
    w3.auto_spawn = False
    for nn in w3.nodes.values():
        w3.sectors[nn["sector"]] = "READY"
    k = place_npc(w3, "RESIDENT", 1401.0, 209.0, "PZ-D-hub-core")
    k["walk"] = 0.0
    k["run"] = 0.0
    k["path"] = [w3.nearest_node(1401.0, 209.0)]
    k["path_i"] = 0
    w3.move_transition(k, "WALKING", "t")
    for _ in range(60):
        w3.tick()
        if k["id"] not in w3.npcs:
            break
    ev = [e["type"] for e in w3.events if e["npc"] == k["id"]]
    s.check("stuck", "recover" in ev or k["id"] not in w3.npcs,
            str(ev[-4:]))
    return s


# ================= POPULATION =================
def suite_population():
    s = Suite("population")
    # convergence in hub: run 600 ticks, population fills toward target
    w = NPCWorld(seed_tag="pop0", focus=(1401.0, 209.0),
                 with_traffic=False)
    for _ in range(600):
        w.tick()
    hub = [n for n in w.npcs.values() if n["zone"] == "PZ-D-hub-core"]
    tgt = w.zones["PZ-D-hub-core"]["target_population"]
    peak = w.zones["PZ-D-hub-core"]["peak_population"]
    s.check("converge", len(hub) >= 0.5 * tgt and len(hub) <= peak,
            "hub=%d target=%d peak=%d" % (len(hub), tgt, peak))
    # density classes differ: urban vs rural targets
    tg = {zid: w.zones[zid]["target_population"]
          for zid in w.zones}
    s.check("density-spread", max(tg.values()) > 5 * min(
        v for v in tg.values() if v > 0),
        "max=%d min+=%d" % (max(tg.values()), min(
            v for v in tg.values() if v > 0)))
    # spawn validity: every active NPC near nav + spaced
    bad = 0
    for n in w.npcs.values():
        nn = w.nearest_node(n["x"], n["z"], rmax=60.0)
        if nn is None:
            bad += 1
    s.check("spawn-valid", bad == 0, "bad=%d n=%d" %
            (bad, len(w.npcs)))
    # duplicate identities: none
    ids = [n["id"] for n in w.npcs.values()]
    s.check("unique-ids", len(ids) == len(set(ids)),
            "n=%d" % len(ids))
    # despawn: over-peak + relevance enforced, safe (no COMMIT kills)
    kills = [e for e in w.events if e["type"] == "despawn"]
    s.check("despawn-policy", all(
        e["data"]["reason"] in ("outside_relevance", "over_peak",
                                "recovery_failed") for e in kills),
            "%d despawns" % len(kills))
    # abstract cover: far zones report targets without actives
    far = [zid for zid in w.zones
           if not any(n["zone"] == zid for n in w.npcs.values())]
    s.check("abstract-cover", len(far) > 0 and all(
        w.zones[z]["target_population"] >= 0 for z in far),
        "%d abstract zones" % len(far))
    return s



SUITES = {"static": suite_static,
          "cross": suite_cross,
          "navigation": suite_navigation,
          "perception": suite_perception,
          "behavior": suite_behavior,
          "population": suite_population,
          "inject": suite_inject,
          "reproduce": suite_reproduce,
          "smoke": suite_smoke,
          "perf": suite_perf,
          "regress": suite_regress,
          "stress": suite_stress}


def main(argv):
    want = list(SUITES) if not argv or argv == ["all"] else argv
    ok = True
    for name in want:
        if name not in SUITES:
            print("unknown suite:", name)
            return 2
        ok = SUITES[name]().report() and ok
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
