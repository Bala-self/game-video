#!/usr/bin/env python3
"""P03 gameplay smoke: kinematic drive-through over exported centerlines.

Drives the 12 CROSS route queries plus one grand tour with a simple
longitudinal model (accel 2.0 / brake 3.5 m/s^2, curve-limited by
v=sqrt(a_lat*R) with a_lat 2.5, junction slow-downs, terminal stops).
No rendering: numeric smoke on centerlines + evidence plots.

Usage: road_smoke.py [--json] [--evidence DIR]
Exit 0 = all trip gates pass.
"""
import json
import math
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from road_model import RoadNetwork  # noqa: E402

A_LAT = 2.5
ACCEL = 2.0
BRAKE = 3.5
QUERIES = [
    ("hub_city", "port_gate", "public"), ("hub_city", "air_gate", "public"),
    ("hub_city", "village_center", "public"), ("hub_city", "sub_center", "public"),
    ("hub_city", "resort_waterfront", "public"), ("hub_city", "ridge_end", "public"),
    ("hub_city", "waterfront_access", "public"), ("hub_city", "jn_W_portal", "public"),
    ("hub_city", "forest_depot", "service"), ("hub_city", "gate_restricted", "restricted"),
    ("jn_ring_W", "jn_ring_S", "public"), ("port_gate", "air_gate", "public"),
]
TOUR = ["hub_city", "resort_waterfront", "port_gate", "air_gate",
        "village_center", "sub_center", "hub_city"]


def circumradius(ax, az, bx, bz, cx, cz):
    ab = math.hypot(bx - ax, bz - az)
    bc = math.hypot(cx - bx, cz - bz)
    ca = math.hypot(ax - cx, az - cz)
    area = abs((bx - ax) * (cz - az) - (cx - ax) * (bz - az)) / 2.0
    if area < 1e-9:
        return float("inf")
    return ab * bc * ca / (4.0 * area)


def drive(rn, nodes_seq, edges_seq):
    """Feasible speed profile over concatenated edge samples. Returns metrics."""
    pts = []  # (x, z, elev, vmax_edge, edge_id)
    for k, eid in enumerate(edges_seq):
        e = rn.edges[eid]
        a, b = e["from_node"], e["to_node"]
        # orient: route enters edge from nodes_seq[k]
        fwd = (a == nodes_seq[k])
        sl = e["samples"] if fwd else list(reversed(e["samples"]))
        vmax = e["effective_speed_kph"] / 3.6
        for i, s in enumerate(sl):
            if k and i == 0:
                continue
            pts.append((s["x"], s["z"], s["elev"], vmax, eid))
    n = len(pts)
    R = [float("inf")] * n
    for i in range(1, n - 1):
        R[i] = circumradius(pts[i - 1][0], pts[i - 1][1],
                            pts[i][0], pts[i][1],
                            pts[i + 1][0], pts[i + 1][1])
    # node proximity slow-downs (junction 30 / roundabout 20 km/h)
    node_xy = {nid: (nd["x"], nd["z"], nd["type"]) for nid, nd in rn.nodes.items()}
    v_allow = []
    for (x, z, _e, vmax, _eid) in pts:
        v = vmax
        for nid, (nx, nz, typ) in node_xy.items():
            dd = math.hypot(x - nx, z - nz)
            if typ == "roundabout" and dd < 80.0:
                v = min(v, 20.0 / 3.6)
            elif typ != "dead_end" and dd < 40.0:
                v = min(v, 30.0 / 3.6)
        v_allow.append(v)
    curve_v = [min(v_allow[i], math.sqrt(A_LAT * R[i]) if R[i] < 1e8 else v_allow[i])
               for i in range(n)]
    # forward pass (accel) then backward pass (brake), rest-to-rest
    v = [0.0] * n
    for i in range(1, n):
        ds = math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
        v[i] = min(curve_v[i], math.sqrt(v[i - 1] ** 2 + 2 * ACCEL * ds))
    v[n - 1] = 0.0
    for i in range(n - 2, -1, -1):
        ds = math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
        v[i] = min(v[i], math.sqrt(v[i + 1] ** 2 + 2 * BRAKE * ds))
    dist, t = 0.0, 0.0
    max_lat, max_g = 0.0, 0.0
    prof = []
    for i in range(1, n):
        ds = math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
        dist += ds
        t += 2 * ds / (v[i] + v[i - 1] + 1e-9)
        if R[i] < 1e8:
            max_lat = max(max_lat, v[i] ** 2 / R[i])
        dh = pts[i][2] - pts[i - 1][2]
        max_g = max(max_g, abs(dh) / ds * 100.0 if ds > 0 else 0.0)
        prof.append((dist, pts[i][2], v[i] * 3.6, R[i]))
    vmove = [x for x in v if x > 0.5]
    return {"distance_m": dist, "time_s": t,
            "avg_kph": dist / t * 3.6 if t > 0 else 0.0,
            "vmax_kph": max(v) * 3.6, "vmin_move_kph": min(vmove) * 3.6 if vmove else 0.0,
            "max_lat_ms2": max_lat, "max_grade_pct": max_g,
            "min_radius_m": min(r for r in R if r < 1e8) if any(r < 1e8 for r in R) else 1e9,
            "profile": prof}


def main():
    want_json = "--json" in sys.argv
    ev = None
    if "--evidence" in sys.argv:
        ev = sys.argv[sys.argv.index("--evidence") + 1]
    rn = RoadNetwork().build()
    trips = {}
    for a, b, prof in QUERIES:
        r = rn.find_route(a, b, prof)
        assert r is not None, "no route %s>%s:%s" % (a, b, prof)
        trips["%s>%s:%s" % (a, b, prof)] = drive(rn, r["nodes"], r["edges"])
    # grand tour: concatenated public legs
    tn, te = [TOUR[0]], []
    for a, b in zip(TOUR, TOUR[1:]):
        r = rn.find_route(a, b, "public")
        assert r is not None, "tour leg %s>%s" % (a, b)
        tn += r["nodes"][1:]
        te += r["edges"]
    trips["GRAND_TOUR"] = drive(rn, tn, te)
    # gates
    fails = []
    for key, m in trips.items():
        if not (math.isfinite(m["time_s"]) and m["time_s"] > 0):
            fails.append((key, "no-completion"))
        if m["avg_kph"] < 15.0:
            fails.append((key, "crawl avg=%.1f" % m["avg_kph"]))
        if m["max_lat_ms2"] > 3.0:
            fails.append((key, "lat=%.2f" % m["max_lat_ms2"]))
        if m["distance_m"] / max(m["time_s"], 1e-9) * 3.6 > 120.0:
            fails.append((key, "overspeed"))
    if ev:
        os.makedirs(ev, exist_ok=True)
        _evidence(rn, trips["GRAND_TOUR"], ev)
    if want_json:
        slim = {k: {j: v for j, v in m.items() if j != "profile"} for k, m in trips.items()}
        print(json.dumps({"trips": slim, "fails": fails}))
    else:
        for key, m in trips.items():
            print("%-28s %7.0fm %6.0fs avg=%5.1f vmax=%5.1f lat=%4.2f grade=%5.1f" % (
                key, m["distance_m"], m["time_s"], m["avg_kph"], m["vmax_kph"],
                m["max_lat_ms2"], m["max_grade_pct"]))
        print("SMOKE:", "FAIL %s" % fails if fails else "OK 13/13 trips")
    return 1 if fails else 0


def _evidence(rn, tour, ev):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    colors = {"primary": "#d62728", "secondary": "#ff7f0e", "tertiary": "#2ca02c",
              "local": "#1f77b4", "rural": "#9467bd", "trail": "#8c564b",
              "service": "#7f7f7f"}
    fig, ax = plt.subplots(figsize=(9, 9))
    th = plt.Circle((0, 0), 2000, fill=False, color="black", lw=1)
    ax.add_patch(th)
    for eid, e in sorted(rn.edges.items()):
        xs = [s["x"] for s in e["samples"]]
        zs = [s["z"] for s in e["samples"]]
        ax.plot(xs, zs, color=colors.get(e["class"], "black"), lw=1.2,
                ls=(0, (4, 2)) if e["tunnel"] else "-")
    for nid, nd in rn.nodes.items():
        if nd["type"] == "roundabout":
            ax.add_patch(plt.Circle((nd["x"], nd["z"]), nd["radius_m"],
                                    fill=False, color="black", lw=1.5))
        ax.plot(nd["x"], nd["z"], "ko", ms=4 if nd["type"] != "dead_end" else 6,
                mew=1 if nd["type"] != "dead_end" else 0,
                mfc="none" if nd["type"] == "dead_end" else "black")
    for b in rn.bridges:
        e = rn.edges[b["road_edge"]]
        sl = e["samples"]
        # mirror of the generator ribbon rule: only the wet span is drawn
        rv = next(r for r in rn.tau["drainage"]["rivers"]
                  if r["id"] == b["water_feature"])
        pts, hw = rv["points"], rv["width_m"] / 2.0
        wet = []
        for s in sl:
            md = 1e18
            for i in range(len(pts) - 1):
                ax0, az0 = pts[i]
                bx, bz = pts[i + 1]
                vx, vz = bx - ax0, bz - az0
                L2 = vx * vx + vz * vz or 1.0
                tt = max(0.0, min(1.0, ((s["x"] - ax0) * vx + (s["z"] - az0) * vz) / L2))
                md = min(md, math.hypot(s["x"] - (ax0 + vx * tt),
                                        s["z"] - (az0 + vz * tt)))
            if md <= hw:
                wet.append(s)
        if wet:
            ax.plot([s["x"] for s in wet], [s["z"] for s in wet],
                    color="#17becf", lw=4, alpha=0.9, solid_capstyle="round")
            mid = wet[len(wet) // 2]
            ax.text(mid["x"], mid["z"], " " + b["id"], fontsize=7, color="#0a7d8c")
    for cls, col in colors.items():
        ax.plot([], [], color=col, lw=2, label=cls)
    ax.plot([], [], color="black", ls=(0, (4, 2)), label="tunnel")
    ax.plot([], [], color="#17becf", lw=4, label="bridge span")
    ax.legend(fontsize=7, loc="lower left")
    ax.set_aspect("equal")
    ax.set_title("P03 road network 23.14km (tunnel dashed, bridges cyan)")
    fig.savefig(os.path.join(ev, "p03_plan.png"), dpi=110)
    plt.close(fig)
    prof = tour["profile"]
    ds = [p[0] for p in prof]
    fig, ax = plt.subplots(figsize=(10, 3.5))
    ax.plot(ds, [p[1] for p in prof], color="black", lw=1)
    ax.set_xlabel("distance (m)")
    ax.set_ylabel("elevation (m)")
    ax.set_title("grand tour elevation profile (%.1fkm)" % (ds[-1] / 1000))
    fig.savefig(os.path.join(ev, "p03_tour_elev.png"), dpi=110)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(10, 3.5))
    ax.plot(ds, [p[2] for p in prof], color="#1f77b4", lw=1)
    ax.set_xlabel("distance (m)")
    ax.set_ylabel("speed (km/h)")
    ax.set_title("grand tour speed profile (avg %.1f km/h)" % tour["avg_kph"])
    fig.savefig(os.path.join(ev, "p03_tour_speed.png"), dpi=110)
    plt.close(fig)


if __name__ == "__main__":
    sys.exit(main())
