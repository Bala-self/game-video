#!/usr/bin/env bash
# P07 clean rebuild (§99): delete derived streaming artifacts, rebuild from
# P00-P06 locked inputs, verify canonical outputs match.
# Authored P07 configs (sector_contract, lod_policy) are inputs, not outputs.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo "=== P07 CLEAN REBUILD ==="
echo "--- checksums before:"
sha256sum data/derived/world_stream_manifest.json reports/p07_size_compare.json \
  reports/p07_cache_compare.json 2>/dev/null | sed 's/  / /' || true
echo "--- deleting derived artifacts:"
rm -f data/derived/world_stream_manifest.json
rm -rf reports/p07/candidates reports/p07/*.json
rm -f reports/p07_size_compare.json reports/p07_cache_compare.json
rm -f reports/p07_golden.json reports/p07_golden_stream.json reports/p07_perf_gates.json
rm -f reports/p07_streaming_summary.json reports/p07_performance_baseline.json
rm -f reports/p07_completion_matrix.json
mkdir -p reports/p07/candidates
echo "--- regenerating manifests:"
python3 tools/sector_manifest.py --size 128 --out reports/p07/candidates/man128.json
python3 tools/sector_manifest.py --size 256 --out reports/p07/candidates/man256.json
python3 tools/sector_manifest.py --size 512 --out reports/p07/candidates/man512.json
cp reports/p07/candidates/man256.json data/derived/world_stream_manifest.json
echo "--- re-running size + cache benchmarks:"
python3 tools/stream_bench.py \
  --manifests 128:reports/p07/candidates/man128.json,256:reports/p07/candidates/man256.json,512:reports/p07/candidates/man512.json \
  --out reports/p07_size_compare.json --repeats 2
python3 tools/stream_bench.py --cache-policies \
  --manifest reports/p07/candidates/man256.json --out reports/p07_cache_compare.json
echo "--- re-running full P07 validation (re-establishes goldens/gates):"
python3 -u tools/validate_p07.py all
echo "--- engine re-verification:"
tools/.godot/godot --headless --path . \
  --script res://tests/godot/tools/streaming_check.gd -- \
  --manifest data/derived/world_stream_manifest.json --lod data/derived/lod_policy.json \
  --golden reports/p07_golden_stream.json | grep -E "STREAMING" | tee /tmp/p07_engine_line.txt
python3 -c "
import json, sys
sys.path.insert(0, 'tools')
from sector_math import fnv1a32_hex, semantic_lines
line = open('/tmp/p07_engine_line.txt').read()
payload = json.loads(line.split('STREAMING_METRICS ', 1)[1])
m = json.load(open('data/derived/world_stream_manifest.json'))
py = fnv1a32_hex('\n'.join(semantic_lines(m['sectors'])))
doc = {'engine': '4.7.2.stable.official.ed1daf0bf', 'renderer': 'headless/none',
 'display': 'unavailable (headless verification only; no visual inspection claimed)',
 'manifest': m['checksum'], 'semantic_checksum32_python': py,
 'semantic_checksum32_engine': payload['semantic_checksum32'],
 'parity': py == payload['semantic_checksum32'],
 'golden_replayed': int(payload['golden'].split('=', 1)[1]),
 'dep_edges': payload['dep_edges'], 'dep_nodes': payload['dep_nodes'],
 'states': payload['states'], 'result': payload['result']}
assert doc['parity'] and doc['result'] == 'STREAMING_OK', doc
json.dump(doc, open('reports/p07/godot_cross.json', 'w'), indent=1)
print('godot_cross regenerated, parity=', doc['parity'])
"
echo "--- regenerating summary + baseline + completion matrix:"
python3 tools/stream_report.py
python3 tools/stream_matrix.py
echo "--- checksums after:"
sha256sum data/derived/world_stream_manifest.json reports/p07_size_compare.json \
  reports/p07_cache_compare.json | sed 's/  / /'
echo "=== REBUILD COMPLETE ==="
