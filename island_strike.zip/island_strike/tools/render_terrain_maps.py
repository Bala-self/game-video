#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 02 — render visual evidence maps (deterministic).

Reads the field only (no engine). Outputs to preview/:
  map_height.png  — hypsometric heightmap + coastline + corridors + sites
  map_slope.png   — grade map (playability: green<=8%, amber<=15%, red>25%)
  map_regions.png — region census + urban zones overlay
"""
import json, math, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from terrain_model import Field  # noqa: E402

STEP = 8.0
R = 2000.0


def main():
    f = Field()
    n = int(2 * R / STEP) + 1
    xs = [-R + i * STEP for i in range(n)]
    H = [[float("nan")] * n for _ in range(n)]
    RG = [[-1] * n for _ in range(n)]
    reg_names = []
    for j in range(n):
        for i in range(n):
            x, z = xs[i], xs[j]
            if x * x + z * z > R * R:
                continue
            H[j][i] = f.height(x, z)
            rn = f.region_at(x, z)
            if rn not in reg_names:
                reg_names.append(rn)
            RG[j][i] = reg_names.index(rn)
    print("regions:", reg_names)
    wl = f.tc["constants"]["water_level_m"] if "water_level_m" in f.tc.get("constants", {}) else 0.0

    # slope from grid central differences
    import numpy as np
    Ha = np.array(H, dtype=float)
    dzdx = (np.roll(Ha, -1, 1) - np.roll(Ha, 1, 1)) / (2 * STEP)
    dzdz = (np.roll(Ha, -1, 0) - np.roll(Ha, 1, 0)) / (2 * STEP)
    grade = np.sqrt(dzdx ** 2 + dzdz ** 2) * 100.0

    au = f.au
    corridors = [(c["id"], c["points"]) for c in au["corridors"] if c["type"] != "tunnel"]
    lakes = [(l["cx"], l["cz"], l["rx"], l["rz"]) for l in au["drainage"]["lakes"]]
    pads = [(p["cx"], p["cz"]) for p in au.get("pads", [])]
    rwc = au["runway"]["center"]

    def base(title):
        fig, ax = plt.subplots(figsize=(9, 9), dpi=110)
        ax.set_title(title, fontsize=12)
        ax.set_xlabel("x (m)"); ax.set_ylabel("z (m)")
        ax.set_aspect("equal")
        return fig, ax

    def overlays(ax, with_corr=True):
        ths = [i * 2 * math.pi / 720.0 for i in range(721)]
        lp = [f.loop.point(f.loop.rs(t), t) for t in ths]
        ax.plot([p[0] for p in lp], [p[1] for p in lp], "k-", lw=0.7, alpha=0.8)
        for cx, cz, rx, rz in lakes:
            e = plt.Circle((cx, cz), max(rx, rz), fill=False, ec="cyan", lw=0.8)
            ax.add_patch(e)
        if with_corr:
            for cid, pts in corridors:
                ax.plot([p[0] for p in pts], [p[1] for p in pts], "m-", lw=0.9, alpha=0.8)
        for px, pz in pads:
            ax.plot([px], [pz], "r^", ms=7)
        ax.plot([rwc[0]], [rwc[1]], "ys", ms=7)
        ax.set_xlim(-2050, 2050); ax.set_ylim(-2050, 2050)

    # 1. heightmap
    fig, ax = base("P02 terrain — height (m) + corridors + lakes + pad/runway")
    v = np.nanmax(np.abs(Ha))
    cmapT = plt.cm.terrain.copy()
    cmapT.set_bad("white")
    im = ax.imshow(Ha, origin="lower", extent=[-R, R, -R, R], cmap=cmapT,
                   vmin=-20, vmax=max(220.0, float(np.nanmax(Ha))))
    fig.colorbar(im, ax=ax, label="height (m)")
    overlays(ax)
    fig.savefig(os.path.join(ROOT, "preview/map_height.png"), bbox_inches="tight")
    plt.close(fig)

    # 2. slope
    fig, ax = base("P02 terrain — grade % (green<=8 amber<=15 red>25)")
    cmap = mcolors.ListedColormap(["#2ca02c", "#ffbf00", "#ff7f0e", "#d62728"])
    cmap.set_bad("white")
    grade[np.isnan(Ha)] = np.nan
    norm = mcolors.BoundaryNorm([0, 8, 15, 25, 300], 4)
    im = ax.imshow(grade, origin="lower", extent=[-R, R, -R, R], cmap=cmap, norm=norm)
    fig.colorbar(im, ax=ax, label="grade %")
    overlays(ax)
    fig.savefig(os.path.join(ROOT, "preview/map_slope.png"), bbox_inches="tight")
    plt.close(fig)

    # 3. regions
    fig, ax = base("P02 terrain — regions (%d) + urban zones" % len(reg_names))
    RGa = np.array(RG, dtype=float)
    RGa[RGa < 0] = np.nan
    cmap20 = plt.cm.tab20.copy()
    cmap20.set_bad("white")
    im = ax.imshow(RGa, origin="lower", extent=[-R, R, -R, R],
                   cmap=cmap20, vmin=0, vmax=max(1, len(reg_names) - 1))
    fig.colorbar(im, ax=ax, label="region idx")
    try:
        z = json.load(open(os.path.join(ROOT, "data/derived/urban_zones.json")))
        p = z["payload"]
        x0, z0 = p["extent"][0], p["extent"][1]
        cm = p["cell_m"]
        zx = [x0 + (c[0] + 0.5) * cm for comp in p["components"] for c in comp["cells"]]
        zz = [z0 + (c[1] + 0.5) * cm for comp in p["components"] for c in comp["cells"]]
        ax.scatter(zx, zz, s=1.5, c="red", alpha=0.5, marker="s", linewidths=0)
    except Exception as e:
        print("zones overlay skipped:", e)
    overlays(ax, with_corr=False)
    fig.savefig(os.path.join(ROOT, "preview/map_regions.png"), bbox_inches="tight")
    plt.close(fig)
    print("wrote preview/map_{height,slope,regions}.png")


if __name__ == "__main__":
    main()
