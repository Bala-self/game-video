#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 05 -- transport structures + roadside infrastructure.

Builds bridges, tunnel lining/portals, retaining structures, barriers,
markings, reservations, roadside dressing metadata and handoff extensions
from LOCKED P03 graph + P04 geometry. Never modifies upstream artifacts.

Outputs (data/derived/):
  transport_structures.json  bridges/tunnel/retaining/barriers + meshes
  transport_markings.json    semantic markings + strip geometry
  transport_reservations.json reservation layers + spatial index grid
  transport_handoff_ext.json  structural extensions to P04 handoffs (by ref)
"""
import json
import math
import os
import random
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from terrain_model import Field, fnv1a_hex  # noqa: E402

STRUCT_CC = os.path.join(ROOT, "data/world/transport_structure_contract.json")
GEO_CC = os.path.join(ROOT, "data/world/road_geometry_contract.json")
GEO_JSON = os.path.join(ROOT, "data/derived/road_geometry.json")
ROADS_JSON = os.path.join(ROOT, "data/derived/roads.json")
OUT_STRUCT = os.path.join(ROOT, "data/derived/transport_structures.json")
OUT_MARK = os.path.join(ROOT, "data/derived/transport_markings.json")
OUT_RESV = os.path.join(ROOT, "data/derived/transport_reservations.json")
OUT_HAND = os.path.join(ROOT, "data/derived/transport_handoff_ext.json")

SECTOR_SIZE = 256.0
GRID_MIN = -2048.0
MASTER_SEED = 13371337
WORLD_VERSION = "0.1.0"


class StructureError(Exception):
    pass


def sector_of(x, z):
    return "SX%02dZ%02d" % (math.floor((x - GRID_MIN) / SECTOR_SIZE),
                            math.floor((z - GRID_MIN) / SECTOR_SIZE))


def seed_for(domain, key):
    text = "IS-SEED/1|v=%s|m=%d|d=%s|k=%s" % (WORLD_VERSION, MASTER_SEED,
                                              domain, key)
    return int(fnv1a_hex(text), 16)


def q6(v):
    return round(float(v), 6)


def canon(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"))


class MeshPart:
    """P04-style mesh part accumulator. Walls use outward-facing winding
    (classified wall parts, not up-facing road rule)."""

    def __init__(self, pid, kind, ref, semantic):
        self.id = pid
        self.kind = kind
        self.ref = ref
        self.semantic = semantic
        self.verts = []
        self.tris = []

    def vert(self, x, y, z, nx=0.0, ny=1.0, nz=0.0):
        self.verts.append([x, y, z, nx, ny, nz])
        return len(self.verts) - 1

    def tri(self, a, b, c):
        A, B, C = self.verts[a], self.verts[b], self.verts[c]
        ux, uy, uz = B[0] - A[0], B[1] - A[1], B[2] - A[2]
        vx, vy, vz = C[0] - A[0], C[1] - A[1], C[2] - A[2]
        nx = uy * vz - uz * vy
        ny = uz * vx - ux * vz
        nz = ux * vy - uy * vx
        area = math.sqrt(nx * nx + ny * ny + nz * nz) / 2.0
        if not (math.isfinite(area)) or area < 1e-9:
            raise StructureError("degenerate tri in %s" % self.id)
        self.tris.append([a, b, c])
        return ny / (2.0 * area)

    def quad_up(self, a, b, c, d):
        """Flatwork quad (a,b,c,d around): must face up."""
        ny1 = self.tri(a, b, c)
        ny2 = self.tri(a, c, d)
        if ny1 <= 0 or ny2 <= 0:
            raise StructureError("non-up flatwork in %s" % self.id)

    def quad(self, a, b, c, d):
        """Wall quad: winding as given (outward by construction)."""
        self.tri(a, b, c)
        self.tri(a, c, d)

    def _normal_of(self, a, b, c):
        A, B, C = self.verts[a], self.verts[b], self.verts[c]
        ux, uy, uz = B[0] - A[0], B[1] - A[1], B[2] - A[2]
        vx, vy, vz = C[0] - A[0], C[1] - A[1], C[2] - A[2]
        return (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)

    def quad_out(self, a, b, c, d, out):
        """Wall quad forced to face the outward hint (label-dependent sides
        orient by construction; geometric check, not trial-and-error)."""
        n = self._normal_of(a, b, c)
        if n[0] * out[0] + n[1] * out[1] + n[2] * out[2] < 0:
            self.tri(a, d, c)
            self.tri(a, c, b)
        else:
            self.tri(a, b, c)
            self.tri(a, c, d)

    def quad_up_either(self, a, b, c, d):
        n = self._normal_of(a, b, c)
        if n[1] < 0:
            self.tri(a, d, c)
            self.tri(a, c, b)
        else:
            if n[1] == 0:
                raise StructureError("vertical flatwork in %s" % self.id)
            self.tri(a, b, c)
            self.tri(a, c, d)

    def tri_up_either(self, a, b, c):
        n = self._normal_of(a, b, c)
        if n[1] < 0:
            self.tri(a, c, b)
        else:
            if n[1] == 0:
                raise StructureError("vertical flatwork in %s" % self.id)
            self.tri(a, b, c)

    def fix_normals(self):
        """Recompute vert normals as area-weighted face normals."""
        acc = [[0.0, 0.0, 0.0] for _ in self.verts]
        for t in self.tris:
            n = self._normal_of(*t)
            for vi in t:
                acc[vi][0] += n[0]
                acc[vi][1] += n[1]
                acc[vi][2] += n[2]
        for v, a in zip(self.verts, acc):
            L = math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])
            if L < 1e-12:
                raise StructureError("zero normal in %s" % self.id)
            v[3], v[4], v[5] = a[0] / L, a[1] / L, a[2] / L

    def export(self):
        return {"id": self.id, "kind": self.kind, "ref": self.ref,
                "verts": self.verts, "tris": self.tris, "skirt": [],
                "semantic": self.semantic}


class Registry:
    def __init__(self):
        self.timers = {}
        self._t0 = None
        self._phase = None

    def _t(self, name):
        now = time.time()
        if self._phase is not None:
            self.timers[self._phase] = self.timers.get(self._phase, 0.0) + now - self._t0
        self._phase = name
        self._t0 = now

    def phase_preflight(self):
        self._t("preflight")
        self.sc = json.load(open(STRUCT_CC))
        self.gc = json.load(open(GEO_CC))
        self.g = json.load(open(GEO_JSON))
        self.r = json.load(open(ROADS_JSON))
        self.f = Field()
        # ---- stale dependency refusal (loud + actionable) ----
        exp = [("road_version", self.sc["road_version"], "0.1.0",
                "road_contract (P03)"),
               ("road_checksum", self.sc["road_checksum_reference"],
                self.r["checksum"], ROADS_JSON),
               ("geometry_version", self.sc["geometry_version"],
                self.g["meta"]["geometry_version"], GEO_JSON),
               ("geometry_checksum", self.sc["geometry_checksum_reference"],
                self.g["checksum"]["geometry"], GEO_JSON),
               ("world_version", self.sc["world_version"], WORLD_VERSION,
                "world_contract (P01)")]
        for name, want, got, owner in exp:
            if want != got:
                raise StructureError(
                    "STALE-DEPENDENCY %s: want %s, got %s (owner %s). "
                    "Repair: rebuild the owning artifact or bump %s after "
                    "a versioned correction." % (name, want, got, owner, name))
        self.parts = {p["id"]: p for p in self.g["parts"]}
        self._t(None)

    # ---- shared source queries ----
    def edge_stations(self, eid):
        return self.g["edges"][eid]["stations"]

    def ribbon_vert(self, eid, station_idx, col_idx):
        E = self.g["edges"][eid]
        nc = len(E["meta"]["columns"])
        return self.parts["ribbon-" + eid]["verts"][station_idx * nc + col_idx]

    def station_range(self, eid, d0, d1):
        st = self.edge_stations(eid)
        return [i for i, p in enumerate(st) if d0 - 1e-9 <= p["d"] <= d1 + 1e-9]

    def span_dlist(self, eid, d0, d1):
        # wet-span point list: span ends + enclosed stations (dedup 1e-6).
        # Validator recomputes the identical list (no trust needed).
        st = self.edge_stations(eid)
        idxs = self.station_range(eid, d0, d1)
        raw = [d0] + [st[i]["d"] for i in idxs] + [d1]
        out = []
        for dd in raw:
            if not out or abs(dd - out[-1]) > 1e-6:
                out.append(dd)
        return out

    def _seg_at(self, eid, dd):
        st = self.edge_stations(eid)
        dd = min(max(dd, st[0]["d"]), st[-1]["d"])
        for i in range(len(st) - 1):
            if st[i]["d"] - 1e-9 <= dd <= st[i + 1]["d"] + 1e-9:
                return i
        return len(st) - 2

    def center_at(self, eid, dd):
        # centerline xyz + tangent + road_elev at chainage (exact stations
        # returned verbatim; span ends interpolated). Bitwise-mirrored by
        # the validator, so the lerp expression must stay in this form.
        st = self.edge_stations(eid)
        for p in st:
            if abs(p["d"] - dd) < 1e-12:
                return (p["x"], p["z"], p["tx"], p["tz"], p["road_elev"])
        i = self._seg_at(eid, dd)
        a, b = st[i], st[i + 1]
        f = (dd - a["d"]) / (b["d"] - a["d"])
        return (a["x"] + (b["x"] - a["x"]) * f,
                a["z"] + (b["z"] - a["z"]) * f,
                a["tx"], a["tz"],
                a["road_elev"] + (b["road_elev"] - a["road_elev"]) * f)

    def ribbon_edge_at(self, eid, ci, dd):
        # ribbon edge vert at chainage (exact stations verbatim, ends lerped;
        # same expression the validator mirrors bitwise).
        st = self.edge_stations(eid)
        for j, p in enumerate(st):
            if abs(p["d"] - dd) < 1e-12:
                return list(self.ribbon_vert(eid, j, ci))
        i = self._seg_at(eid, dd)
        a, b = st[i], st[i + 1]
        f = (dd - a["d"]) / (b["d"] - a["d"])
        va = self.ribbon_vert(eid, i, ci)
        vb = self.ribbon_vert(eid, i + 1, ci)
        return [va[k] + (vb[k] - va[k]) * f for k in range(3)]

    def surf_y_at(self, eid, station_idx, offset):
        """Exact P04 surface height at lateral offset (column interp)."""
        from road_geometry import station_cols
        E = self.g["edges"][eid]
        meta = E["meta"]
        p = self.edge_stations(eid)[station_idx]
        cols = station_cols(meta["columns"], meta["lift"], meta["crown"],
                            meta["fall"], p, 0.5)
        offs = meta["columns"]
        if offset <= offs[0]:
            c = cols[0]
            return c["y"], c["x"], c["z"]
        if offset >= offs[-1]:
            c = cols[-1]
            return c["y"], c["x"], c["z"]
        for k in range(len(offs) - 1):
            if offs[k] <= offset <= offs[k + 1]:
                f = (offset - offs[k]) / (offs[k + 1] - offs[k])
                a, b = cols[k], cols[k + 1]
                return (a["y"] + (b["y"] - a["y"]) * f,
                        a["x"] + (b["x"] - a["x"]) * f,
                        a["z"] + (b["z"] - a["z"]) * f)
        raise StructureError("offset interp failed %s %s" % (eid, offset))

    def checksum_scope(self, items):
        lines = sorted(canon(it) for it in items)
        return fnv1a_hex("\n".join(lines))

    # ================= BRIDGES =================
    def phase_bridges(self):
        self._t("bridges")
        self.bridges = {}
        self.bridge_mesh = []
        for bid in sorted(self.g["bridges"]):
            self._build_bridge(bid)
        self._t(None)

    def _build_bridge(self, bid):
        b = self.g["bridges"][bid]
        eid = b["edge"]
        E = self.g["edges"][eid]
        sc = self.sc["bridge_rules"]
        half = E["width_m"] / 2.0
        dlist = self.span_dlist(eid, b["wet0"], b["wet1"])
        if len(dlist) < 2:
            raise StructureError("bridge %s deck span has <2 stations" % bid)
        deck = []
        for dd in dlist:
            cx, cz, tx, tz, elev = self.center_at(eid, dd)
            deck.append({"d": dd, "x": cx, "z": cz, "tx": tx, "tz": tz,
                         "road_elev": elev})
        # seeded finish variation (metadata only: no collision impact)
        rng = random.Random(seed_for("p05-bridge", bid))
        finish = rng.choice(["smooth_form", "boardmarked"])
        comp = {"id": "ST-%s" % bid, "bridge": bid, "edge": eid,
                "class": E["class"], "access": E["access"],
                "station_range": [deck[0]["d"], deck[-1]["d"]],
                "deck_width": E["width_m"],
                "deck_profile": [{"d": q6(d["d"]), "elev": q6(d["road_elev"])}
                                 for d in deck],
                "water": b["water"], "wet": [b["wet0"], b["wet1"]],
                "approaches": {"a": b["anchor_a"], "b": b["anchor_b"],
                               "appr0": b["appr0"], "appr1": b["appr1"]},
                "deck_floor": b["deck_floor"],
                "water_clearance": b["deck_floor"] - b["water_est"],
                "clearance_min": b["clearance_min"],
                "finish": finish,
                "condition": "new", "wear_state": "fresh",
                "damage_state": "none", "maintenance_priority": "routine",
                "components": []}
        # parapets + fascia follow the P04 ribbon edge verts exactly
        for side, col, sname in ((0, 0, "L"), (-1, -1, "R")):
            nc = len(E["meta"]["columns"])
            ci = 0 if col == 0 else nc - 1
            edge = [self.ribbon_edge_at(eid, ci, dd) for dd in dlist]
            pid = "ST-%s-parapet-%s" % (bid, sname)
            mp = MeshPart(pid, "bridge_parapet", bid,
                          {"structure": pid, "bridge": bid, "edge": eid,
                           "material": sc["parapet_material"],
                           "access": E["access"]})
            self._parapet_strip(mp, edge, deck, half if sname == "R" else -half)
            self.bridge_mesh.append(mp.export())
            comp["components"].append(
                self._comp_rec(pid, "bridge_parapet", mp, eid, E["access"]))
            pid = "ST-%s-fascia-%s" % (bid, sname)
            mf = MeshPart(pid, "bridge_fascia", bid,
                          {"structure": pid, "bridge": bid, "edge": eid,
                           "material": sc["fascia_material"],
                           "access": E["access"]})
            self._fascia_strip(mf, edge, deck, sc["deck_depth_m"])
            self.bridge_mesh.append(mf.export())
            comp["components"].append(
                self._comp_rec(pid, "bridge_fascia", mf, eid, E["access"]))
        # abutments under both deck ends (approach side)
        for end, dd in (("A", b["wet0"]), ("B", b["wet1"])):
            pid = "ST-%s-abutment-%s" % (bid, end)
            ma = MeshPart(pid, "bridge_abutment", bid,
                          {"structure": pid, "bridge": bid, "edge": eid,
                           "material": "concrete", "access": E["access"],
                           "foundation": "classified_burial"})
            top = self._abutment_box(ma, eid, dd, E["width_m"], sc)
            self.bridge_mesh.append(ma.export())
            rec = self._comp_rec(pid, "bridge_abutment", ma, eid, E["access"])
            rec["deck_underside_ref"] = q6(top)
            comp["components"].append(rec)
        comp["piers"] = {"count": 0, "reason": sc["pier_policy"],
                         "note": "wet spans %.1f m single-span; no pier "
                                 "source data in P04" % (b["wet1"] - b["wet0"])}
        comp["sectors"] = self._sectors_of_mesh(
            [p for p in self.bridge_mesh if p["id"].startswith("ST-" + bid)])
        self.bridges[bid] = comp

    def _comp_rec(self, pid, cls, mp, eid, access):
        return {"id": pid, "class": cls, "edge": eid, "access": access,
                "material": mp.semantic["material"],
                "verts": len(mp.verts), "tris": len(mp.tris),
                "sectors": self._sectors_of_verts(mp.verts),
                "lod": {"near": "full_structural", "mid": "simplified_profile",
                        "far": "bounds_plus_reservation"},
                "streaming": {"order": ["ROAD_EDGE", "STRUCTURE", "DETAILS"],
                              "source": "ribbon-" + eid}}

    def _sectors_of_verts(self, verts):
        return sorted(set(sector_of(v[0], v[2]) for v in verts))

    def _sectors_of_mesh(self, parts):
        out = set()
        for p in parts:
            out.update(self._sectors_of_verts(p["verts"]))
        return sorted(out)

    def _parapet_strip(self, mp, edge, deck, side_sign):
        h = float(self.sc["barrier_rules"]["bridge_parapet"]["height_m"])
        w = float(self.sc["barrier_rules"]["bridge_parapet"]["width_m"])
        ring = []
        for v, d in zip(edge, deck):
            # outward unit (plan), from travel tangent
            ox, oz = -d["tz"] * side_sign / abs(side_sign), d["tx"] * side_sign / abs(side_sign)
            # NOTE side_sign=±half: outward = lateral dir of that side
            lat = (d["tz"], -d["tx"])  # +offset lateral (matches P04?)
            # determine outward sign empirically from ribbon: edge vert vs center
            cx = d["x"]
            cz = d["z"]
            ovx, ovz = v[0] - cx, v[2] - cz
            L = math.hypot(ovx, ovz) or 1.0
            ovx, ovz = ovx / L, ovz / L
            ob = mp.vert(v[0], v[1], v[2], ovx, 0.0, ovz)
            ot = mp.vert(v[0], v[1] + h, v[2], ovx, 0.0, ovz)
            ib = mp.vert(v[0] - ovx * w, v[1], v[2] - ovz * w, -ovx, 0.0, -ovz)
            it = mp.vert(v[0] - ovx * w, v[1] + h, v[2] - ovz * w, 0.0, 1.0, 0.0)
            ring.append((ob, ot, ib, it))
        for k in range(len(ring) - 1):
            a0, a1, a2, a3 = ring[k]
            b0, b1, b2, b3 = ring[k + 1]
            A, B = mp.verts[a0], mp.verts[b0]
            # outward hint: horizontal perp of travel, toward outer side
            dx, dz = B[0] - A[0], B[2] - A[2]
            L = math.hypot(dx, dz) or 1.0
            mx = (A[0] + B[0]) / 2.0 - (deck[k]["x"] + deck[k + 1]["x"]) / 2.0
            mz = (A[2] + B[2]) / 2.0 - (deck[k]["z"] + deck[k + 1]["z"]) / 2.0
            ML = math.hypot(mx, mz) or 1.0
            out = (mx / ML, 0.0, mz / ML)
            mp.quad_out(a0, b0, b1, a1, out)    # outer face
            mp.quad_out(a2, a3, b3, b2, (-out[0], 0.0, -out[2]))  # inner
        # top cap with dedicated verts (flat normals; base ring stride 4 kept)
        cap = []
        for (_o0, o1, _i0, i1) in ring:
            T, I = mp.verts[o1], mp.verts[i1]
            cap.append((mp.vert(T[0], T[1], T[2]),
                        mp.vert(I[0], I[1], I[2])))
        for k in range(len(cap) - 1):
            o0, i0 = cap[k]
            o1, i1 = cap[k + 1]
            mp.quad_up_either(o0, o1, i1, i0)
        mp.fix_normals()

    def _fascia_strip(self, mp, edge, deck, depth):
        ring = []
        for v in edge:
            t = mp.vert(v[0], v[1], v[2], 0.0, 0.0, 0.0)
            b = mp.vert(v[0], v[1] - depth, v[2], 0.0, 0.0, 0.0)
            ring.append((t, b))
        for k in range(len(ring) - 1):
            t0, b0 = ring[k]
            t1, b1 = ring[k + 1]
            A, B = mp.verts[t0], mp.verts[t1]
            mx = (A[0] + B[0]) / 2.0 - (deck[k]["x"] + deck[k + 1]["x"]) / 2.0
            mz = (A[2] + B[2]) / 2.0 - (deck[k]["z"] + deck[k + 1]["z"]) / 2.0
            ML = math.hypot(mx, mz) or 1.0
            mp.quad_out(t0, t1, b1, b0, (mx / ML, 0.0, mz / ML))
        mp.fix_normals()

    def _abutment_box(self, mp, eid, dd, width, sc):
        st = self.edge_stations(eid)
        # interpolate center/tangent/elev at dd
        seg = None
        for i in range(len(st) - 1):
            if st[i]["d"] - 1e-9 <= dd <= st[i + 1]["d"] + 1e-9:
                seg = i
                break
        if seg is None:
            raise StructureError("abutment d=%.2f off stations %s" % (dd, eid))
        a, b = st[seg], st[seg + 1]
        f = 0.0 if b["d"] == a["d"] else (dd - a["d"]) / (b["d"] - a["d"])
        cx = a["x"] + (b["x"] - a["x"]) * f
        cz = a["z"] + (b["z"] - a["z"]) * f
        tx, tz = a["tx"], a["tz"]
        elev = a["road_elev"] + (b["road_elev"] - a["road_elev"]) * f
        top = elev - sc["deck_depth_m"]
        half = (width + 1.0) / 2.0
        L = sc["abutment_length_m"] / 2.0
        # approach side: wet0 end -> box toward -tangent; wet1 -> +tangent
        sgn = -1.0 if dd <= (a["d"] + b["d"]) / 2.0 + (st[-1]["d"] - st[0]["d"]) \
            else 1.0
        # robust: approach side = away from the wet span midpoint is unknown
        # here; caller passes wet0 (sgn -1) / wet1 (sgn +1) via dd order:
        sgn = -1.0 if mp.id.endswith("-A") else 1.0
        ccx, ccz = cx + tx * sgn * L, cz + tz * sgn * L
        nx, nz = tz, -tx  # lateral
        # base from terrain samples over footprint
        tmin = 1e300
        for du in (-L, 0.0, L):
            for dv in (-half, 0.0, half):
                tmin = min(tmin, self.f.height(ccx + tx * du + nx * dv,
                                               ccz + tz * du + nz * dv))
        base = min(tmin - sc["abutment_burial_m"], top - 0.5)
        c = [(ccx + tx * du + nx * dv, ccz + tz * du + nz * dv)
             for du in (-L, L) for dv in (-half, half)]
        # corners as coords; each face gets its own verts (flat normals)
        cc = {}
        for k, (px, pz) in enumerate(c):
            cc[(k, 0)] = (px, base, pz)
            cc[(k, 1)] = (px, top, pz)
        faces = [((0, 0), (0, 1), (1, 1), (1, 0), (-tx, 0.0, -tz)),
                 ((2, 0), (3, 0), (3, 1), (2, 1), (tx, 0.0, tz)),
                 ((0, 0), (2, 0), (2, 1), (0, 1), (-nx, 0.0, -nz)),
                 ((1, 0), (1, 1), (3, 1), (3, 0), (nx, 0.0, nz)),
                 ((0, 1), (2, 1), (3, 1), (1, 1), (0.0, 1.0, 0.0)),
                 ((0, 0), (1, 0), (3, 0), (2, 0), (0.0, -1.0, 0.0))]
        for q0, q1, q2, q3, out in faces:
            vs = [mp.vert(*cc[q]) for q in (q0, q1, q2, q3)]
            mp.quad_out(vs[0], vs[1], vs[2], vs[3], out)
        mp.fix_normals()
        return top

    # ================= TUNNEL =================
    def phase_tunnel(self):
        self._t("tunnel")
        self.tunnel_mesh = []
        t = self.g["tunnel"]
        eid = t["edge"]
        E = self.g["edges"][eid]
        half = E["width_m"] / 2.0
        tr = self.sc["tunnel_rules"]
        st = self.edge_stations(eid)
        bore = [i for i, p in enumerate(st) if p["structure"] == "TUNNEL"]
        # dedupe d within 1 mm (P04 kept marks+samples pairs)
        clean = []
        for i in bore:
            if clean and abs(st[i]["d"] - st[clean[-1]]["d"]) < 1e-3:
                continue
            clean.append(i)
        bore = clean
        if len(bore) < 2:
            raise StructureError("tunnel bore has <2 stations")
        # lining arch profile per bore station
        lo = tr["lining_offset_beyond_road_m"]
        W = half + lo
        prof = []
        min_clear = 1e300
        for i in bore:
            p = st[i]
            n = (p["tz"], -p["tx"])
            yL = self.surf_y_at(eid, i, -half)[0]
            yR = self.surf_y_at(eid, i, half)[0]
            yC = self.surf_y_at(eid, i, 0.0)[0]
            crown = yC + self.sc["clearance"]["tunnel_vehicle_m"] + \
                tr["crown_above_clearance_m"]
            min_clear = min(min_clear, crown - yC)
            wtL, wtR = yL + tr["wall_height_m"], yR + tr["wall_height_m"]
            pts = []
            pts.append((-W, yL))
            pts.append((-W, wtL))
            for k in (1, 2, 3):
                a = math.pi / 2.0 * k / 4.0
                pts.append((-W * math.cos(a),
                            wtL + (crown - wtL) * math.sin(a)))
            pts.append((0.0, crown))
            for k in (3, 2, 1):
                a = math.pi / 2.0 * k / 4.0
                pts.append((W * math.cos(a),
                            wtR + (crown - wtR) * math.sin(a)))
            pts.append((W, wtR))
            pts.append((W, yR))
            prof.append([(p["x"] + n[0] * off, y, p["z"] + n[1] * off)
                         for off, y in pts])
        mp = MeshPart("ST-TN-lining", "tunnel_lining", "TN",
                      {"structure": "ST-TN-lining", "edge": eid,
                       "material": tr["lining_material"], "access": E["access"]})
        rings = []
        for ring in prof:
            rings.append([mp.vert(x, y, z) for x, y, z in ring])
        for k in range(len(rings) - 1):
            cx = (st[bore[k]]["x"] + st[bore[k + 1]]["x"]) / 2.0
            cz = (st[bore[k]]["z"] + st[bore[k + 1]]["z"]) / 2.0
            for j in range(len(rings[k]) - 1):
                a0, a1 = rings[k][j], rings[k][j + 1]
                b0, b1 = rings[k + 1][j], rings[k + 1][j + 1]
                A, B = mp.verts[a0], mp.verts[b1]
                mx = (A[0] + B[0]) / 2.0
                mz = (A[2] + B[2]) / 2.0
                inw = (cx - mx, 0.0, cz - mz)
                L = math.hypot(inw[0], inw[2]) or 1.0
                mp.quad_out(a0, b0, b1, a1, (inw[0] / L, 0.0, inw[2] / L))
        mp.fix_normals()
        self.tunnel_mesh.append(mp.export())
        # portal cuts (measured from transition stations)
        cuts = {}
        for ref in ("portal_E", "portal_W"):
            ds = [p["terrain"] - p["road_elev"] for p in st
                  if p.get("struct_ref") == ref]
            cuts[ref] = max(ds) if ds else 0.0
        comp = {"id": "ST-TN", "edge": eid, "class": E["class"],
                "access": E["access"],
                "bore_range": [st[bore[0]]["d"], st[bore[-1]]["d"]],
                "bore_stations": len(bore),
                "lining_clearance_min": q6(min_clear),
                "portal_cuts": {k: q6(v) for k, v in cuts.items()},
                "portal_nodes": {"E": t["portal_E_node"],
                                 "W": t["portal_W_node"]},
                "condition": "new", "wear_state": "fresh",
                "damage_state": "none", "maintenance_priority": "routine",
                "components": [self._comp_rec(
                    "ST-TN-lining", "tunnel_lining", mp, eid, E["access"])]}
        # headwalls + wing walls at both bore ends
        for end, bi, ref in (("E", bore[0], "portal_E"),
                             ("W", bore[-1], "portal_W")):
            self._portal_works(comp, eid, E, st[bi], bi, end, ref, cuts[ref])
        comp["sectors"] = self._sectors_of_mesh(self.tunnel_mesh)
        # mount zones every 50 m, staggered types (semantic reservations)
        comp["mount_zones"] = []
        d0, d1 = comp["bore_range"]
        dd = math.ceil(d0 / 50.0) * 50.0
        zi = 0
        zones = tr["mount_zones"]
        while dd < d1:
            comp["mount_zones"].append(
                {"d": q6(dd), "zone": zones[zi % len(zones)],
                 "side": "L" if (zi % 2 == 0) else "R"})
            zi += 1
            dd += 50.0
        self.tunnel = comp
        self._t(None)

    def _portal_works(self, comp, eid, E, p, bi, end, ref, cut):
        tr = self.sc["tunnel_rules"]
        half = E["width_m"] / 2.0
        lo = tr["lining_offset_beyond_road_m"]
        W = half + lo
        open_half = W + 0.75
        wall_half = W + 6.0
        yC = self.surf_y_at(eid, bi, 0.0)[0]
        crown = yC + self.sc["clearance"]["tunnel_vehicle_m"] + \
            tr["crown_above_clearance_m"]
        top = yC + cut + tr["headwall_freeboard_m"]
        base = yC - 1.0
        tx, tz = p["tx"], p["tz"]
        # bore direction: E portal faces -tangent(d increasing into bore)
        sgn = -1.0 if end == "E" else 1.0
        n = (tz, -tx)
        pid = "ST-TN-headwall-%s" % end
        mp = MeshPart(pid, "tunnel_headwall", "TN",
                      {"structure": pid, "edge": eid, "portal": ref,
                       "material": "concrete", "access": E["access"]})
        # piers: [-wall_half,-open_half],[open_half,wall_half] x [base,top]
        # lintel: [-open_half,open_half] x [crown+0.5, top]
        quads = [(-wall_half, base, -open_half, top),
                 (open_half, base, wall_half, top),
                 (-open_half, crown + 0.5, open_half, top)]
        for x0, y0, x1, y1 in quads:
            v0 = mp.vert(p["x"] + n[0] * x0, y0, p["z"] + n[1] * x0)
            v1 = mp.vert(p["x"] + n[0] * x1, y0, p["z"] + n[1] * x1)
            v2 = mp.vert(p["x"] + n[0] * x1, y1, p["z"] + n[1] * x1)
            v3 = mp.vert(p["x"] + n[0] * x0, y1, p["z"] + n[1] * x0)
            mp.quad_out(v0, v1, v2, v3, (tx * sgn, 0.0, tz * sgn))
        mp.fix_normals()
        self.tunnel_mesh.append(mp.export())
        rec = self._comp_rec(pid, "tunnel_headwall", mp, eid, E["access"])
        rec["opening"] = {"half_width": q6(open_half), "crown": q6(crown + 0.5)}
        comp["components"].append(rec)
        # wing walls: from headwall ends angled back into the cut
        ang = math.radians(tr["wingwall_angle_deg"])
        wlen = min(12.0, max(4.0, cut))
        wtop = yC + min(cut, 4.0)
        for side, sgn2 in (("L", -1.0), ("R", 1.0)):
            wid = "ST-TN-wingwall-%s-%s" % (end, side)
            mw = MeshPart(wid, "tunnel_wingwall", "TN",
                          {"structure": wid, "edge": eid, "portal": ref,
                           "material": "concrete", "access": E["access"]})
            # direction: outward+approach (away from bore, away from road)
            dx = tx * sgn * math.cos(ang) + n[0] * sgn2 * math.sin(ang)
            dz = tz * sgn * math.cos(ang) + n[1] * sgn2 * math.sin(ang)
            x0, z0 = p["x"] + n[0] * sgn2 * wall_half, \
                p["z"] + n[1] * sgn2 * wall_half
            x1, z1 = x0 + dx * wlen, z0 + dz * wlen
            v0 = mw.vert(x0, base, z0)
            v1 = mw.vert(x1, base, z1)
            v2 = mw.vert(x1, wtop, z1)
            v3 = mw.vert(x0, top, z0)
            # faces the cut (away from road center): hint outward
            mw.quad_out(v0, v1, v2, v3, (n[0] * sgn2, 0.0, n[1] * sgn2))
            mw.fix_normals()
            self.tunnel_mesh.append(mw.export())
            wrec = self._comp_rec(wid, "tunnel_wingwall", mw, eid, E["access"])
            wrec["length"] = q6(wlen)
            comp["components"].append(wrec)

    # ================= RETAINING =================
    def phase_retaining(self):
        self._t("retaining")
        self.retaining = {"dispositions": [], "walls": []}
        self.retaining_mesh = []
        for ci, cut in enumerate(self.g["cuts"]):
            if "edge" in cut:
                self._edge_cut(ci, cut)
            else:
                self._node_cut(ci, cut)
        self._retained_lip_treatments()
        self._t(None)

    def _ground_class(self, region, coast_d, slope):
        if slope > 0.6 or "highland" in region:
            return "rock"
        if coast_d is not None and coast_d < 60.0:
            return "mixed"
        return "soil"

    def _edge_cut(self, ci, cut):
        eid = cut["edge"]
        E = self.g["edges"][eid]
        half = E["width_m"] / 2.0
        st = self.edge_stations(eid)
        idxs = self.station_range(eid, cut["d0"], cut["d1"])
        if not idxs:
            idxs = [min(range(len(st)), key=lambda i: abs(st[i]["d"] - cut["d0"]))]
        sc = self.sc["retaining_rules"]
        if cut["max_depth"] < sc["wall_min_depth_m"]:
            self.retaining["dispositions"].append(
                {"cut_id": ci, "source": {"edge": eid}, "decision": "natural_slope",
                 "reason": "max_depth %.2f < wall_min %.2f" % (
                     cut["max_depth"], sc["wall_min_depth_m"]),
                 "max_depth": q6(cut["max_depth"]),
                 "ground": self._ground_class(
                     st[idxs[0]]["region"], st[idxs[0]]["coast_d"], 0.3)})
            return
        for side, sgn in (("L", -1.0), ("R", 1.0)):
            pts = []
            for i in idxs:
                p = st[i]
                n = (p["tz"], -p["tx"])
                off = sgn * (half + 1.5)
                x, z = p["x"] + n[0] * off, p["z"] + n[1] * off
                terr = self.f.height(x, z)
                sy = self.surf_y_at(eid, i, sgn * half)[0]
                pts.append((x, z, sy, terr, p["d"]))
            if max(t - s for _, _, s, t, _ in pts) < sc["wall_min_depth_m"]:
                continue
            wid = "ST-RW-%s-%s-%d" % (eid, side, ci)
            self._wall_run(wid, eid, E, pts, "retaining_wall", ci)

    def _node_cut(self, ci, cut):
        nid = cut["node"]
        J = self.g["junctions"][nid]
        n = self.r["nodes"][nid]
        sc = self.sc["retaining_rules"]
        # portal nodes: tunnel builder owns the treatment (cross-reference)
        if nid in (self.g["tunnel"]["portal_E_node"],
                   self.g["tunnel"]["portal_W_node"]):
            self.retaining["dispositions"].append(
                {"cut_id": ci, "source": {"node": nid},
                 "decision": "portal_treatment",
                 "reason": "portal cutting owned by ST-TN headwall/wingwalls",
                 "max_depth": q6(cut["max_depth"]),
                 "structure_ref": "ST-TN"})
            return
        if cut["max_depth"] < sc["wall_min_depth_m"]:
            self.retaining["dispositions"].append(
                {"cut_id": ci, "source": {"node": nid},
                 "decision": "natural_slope",
                 "reason": "max_depth %.2f < wall_min %.2f" % (
                     cut["max_depth"], sc["wall_min_depth_m"]),
                 "max_depth": q6(cut["max_depth"]), "ground": "soil"})
            return
        # platform ref elev = min mouth road_elev (exact P04 data)
        pe = 1e300
        for m in J["mouths"]:
            E2 = self.g["edges"][m["edge"]]
            st2 = E2["stations"]
            q = st2[-1] if m["side"] == "to" else st2[0]
            pe = min(pe, q["road_elev"])
        # mouth bearing exclusions (walls must never block legal turns)
        excl = []
        for m in J["mouths"]:
            ang = math.degrees(math.atan2(m["z"] - n["z"], m["x"] - n["x"]))
            half_ang = math.degrees(math.atan2(m["width"] / 2.0 + 2.0, J["R"]))
            excl.append((ang - half_ang, ang + half_ang))

        def in_mouth(a):
            for lo, hi in excl:
                d = (a - lo) % 360.0
                if d < (hi - lo) % 360.0 + 1e-9:
                    return True
            return False

        # sample ring; keep wall bearings (depth>1.5, non-mouth)
        sweeps, cur = [], []
        for deg in range(0, 360, 5):
            a = math.radians(deg)
            x = n["x"] + math.cos(a) * (J["R"] + 1.5)
            z = n["z"] + math.sin(a) * (J["R"] + 1.5)
            depth = self.f.height(x, z) - pe
            if depth > 1.5 and not in_mouth(deg):
                cur.append((x, z, pe, self.f.height(x, z), float(deg)))
            elif cur:
                sweeps.append(cur)
                cur = []
        if cur:
            sweeps.append(cur)
        if sweeps and len(sweeps) > 1:
            # merge wrap-around run
            if sweeps[0][0][4] == 0.0 and sweeps[-1][-1][4] == 355.0:
                sweeps = [sweeps[-1] + sweeps[0]] + sweeps[1:-1]
        made = 0
        for run in sweeps:
            L = sum(math.hypot(run[k + 1][0] - run[k][0],
                               run[k + 1][2] - run[k][2])
                    for k in range(len(run) - 1))
            if L < 5.0 or len(run) < 2:
                continue
            wid = "ST-RW-%s-%d" % (nid, made)
            self._wall_run(wid, None, None, run, "retaining_wall", ci,
                           node=nid, access=self.r["nodes"][nid]["access"])
            made += 1
        self.retaining["dispositions"].append(
            {"cut_id": ci, "source": {"node": nid},
             "decision": "mixed" if made else "natural_slope",
             "reason": "%d wall arc(s), remainder natural slope" % made
                       if made else "no non-mouth arc with depth>1.5",
             "max_depth": q6(cut["max_depth"]),
             "ground": "mixed" if made else "soil"})

    def _wall_run(self, wid, eid, E, pts, cls, ci, node=None, access="PUBLIC"):
        sc = self.sc["retaining_rules"]
        mp = MeshPart(wid, cls, node or eid,
                      {"structure": wid, "material": "concrete",
                       "access": access, "cut_id": ci,
                       "foundation": "classified_burial"})
        ring = []
        hmax = 0.0
        for x, z, sy, terr, dd in pts:
            base = sy - sc["wall_base_burial_m"]
            top = terr + sc["top_freeboard_m"]
            hmax = max(hmax, top - base)
            ring.append((mp.vert(x, base, z), mp.vert(x, top, z)))
        # face toward road: per-seg terrain probe votes, majority wins, all
        # quads share one winding (no flip-flop on noisy segments)
        segs = []
        for k in range(len(ring) - 1):
            (b0, t0), (b1, t1) = ring[k], ring[k + 1]
            A, B = mp.verts[b0], mp.verts[b1]
            dx, dz = B[0] - A[0], B[2] - A[2]
            L = math.hypot(dx, dz) or 1.0
            px, pz = dz / L, -dx / L
            mx, mz = (A[0] + B[0]) / 2.0, (A[2] + B[2]) / 2.0
            t_plus = self.f.height(mx + px * 3.0, mz + pz * 3.0)
            t_minus = self.f.height(mx - px * 3.0, mz - pz * 3.0)
            inw = (-px, 0.0, -pz) if t_plus > t_minus else (px, 0.0, pz)
            segs.append((b0, b1, t1, t0, inw))
        votes = 0
        for (b0, b1, t1, t0, inw) in segs:
            nn = mp._normal_of(b0, b1, t1)
            votes += 1 if nn[0] * inw[0] + nn[2] * inw[2] >= 0 else -1
        for (b0, b1, t1, t0, _inw) in segs:
            if votes >= 0:
                mp.quad(b0, b1, t1, t0)
            else:
                mp.quad(b0, t0, t1, b1)
        mp.fix_normals()
        self.retaining_mesh.append(mp.export())
        rec = self._comp_rec(wid, cls, mp, eid or ("node:" + node), access)
        rec["cut_id"] = ci
        rec["height_max"] = q6(hmax)
        rec["length"] = q6(sum(
            math.hypot(pts[k + 1][0] - pts[k][0], pts[k + 1][1] - pts[k][1])
            for k in range(len(pts) - 1)))
        rec["drainage"] = "french_drain" if hmax > 3.0 else "weep_holes"
        rec["streaming"]["source"] = ("ribbon-" + eid) if eid else \
            ("platform-" + node if "platform-" + node in self.parts
             else "ring-" + node)
        self.retaining["walls"].append(rec)
        self.retaining["dispositions"].append(
            {"cut_id": ci, "source": ({"edge": eid} if eid else {"node": node}),
             "decision": "retaining_wall", "reason": "measured depth>=1.0",
             "structure_ref": wid, "height_max": q6(hmax)})

    def _retained_lip_treatments(self):
        # retained lips are steps ON the drivable platform: no wall (would
        # block legal turns). Treatment: hazard marker + hatch marking
        # (marking phase) + reservation. Recorded per lip tri.
        self.retaining["lip_treatments"] = []
        for l in self.g["lips"]:
            if l["class"] != "retained":
                continue
            p = self.parts[l["part"]]
            vs = [p["verts"][i] for i in l["tri"]]
            cx = sum(v[0] for v in vs) / 3.0
            cy = sum(v[1] for v in vs) / 3.0
            cz = sum(v[2] for v in vs) / 3.0
            self.retaining["lip_treatments"].append(
                {"lip": {"part": l["part"], "tri": l["tri"]},
                 "treatment": "hazard_marker_plus_hatch",
                 "pos": [q6(cx), q6(cy), q6(cz)],
                 "height": l["height"],
                 "reason": "platform step: wall would block legal movement"})

    # ================= BARRIERS =================
    def phase_barriers(self):
        self._t("barriers")
        self.barriers = {"runs": [], "delineators": [], "hazard_markers": [],
                         "bollards": []}
        self.barrier_mesh = []
        br = self.sc["barrier_rules"]
        for eid in sorted(self.g["edges"]):
            self._edge_barriers(eid, br)
        self._hazard_markers(br)
        self._bollards(br)
        self._t(None)

    def _offset_polyline(self, eid, d0, d1, offset, step=5.0):
        st = self.edge_stations(eid)
        pts = []
        d = d0
        while d < d1 + 1e-9:
            dd = min(d, d1)
            seg = None
            for i in range(len(st) - 1):
                if st[i]["d"] - 1e-9 <= dd <= st[i + 1]["d"] + 1e-9:
                    seg = i
                    break
            if seg is None:
                break
            a, b = st[seg], st[seg + 1]
            f = 0.0 if b["d"] == a["d"] else (dd - a["d"]) / (b["d"] - a["d"])
            x = a["x"] + (b["x"] - a["x"]) * f
            z = a["z"] + (b["z"] - a["z"]) * f
            n = (a["tz"], -a["tx"])
            px, pz = x + n[0] * offset, z + n[1] * offset
            inw = (-n[0] * (1.0 if offset > 0 else -1.0),
                   -n[1] * (1.0 if offset > 0 else -1.0))
            pts.append((px, pz, self.f.height(px, pz), dd, inw[0], inw[1]))
            if dd >= d1 - 1e-9:
                break
            d += step
        return pts

    def _curve_radius(self, st, i):
        if i < 1 or i > len(st) - 2:
            return 1e9
        a, b, c = st[i - 1], st[i], st[i + 1]
        ab = math.hypot(b["x"] - a["x"], b["z"] - a["z"])
        bc = math.hypot(c["x"] - b["x"], c["z"] - b["z"])
        ca = math.hypot(a["x"] - c["x"], a["z"] - c["z"])
        area = abs((b["x"] - a["x"]) * (c["z"] - a["z"]) -
                   (c["x"] - a["x"]) * (b["z"] - a["z"])) / 2.0
        if area < 1e-9:
            return 1e9
        return ab * bc * ca / (4.0 * area)

    def _edge_barriers(self, eid, br):
        E = self.g["edges"][eid]
        st = self.edge_stations(eid)
        half = E["width_m"] / 2.0
        d_lo = st[0]["d"] + 2.0
        d_hi = st[-1]["d"] - 2.0
        if d_hi - d_lo < 8.0:
            return
        risk = br["risk"]
        # per-side risk flags per station pair
        for side, sgn in (("L", -1.0), ("R", 1.0)):
            flags = []
            for i in range(len(st) - 1):
                a, b = st[i], st[i + 1]
                mid = (a["d"] + b["d"]) / 2.0
                if mid < d_lo or mid > d_hi:
                    flags.append(None)
                    continue
                if a["structure"] == "TUNNEL" or b["structure"] == "TUNNEL":
                    flags.append(None)  # lining owns the bore
                    continue
                if a["structure"] == "BRIDGE" or b["structure"] == "BRIDGE":
                    flags.append(None)  # parapet owns the wet span
                    continue
                n = (a["tz"], -a["tx"])
                ex = a["x"] + n[0] * sgn * half
                ez = a["z"] + n[1] * sgn * half
                ey = self.surf_y_at(eid, i, sgn * half)[0]
                t_near = self.f.height(a["x"] + n[0] * sgn * (half + 1.0),
                                       a["z"] + n[1] * sgn * (half + 1.0))
                t_far = self.f.height(a["x"] + n[0] * sgn * (half + 6.0),
                                      a["z"] + n[1] * sgn * (half + 6.0))
                R = self._curve_radius(st, i)
                kind = None
                struct = a.get("struct_ref") or ""
                if struct.startswith("portal"):
                    kind = "low_curb"
                elif struct.startswith("BC-") or "appr" in struct:
                    if ey - t_near > 1.5:
                        kind = "concrete_barrier"
                    elif ey - t_near > risk["embankment_height_m"] or \
                            ey - t_far > risk["cliff_drop_m"]:
                        kind = "guardrail"
                else:
                    if ey - t_far > risk["cliff_drop_m"] or \
                       ey - t_near > risk["embankment_height_m"]:
                        kind = "guardrail"
                    elif R < risk["curve_radius_m"] and \
                            E["class"] in ("primary", "secondary"):
                        # outer side only: turn center side test
                        c = st[i + 1]
                        cross = (b["x"] - a["x"]) * (c["z"] - b["z"]) - \
                            (b["z"] - a["z"]) * (c["x"] - b["x"])
                        # lateral n=(tz,-tx): outer side sign vs cross
                        if (cross > 0 and sgn < 0) or (cross < 0 and sgn > 0):
                            kind = "guardrail"
                flags.append(kind)
            # merge into runs (bridge gaps < min_unprotected_edge_m)
            runs, cur = [], None
            gap = 0.0
            for i, k in enumerate(flags):
                if k is None:
                    if cur is not None:
                        gap += st[i + 1]["d"] - st[i]["d"]
                        if gap >= risk["min_unprotected_edge_m"]:
                            runs.append(cur)
                            cur = None
                            gap = 0.0
                    continue
                if cur is None:
                    cur = {"kind": k, "i0": i, "i1": i}
                elif cur["kind"] == k:
                    cur["i1"] = i
                    gap = 0.0
                else:
                    runs.append(cur)
                    cur = {"kind": k, "i0": i, "i1": i}
                gap = 0.0
            if cur is not None:
                runs.append(cur)
            for r in runs:
                d0 = st[r["i0"]]["d"]
                d1 = st[r["i1"] + 1]["d"]
                if d1 - d0 < 8.0:
                    continue
                self._barrier_run(eid, E, side, sgn, r["kind"],
                                  max(d0, d_lo), min(d1, d_hi), br)
            self._delineators(eid, E, side, sgn, d_lo, d_hi, br)

    def _barrier_run(self, eid, E, side, sgn, kind, d0, d1, br):
        half = E["width_m"] / 2.0
        off = sgn * (half + 0.6)
        pts = self._offset_polyline(eid, d0, d1, off)
        if len(pts) < 2:
            return
        rid = "ST-BAR-%s-%s-%d" % (eid, side, len(
            [r for r in self.barriers["runs"] if r["edge"] == eid]))
        if kind == "guardrail":
            cls, mat = "guardrail", br["guardrail"]["material"]
            mp = MeshPart(rid, cls, eid,
                          {"structure": rid, "edge": eid, "material": mat,
                           "access": E["access"]})
            self._guardrail_mesh(mp, pts, br)
        elif kind == "concrete_barrier":
            cls, mat = "concrete_barrier", "concrete"
            mp = MeshPart(rid, cls, eid,
                          {"structure": rid, "edge": eid, "material": mat,
                           "access": E["access"]})
            self._concrete_mesh(mp, pts, br)
        else:
            cls, mat = "low_curb", "concrete"
            mp = MeshPart(rid, cls, eid,
                          {"structure": rid, "edge": eid, "material": mat,
                           "access": E["access"]})
            self._curb_mesh(mp, pts, br)
        self.barrier_mesh.append(mp.export())
        self.barriers["runs"].append(
            {"id": rid, "class": cls, "edge": eid, "side": side,
             "d0": q6(d0), "d1": q6(d1), "offset": q6(off),
             "material": mat, "access": E["access"],
             "sectors": self._sectors_of_verts(mp.verts),
             "verts": len(mp.verts), "tris": len(mp.tris),
             "streaming": {"order": ["ROAD_EDGE", "STRUCTURE", "DETAILS"],
                           "source": "ribbon-" + eid}})

    def _guardrail_mesh(self, mp, pts, br):
        gh = br["guardrail"]["height_m"]
        ring = []
        for x, z, gy, _, _, _ in pts:
            f0 = mp.vert(x, gy + 0.45, z)
            f1 = mp.vert(x, gy + gh, z)
            ring.append((f0, f1))
        for k in range(len(ring) - 1):
            f0, f1 = ring[k]
            g0, g1 = ring[k + 1]
            inw = (pts[k][4], 0.0, pts[k][5])
            mp.quad_out(f0, g0, g1, f1, inw)
        # posts every 4 m (deterministic chainage)
        post_at = 0.0
        acc = 0.0
        for k in range(len(pts) - 1):
            x0, z0, gy0, _, _, _ = pts[k]
            x1, z1, gy1, _, _, _ = pts[k + 1]
            seg = math.hypot(x1 - x0, z1 - z0)
            while post_at <= acc + seg:
                f = 0.0 if seg == 0 else (post_at - acc) / seg
                px = x0 + (x1 - x0) * f
                pz = z0 + (z1 - z0) * f
                gy = gy0 + (gy1 - gy0) * f
                self._post_box(mp, px, pz, gy, 0.15, gh)
                post_at += br["guardrail"]["post_spacing_m"]
            acc += seg
        mp.fix_normals()

    def _post_box(self, mp, x, z, gy, w, h):
        # per-face verts (flat normals on hard edges; no shared corners)
        x0, x1, z0, z1, y0, y1 = x - w / 2, x + w / 2, z - w / 2, z + w / 2, gy, gy + h
        faces = [([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)],
                  (0.0, 0.0, -1.0)),
                 ([(x1, y0, z1), (x0, y0, z1), (x0, y1, z1), (x1, y1, z1)],
                  (0.0, 0.0, 1.0)),
                 ([(x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)],
                  (1.0, 0.0, 0.0)),
                 ([(x0, y0, z1), (x0, y0, z0), (x0, y1, z0), (x0, y1, z1)],
                  (-1.0, 0.0, 0.0)),
                 ([(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)],
                  (0.0, 1.0, 0.0))]
        for corners, out in faces:
            vs = [mp.vert(px, py, pz) for px, py, pz in corners]
            mp.quad_out(vs[0], vs[1], vs[2], vs[3], out)

    def _section_frames(self, pts):
        # per-station plan perp of local travel, unflipped (stable sections)
        frames = []
        prev = None
        for k, (x, z, gy, _dd, _ix, _iz) in enumerate(pts):
            a = pts[max(0, k - 1)]
            b = pts[min(len(pts) - 1, k + 1)]
            dx, dz = b[0] - a[0], b[1] - a[1]
            L = math.hypot(dx, dz) or 1.0
            px, pz = dz / L, -dx / L
            if prev is not None and px * prev[0] + pz * prev[1] < 0:
                px, pz = -px, -pz
            prev = (px, pz)
            frames.append((x, z, gy, px, pz))
        return frames

    def _box_run_mesh(self, mp, pts, w, h):
        # rectangular-section run along travel-perp sections; sides face
        # outward, cap uses dedicated verts (flat normals throughout)
        frames = self._section_frames(pts)
        ring = []
        for x, z, gy, px, pz in frames:
            ring.append((mp.vert(x - px * w / 2, gy, z - pz * w / 2),
                         mp.vert(x + px * w / 2, gy, z + pz * w / 2),
                         mp.vert(x + px * w / 2, gy + h, z + pz * w / 2),
                         mp.vert(x - px * w / 2, gy + h, z - pz * w / 2)))
        for k in range(len(ring) - 1):
            a0, a1, a2, a3 = ring[k]
            b0, b1, b2, b3 = ring[k + 1]
            out = (frames[k][3], 0.0, frames[k][4])
            mp.quad_out(a0, b0, b3, a3, (-out[0], 0.0, -out[2]))
            mp.quad_out(a1, a2, b2, b1, out)
        cap = []
        for (_a0, _a1, a2, a3) in ring:
            T, U = mp.verts[a2], mp.verts[a3]
            cap.append((mp.vert(T[0], T[1], T[2]),
                        mp.vert(U[0], U[1], U[2])))
        for k in range(len(cap) - 1):
            r0, l0 = cap[k]
            r1, l1 = cap[k + 1]
            mp.quad_up_either(l0, l1, r1, r0)
        mp.fix_normals()

    def _concrete_mesh(self, mp, pts, br):
        self._box_run_mesh(mp, pts, br["concrete_barrier"]["width_m"],
                           br["concrete_barrier"]["height_m"])

    def _curb_mesh(self, mp, pts, br):
        self._box_run_mesh(mp, pts, br["low_curb"]["width_m"]
                           if "width_m" in br["low_curb"] else 0.3,
                           br["low_curb"]["height_m"])

    def _delineators(self, eid, E, side, sgn, d_lo, d_hi, br):
        # sparse: curves (R<150), highland region, or within 60 m of a
        # bridge/tunnel approach. Never a blanket run.
        st = self.edge_stations(eid)
        half = E["width_m"] / 2.0
        near_struct = False
        for b in self.g["bridges"].values():
            if b["edge"] == eid:
                near_struct = True
        if self.g["tunnel"]["edge"] == eid:
            near_struct = True
        d = math.ceil(d_lo / br["delineator_spacing_m"]) * \
            br["delineator_spacing_m"]
        while d < d_hi:
            seg = None
            for i in range(len(st) - 1):
                if st[i]["d"] <= d <= st[i + 1]["d"]:
                    seg = i
                    break
            if seg is not None:
                a, b = st[seg], st[seg + 1]
                f = 0.0 if b["d"] == a["d"] else (d - a["d"]) / (b["d"] - a["d"])
                if a["structure"] not in ("TUNNEL", "BRIDGE"):
                    R = self._curve_radius(st, seg)
                    high = "highland" in a["region"]
                    appr = bool(a.get("struct_ref"))
                    if R < 150.0 or high or (near_struct and appr):
                        n = (a["tz"], -a["tx"])
                        x = a["x"] + (b["x"] - a["x"]) * f + n[0] * sgn * (half + 1.0)
                        z = a["z"] + (b["z"] - a["z"]) * f + n[1] * sgn * (half + 1.0)
                        self.barriers["delineators"].append(
                            {"id": "ST-DEL-%s-%s-%d" % (eid, side, int(d)),
                             "edge": eid, "side": side, "d": q6(d),
                             "pos": [q6(x), q6(self.f.height(x, z)), q6(z)],
                             "reason": ("curve_R%.0f" % R) if R < 150.0
                             else ("highland" if high else "approach"),
                             "sector": sector_of(x, z)})
            d += br["delineator_spacing_m"]

    def _hazard_markers(self, br):
        recs = []
        # retained lips (platform steps)
        for lt in self.retaining["lip_treatments"]:
            recs.append((lt["pos"][0], lt["pos"][2], "retained_lip"))
        # bridge ends (both sides, both ends)
        for bid, b in sorted(self.g["bridges"].items()):
            st = self.edge_stations(b["edge"])
            E = self.g["edges"][b["edge"]]
            half = E["width_m"] / 2.0
            for dd in (b["wet0"], b["wet1"]):
                seg = next(i for i in range(len(st) - 1)
                           if st[i]["d"] <= dd <= st[i + 1]["d"] + 1e-9)
                a = st[seg]
                n = (a["tz"], -a["tx"])
                for sgn in (-1.0, 1.0):
                    recs.append((a["x"] + n[0] * sgn * (half + 1.0),
                                 a["z"] + n[1] * sgn * (half + 1.0),
                                 "bridge_end"))
        # tunnel portals (both sides, both ends of bore)
        eid = self.g["tunnel"]["edge"]
        E = self.g["edges"][eid]
        half = E["width_m"] / 2.0
        st = self.edge_stations(eid)
        bore = [i for i, p in enumerate(st) if p["structure"] == "TUNNEL"]
        for bi in (bore[0], bore[-1]):
            a = st[bi]
            n = (a["tz"], -a["tx"])
            for sgn in (-1.0, 1.0):
                recs.append((a["x"] + n[0] * sgn * (half + 2.0),
                             a["z"] + n[1] * sgn * (half + 2.0), "portal"))
        mp = MeshPart("ST-hazard-markers", "hazard_marker", "world",
                      {"structure": "ST-hazard-markers", "material": "steel_galvanized",
                       "access": "PUBLIC"})
        for k, (x, z, why) in enumerate(sorted(recs)):
            gy = self.f.height(x, z)
            self._post_box(mp, x, z, gy, 0.2, 1.0)
            self.barriers["hazard_markers"].append(
                {"id": "ST-HAZ-%d" % k,
                 "pos": [q6(x), q6(gy), q6(z)], "reason": why,
                 "sector": sector_of(x, z)})
        mp.fix_normals()
        self.barrier_mesh.append(mp.export())

    def _bollards(self, br):
        # gate_restricted spur entry flanks + tunnel walkway ends.
        # Off-road (beyond shoulder), never blocking legal movement.
        recs = []
        for eid in ("E_spur_restricted_access_00",):
            E = self.g["edges"][eid]
            half = E["width_m"] / 2.0
            st = self.edge_stations(eid)
            for si in (0, -1):
                a = st[si]
                n = (a["tz"], -a["tx"])
                for sgn in (-1.0, 1.0):
                    recs.append((a["x"] + n[0] * sgn * (half + 1.2),
                                 a["z"] + n[1] * sgn * (half + 1.2),
                                 "restricted_entry", E["access"]))
        eid = self.g["tunnel"]["edge"]
        E = self.g["edges"][eid]
        half = E["width_m"] / 2.0
        st = self.edge_stations(eid)
        bore = [i for i, p in enumerate(st) if p["structure"] == "TUNNEL"]
        for bi, inward in ((bore[0], 1.0), (bore[-1], -1.0)):
            a = st[bi]
            dd = a["d"] + inward * 3.0
            seg = self._seg_at(eid, dd)
            p, q = st[seg], st[seg + 1]
            f = (dd - p["d"]) / (q["d"] - p["d"])
            cx = p["x"] + (q["x"] - p["x"]) * f
            cz = p["z"] + (q["z"] - p["z"]) * f
            n = (p["tz"], -p["tx"])
            for sgn in (-1.0, 1.0):
                x = cx + n[0] * sgn * (half - 0.6)
                z = cz + n[1] * sgn * (half - 0.6)
                sy = self.surf_y_at(eid, seg, sgn * (half - 0.6))[0]
                recs.append((x, z, "portal_walkway", E["access"], sy + 0.02))
        mp = MeshPart("ST-bollards", "bollard", "world",
                      {"structure": "ST-bollards", "material": "steel_galvanized",
                       "access": "PUBLIC"})
        for k, rec in enumerate(sorted(recs)):
            x, z, why, acc = rec[:4]
            gy = rec[4] if len(rec) > 4 else self.f.height(x, z)
            self._post_box(mp, x, z, gy, 0.25, 0.9)
            self.barriers["bollards"].append(
                {"id": "ST-BOL-%d" % k, "pos": [q6(x), q6(gy), q6(z)],
                 "reason": why, "access": acc, "sector": sector_of(x, z)})
        mp.fix_normals()
        self.barrier_mesh.append(mp.export())

    # ================= MARKINGS =================
    def phase_markings(self):
        self._t("markings")
        from road_geometry import ProfileRegistry
        self.prof = ProfileRegistry(self.gc)
        self.markings = {"records": [], "skipped": [], "not_applicable": []}
        self.marking_mesh = []
        for eid in sorted(self.g["edges"]):
            self._edge_markings(eid)
        for nid in sorted(self.g["junctions"]):
            self._junction_markings(nid)
        for cid in sorted(self.g["connectors"]):
            c = self.g["connectors"][cid]
            if c["junction"] is None:
                self.markings["skipped"].append(
                    {"connector": cid,
                     "reason": "junction-None transition: continuity covered "
                               "by edge lines"})
        self._roundabout_markings()
        self._gore_hatches()
        self.markings["not_applicable"].append(
            {"class": "crosswalk", "reason": "no pedestrian network in "
             "P03/P04; future owner: pedestrian prompt"})
        self._t(None)

    def _lane_geom(self, cls, width):
        var = self.prof.classes[cls]["variants"]["w%d" % int(round(width))]
        return (var["lanes"], var["lane_width_m"], var["median_width_m"])

    def _strip_part(self, pid, ref, sem_extra):
        sem = {"marking_part": pid, "material": "asphalt_marking_white",
               "access": "PUBLIC"}
        sem.update(sem_extra)
        return MeshPart(pid, "marking", ref, sem)

    def _strip_run(self, mp, line, width, lift, closed=False):
        """Emit flat strip over polyline [(x,y,z)...] with perp expansion.
        Frames propagate unflipped (no twist through curls); closed loops
        wrap to the first point."""
        pts = list(line)
        if closed and len(pts) > 2:
            pts = pts + [pts[0]]
        n = len(pts)
        if n < 2:
            return None
        # forward-difference directions, perp unflipped vs previous frame
        perps = []
        for k in range(n):
            a = pts[k]
            b = pts[min(n - 1, k + 1)] if k < n - 1 else pts[k - 1]
            if k == n - 1 and not closed:
                a, b = pts[k - 1], pts[k]
            dx, dz = b[0] - a[0], b[2] - a[2]
            L = math.hypot(dx, dz)
            if L < 1e-9:
                perps.append(perps[-1] if perps else (1.0, 0.0))
                continue
            px, pz = dz / L, -dx / L
            if perps and px * perps[-1][0] + pz * perps[-1][1] < 0:
                px, pz = -px, -pz
            perps.append((px, pz))
        start = len(mp.tris)
        ring = []
        for (x, y, z), (px, pz) in zip(pts, perps):
            ring.append((mp.vert(x - px * width / 2.0, y + lift,
                                 z - pz * width / 2.0),
                         mp.vert(x + px * width / 2.0, y + lift,
                                 z + pz * width / 2.0)))
        for k in range(n - 1):
            a0, a1 = ring[k]
            b0, b1 = ring[k + 1]
            # skip zero-length joints (duplicate points)
            A, B = mp.verts[a0], mp.verts[b0]
            if math.hypot(B[0] - A[0], B[2] - A[2]) < 1e-9:
                continue
            mp.tri_up_either(a0, b0, b1)
            mp.tri_up_either(a0, b1, a1)
        if start == len(mp.tris):
            return None
        return (start, len(mp.tris))

    def _split_sectors(self, pts):
        runs, cur, cs = [], [], None
        for p in pts:
            s = sector_of(p[0], p[2])
            if cs is None:
                cs = s
            if s != cs:
                runs.append((cs, cur))
                cur, cs = [p], s
            else:
                cur.append(p)
        if cur:
            runs.append((cs, cur))
        # drop degenerate single-point runs by merging into neighbor
        out = []
        for s, r in runs:
            if len(r) < 2 and out:
                out[-1][1].extend(r)
            elif len(r) < 2:
                continue
            else:
                out.append([s, r])
        return [(s, r) for s, r in out if len(r) >= 2]

    def _edge_markings(self, eid):
        E = self.g["edges"][eid]
        mr = self.sc["marking_rules"]
        lanes, lw, med = self._lane_geom(E["class"], E["width_m"])
        half = E["width_m"] / 2.0
        trav = med / 2.0 + (lanes / 2.0) * lw
        lines = []  # (offset, cls, color, dashed)
        lines.append((-(trav - 0.3), "edge", "white", False))
        lines.append(((trav - 0.3), "edge", "white", False))
        if med > 0:
            for k in range(1, lanes // 2):
                lines.append((-(med / 2.0 + k * lw), "lane", "white", True))
                lines.append(((med / 2.0 + k * lw), "lane", "white", True))
            lines.append((-(med / 2.0 + 0.15), "edge", "white", False))
            lines.append(((med / 2.0 + 0.15), "edge", "white", False))
        else:
            if lanes == 2:
                lines.append((0.0, "centerline", "yellow", True))
            else:
                for k in range(1, lanes // 2):
                    lines.append((-(k * lw), "lane", "white", True))
                    lines.append(((k * lw), "lane", "white", True))
        st = self.edge_stations(eid)
        mp = self._strip_part("MK-%s" % eid, eid,
                              {"edge": eid, "access": E["access"]})
        for off, cls, color, dashed in lines:
            if abs(off) > half - 0.1:
                continue
            full = []
            for i, p in enumerate(st):
                y, x, z = self.surf_y_at(eid, i, off)
                full.append((x, y, z, p["d"]))
            if dashed:
                cyc, dl = 12.0, 3.0
                segs, cur, d00 = [], [], full[0][3]
                for pt in full:
                    ph = (pt[3] - d00) % cyc
                    if ph < dl:
                        cur.append(pt[:3])
                    elif cur:
                        segs.append(cur)
                        cur = []
                if cur:
                    segs.append(cur)
            else:
                segs = [[pt[:3] for pt in full]]
            frags = []
            for seg in segs:
                for s, run in self._split_sectors(seg):
                    tr = self._strip_run(mp, run, mr["widths"][cls + "_m"]
                                         if cls + "_m" in mr["widths"]
                                         else 0.15, mr["lift_above_surface_m"])
                    if tr is not None:
                        frags.append({"sector": s, "tris": list(tr)})
            self.markings["records"].append(
                {"id": "MK-%s-%s-%s" % (eid, cls,
                                       ("C" if off == 0 else
                                        ("L%d" % abs(off) if off < 0
                                         else "R%d" % abs(off)))),
                 "class": cls, "color": color, "dashed": dashed,
                 "source": {"edge": eid}, "offset": q6(off),
                 "part": mp.id, "fragments": frags,
                 "wear_state": "fresh", "access": E["access"]})
        if mp.tris:
            self.marking_mesh.append(mp.export())

    def _junction_markings(self, nid):
        J = self.g["junctions"][nid]
        mr = self.sc["marking_rules"]
        mp = self._strip_part("MK-CN-%s" % nid, nid,
                              {"junction": nid,
                               "access": self.r["nodes"][nid]["access"]})
        for cid in sorted(self.g["connectors"]):
            c = self.g["connectors"][cid]
            if c["junction"] != nid:
                continue
            if not c["allowed"]:
                self.markings["skipped"].append(
                    {"connector": cid, "reason": "movement not allowed: no "
                     "public-facing marking"})
                continue
            t = c["type"]
            pts = [(p[0], p[1], p[2]) for p in c["pts"]]
            if t in ("BRIDGE_TRANSITION", "TUNNEL_TRANSITION"):
                self.markings["skipped"].append(
                    {"connector": cid,
                     "reason": "continuity covered by edge lines"})
                continue
            if t == "STRAIGHT":
                # guidance only, never an arrow
                frags = []
                for s, run in self._split_sectors(pts):
                    tr = self._strip_run(mp, run, 0.15,
                                         mr["lift_above_surface_m"])
                    if tr is not None:
                        frags.append({"sector": s, "tris": list(tr)})
                self.markings["records"].append(
                    {"id": "MK-%s-guidance" % cid, "class": "guidance",
                     "color": "white", "dashed": True,
                     "source": {"connector": cid, "junction": nid},
                     "part": mp.id, "fragments": frags,
                     "wear_state": "fresh",
                     "access": self.r["nodes"][nid]["access"]})
                continue
            # turns / merges / uturns / roundabout legs: guidance + arrow
            frags = []
            for s, run in self._split_sectors(pts):
                tr = self._strip_run(mp, run, 0.15, mr["lift_above_surface_m"])
                if tr is not None:
                    frags.append({"sector": s, "tris": list(tr)})
            self.markings["records"].append(
                {"id": "MK-%s-guidance" % cid, "class": "guidance",
                 "color": "white", "dashed": True,
                 "source": {"connector": cid, "junction": nid},
                 "part": mp.id, "fragments": frags, "wear_state": "fresh",
                 "access": self.r["nodes"][nid]["access"]})
            if t in ("LEFT", "RIGHT", "SHARP", "UTURN"):
                k = max(1, len(pts) // 4)
                a0 = self._arrow(mp, pts[k - 1], pts[k], mr)
                self.markings["records"].append(
                    {"id": "MK-%s-arrow" % cid, "class": "turn_arrow",
                     "color": "white", "dashed": False,
                     "source": {"connector": cid, "junction": nid,
                                "turn": t},
                     "part": mp.id, "fragments": [{"sector": sector_of(
                         pts[k][0], pts[k][2]), "tris": list(a0)}],
                     "wear_state": "fresh",
                     "access": self.r["nodes"][nid]["access"]})
            if t == "ROUNDABOUT_ENTRY":
                yb = self._yield_bar(mp, pts[0], pts[1], mr)
                self.markings["records"].append(
                    {"id": "MK-%s-yield" % cid, "class": "yield_line",
                     "color": "white", "dashed": True,
                     "source": {"connector": cid, "junction": nid},
                     "part": mp.id, "fragments": [{"sector": sector_of(
                         pts[0][0], pts[0][2]), "tris": list(yb)}],
                     "wear_state": "fresh",
                     "access": self.r["nodes"][nid]["access"]})
        # stop lines at restricted junction mouths only (justified control)
        if self.r["nodes"][nid]["access"] == "RESTRICTED":
            n = self.r["nodes"][nid]
            for m in J["mouths"]:
                E2 = self.g["edges"][m["edge"]]
                st2 = E2["stations"]
                q = st2[-1] if m["side"] == "to" else st2[0]
                lat = (q["tz"], -q["tx"])
                w = E2["width_m"] / 4.0
                p0 = (q["x"] - lat[0] * w, q["road_elev"], q["z"] - lat[1] * w)
                p1 = (q["x"] + lat[0] * w, q["road_elev"], q["z"] + lat[1] * w)
                tr = self._strip_run(mp, [p0, p1], mr["stop_line_width_m"],
                                     mr["lift_above_surface_m"])
                if tr is not None:
                    self.markings["records"].append(
                        {"id": "MK-%s-stop-%s" % (nid, m["edge"]),
                         "class": "stop_line", "color": "white",
                         "dashed": False,
                         "source": {"junction": nid, "edge": m["edge"]},
                         "part": mp.id, "fragments": [
                             {"sector": sector_of(q["x"], q["z"]),
                              "tris": list(tr)}],
                         "wear_state": "fresh", "access": "RESTRICTED"})
        if mp.tris:
            self.marking_mesh.append(mp.export())

    def _arrow(self, mp, p0, p1, mr):
        dx, dz = p1[0] - p0[0], p1[2] - p0[2]
        L = math.hypot(dx, dz) or 1.0
        ux, uz = dx / L, dz / L
        px, pz = uz, -ux
        y = p1[1] + mr["lift_above_surface_m"]
        cx, cz = p1[0], p1[2]
        s = [(cx - ux * 2.4 + px * 0.15, cz - uz * 2.4 + pz * 0.15),
             (cx - ux * 2.4 - px * 0.15, cz - uz * 2.4 - pz * 0.15),
             (cx - ux * 0.9 - px * 0.15, cz - uz * 0.9 - pz * 0.15),
             (cx - ux * 0.9 - px * 0.6, cz - uz * 0.9 - pz * 0.6),
             (cx + ux * 0.6, cz + uz * 0.6),
             (cx - ux * 0.9 + px * 0.6, cz - uz * 0.9 + pz * 0.6),
             (cx - ux * 0.9 + px * 0.15, cz - uz * 0.9 + pz * 0.15)]
        start = len(mp.tris)
        vs = [mp.vert(x, y, z) for x, z in s]
        mp.quad_up_either(vs[0], vs[1], vs[2], vs[6])
        mp.tri_up_either(vs[2], vs[6], vs[4])
        mp.tri_up_either(vs[6], vs[5], vs[4])
        mp.tri_up_either(vs[2], vs[4], vs[3])
        return (start, len(mp.tris))

    def _yield_bar(self, mp, p0, p1, mr):
        dx, dz = p1[0] - p0[0], p1[2] - p0[2]
        L = math.hypot(dx, dz) or 1.0
        px, pz = dz / L, -dx / L
        w = 1.75
        a = (p0[0] - px * w, p0[1], p0[2] - pz * w)
        b = (p0[0] + px * w, p0[1], p0[2] + pz * w)
        start = len(mp.tris)
        # dashed yield: 3 blocks with gaps
        for f0, f1 in ((0.0, 0.25), (0.375, 0.625), (0.75, 1.0)):
            q0 = (a[0] + (b[0] - a[0]) * f0, a[1], a[2] + (b[2] - a[2]) * f0)
            q1 = (a[0] + (b[0] - a[0]) * f1, a[1], a[2] + (b[2] - a[2]) * f1)
            self._strip_run(mp, [q0, q1], 0.3, mr["lift_above_surface_m"])
        return (start, len(mp.tris))

    def _roundabout_markings(self):
        nid = self.g["roundabout"]["node"]
        n = self.r["nodes"][nid]
        rb = self.gc["roundabout"]
        mr = self.sc["marking_rules"]
        mp = self._strip_part("MK-roundabout", nid,
                              {"junction": nid, "access": "PUBLIC"})
        E_avg = self.g["roundabout"]["E_avg"]
        # circulating dashed lane circle at ring mid radius
        Rmid = float(rb["ring_centerline_R_m"])
        circ = []
        for k in range(72):
            a = math.pi * 2.0 * k / 72.0
            circ.append((n["x"] + math.cos(a) * Rmid, E_avg,
                         n["z"] + math.sin(a) * Rmid))
        # dashed: keep 3/12 pattern along the circle
        segs, cur = [], []
        per = len(circ) / 12.0
        for k, pt in enumerate(circ):
            if (k % 12) < 3:
                cur.append(pt)
            elif cur:
                segs.append(cur)
                cur = []
        if cur:
            segs.append(cur)
        frags = []
        for seg in segs:
            if len(seg) < 2:
                continue
            for s, run in self._split_sectors(seg):
                tr = self._strip_run(mp, run, 0.15, mr["lift_above_surface_m"])
                if tr is not None:
                    frags.append({"sector": s, "tris": list(tr)})
        self.markings["records"].append(
            {"id": "MK-roundabout-circulating", "class": "guidance",
             "color": "white", "dashed": True,
             "source": {"junction": nid, "roundabout": True},
             "part": mp.id, "fragments": frags, "wear_state": "fresh",
             "access": "PUBLIC"})
        # island edge ring (solid)
        Ri = float(rb["island_R_m"]) + 0.3
        ring = [(n["x"] + math.cos(math.pi * 2.0 * k / 72.0) * Ri, E_avg,
                 n["z"] + math.sin(math.pi * 2.0 * k / 72.0) * Ri)
                for k in range(72)]
        frags = []
        for s, run in self._split_sectors(ring):
            tr = self._strip_run(mp, run, 0.15, mr["lift_above_surface_m"],
                                 closed=(len(run) == len(ring)))
            if tr is not None:
                frags.append({"sector": s, "tris": list(tr)})
        self.markings["records"].append(
            {"id": "MK-roundabout-island-ring", "class": "island_ring",
             "color": "yellow", "dashed": False,
             "source": {"junction": nid, "roundabout": True},
             "part": mp.id, "fragments": frags, "wear_state": "fresh",
             "access": "PUBLIC"})
        if mp.tris:
            self.marking_mesh.append(mp.export())

    def _gore_hatches(self):
        mr = self.sc["marking_rules"]
        for pid, p in sorted(self.parts.items()):
            if p["kind"] != "gore":
                continue
            nid = p["ref"]
            mp = self._strip_part("MK-hatch-%s" % nid, nid,
                                  {"junction": nid, "gore": pid,
                                   "access": p["semantic"].get("access",
                                                               "PUBLIC")})
            xs = [v[0] for v in p["verts"]]
            ys = [v[1] for v in p["verts"]]
            zs = [v[2] for v in p["verts"]]
            x0, x1 = min(xs), max(xs)
            z0, z1 = min(zs), max(zs)
            y = max(ys) + 0.02
            # border + diagonal bars every 1 m across the nose bbox
            bars = [[(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1),
                     (x0, y, z0)]]
            d = -((x1 - x0) + (z1 - z0))
            while d < (x1 - x0) + (z1 - z0):
                bars.append([(x0 + d, y, z0), (x0 + d + (z1 - z0), y, z1)])
                d += 1.0
            start = len(mp.tris)
            for bar in bars:
                clip = [(max(x0, min(x1, x)), y, max(z0, min(z1, z)))
                        for x, y, z in bar]
                if len(clip) >= 2:
                    self._strip_run(mp, clip, 0.15, 0.0)
            self.markings["records"].append(
                {"id": "MK-hatch-%s" % nid, "class": "hatched_exclusion",
                 "color": "white", "dashed": False,
                 "source": {"junction": nid, "gore": pid},
                 "part": mp.id, "fragments": [
                     {"sector": sector_of((x0 + x1) / 2, (z0 + z1) / 2),
                      "tris": [start, len(mp.tris)]}],
                 "wear_state": "fresh",
                 "access": p["semantic"].get("access", "PUBLIC")})
            if mp.tris:
                self.marking_mesh.append(mp.export())

    # ================= RESERVATIONS =================
    def phase_reservations(self):
        self._t("reservations")
        self.reservations = {"layers": {}, "not_applicable": []}
        L = self.reservations["layers"]
        rr = self.sc["reserverules"]
        L["road_safety"] = []
        for eid in sorted(self.g["edges"]):
            E = self.g["edges"][eid]
            st = self.edge_stations(eid)
            half = E["width_m"] / 2.0
            L["road_safety"].append(
                {"id": "RSV-safe-%s" % eid, "edge": eid,
                 "d0": q6(st[0]["d"]), "d1": q6(st[-1]["d"]),
                 "inner_off": q6(half), "outer_off": q6(half + rr["road_safety_offset_m"])})
        L["junction"] = []
        for nid in sorted(self.g["junctions"]):
            J = self.g["junctions"][nid]
            n = self.r["nodes"][nid]
            L["junction"].append(
                {"id": "RSV-jn-%s" % nid, "node": nid,
                 "x": q6(n["x"]), "z": q6(n["z"]),
                 "R": q6(J["R"] + rr["junction_envelope_margin_m"])})
        L["visibility"] = []
        for nid in sorted(self.g["junctions"]):
            J = self.g["junctions"][nid]
            if len(J["mouths"]) < 2:
                continue
            n = self.r["nodes"][nid]
            for m in J["mouths"]:
                E2 = self.g["edges"][m["edge"]]
                sd = float(self.sc["sight_distance_m"][E2["class"]])
                # eye pulled back along arm from mouth pos
                mx, mz = m["x"], m["z"]
                dx, dz = mx - n["x"], mz - n["z"]
                DL = math.hypot(dx, dz) or 1.0
                ex = mx + dx / DL * sd
                ez = mz + dz / DL * sd
                lat = (-dz / DL * 3.0, dx / DL * 3.0)
                L["visibility"].append(
                    {"id": "RSV-vis-%s-%s" % (nid, m["edge"]),
                     "node": nid, "edge": m["edge"],
                     "class": E2["class"], "sight_m": sd,
                     "tri": [[q6(ex), q6(ez)],
                             [q6(n["x"]), q6(n["z"])],
                             [q6(ex + lat[0]), q6(ez + lat[1])]]})
        L["bridge_exclusion"] = []
        for bid, b in sorted(self.g["bridges"].items()):
            E = self.g["edges"][b["edge"]]
            L["bridge_exclusion"].append(
                {"id": "RSV-br-%s" % bid, "bridge": bid, "edge": b["edge"],
                 "d0": q6(b["appr0"]), "d1": q6(b["appr1"]),
                 "offset": q6(E["width_m"] / 2.0 + rr["bridge_exclusion_offset_m"])})
        L["tunnel_exclusion"] = []
        t = self.g["tunnel"]
        E = self.g["edges"][t["edge"]]
        d0, d1 = self.tunnel["bore_range"]
        L["tunnel_exclusion"].append(
            {"id": "RSV-tn", "edge": t["edge"], "d0": q6(d0 - 60.0),
             "d1": q6(d1 + 60.0),
             "offset": q6(E["width_m"] / 2.0 + rr["tunnel_exclusion_offset_m"])})
        L["retaining_footprint"] = []
        for w in self.retaining["walls"]:
            mp = next(p for p in self.retaining_mesh if p["id"] == w["id"])
            xs = [v[0] for v in mp["verts"]]
            zs = [v[2] for v in mp["verts"]]
            L["retaining_footprint"].append(
                {"id": "RSV-rw-%s" % w["id"], "structure": w["id"],
                 "bbox": [q6(min(xs) - 1.5), q6(min(zs) - 1.5),
                          q6(max(xs) + 1.5), q6(max(zs) + 1.5)]})
        L["sign_anchor"] = []
        self._sign_anchors(L["sign_anchor"])
        L["street_light"] = []
        self._street_lights(L["street_light"])
        L["utility"] = []
        for eid in sorted(self.g["edges"]):
            if self._lit_region(eid):
                E = self.g["edges"][eid]
                st = self.edge_stations(eid)
                L["utility"].append(
                    {"id": "RSV-util-%s" % eid, "edge": eid,
                     "d0": q6(st[0]["d"]), "d1": q6(st[-1]["d"]),
                     "offset": q6(E["width_m"] / 2.0 + rr["utility_offset_m"])})
        L["vegetation_exclusion"] = []
        for eid in sorted(self.g["edges"]):
            E = self.g["edges"][eid]
            st = self.edge_stations(eid)
            half = E["width_m"] / 2.0
            L["vegetation_exclusion"].append(
                {"id": "RSV-veg-%s" % eid, "edge": eid,
                 "d0": q6(st[0]["d"]), "d1": q6(st[-1]["d"]),
                 "offset": q6(half + rr["vegetation_exclusion_offset_m"])})
        L["building_setback"] = []
        for eid in sorted(self.g["edges"]):
            E = self.g["edges"][eid]
            st = self.edge_stations(eid)
            half = E["width_m"] / 2.0
            L["building_setback"].append(
                {"id": "RSV-bset-%s" % eid, "edge": eid, "hard": False,
                 "d0": q6(st[0]["d"]), "d1": q6(st[-1]["d"]),
                 "offset": q6(half + rr["building_setback_m"])})
        L["maintenance"] = []
        for bid, b in sorted(self.g["bridges"].items()):
            st = self.edge_stations(b["edge"])
            for dd in (b["wet0"], b["wet1"]):
                seg = next(i for i in range(len(st) - 1)
                           if st[i]["d"] <= dd <= st[i + 1]["d"] + 1e-9)
                a = st[seg]
                L["maintenance"].append(
                    {"id": "RSV-mnt-%s-%d" % (bid, int(dd)),
                     "source": bid, "x": q6(a["x"]), "z": q6(a["z"]),
                     "R": rr["maintenance_area_m"]})
        eid = self.g["tunnel"]["edge"]
        st = self.edge_stations(eid)
        bore = [i for i, p in enumerate(st) if p["structure"] == "TUNNEL"]
        for bi in (bore[0], bore[-1]):
            a = st[bi]
            L["maintenance"].append(
                {"id": "RSV-mnt-TN-%d" % int(a["d"]), "source": "ST-TN",
                 "x": q6(a["x"]), "z": q6(a["z"]),
                 "R": rr["maintenance_area_m"] + 9.0})
        L["pulloff"] = []
        E = self.g["edges"][eid]
        half = E["width_m"] / 2.0
        for bi in (bore[0], bore[-1]):
            a = st[bi]
            n = (a["tz"], -a["tx"])
            L["pulloff"].append(
                {"id": "RSV-pull-TN-%d" % int(a["d"]),
                 "x": q6(a["x"] + n[0] * (half + 6.0)),
                 "z": q6(a["z"] + n[1] * (half + 6.0)),
                 "size": [12.0, 3.0],
                 "justification": "tunnel portal staging"})
        self.reservations["not_applicable"].extend([
            {"layer": "bus_stop",
             "reason": "no transit data in P03/P04; future owner: transit prompt"},
            {"layer": "bench_bin",
             "reason": "no pedestrian zones in P03/P04; future owner: street prompt"}])
        # spatial index grid (64 m cells -> reservation ids)
        self.reservations["index_cell_m"] = 64.0
        self.reservations["index"] = self._build_index(L)
        self._t(None)

    def _light_spacing(self, eid):
        """Street-light spacing by dominant region (m); None = unlit.
        Urban/suburban/industrial/port: full 35 m. Highway infra corridors
        (primary only): sparse 70 m. Rural/forest/highland/wetland: none."""
        from collections import Counter
        st = self.edge_stations(eid)
        reg = Counter(p["region"] for p in st).most_common(1)[0][0]
        cls = self.g["edges"][eid]["class"]
        if any(k in reg for k in ("urban", "suburb", "indust", "port")):
            return 35.0
        if reg == "infra_corridors" and cls == "primary":
            return 70.0
        return None

    def _lit_region(self, eid):
        return self._light_spacing(eid) is not None

    @staticmethod
    def _in_tri(tri, x, z):
        (ax, az), (bx, bz), (cx, cz) = tri
        d = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz)
        if abs(d) < 1e-12:
            return False
        la = ((bz - cz) * (x - cx) + (cx - bx) * (z - cz)) / d
        lb = ((cz - az) * (x - cx) + (ax - cx) * (z - cz)) / d
        return la >= 0 and lb >= 0 and la + lb <= 1

    def _sign_anchors(self, out):
        rr = self.sc["reserverules"]
        for nid in sorted(self.g["junctions"]):
            J = self.g["junctions"][nid]
            n = self.r["nodes"][nid]
            acc = self.r["nodes"][nid]["access"]
            for m in J["mouths"]:
                E2 = self.g["edges"][m["edge"]]
                dx, dz = m["x"] - n["x"], m["z"] - n["z"]
                DL = math.hypot(dx, dz) or 1.0
                back = 10.0
                x = m["x"] + dx / DL * back + (-dz / DL) * \
                    (E2["width_m"] / 2.0 + rr["sign_anchor_offset_m"])
                z = m["z"] + dz / DL * back + (dx / DL) * \
                    (E2["width_m"] / 2.0 + rr["sign_anchor_offset_m"])
                st = "restricted" if acc != "PUBLIC" else "directional"
                out.append({"id": "RSV-sign-%s-%s" % (nid, m["edge"]),
                            "type": st, "node": nid, "edge": m["edge"],
                            "pos": [q6(x), q6(z)],
                            "facing_deg": q6((math.degrees(math.atan2(
                                -dx, -dz)) + 360.0) % 360.0),
                            "sector": sector_of(x, z), "priority": "normal"})
        # warning signs at sharp curves (R<100, one per qualifying edge run)
        for eid in sorted(self.g["edges"]):
            st = self.edge_stations(eid)
            for i in range(1, len(st) - 1):
                if self._curve_radius(st, i) < 100.0:
                    p = st[i - 1]
                    n = (p["tz"], -p["tx"])
                    E2 = self.g["edges"][eid]
                    x = p["x"] + n[0] * (E2["width_m"] / 2.0 + 3.5)
                    z = p["z"] + n[1] * (E2["width_m"] / 2.0 + 3.5)
                    out.append({"id": "RSV-sign-warn-%s-%d" % (eid, i),
                                "type": "warning", "node": None, "edge": eid,
                                "pos": [q6(x), q6(z)],
                                "facing_deg": q6((math.degrees(math.atan2(
                                    p["tx"], p["tz"])) + 360.0) % 360.0),
                                "sector": sector_of(x, z),
                                "priority": "normal"})
                    break
        # nudge anchors out of sight triangles (deterministic compass
        # search: clears every triangle while keeping own-edge clearance)
        tris = self.reservations["layers"]["visibility"]
        dirs = [(math.cos(a), math.sin(a))
                for a in [i * math.pi / 4.0 for i in range(8)]]
        for sg in out:
            E2 = self.g["edges"][sg["edge"]]
            st = self.edge_stations(sg["edge"])

            def clear(x, z):
                for v in tris:
                    if self._in_tri(v["tri"], x, z):
                        return False
                bi = min(range(len(st)),
                         key=lambda i: (st[i]["x"] - x) ** 2 + (st[i]["z"] - z) ** 2)
                pp = st[bi]
                lat = abs((x - pp["x"]) * pp["tz"] - (z - pp["z"]) * pp["tx"])
                return lat >= E2["width_m"] / 2.0 + 1.0

            if clear(sg["pos"][0], sg["pos"][1]):
                continue
            for step in (1.5, 3.0, 4.5, 6.0, 9.0, 12.0):
                done = False
                for dx, dz in dirs:
                    x = sg["pos"][0] + dx * step
                    z = sg["pos"][1] + dz * step
                    if clear(x, z):
                        sg["pos"] = [q6(x), q6(z)]
                        done = True
                        break
                if done:
                    break
            sg["sector"] = sector_of(sg["pos"][0], sg["pos"][1])

    def _street_lights(self, out):
        rr = self.sc["reserverules"]
        for eid in sorted(self.g["edges"]):
            spacing = self._light_spacing(eid)
            if spacing is None:
                continue
            E = self.g["edges"][eid]
            st = self.edge_stations(eid)
            half = E["width_m"] / 2.0
            d = math.ceil((st[0]["d"] + 5.0) / spacing) * spacing
            k = 0
            while d < st[-1]["d"] - 5.0:
                seg = next((i for i in range(len(st) - 1)
                            if st[i]["d"] <= d <= st[i + 1]["d"] + 1e-9), None)
                if seg is not None and \
                        st[seg]["structure"] not in ("TUNNEL", "BRIDGE"):
                    a, b = st[seg], st[seg + 1]
                    f = 0.0 if b["d"] == a["d"] else (d - a["d"]) / (b["d"] - a["d"])
                    sgn = 1.0 if k % 2 == 0 else -1.0
                    n = (a["tz"], -a["tx"])
                    x = a["x"] + (b["x"] - a["x"]) * f + n[0] * sgn * (half + 1.5)
                    z = a["z"] + (b["z"] - a["z"]) * f + n[1] * sgn * (half + 1.5)
                    out.append({"id": "RSV-light-%s-%d" % (eid, int(d)),
                                "edge": eid, "d": q6(d),
                                "pos": [q6(x), q6(z)],
                                "spacing_m": spacing,
                                "class": E["class"], "sector": sector_of(x, z),
                                "priority": "normal"})
                    k += 1
                d += spacing

    def _build_index(self, L):
        cell = 64.0
        idx = {}

        def put(x, z, rid):
            key = "%d,%d" % (math.floor((x - GRID_MIN) / cell),
                             math.floor((z - GRID_MIN) / cell))
            idx.setdefault(key, []).append(rid)

        for lid, items in L.items():
            for it in items:
                rid = it["id"]
                if "x" in it and "z" in it:
                    R = it.get("R", 8.0)
                    for dx in (-R, 0.0, R):
                        for dz in (-R, 0.0, R):
                            put(it["x"] + dx, it["z"] + dz, rid)
                elif "pos" in it:
                    put(it["pos"][0], it["pos"][1], rid)
                elif "tri" in it:
                    for pt in it["tri"]:
                        put(pt[0], pt[1], rid)
                elif "bbox" in it:
                    x0, z0, x1, z1 = it["bbox"]
                    put(x0, z0, rid)
                    put(x1, z1, rid)
                elif "edge" in it:
                    st = self.edge_stations(it["edge"])
                    lo, hi = st[0]["d"], st[-1]["d"]
                    d = min(max(it["d0"], lo), hi)
                    d1 = min(max(it["d1"], lo), hi)
                    if d1 < d:
                        d, d1 = d1, d
                    made = 0
                    while d < d1:
                        seg = next((i for i in range(len(st) - 1)
                                    if st[i]["d"] - 1e-6 <= d <= st[i + 1]["d"] + 1e-6),
                                   None)
                        if seg is None:
                            break
                        a, b = st[seg], st[seg + 1]
                        f = 0.0 if b["d"] == a["d"] else (d - a["d"]) / (b["d"] - a["d"])
                        f = max(0.0, min(1.0, f))
                        put(a["x"] + (b["x"] - a["x"]) * f,
                            a["z"] + (b["z"] - a["z"]) * f, rid)
                        made += 1
                        d += 32.0
                    if d1 >= hi - 1e-6:
                        put(st[-1]["x"], st[-1]["z"], rid)
                        made += 1
                    else:
                        seg = next((i for i in range(len(st) - 1)
                                    if st[i]["d"] - 1e-6 <= d1 <= st[i + 1]["d"] + 1e-6),
                                   None)
                        if seg is not None:
                            a, b = st[seg], st[seg + 1]
                            f = 0.0 if b["d"] == a["d"] else (d1 - a["d"]) / (b["d"] - a["d"])
                            f = max(0.0, min(1.0, f))
                            put(a["x"] + (b["x"] - a["x"]) * f,
                                a["z"] + (b["z"] - a["z"]) * f, rid)
                            made += 1
                    if made == 0:
                        # degenerate range: pin to nearest station cell
                        bi = min(range(len(st)),
                                 key=lambda i: abs(st[i]["d"] - (d + d1) / 2.0))
                        put(st[bi]["x"], st[bi]["z"], rid)
                elif "size" in it:
                    put(it["x"], it["z"], rid)
        for k in idx:
            idx[k] = sorted(set(idx[k]))
        return idx

    # ================= DRESSING =================
    def phase_dressing(self):
        self._t("dressing")
        self.dressing = {"segments": []}
        for eid in sorted(self.g["edges"]):
            E = self.g["edges"][eid]
            st = self.edge_stations(eid)
            half = E["width_m"] / 2.0
            d = st[0]["d"]
            while d < st[-1]["d"]:
                seg = next((i for i in range(len(st) - 1)
                            if st[i]["d"] <= d <= st[i + 1]["d"] + 1e-9), None)
                if seg is None:
                    break
                a = st[seg]
                for sgn, side in ((-1.0, "L"), (1.0, "R")):
                    n = (a["tz"], -a["tx"])
                    x = a["x"] + n[0] * sgn * (half + 2.0)
                    z = a["z"] + n[1] * sgn * (half + 2.0)
                    gx = (self.f.height(x + 2.0, z) - self.f.height(x - 2.0, z)) / 4.0
                    gz = (self.f.height(x, z + 2.0) - self.f.height(x, z - 2.0)) / 4.0
                    slope = math.hypot(gx, gz)
                    cls = self._ground_class(a["region"], a["coast_d"], slope)
                    if slope < 0.15 and "forest" in a["region"]:
                        cls = "grass"
                    self.dressing["segments"].append(
                        {"edge": eid, "side": side, "d": q6(d),
                         "surface": cls, "slope": q6(slope),
                         "vegetation": "permit" if cls in ("soil", "grass")
                         else "exclude",
                         "note": "toe unchanged (P04 owns terrain contact)"})
                d += 50.0
        self._t(None)

    # ================= EXPORT =================
    def phase_export(self):
        self._t("export")
        outdir = os.environ.get("P05_OUT_DIR", os.path.join(ROOT, "data/derived"))
        os.makedirs(outdir, exist_ok=True)
        meta = {"structure_version": self.sc["structure_version"],
                "marking_version": self.sc["marking_version"],
                "reservation_version": self.sc["reservation_version"],
                "road_version": self.sc["road_version"],
                "road_checksum": self.r["checksum"],
                "geometry_version": self.sc["geometry_version"],
                "geometry_checksum": self.g["checksum"]["geometry"],
                "terrain_version": self.sc["terrain_version"],
                "coast_version": self.sc["coast_version"],
                "world_version": self.sc["world_version"],
                "generator": "transport_structures.py"}
        struct_items = ([{"scope": "bridge", "data": self.bridges[bid]}
                         for bid in sorted(self.bridges)] +
                        [{"scope": "tunnel", "data": self.tunnel}] +
                        [{"scope": "retaining", "data": self.retaining}] +
                        [{"scope": "barriers", "data": self.barriers}] +
                        [{"scope": "dressing", "data": self.dressing}] +
                        [{"scope": "mesh", "data": p} for p in
                         self.bridge_mesh + self.tunnel_mesh +
                         self.retaining_mesh + self.barrier_mesh])
        sdoc = {"meta": meta,
                "bridges": self.bridges, "tunnel": self.tunnel,
                "retaining": self.retaining, "barriers": self.barriers,
                "dressing": self.dressing,
                "parts": self.bridge_mesh + self.tunnel_mesh +
                self.retaining_mesh + self.barrier_mesh}
        sdoc["checksum"] = self.checksum_scope(struct_items)
        json.dump(sdoc, open(os.path.join(outdir, "transport_structures.json"), "w"))
        mark_items = ([{"scope": "record", "data": r}
                       for r in self.markings["records"]] +
                      [{"scope": "mesh", "data": p} for p in self.marking_mesh])
        mdoc = {"meta": meta, "markings": self.markings["records"],
                "skipped": self.markings["skipped"],
                "not_applicable": self.markings["not_applicable"],
                "parts": self.marking_mesh}
        mdoc["checksum"] = self.checksum_scope(mark_items)
        json.dump(mdoc, open(os.path.join(outdir, "transport_markings.json"), "w"))
        rdoc = {"meta": meta, "layers": self.reservations["layers"],
                "not_applicable": self.reservations["not_applicable"],
                "index_cell_m": self.reservations["index_cell_m"],
                "index": self.reservations["index"]}
        rdoc["checksum"] = self.checksum_scope(
            [{"scope": "layer", "name": k, "data": v}
             for k, v in sorted(self.reservations["layers"].items())])
        json.dump(rdoc, open(os.path.join(outdir, "transport_reservations.json"), "w"))
        import hashlib
        hext = {"label": "P05 structural extensions (inputs, not final systems)",
                "extends": {
                    "nav": {"file": "data/derived/road_nav_handoff.json",
                            "sha256": hashlib.sha256(open(os.path.join(
                                ROOT, "data/derived/road_nav_handoff.json"),
                                "rb").read()).hexdigest()},
                    "traffic": {"file": "data/derived/road_traffic_handoff.json",
                                "sha256": hashlib.sha256(open(os.path.join(
                                    ROOT, "data/derived/road_traffic_handoff.json"),
                                    "rb").read()).hexdigest()},
                    "collision": {"file": "data/derived/road_collision.json",
                                  "sha256": hashlib.sha256(open(os.path.join(
                                      ROOT, "data/derived/road_collision.json"),
                                      "rb").read()).hexdigest()}},
                "meta": meta,
                "barrier_runs": [(r["id"], r["edge"], r["d0"], r["d1"])
                                 for r in self.barriers["runs"]],
                "bridge_clearances": {bid: b["clearance_min"]
                                      for bid, b in self.bridges.items()},
                "tunnel_interior": {
                    "bore_range": self.tunnel["bore_range"],
                    "clearance_min": self.tunnel["lining_clearance_min"]},
                "marking_semantics": {"count": len(self.markings["records"])},
                "access_restrictions": sorted(set(
                    r["access"] for r in self.markings["records"]))}
        json.dump(hext, open(os.path.join(outdir, "transport_handoff_ext.json"), "w"))
        self.checksums = {"structures": sdoc["checksum"],
                          "markings": mdoc["checksum"],
                          "reservations": rdoc["checksum"]}
        self._t(None)

    def build_all(self):
        self.phase_preflight()
        for ph in ("bridges", "tunnel", "retaining", "barriers", "markings",
                   "reservations", "dressing", "export"):
            getattr(self, "phase_" + ph)()
        # close last timer
        self._t("done")
        self._t(None)
        return self.timers


def main():
    import sys as _sys
    sc_path = _sys.argv[_sys.argv.index("--contract") + 1] \
        if "--contract" in _sys.argv else None
    if sc_path:
        global STRUCT_CC
        STRUCT_CC = sc_path
    r = Registry()
    timers = r.build_all()
    print("structures: %d bridges %d tunnel %d walls %d barrier_runs %d "
          "marks %d resv_layers -> %s" % (
              len(r.bridges), 1, len(r.retaining["walls"]),
              len(r.barriers["runs"]), len(r.markings["records"]),
              len(r.reservations["layers"]),
              os.environ.get("P05_OUT_DIR", "data/derived")))
    print("checksums: %s" % (r.checksums,))
    print("timers: %s" % (" ".join("%s=%.2f" % kv
                                   for kv in sorted(timers.items()))))


if __name__ == "__main__":
    main()
