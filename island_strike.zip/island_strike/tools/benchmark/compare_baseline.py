#!/usr/bin/env python3
"""Performance regression hook (Prompt 01, §56). Compares two benchmark reports.

Usage: compare_baseline.py BASELINE.json CURRENT.json
Matches records by `label`, compares `mean`, prints delta table with severity:
  informational (<25% slower), warning (25-100%), critical (>100% or new failures).
Exit 0 always in Prompt 01 (informational-only; gates belong to Prompt 07),
unless files are unreadable (exit 2).
"""
import json, sys

def load(path):
    with open(path) as f:
        return json.load(f)

def index(report):
    out = {}
    for r in report.get("results", []):
        if r.get("status") == "measured" and r.get("mean") is not None:
            out[r["label"]] = r["mean"]
    return out

def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    try:
        base, cur = index(load(argv[1])), index(load(argv[2]))
    except Exception as e:
        print(f"COMPARE_ERROR {e}")
        return 2
    print(f"baseline={argv[1]} current={argv[2]}")
    for label in sorted(set(base) | set(cur)):
        if label not in base:
            print(f"  [new] {label}: {cur[label]*1000:.3f} ms (no baseline)");
        elif label not in cur:
            print(f"  [missing] {label}: absent in current run")
        else:
            b, c = base[label], cur[label]
            pct = (c - b) / b * 100.0 if b > 0 else (0.0 if c == 0 else float("inf"))
            sev = "informational" if pct < 25 else ("warning" if pct < 100 else "critical")
            if pct < -5:
                sev = "informational"
            print(f"  [{sev}] {label}: {b*1000:.3f} -> {c*1000:.3f} ms ({pct:+.1f}%)")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
