#!/usr/bin/env python3
"""P04 geometry smoke: rebuild + gate counts + checksum.

Fast CI gate (no engine): runs the builder, asserts part/tri counts,
lip/contested/fillet inventories, and prints the geometry checksum.
Exit 0 = all smoke gates pass.
"""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEO_JSON = os.path.join(ROOT, "data/derived/road_geometry.json")

GATES = {
    "parts": 53, "junctions": 21, "connectors": 121, "movements": 145,
    "fragments": 248, "reservations": 179, "lips": 6,
    "contested": 5, "fillets": 2, "cuts": 18, "deck_edges": 2,
    "butt_joints": 1, "bridges": 2,
}


def main():
    r = subprocess.run([sys.executable, os.path.join(ROOT, "tools/road_geometry.py")],
                       capture_output=True, text=True, cwd=ROOT)
    print(r.stdout.strip().splitlines()[-1] if r.stdout else "")
    if r.returncode != 0:
        print("SMOKE-FAIL: builder red")
        print(r.stderr[-2000:])
        return 1
    g = json.load(open(GEO_JSON))
    bad = []
    actual = {
        "parts": g["mesh_counts"]["parts"], "junctions": len(g["junctions"]),
        "connectors": len(g["connectors"]), "movements": len(g["movements"]),
        "fragments": len(g["fragments"]), "reservations": len(g["reservations"]),
        "lips": len(g["lips"]), "contested": len(g["contested"]),
        "fillets": len(g.get("fillets", [])), "cuts": len(g["cuts"]),
        "deck_edges": len(g["deck_edges"]), "butt_joints": len(g["butt_joints"]),
        "bridges": len(g["bridges"]),
    }
    for k, want in GATES.items():
        ok = actual[k] == want
        print("  [%s] %s = %s (want %s)" % ("PASS" if ok else "FAIL", k, actual[k], want))
        if not ok:
            bad.append(k)
    print("checksum: %s" % g["checksum"]["geometry"])
    print("SMOKE-GEOMETRY: %d/%d passed" % (len(GATES) - len(bad), len(GATES)))
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
