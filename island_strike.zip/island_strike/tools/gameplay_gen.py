#!/usr/bin/env python3
"""ISLAND STRIKE P10 — gameplay data generator.

Reads locked P00-P09 sources + P10 contracts, emits derived gameplay
artifacts with checksums. Deterministic: sorted iteration, fixed seeds.

Outputs (data/derived/):
  gameplay_mission_index.json     mission defs + mission_checksum
  gameplay_objective_graph.json   objective graphs + objective_graph_checksum
  gameplay_economy.json           shops/prices/rewards + economy_checksum
  gameplay_wanted.json            offense/dispatch/escape tables + wanted_checksum
  gameplay_events.json            world events + event_graph_checksum
  gameplay_save_schema.json       save schema + save_schema_checksum
  gameplay_manifest.json          component pins + gameplay_checksum
"""
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from npc_gen import canon, fnv1a64_hex  # noqa: E402

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
DD = os.path.join(ROOT, "data", "derived")
DW = os.path.join(ROOT, "data", "world")


def load(fn, world=False):
    with open(os.path.join(DW if world else DD, fn)) as f:
        return json.load(f)


# ---------- shared geo helpers (sim + validator import these) ----------
def point_in_bounds(x, z, bounds):
    if "disc" in bounds:
        cx, cz, r = bounds["disc"]
        return math.hypot(x - cx, z - cz) <= r
    if "sector" in bounds:
        cx, cz, r0, r1, a0, a1 = bounds["sector"]
        d = math.hypot(x - cx, z - cz)
        if not (r0 <= d <= r1):
            return False
        a = math.atan2(z - cz, x - cx)
        if a < 0:
            a += 2 * math.pi
        lo, hi = a0 % (2 * math.pi), a1 % (2 * math.pi)
        if lo <= hi:
            return lo <= a <= hi
        return a >= lo or a <= hi
    return False


def bounds_center(bounds):
    if "disc" in bounds:
        return (bounds["disc"][0], bounds["disc"][1])
    cx, cz, r0, r1, a0, a1 = bounds["sector"]
    mid = (r0 + r1) / 2.0
    ang = (a0 + a1) / 2.0
    return (cx + math.cos(ang) * mid, cz + math.sin(ang) * mid)


# coverage labels (§87) -> district
COVERAGE = {
    "CITY": "D-hub-core", "SUBURBAN": "D-sub-sub",
    "INDUSTRIAL": "D-port-ind", "PORT": "D-port-ops",
    "AIRFIELD": "D-air-ops", "RURAL": "D-vil-core",
    "FOREST": "D-for-svc",
    "WETLAND": "D-farmA",  # lowland farms; documented approximation
    "RESORT": "D-res-main", "HIGHLAND": "D-hi-look",
    "COAST": "D-hub-water", "RESTRICTED": "D-res-secure",
}

# template -> (objective pattern, roles, vehicle roles, route mode)
# objective pattern entries: (otype, params-key)
PATTERNS = {
    "TRAVEL": (["REACH", "REACH", "REACH"], [], [], "MIXED"),
    "DELIVERY": (["COLLECT", "REACH"], [], [{"class": "van"}], "VEHICLE"),
    "ESCORT": (["MEET", "FOLLOW", "REACH"],
               [{"role": "ESCORT_TARGET", "archetype": "CIVILIAN"},
                {"role": "CONTACT", "archetype": "CIVILIAN"}],
               [], "ON_FOOT"),
    "FOLLOW": (["FOLLOW", "REACH"],
               [{"role": "MISSION_TARGET", "archetype": "CIVILIAN"}],
               [], "ON_FOOT"),
    "INTERCEPT": (["INTERCEPT", "REACH"],
                  [], [{"class": "sedan", "driver": "CHASE_TARGET"}],
                  "VEHICLE"),
    "CHASE": (["CHASE", "REACH"],
              [{"role": "CHASE_TARGET", "archetype": "CIVILIAN"}],
              [], "MIXED"),
    "SURVIVE": (["TIMER", "REACH"], [], [], "ON_FOOT"),
    "COLLECT": (["COLLECT", "COLLECT", "REACH"], [], [], "ON_FOOT"),
    "MEET": (["MEET"],
             [{"role": "CONTACT", "archetype": "CIVILIAN"}], [], "ON_FOOT"),
    "RACE_HOOK": (["REACH", "REACH", "REACH"], [], [], "VEHICLE"),
    "ESCAPE": (["TIMER", "REACH"], [], [], "MIXED"),
    "RETRIEVE": (["REACH", "RETURN"],
                 [{"role": "CONTACT", "archetype": "CIVILIAN"}],
                 [], "ON_FOOT"),
    "OBSERVE": (["OBSERVE", "REACH"],
                [{"role": "MISSION_TARGET", "archetype": "CIVILIAN"}],
                [], "ON_FOOT"),
    "PROTECT": (["STATE", "REACH"],
                [{"role": "ESCORT_TARGET", "archetype": "CIVILIAN"}],
                [], "ON_FOOT"),
}

REWARD_BASE = {"TRAVEL": 120, "DELIVERY": 200, "ESCORT": 260,
               "FOLLOW": 180, "INTERCEPT": 240, "CHASE": 240,
               "SURVIVE": 160, "COLLECT": 150, "MEET": 100,
               "RACE_HOOK": 220, "ESCAPE": 260, "RETRIEVE": 190,
               "OBSERVE": 170, "PROTECT": 250}

BASE_PRICES = {"shop": 45, "dine": 30, "lodge": 120, "work": 60,
               "mixed_trade": 55, "service_trade": 70, "freight": 150,
               "farmstead": 40, "farm_ops": 90}

REGION_MOD = {"CITY_CORE": 1.3, "COMMERCIAL": 1.25, "CIVIC": 1.1,
              "MIXED_USE": 1.05, "RESIDENTIAL_INNER": 1.0,
              "RESIDENTIAL_OUTER": 0.95, "SUBURBAN": 0.9,
              "INDUSTRIAL": 0.85, "PORT": 0.9, "AIRFIELD": 1.0,
              "RESORT": 1.5, "WATERFRONT": 1.2, "RURAL_VILLAGE": 0.8,
              "AGRICULTURAL": 0.75, "FOREST_SETTLEMENT": 0.8,
              "HIGHLAND_SETTLEMENT": 0.85, "RESTRICTED": 1.0,
              "ARRIVAL": 1.0}


def build_missions(D):
    districts = {d["id"]: d for d in D["districts"]["districts"]}
    nav = D["nav"]["nodes"]
    pois = []  # (x, z, district, ref)
    for lm in D["places"]["landmarks"]:
        pois.append((lm["at"][0], lm["at"][1], lm["district"],
                     lm["id"]))
    for row in D["missions"]["rows"]:
        b = D["buildings"][row["building"]]
        fp = b["footprint"]
        cx = sum(p[0] for p in fp) / len(fp)
        cz = sum(p[1] for p in fp) / len(fp)
        pois.append((cx, cz, b["district"], row["zone"]))
    for a in D["nav_arrivals"]:
        pois.append((a["x"], a["z"], a.get("district", "D-hub-core"),
                     a["id"]))
    pois.sort(key=lambda p: (p[2], p[3]))
    by_district = {}
    for p in pois:
        by_district.setdefault(p[2], []).append(p)

    def zone_for(district):
        zid = "PZ-" + district
        zones = D["pop"]["zones"]
        if any(z["zone_id"] == zid for z in zones):
            return zid
        return "PZ-D-hub-core"

    def nearest_node(x, z):
        best = None
        for n in nav:
            if n["kind"] not in ("ENTRY", "AREA_CENTROID", "AREA_MID"):
                continue
            d2 = (n["x"] - x) ** 2 + (n["z"] - z) ** 2
            if best is None or d2 < best[0]:
                best = (d2, n["id"])
        return best[1] if best else None

    def nearest_tszone(x, z):
        best = None
        for zid, zn in sorted(D["traffic"]["spawn_zones"].items()):
            p = zn["pos"]
            d2 = (p[0] - x) ** 2 + (p[2] - z) ** 2
            if best is None or d2 < best[0]:
                best = (d2, zid)
        return best[1] if best else None

    # 16 missions: 14 templates + 2 chain seconds
    plan = [
        ("TRAVEL", "CITY"), ("DELIVERY", "PORT"), ("ESCORT", "CITY"),
        ("FOLLOW", "SUBURBAN"), ("INTERCEPT", "INDUSTRIAL"),
        ("CHASE", "CITY"), ("SURVIVE", "RURAL"), ("COLLECT", "FOREST"),
        ("MEET", "CIVIC" if "CIVIC" in [d for d in districts] else "CITY"),
        ("RACE_HOOK", "COAST"), ("ESCAPE", "RESTRICTED"),
        ("RETRIEVE", "RESORT"), ("OBSERVE", "HIGHLAND"),
        ("PROTECT", "AIRFIELD"), ("TRAVEL", "WETLAND"),
        ("DELIVERY", "RURAL"),
    ]
    # MEET label fix: coverage has no CIVIC; use CITY pool
    plan[8] = ("MEET", "CITY")
    missions = []
    obj_graphs = {}
    counters = {}
    for (tmpl, cov) in plan:
        district = COVERAGE[cov]
        pool = by_district.get(district, pois)
        k = counters.get(tmpl, 0)
        counters[tmpl] = k + 1
        mid = "M-%s-%02d" % (tmpl, k + 1)
        # deterministic POI picks spread across the pool
        picks = [pool[(k * 3 + j) % len(pool)] for j in range(3)]
        start = picks[0]
        objs, edges = [], []
        pattern, roles, vehicles, mode = PATTERNS[tmpl]
        prev = None
        for i, otype in enumerate(pattern):
            oid = "%s-O%d" % (mid, i + 1)
            tgt = picks[min(i, len(picks) - 1)]
            req = {"otype": otype}
            if otype in ("REACH", "RETURN", "MEET", "COLLECT",
                         "INTERCEPT"):
                # P10-D2: objective points snap to walkable nav nodes;
                # the POI is kept as reference only (never inside walls)
                nid = nearest_node(tgt[0], tgt[1])
                nd = next(n for n in nav if n["id"] == nid)
                req["point"] = [round(nd["x"], 2), round(nd["z"], 2)]
                req["poi_ref"] = tgt[3]
                req["radius_m"] = 12.0 if otype != "MEET" else 6.0
                req["node_ref"] = nid
                if otype == "COLLECT":
                    req["count"] = 3
                if otype == "INTERCEPT":
                    req["radius_m"] = 20.0
            elif otype in ("FOLLOW", "CHASE", "OBSERVE", "STATE"):
                req["role"] = roles[0]["role"] if roles else \
                    "MISSION_TARGET"
                req["band_m"] = [4.0, 30.0]
                req["ticks"] = 300
                if otype == "OBSERVE":
                    req["los_required"] = True
            elif otype == "TIMER":
                req["ticks"] = 300
                req["area_ref"] = district
            req["timeout_ticks"] = 1800
            objs.append({"objective_id": oid, "type": otype,
                         "requirements": req,
                         "marker": {"type": "OBJECTIVE",
                                    "priority": 10 - i},
                         "timeout_ticks": 1800,
                         "dependencies": [prev] if prev else []})
            if prev:
                edges.append([prev, oid])
            prev = oid
        # graph validation (gen-side; also validated by suites)
        ids = [o["objective_id"] for o in objs]
        assert len(ids) == len(set(ids)), mid
        assert not any(o["objective_id"] in o["dependencies"]
                       for o in objs), mid
        obj_graphs[mid] = {"nodes": ids, "edges": edges,
                           "validated": {"acyclic": True,
                                         "reachable": True,
                                         "no_dup": True,
                                         "no_dead_end": True}}
        npc_roles = []
        for r in roles:
            npc_roles.append({"role": r["role"],
                              "archetype": r["archetype"],
                              "zone": zone_for(district), "count": 1})
        veh_roles = []
        for v in vehicles:
            veh_roles.append(
                {"class": v["class"],
                 "spawn_zone": nearest_tszone(start[0], start[1]),
                 "count": 1, "driver": v.get("driver")})
        checkpoints = [{"after_objective": o["objective_id"],
                        "snapshot": ["player_position",
                                     "vehicle_context",
                                     "objective_state", "mission_npcs",
                                     "mission_timer",
                                     "world_event_stage"]}
                       for o in objs[:-1]]
        reward = REWARD_BASE[tmpl] + 25 * len(objs)
        missions.append({
            "mission_id": mid, "version": "p10msn1",
            "title_key": "title." + mid, "description_key": "desc." + mid,
            "type": tmpl,
            "availability": {"district": district,
                             "coverage": cov,
                             "cooldown_ticks": 600,
                             "prev_mission": ("M-%s-01" % tmpl)
                             if k == 1 else None},
            "start_conditions": {
                "player_at": {"point": [round(
                    next(n for n in nav if n["id"] == nearest_node(
                        start[0], start[1]))["x"], 2), round(
                    next(n for n in nav if n["id"] == nearest_node(
                        start[0], start[1]))["z"], 2)],
                              "radius_m": 60.0},
                "wanted_max": "WANTED_5" if tmpl == "ESCAPE" else
                "SUSPECTED",
                "sector_ready": True, "roles_available": True},
            "objectives": ids, "checkpoints": checkpoints,
            "objective_defs": objs,
            "failure_conditions": ["TIMEOUT", "AREA_EXIT",
                                   "OBJECTIVE_FAILED",
                                   "TARGET_LOST", "NPC_LOST",
                                   "PLAYER_ARRESTED",
                                   "PLAYER_ABORTED",
                                   "WORLD_STATE_INVALID",
                                   "VEHICLE_DESTROYED",
                                   "PLAYER_DEAD"],
            "success_conditions": ["ALL_REQUIRED_OBJECTIVES"],
            "rewards": {"money": reward,
                        "world_flag": "FLAG_%s_DONE" % mid,
                        "unlock_hook": None},
            "world_effects": ["FLAG_%s_DONE" % mid],
            "npc_roles": npc_roles, "vehicle_roles": veh_roles,
            "route_requirements": {
                "mode": mode,
                "origin_ref": nearest_node(start[0], start[1]),
                "dest_ref": nearest_node(picks[-1][0], picks[-1][1])},
            "wanted_policy": {
                "allowed": True, "prohibited": False,
                "clears_on_stage": ids[-1] if tmpl == "ESCAPE" else None,
                "pauses_on_arrest": tmpl != "ESCAPE",
                "fails_on_arrest": False},
            "economy_policy": {"entry_fee": 0},
            "cleanup_policy": {"default_full": True}})
    return missions, obj_graphs


def build_economy(D):
    tc = D["economy_contract"]
    shops = []
    prices = []
    by_biz = {}
    for row in D["economy"]["rows"]:
        b = D["buildings"][row["building"]]
        fp = b["footprint"]
        cx = sum(p[0] for p in fp) / len(fp)
        cz = sum(p[1] for p in fp) / len(fp)
        by_biz.setdefault(row["business"], []).append(row["building"])
        shops.append({"shop_id": "SHOP-" + row["building"],
                      "building": row["building"],
                      "business": row["business"],
                      "class": row["class"],
                      "district": b["district"],
                      "point": [round(cx, 2), round(cz, 2)]})
    shops.sort(key=lambda s: s["shop_id"])
    for biz in sorted(by_biz.keys()):
        base = BASE_PRICES.get(biz, 50)
        for dcls in sorted(REGION_MOD.keys()):
            prices.append(
                {"product_or_service_id": biz,
                 "base_price": base, "region": dcls,
                 "region_modifier": REGION_MOD[dcls],
                 "price": round(base * REGION_MOD[dcls], 2)})
    return {"shops": shops, "prices": prices,
            "currency": tc["currency"]["code"]}


def build_wanted(D):
    tc = D["wanted_contract"]
    sev = {"TRESPASS": 2, "VEHICLE_THEFT": 3}
    offenses = []
    for cls in tc["offenses"]["classes"]:
        offenses.append(
            {"class": cls, "enabled": cls in tc["offenses"]["enabled"],
             "severity": sev.get(cls, 1),
             "wanted_impact": sev.get(cls, 0),
             "evidence": ["witness", "location", "tick"]})
    units = {"WANTED_1": {"npc": 1, "vehicle": 0},
             "WANTED_2": {"npc": 2, "vehicle": 0},
             "WANTED_3": {"npc": 2, "vehicle": 1},
             "WANTED_4": {"npc": 3, "vehicle": 1},
             "WANTED_5": {"npc": 3, "vehicle": 2}}
    return {"offenses": offenses,
            "wanted_levels": tc["wanted_levels"],
            "wanted_transitions": tc["wanted_policy"]["transitions"],
            "pursuit_transitions": tc["pursuit"]["transitions"],
            "witness": tc["witness"],
            "dispatch_units": units,
            "escape": {"unseen_ticks": 300, "near_m": 40.0,
                       "far_m": 150.0, "coverage_weight": 0.2},
            "fines": {"TRESPASS": 150, "VEHICLE_THEFT": 300}}


def build_events(D):
    evts = []
    specs = [
        ("EVT-port-activity", "PORT", "AREA_ENTER",
         ["FLAG_PORT_ACTIVE"]),
        ("EVT-market-day", "CITY", "TIMER", ["FLAG_MARKET_DAY"]),
        ("EVT-heightened-alert", "RESTRICTED", "WANTED_STATE",
         ["FLAG_ALERT"]),
        ("EVT-festival", "RESORT", "AREA_ENTER",
         ["FLAG_FESTIVAL"]),
        ("EVT-harbor-patrol", "COAST", "TIMER",
         ["FLAG_PATROL"]),
        ("EVT-quiet-night", "RURAL", "TIMER", ["FLAG_QUIET"]),
    ]
    for eid, cov, trig, fx in specs:
        district = COVERAGE[cov]
        d = next(x for x in D["districts"]["districts"]
                 if x["id"] == district)
        cx, cz = bounds_center(d["bounds"])
        evts.append({"event_id": eid, "coverage": cov,
                     "district": district,
                     "trigger": {"type": trig,
                                 "point": [round(cx, 2),
                                           round(cz, 2)],
                                 "radius_m": 80.0, "ticks": 600},
                     "effects": fx, "initial": "DORMANT"})
    return {"events": evts}


def main():
    D = {}
    D["districts"] = load("districts.json")
    D["places"] = load("places.json")
    _b = load("buildings.json")
    _bl = _b["buildings"]
    D["buildings"] = {b["id"]: b for b in _bl} if isinstance(
        _bl, list) else _bl
    nav = load("npc_navigation_manifest.json")
    D["nav"] = nav
    D["nav_arrivals"] = [n for n in nav["nodes"]
                         if n["kind"] == "ARRIVAL"]
    D["pop"] = load("npc_population_manifest.json")
    D["traffic"] = load("traffic_graph.json")
    D["missions"] = load("p06_handoff_missions.json")
    D["economy"] = load("p06_handoff_economy.json")
    D["gameplay_contract"] = load("gameplay_contract.json", world=True)
    D["economy_contract"] = load("economy_contract.json", world=True)
    D["wanted_contract"] = load("wanted_contract.json", world=True)

    missions, graphs = build_missions(D)
    gc = D["gameplay_contract"]
    mission_core = {
        "missions": missions,
        "mission_machine": gc["mission_policy"]["transitions"],
        "objective_machine": gc["objective_policy"]["transitions"],
        "mission_version": gc["mission_version"],
        "sources": gc["sources"]}
    mission_checksum = fnv1a64_hex(canon(mission_core))
    graph_core = {"graphs": graphs, "mission_version": "p10msn1",
                  "sources": gc["sources"]}
    graph_checksum = fnv1a64_hex(canon(graph_core))
    eco = build_economy(D)
    eco_core = dict(eco)
    eco_core["sources"] = gc["sources"]
    economy_checksum = fnv1a64_hex(canon(eco_core))
    wtd = build_wanted(D)
    wtd_core = dict(wtd)
    wtd_core["sources"] = gc["sources"]
    wanted_checksum = fnv1a64_hex(canon(wtd_core))
    ev = build_events(D)
    ev_core = dict(ev)
    ev_core["sources"] = gc["sources"]
    event_checksum = fnv1a64_hex(canon(ev_core))
    sp = gc["save_policy"]
    save_core = {"fields": sp["fields"],
                 "versions": sp["versions"],
                 "migration": sp["migration"],
                 "never_persist": sp["never_persist"],
                 "sources": gc["sources"]}
    save_checksum = fnv1a64_hex(canon(save_core))
    manifest_core = {
        "mission_checksum": mission_checksum,
        "objective_graph_checksum": graph_checksum,
        "economy_checksum": economy_checksum,
        "wanted_checksum": wanted_checksum,
        "event_graph_checksum": event_checksum,
        "save_schema_checksum": save_checksum,
        "gameplay_version": gc["gameplay_version"],
        "sources": gc["sources"]}
    gameplay_checksum = fnv1a64_hex(canon(manifest_core))

    def write(fn, core, checksum, key):
        doc = dict(core)
        doc[key] = checksum
        with open(os.path.join(DD, fn), "w") as f:
            json.dump(doc, f, indent=1, sort_keys=True)

    write("gameplay_mission_index.json", mission_core,
          mission_checksum, "mission_checksum")
    write("gameplay_objective_graph.json", graph_core,
          graph_checksum, "objective_graph_checksum")
    write("gameplay_economy.json", eco_core, economy_checksum,
          "economy_checksum")
    write("gameplay_wanted.json", wtd_core, wanted_checksum,
          "wanted_checksum")
    write("gameplay_events.json", ev_core, event_checksum,
          "event_graph_checksum")
    write("gameplay_save_schema.json", save_core, save_checksum,
          "save_schema_checksum")
    write("gameplay_manifest.json", manifest_core,
          gameplay_checksum, "gameplay_checksum")
    print("missions=%d objectives=%d shops=%d prices=%d events=%d" % (
        len(missions),
        sum(len(m["objectives"]) for m in missions),
        len(eco["shops"]), len(eco["prices"]), len(ev["events"])))
    print("gameplay=%s mission=%s objgraph=%s economy=%s wanted=%s "
          "events=%s save=%s" % (
              gameplay_checksum, mission_checksum, graph_checksum,
              economy_checksum, wanted_checksum, event_checksum,
              save_checksum))


if __name__ == "__main__":
    main()
