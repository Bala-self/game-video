#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 04 — authoritative road GEOMETRY builder.

P03 road graph (LOCKED) -> physical road geometry: surface ribbons,
junction platforms, turn connectors, roundabout ring, bridge decks,
tunnel portal chain, sector fragments, collision/nav/traffic handoffs.

Rules: never redesign the graph; never duplicate terrain math (Field API
only); elevations derived from P03 samples + terrain verification + lift;
full-precision export; deterministic canonical mesh rebuild from export.

Usage: road_geometry.py  (builds + exports + prints summary/checksum)
"""
import json
import math
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from terrain_model import Field, fnv1a_hex  # noqa: E402

GEO_CC = os.path.join(ROOT, "data/world/road_geometry_contract.json")
ROADS_JSON = os.path.join(ROOT, "data/derived/roads.json")
GEO_JSON = os.path.join(ROOT, "data/derived/road_geometry.json")
NAV_JSON = os.path.join(ROOT, "data/derived/road_nav_handoff.json")
TRAFFIC_JSON = os.path.join(ROOT, "data/derived/road_traffic_handoff.json")
COLLISION_JSON = os.path.join(ROOT, "data/derived/road_collision.json")
TERRAIN_AUTH = os.path.join(ROOT, "data/terrain/authoring.json")


class GeometryError(Exception):
    pass


# ---------- small math ----------
def sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def norm2(v):
    L = math.hypot(v[0], v[1])
    return (v[0] / L, v[1] / L) if L > 0 else (1.0, 0.0)


def compass(dx, dz):
    """Compass bearing deg: 0=N(-Z), clockwise."""
    return (math.degrees(math.atan2(dx, -dz)) + 360.0) % 360.0


def ang_diff(a, b):
    """Signed smallest a->b in degrees (-180, 180]."""
    return (b - a + 540.0) % 360.0 - 180.0


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def smoothstep(t):
    t = clamp(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def circum_r(ax, az, bx, bz, cx, cz):
    ab = math.hypot(bx - ax, bz - az)
    bc = math.hypot(cx - bx, cz - bz)
    ca = math.hypot(ax - cx, az - cz)
    area = abs((bx - ax) * (cz - az) - (cx - ax) * (bz - az)) / 2.0
    if area < 1e-9:
        return float("inf")
    return ab * bc * ca / (4.0 * area)


def seg_dist(px, pz, ax, az, bx, bz):
    vx, vz = bx - ax, bz - az
    L2 = vx * vx + vz * vz or 1.0
    t = clamp(((px - ax) * vx + (pz - az) * vz) / L2, 0.0, 1.0)
    return math.hypot(px - (ax + vx * t), pz - (az + vz * t))


def q(v):
    """Half-away-from-zero int quantization (P03 lesson: matches roundf)."""
    return math.floor(v + 0.5) if v >= 0.0 else math.ceil(v - 0.5)


# ---------- shared mesh recipes (module level: builder + validator + ports) ----------
def platform_elev_at(J, x, z):
    """Junction plaza elevation (crown-free). J = {node:{x,z}, R, mouths}.
    Mouth: {pos, E, g_out}. Grade-matched radial, angular tents."""
    nx, nz = J["node"]["x"], J["node"]["z"]
    dx, dz = x - nx, z - nz
    r = math.hypot(dx, dz)
    th = compass(dx, dz) if r > 1e-9 else 0.0
    ms = J["mouths"]
    if len(ms) == 1:
        m = ms[0]
        return m["E"] - m["g_out"] * (J["R"] - min(r, J["R"]))
    bs = [m["pos"] for m in ms]
    acc, wsum = 0.0, 0.0
    for k, m in enumerate(ms):
        prev_b = bs[(k - 1) % len(bs)]
        next_b = bs[(k + 1) % len(bs)]
        hw = min(abs(ang_diff(m["pos"], prev_b)),
                 abs(ang_diff(m["pos"], next_b))) / 2.0
        hw = max(hw, 15.0)
        w = max(0.0, 1.0 - abs(ang_diff(m["pos"], th)) / hw)
        if w > 0:
            E = m["E"] - m["g_out"] * (J["R"] - min(r, J["R"]))
            acc += w * E
            wsum += w
    if wsum <= 0:
        return sum(m["E"] for m in ms) / len(ms)
    return acc / wsum


def ring_angular_elev_at(mouths_sorted, E_avg, theta_deg):
    bs = [m["pos"] for m in mouths_sorted]
    Es = [m["E"] for m in mouths_sorted]
    th = theta_deg % 360.0
    for k in range(len(mouths_sorted)):
        a0, a1 = bs[k], bs[(k + 1) % len(mouths_sorted)]
        gap = (a1 - a0) % 360.0
        rel = (th - a0) % 360.0
        if rel <= gap:
            t = rel / gap if gap > 0 else 0.0
            w = (1.0 - math.cos(math.pi * t)) / 2.0
            return Es[k] * (1.0 - w) + Es[(k + 1) % len(mouths_sorted)] * w
    return E_avg


def station_cols(columns, lift, crown, fall, p, normal_min_y=0.5):
    """Cross-section columns -> world verts + analytic normals (up).

    p['squeeze'] (default 1) narrows the section at sharp kinks (miter
    squeeze, works zones): effective offset oe = off*squeeze. 'off' keeps
    the design offset (band semantics); positions use oe.
    """
    lx, lz = p["tz"], -p["tx"]
    g = p.get("grade_re", p["grade"] / 100.0)
    sq = p.get("squeeze", 1.0)
    cols = []
    for off in columns:
        oe = off * sq
        rise = max(0.0, crown - abs(oe) * fall)
        x = p["x"] + oe * lx
        z = p["z"] + oe * lz
        y = p["road_elev"] + lift + rise
        if abs(oe) * fall < crown and abs(oe) > 1e-12:
            lat = -math.copysign(1.0, oe) * fall
        else:
            lat = 0.0
        T3 = (p["tx"], g, p["tz"])
        S3 = (lx, lat, lz)
        n = (T3[1] * S3[2] - T3[2] * S3[1],
             T3[2] * S3[0] - T3[0] * S3[2],
             T3[0] * S3[1] - T3[1] * S3[0])
        L = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2) or 1.0
        n = (n[0] / L, n[1] / L, n[2] / L)
        if n[1] < normal_min_y:
            raise GeometryError("surface normal tipped (off=%.2f)" % off)
        cols.append({"off": off, "x": x, "y": y, "z": z,
                     "nx": n[0], "ny": n[1], "nz": n[2]})
    return cols


def adaptive_angles(node_xz, R, mouths, col_angles, fill_deg=5.0):
    """Rim sector angles: mouth positions + column angles + <=fill_DEG fill."""
    base = [m["pos"] for m in mouths] + list(col_angles)
    base = sorted(set(round(b, 9) for b in base))
    out = []
    nb = len(base)
    for i in range(nb):
        a0 = base[i]
        a1 = base[(i + 1) % nb]
        gap = (a1 - a0) % 360.0
        out.append(a0)
        nfill = max(0, math.ceil(gap / fill_deg) - 1)
        for k in range(1, nfill + 1):
            out.append((a0 + gap * k / (nfill + 1)) % 360.0)
    return sorted(out)


def polar_at(nx, nz, r, theta_deg):
    th = math.radians(theta_deg)
    return (nx + r * math.sin(th), nz - r * math.cos(th))


def ring_elev_at(rb, mouths_sorted, E_avg, r, theta_deg):
    out = float(rb["flare_outer_R_m"])
    return ring_angular_elev_at(mouths_sorted, E_avg, theta_deg) + (out - r) * 0.02


def surf_normal(fn, x, z, h=1.0):
    dhdx = (fn(x + h, z) - fn(x - h, z)) / (2.0 * h)
    dhdz = (fn(x, z + h) - fn(x, z - h)) / (2.0 * h)
    L = math.sqrt(dhdx ** 2 + 1.0 + dhdz ** 2)
    return (-dhdx / L, 1.0 / L, -dhdz / L)


def build_mesh(geo, gc):
    """Canonical mesh rebuild from exported analytic geometry.

    Deterministic: same export -> same verts/tris/order. Used by the
    builder (checksum), the validator (recompute check), and evidence.
    Part index spaces are independent; cross-part joints are coincident
    verts validated to 1e-9 (no shared index space across parts).
    """
    parts = []
    contested_all = {}
    nmin = float(gc["mesh_quality"]["normal_up_min_y"])
    skip_area = float(gc["mesh_rules"]["skip_area_m2"])
    skipped = [0]
    ctx = ["?"]
    steep = []  # (ctx, tri, ny_unit, area, height, plan_area)

    def _area2(A, B, C):
        ux, uy, uz = B[0] - A[0], B[1] - A[1], B[2] - A[2]
        vx, vy, vz = C[0] - A[0], C[1] - A[1], C[2] - A[2]
        nx = uy * vz - uz * vy
        ny = uz * vx - ux * vz
        nz = ux * vy - uy * vx
        return math.sqrt(nx * nx + ny * ny + nz * nz) / 2.0, ny

    def _lip_note(tris, verts, A, B, C, flip):
        P, Q, R = verts[A], verts[B], verts[C]
        area, ny = _area2(P, Q, R)
        if area < skip_area or ny == 0:
            return
        nyu = abs(ny) / (2.0 * area)
        if nyu < 0.2:
            h = max(P[1], Q[1], R[1]) - min(P[1], Q[1], R[1])
            pa = abs((Q[0] - P[0]) * (R[2] - P[2]) -
                   (R[0] - P[0]) * (Q[2] - P[2])) / 2.0
            t = [A, C, B] if flip else [A, B, C]
            steep.append((ctx[0], t, nyu, area, h, pa))

    def _emit_up(tris, verts, A, B, C):
        # Label-dependent patches (bowtie lobes/noses: no uniform chirality)
        # orient by exhaustion: exactly one order faces up (negations are
        # bitwise-exact); degenerate -> skip; neither up -> loud defect.
        # (Uniform-chirality surfaces keep FIXED orders + strict _emit.)
        P, Q, R = verts[A], verts[B], verts[C]
        area, ny = _area2(P, Q, R)
        if area < skip_area:
            skipped[0] += 1
            return
        if ny > 0:
            tris.append([A, B, C])
            _lip_note(tris, verts, A, B, C, False)
        elif ny < 0:
            tris.append([A, C, B])
            _lip_note(tris, verts, A, B, C, True)
        else:
            raise GeometryError("vertical tri in %s" % ctx[0])

    def _emit(tris, verts, tri):
        # Coincident-vertex tris carry zero coverage and are not emitted;
        # validator proves coverage independently (boundary analysis) and
        # asserts the separation gap (min emitted area >> skip threshold).
        # Threshold 1e-9 m^2: exact-pinch FP residue at |coords|~1e3 peaks
        # ~1e-11, smallest real tri ~5e-2: residue << threshold << real.
        A, B, C = verts[tri[0]], verts[tri[1]], verts[tri[2]]
        area, ny = _area2(A, B, C)
        if area < skip_area:
            skipped[0] += 1
            return
        if ny <= 0:
            raise GeometryError(
                "inverted tri in %s: %s ny=%.3e area=%.3e" % (
                    ctx[0], tri, ny, area))
        tris.append(tri)
        _lip_note(tris, verts, tri[0], tri[1], tri[2], False)

    sk = gc["skirts"]
    skirt_out = float(sk["out_m"])
    skirt_tuck = float(sk["tuck_m"])

    def _cross(u, v):
        return (u[1] * v[2] - u[2] * v[1],
                u[2] * v[0] - u[0] * v[2],
                u[0] * v[1] - u[1] * v[0])

    def _norm3(v):
        L = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
        return (v[0] / L, v[1] / L, v[2] / L)

    _field = [None]

    def _skirt_vert(verts, skirt_idx, ax, ay, az, tx3, tz3_out):
        """Embankment toe: 3m out along the ground offset, tucked under terrain."""
        if _field[0] is None:
            _field[0] = Field()
        ox, oz = tz3_out
        L = math.hypot(ox, oz) or 1.0
        sx = ax + ox / L * skirt_out
        sz = az + oz / L * skirt_out
        sy = _field[0].height(sx, sz) - skirt_tuck
        out3 = _norm3((sx - ax, sy - ay, sz - az))
        n = _norm3(_cross(out3, tx3))
        if n[1] < 0:
            n = _norm3(_cross(tx3, out3))
        verts.append([sx, sy, sz, n[0], n[1], n[2]])
        skirt_idx.append(len(verts) - 1)
        return len(verts) - 1

    # ribbons (+ approach embankment skirts on SPECIAL stations)
    for eid in sorted(geo["edges"]):
        ctx[0] = "ribbon-" + eid
        E = geo["edges"][eid]
        st = E["stations"]
        meta = E["meta"]
        cols_all = [station_cols(meta["columns"], meta["lift"], meta["crown"],
                                 meta["fall"], p, nmin) for p in st]
        verts, nc = [], len(meta["columns"])
        for cols in cols_all:
            for c in cols:
                verts.append([c["x"], c["y"], c["z"], c["nx"], c["ny"], c["nz"]])
        tris = []
        skirt_idx = []
        for i in range(len(st) - 1):
            for j in range(nc - 1):
                A, B = i * nc + j, (i + 1) * nc + j
                C, D = (i + 1) * nc + j + 1, i * nc + j + 1
                _emit(tris, verts, [A, B, C])
                _emit(tris, verts, [A, C, D])
        for i in range(len(st) - 1):
            if st[i].get("structure") != "SPECIAL" or \
               st[i + 1].get("structure") != "SPECIAL":
                continue
            for cj in (0, nc - 1):
                A = i * nc + cj
                B = (i + 1) * nc + cj
                va, vb = verts[A], verts[B]
                t3 = _norm3((vb[0] - va[0], vb[1] - va[1], vb[2] - va[2]))
                pa, pb = st[i], st[i + 1]
                oa = (va[0] - pa["x"], va[2] - pa["z"])
                ob = (vb[0] - pb["x"], vb[2] - pb["z"])
                SA = _skirt_vert(verts, skirt_idx, va[0], va[1], va[2], t3, oa)
                SB = _skirt_vert(verts, skirt_idx, vb[0], vb[1], vb[2], t3, ob)
                if cj == 0:
                    _emit(tris, verts, [A, SB, B])
                    _emit(tris, verts, [A, SA, SB])
                else:
                    _emit(tris, verts, [A, B, SB])
                    _emit(tris, verts, [A, SB, SA])
        parts.append({"id": "ribbon-" + eid, "kind": "ribbon", "ref": eid,
                      "verts": verts, "tris": tris, "skirt": skirt_idx,
                      "semantic": {"edge": eid, "material": meta["material"],
                                   "access": E["access"], "class": E["class"]}})
    # platforms (+stitches+skirts) and ring
    for nid in sorted(geo["junctions"]):
        J = geo["junctions"][nid]
        ctx[0] = ("ring-" if J["kind"] == "ring" else "platform-") + nid
        nx, nz, R = J["node"]["x"], J["node"]["z"], J["R"]
        angs = J["sector_angles"]
        ns = len(angs)
        is_ring = (J["kind"] == "ring")
        if is_ring:
            rb = gc["roundabout"]
            rows = [float(v) for v in rb["mesh_rows_R"]]
            E_avg = geo["roundabout"]["E_avg"]
            ms = sorted(J["mouths"], key=lambda m: m["pos"])
            fn = lambda x, z, _m=ms, _e=E_avg: ring_elev_at(
                rb, _m, _e, math.hypot(x - nx, z - nz),
                compass(x - nx, z - nz))
        else:
            rows = [R / 3.0, 2.0 * R / 3.0, R]
            fn = lambda x, z, _J=J: platform_elev_at(_J, x, z)
        # Mouth data (shared by rim map, strips, contested extensions).
        # Rim road-follow: within a mouth's column span the rim carries the
        # MOUTH's y (angle-fraction lerp) so strips meet the rim in 3D
        # exactly. At contested angles (>=2 spans cover) the rim follows the
        # INNERMOST mouth (the one stripping there). Outside spans: plaza.
        mouths = []
        for mi, m in enumerate(J["mouths"]):
            E = geo["edges"][m["edge"]]
            st = E["stations"]
            p = st[0] if m["side"] == "from" else st[-1]
            cols = station_cols(E["meta"]["columns"], E["meta"]["lift"],
                                E["meta"]["crown"], E["meta"]["fall"], p, nmin)
            col_ang = [round(compass(c["x"] - nx, c["z"] - nz), 9)
                       for c in cols]
            segs = [ang_diff(col_ang[j], col_ang[j + 1])
                    for j in range(len(col_ang) - 1)]
            span = sum(segs)
            step = 1 if span >= 0 else -1
            if any(d * step < 0 for d in segs):
                raise GeometryError("non-monotonic mouth at " + nid)
            mouths.append({"cols": cols, "col_ang": col_ang, "step": step})

        def _seg_point(md, a):
            """Angle-fraction lerp point (x, y, z) on a mouth chord at bearing a.
            Returns None when a is outside the (closed) span."""
            col_ang, cols, step = md["col_ang"], md["cols"], md["step"]
            for j in range(len(cols) - 1):
                arc = ((col_ang[j + 1] - col_ang[j]) % 360.0) if step > 0 else \
                    ((col_ang[j] - col_ang[j + 1]) % 360.0)
                rel = ((a - col_ang[j]) % 360.0) if step > 0 else \
                    ((col_ang[j] - a) % 360.0)
                if 0.0 <= rel <= arc and arc > 0:
                    f = rel / arc
                    A, B = cols[j], cols[j + 1]
                    return (A["x"] + (B["x"] - A["x"]) * f,
                            A["y"] + (B["y"] - A["y"]) * f,
                            A["z"] + (B["z"] - A["z"]) * f)
            return None

        def _covers_strict(md, a):
            col_ang, step = md["col_ang"], md["step"]
            tot = sum(ang_diff(col_ang[j], col_ang[j + 1])
                      for j in range(len(col_ang) - 1))
            rel = ((a - col_ang[0]) % 360.0) if step > 0 else \
                ((col_ang[0] - a) % 360.0)
            return 0.0 < rel < abs(tot)

        def _innermost(cands, a):
            best = None
            for mi in cands:
                pt = _seg_point(mouths[mi], a)
                r = math.hypot(pt[0] - nx, pt[2] - nz)
                if best is None or r < best[0] - 1e-12 or \
                   (abs(r - best[0]) <= 1e-12 and mi < best[1]):
                    best = (r, mi)
            return best[1]

        # Contested rim edges (strict-interior cover by >=2 mouths) -> arcs.
        # ARC-LEVEL stripping (stable, twist-free): the arc-inner mouth
        # strips every contested edge; the outer skips all; rim y over the
        # CLOSED arc follows the arc-inner mouth (its strips stay flat; the
        # outer's single transition quad per arc end tilts <= dE/width).
        # Radius-order swaps inside the arc do NOT split stripping (the
        # piercing = merge lip, bounded + gated, not a twist).
        edge_cover = {}
        for s in range(ns):
            s2 = (s + 1) % ns
            gap = (angs[s2] - angs[s]) % 360.0
            mid = (angs[s] + gap / 2.0) % 360.0
            cov = [mi for mi in range(len(mouths))
                   if _covers_strict(mouths[mi], mid)]
            if len(cov) >= 2:
                edge_cover[(s, s2)] = sorted(cov)
        contested_arcs = []  # {idxs, edges, angles(set), pair, ain, aout}
        if edge_cover:
            starts = [e for e in edge_cover
                      if ((e[0] - 1) % ns, e[0]) not in edge_cover]
            for st in starts:
                run = [st]
                while (run[-1][1], (run[-1][1] + 1) % ns) in edge_cover:
                    run.append((run[-1][1], (run[-1][1] + 1) % ns))
                idxs = [run[0][0]] + [e[1] for e in run]
                pair = sorted(set(sum((edge_cover[e] for e in run), [])))
                if len(pair) != 2:
                    raise GeometryError(
                        "triple span overlap at %s (no rule)" % nid)
                mid_a = angs[idxs[len(idxs) // 2]]
                rad_a = math.hypot(*[c - n for c, n in zip(
                    _seg_point(mouths[pair[0]], mid_a)[::2], (nx, nz))])
                rad_b = math.hypot(*[c - n for c, n in zip(
                    _seg_point(mouths[pair[1]], mid_a)[::2], (nx, nz))])
                ain = pair[0] if rad_a <= rad_b else pair[1]
                aout = pair[1] if rad_a <= rad_b else pair[0]
                contested_arcs.append(
                    {"idxs": idxs, "edges": set(run),
                     "angles": set(round(angs[i], 9) for i in idxs),
                     "pair": tuple(pair), "ain": ain, "aout": aout})
                for e in run:
                    del edge_cover[e]
            if edge_cover:
                raise GeometryError("contested rim wraps fully at " + nid)

        def _span_y(a):
            for ca in contested_arcs:
                if a in ca["angles"]:
                    return _seg_point(mouths[ca["ain"]], a)[1]
            cands = [mi for mi in range(len(mouths))
                     if _seg_point(mouths[mi], a) is not None]
            if not cands:
                return None
            if len(cands) == 1:
                return _seg_point(mouths[cands[0]], a)[1]
            # sub-edge overlap (no rim-edge mid inside; <1 deg): innermost
            return _seg_point(mouths[_innermost(cands, a)], a)[1]
        verts = []
        skirt_idx = []
        base_rows = 0
        if not is_ring:
            cy = fn(nx, nz)
            cn = surf_normal(fn, nx, nz)
            verts.append([nx, cy, nz, cn[0], cn[1], cn[2]])
            base_rows = 1
        for ri, rr in enumerate(rows):
            last = (ri == len(rows) - 1)
            for a in angs:
                x, z = polar_at(nx, nz, rr, a)
                key = round(a, 9)
                sy = _span_y(key) if last else None
                if sy is not None:
                    y = sy
                else:
                    y = fn(x, z)
                nn = surf_normal(fn, x, z)
                verts.append([x, y, z, nn[0], nn[1], nn[2]])
        tris = []
        if not is_ring:
            for s in range(ns):
                _emit(tris, verts, [0, base_rows + (s + 1) % ns, base_rows + s])
            for s in range(ns):
                s2 = (s + 1) % ns
                _emit(tris, verts, [base_rows + s, base_rows + ns + s2,
                                    base_rows + ns + s])
                _emit(tris, verts, [base_rows + s, base_rows + s2,
                                    base_rows + ns + s2])
            for s in range(ns):
                s2 = (s + 1) % ns
                _emit(tris, verts, [base_rows + ns + s, base_rows + 2 * ns + s2,
                                    base_rows + 2 * ns + s])
                _emit(tris, verts, [base_rows + ns + s, base_rows + ns + s2,
                                    base_rows + 2 * ns + s2])
        else:
            for ri in range(len(rows) - 1):
                r0 = ri * ns
                r1 = (ri + 1) * ns
                for s in range(ns):
                    s2 = (s + 1) % ns
                    _emit(tris, verts, [r0 + s, r1 + s2, r1 + s])
                    _emit(tris, verts, [r0 + s, r0 + s2, r1 + s2])
        # stitches: mouth-column strips following rim subdivisions.
        # Contested rim edges are stripped ONLY by the innermost mouth (other
        # mouths skip; extensions cover between the chords). Strip quads fully
        # inside the disc are skipped (ribbon+platform cover there); inside
        # verts of straddling quads get a 5mm micro-lift (anti-z-fight: the
        # strip would otherwise lie coplanar on the ribbon end).
        microlift = float(gc["mesh_rules"]["strip_microlift_m"])
        rim = base_rows + (len(rows) - 1) * ns
        ang_index = {round(a, 9): i for i, a in enumerate(angs)}
        arc_edge_owner = {}
        for ca in contested_arcs:
            for e in ca["edges"]:
                arc_edge_owner[e] = ca["ain"]
        stitched = set()
        mouth_cache = {}

        def _mouth_vert(mi, a):
            key = (mi, round(a, 9))
            hit = mouth_cache.get(key)
            if hit is not None:
                return hit
            md = mouths[mi]
            col_ang, cols, step = md["col_ang"], md["cols"], md["step"]
            for j in range(len(cols) - 1):
                arc = ((col_ang[j + 1] - col_ang[j]) % 360.0) if step > 0 else \
                    ((col_ang[j] - col_ang[j + 1]) % 360.0)
                rel = ((a - col_ang[j]) % 360.0) if step > 0 else \
                    ((col_ang[j] - a) % 360.0)
                if 0.0 <= rel <= arc and arc > 0:
                    f = rel / arc
                    A, B = cols[j], cols[j + 1]
                    mx = A["x"] + (B["x"] - A["x"]) * f
                    my = A["y"] + (B["y"] - A["y"]) * f
                    mz = A["z"] + (B["z"] - A["z"]) * f
                    mn = _norm3((A["nx"] + (B["nx"] - A["nx"]) * f,
                                 A["ny"] + (B["ny"] - A["ny"]) * f,
                                 A["nz"] + (B["nz"] - A["nz"]) * f))
                    r = math.hypot(mx - nx, mz - nz)
                    inside = r < R - 1e-9
                    if inside:
                        my += microlift
                    idx = len(verts)
                    verts.append([mx, my, mz, mn[0], mn[1], mn[2]])
                    rec = (idx, inside)
                    mouth_cache[key] = rec
                    return rec
            raise GeometryError("mouth angle outside span at " + nid)

        for mi, md in enumerate(mouths):
            col_ang, step = md["col_ang"], md["step"]
            for j in range(len(col_ang) - 1):
                kj = ang_index[col_ang[j]]
                kj1 = ang_index[col_ang[j + 1]]
                idxs = [kj]
                guard = 0
                while idxs[-1] != kj1 and guard <= ns + 1:
                    idxs.append((idxs[-1] + step) % ns)
                    guard += 1
                if idxs[-1] != kj1:
                    raise GeometryError("rim walk failed at " + nid)
                for t in range(len(idxs) - 1):
                    i0, i1 = idxs[t], idxs[t + 1]
                    ekey = (i0, i1) if step > 0 else (i1, i0)
                    if ekey in arc_edge_owner and arc_edge_owner[ekey] != mi:
                        continue
                    M0, in0 = _mouth_vert(mi, angs[i0])
                    M1, in1 = _mouth_vert(mi, angs[i1])
                    if in0 and in1:
                        continue
                    R0, R1 = rim + i0, rim + i1
                    stitched.add(ekey)
                    # Uniform chirality (both outside): fixed order, strict.
                    # Straddling (rim dip): exhaustion per tri (in/out varies).
                    if in0 or in1:
                        if step > 0:
                            _emit_up(tris, verts, M0, R0, R1)
                            _emit_up(tris, verts, M0, R1, M1)
                        else:
                            _emit_up(tris, verts, M0, R1, R0)
                            _emit_up(tris, verts, M0, M1, R1)
                    elif step > 0:
                        _emit(tris, verts, [M0, R0, R1])
                        _emit(tris, verts, [M0, R1, M1])
                    else:
                        _emit(tris, verts, [M0, R1, R0])
                        _emit(tris, verts, [M0, M1, R1])
        # contested extensions: ruled chord-to-chord strips between the pair
        # (matched rim-angle subdivisions; shared mouth-vert cache). Merge
        # mouths' chords CROSS (all 5 contested sites are merges): the ruled
        # family follows the LOCAL radius order per quad (inner->outer flips
        # across the crossing). Bowtie quads (proper chord crossing strictly
        # inside) emit 2 lobes (road, manifold-forced order) + 2 paved gore
        # nose caps (separate gore parts, non-drivable); gore quadrants past
        # the noses stay open terrain (nose-edge boundary rule).
        def _bowtie_x(PA, QA, RB, SB):
            rx, rz = QA[0] - PA[0], QA[2] - PA[2]
            sx, sz = SB[0] - RB[0], SB[2] - RB[2]
            den = rx * sz - rz * sx
            tt = ((RB[0] - PA[0]) * sz - (RB[2] - PA[2]) * sx) / den
            uu = ((RB[0] - PA[0]) * rz - (RB[2] - PA[2]) * rx) / den
            xx = PA[0] + rx * tt
            xz = PA[2] + rz * tt
            xy = (PA[1] + (QA[1] - PA[1]) * tt
                  + RB[1] + (SB[1] - RB[1]) * uu) / 2.0
            xn = _norm3((PA[3] + QA[3] + RB[3] + SB[3],
                         PA[4] + QA[4] + RB[4] + SB[4],
                         PA[5] + QA[5] + RB[5] + SB[5]))
            return [xx, xy, xz, xn[0], xn[1], xn[2]]

        gore_parts = []
        contested_rec = []
        for ca in contested_arcs:
            pa, pb = ca["ain"], ca["aout"]
            idxs = ca["idxs"]
            ca_bowties = []
            ca["bowties"] = ca_bowties
            for t in range(len(idxs) - 1):
                i0, i1 = idxs[t], idxs[t + 1]
                A0, ain0 = _mouth_vert(pa, angs[i0])
                A1, ain1 = _mouth_vert(pa, angs[i1])
                B0, bin0 = _mouth_vert(pb, angs[i0])
                B1, bin1 = _mouth_vert(pb, angs[i1])
                if ain0 and ain1 and bin0 and bin1:
                    continue
                PA = verts[A0]
                QA = verts[A1]
                RB = verts[B0]
                SB = verts[B1]
                # proper crossing of plan segments PA-QA x RB-SB (strict)?
                d1 = (SB[0] - RB[0]) * (PA[2] - RB[2]) - (SB[2] - RB[2]) * (PA[0] - RB[0])
                d2 = (SB[0] - RB[0]) * (QA[2] - RB[2]) - (SB[2] - RB[2]) * (QA[0] - RB[0])
                d3 = (QA[0] - PA[0]) * (RB[2] - PA[2]) - (QA[2] - PA[2]) * (RB[0] - PA[0])
                d4 = (QA[0] - PA[0]) * (SB[2] - PA[2]) - (QA[2] - PA[2]) * (SB[0] - PA[0])
                if d1 * d2 < 0.0 and d3 * d4 < 0.0:
                    ca_bowties.append((i0, i1))
                    X = _bowtie_x(PA, QA, RB, SB)
                    XI = len(verts)
                    verts.append(X)
                    _emit_up(tris, verts, XI, B0, A0)
                    _emit_up(tris, verts, XI, B1, A1)
                    gv = [list(X), list(PA), list(QA), list(RB), list(SB)]
                    gt = []
                    _emit_up(gt, gv, 3, 0, 2)
                    _emit_up(gt, gv, 4, 0, 1)
                    gore_parts.append({"verts": gv, "tris": gt})
                else:
                    # Non-bowtie ruled quad: per-tri exhaustion on the fixed
                    # A0-B1 diagonal (no radius family claimed; up-verified).
                    _emit_up(tris, verts, A0, B1, B0)
                    _emit_up(tris, verts, A0, A1, B1)
        gm = geo["junctions"][nid]["mouths"]
        for ca in contested_arcs:
            ma_edge = gm[ca["ain"]]["edge"]
            mb_edge = gm[ca["aout"]]["edge"]
            contested_rec.append({
                "pair": (ma_edge, mb_edge),
                "ain_edge": ma_edge, "aout_edge": mb_edge,
                "n_edges": len(ca["idxs"]) - 1,
                "bowties": list(ca["bowties"]),
                "angles": [round(angs[i], 4) for i in ca["idxs"]]})
        if contested_rec:
            contested_all[nid] = contested_rec
        for k, gp in enumerate(gore_parts):
            parts.append({"id": "gore-%s-%d" % (nid, k), "kind": "gore",
                          "ref": nid, "verts": gp["verts"], "tris": gp["tris"],
                          "skirt": [],
                          "semantic": {"node": nid, "kind": "gore",
                                       "access": J.get("access", "PUBLIC")}})
        # skirts on non-mouth rim spans (embankment to terrain)
        for s in range(ns):
            s2 = (s + 1) % ns
            if (s, s2) in stitched:
                continue
            V0, V1 = rim + s, rim + s2
            v0, v1 = verts[V0], verts[V1]
            t3 = _norm3((v1[0] - v0[0], v1[1] - v0[1], v1[2] - v0[2]))
            S0 = _skirt_vert(verts, skirt_idx, v0[0], v0[1], v0[2], t3,
                             (v0[0] - nx, v0[2] - nz))
            S1 = _skirt_vert(verts, skirt_idx, v1[0], v1[1], v1[2], t3,
                             (v1[0] - nx, v1[2] - nz))
            _emit(tris, verts, [V0, V1, S1])
            _emit(tris, verts, [V0, S1, S0])
        parts.append({"id": ("ring-" if is_ring else "platform-") + nid,
                      "kind": "ring" if is_ring else "platform",
                      "ref": nid, "verts": verts, "tris": tris,
                      "skirt": skirt_idx,
                      "semantic": {"node": nid, "kind": J["kind"],
                                   "access": J.get("access", "PUBLIC")}})
        if is_ring:
            # island disc (non-drivable reservation, curb-lifted)
            rb = gc["roundabout"]
            E_avg = geo["roundabout"]["E_avg"]
            lift = float(rb["island_lift_m"])
            # island surveys its disc: elev = max terrain + lift (never buried)
            irows0 = [float(v) for v in rb["island_rows_R"]]
            nsec0 = int(rb["island_sectors"])
            isle_y = E_avg + lift
            for rr in irows0 + [0.0]:
                for s in range(nsec0):
                    a = 360.0 * s / nsec0
                    sx, sz = polar_at(nx, nz, rr, a)
                    isle_y = max(isle_y, _field[0].height(sx, sz) + lift)
            irows = [float(v) for v in rb["island_rows_R"]]
            nsec = int(rb["island_sectors"])
            ctx[0] = "island-" + nid
            iv, it = [], []
            iv.append([nx, isle_y, nz, 0.0, 1.0, 0.0])
            for rr in irows:
                for s in range(nsec):
                    a = 360.0 * s / nsec
                    x, z = polar_at(nx, nz, rr, a)
                    iv.append([x, isle_y, z, 0.0, 1.0, 0.0])
            for s in range(nsec):
                _emit(it, iv, [0, 1 + (s + 1) % nsec, 1 + s])
            r0, r1 = 1, 1 + nsec
            for s in range(nsec):
                s2 = (s + 1) % nsec
                _emit(it, iv, [r0 + s, r1 + s2, r1 + s])
                _emit(it, iv, [r0 + s, r0 + s2, r1 + s2])
            parts.append({"id": "island-" + nid, "kind": "island", "ref": nid,
                          "verts": iv, "tris": it, "skirt": [],
                          "semantic": {"node": nid, "kind": "island",
                                       "access": "NONE"}})
    # butt joints (pass-through nodes: ribbon end to ribbon end).
    # Through pair = same P03 route = continuous travel direction: both
    # sections share the lateral frame (no mirroring); ribbon-order stitch.
    for bj in geo.get("butt_joints", []):
        ctx[0] = "butt-" + bj["node"]
        E0 = geo["edges"][bj["edge_a"]]
        E1 = geo["edges"][bj["edge_b"]]
        pA = E0["stations"][-1] if bj["side_a"] == "to" else E0["stations"][0]
        pB = E1["stations"][0] if bj["side_b"] == "from" else E1["stations"][-1]
        cA = station_cols(E0["meta"]["columns"], E0["meta"]["lift"],
                          E0["meta"]["crown"], E0["meta"]["fall"], pA, nmin)
        cB = station_cols(E1["meta"]["columns"], E1["meta"]["lift"],
                          E1["meta"]["crown"], E1["meta"]["fall"], pB, nmin)
        if len(cA) != len(cB):
            raise GeometryError("butt column mismatch at " + bj["node"])
        verts = []
        for c in cA:
            verts.append([c["x"], c["y"], c["z"], c["nx"], c["ny"], c["nz"]])
        for c in cB:
            verts.append([c["x"], c["y"], c["z"], c["nx"], c["ny"], c["nz"]])
        n = len(cA)
        tris = []
        # 49-degree wedge over a shared centerpoint: no uniform chirality
        # (saddle sides + pinched center quads); per-tri exhaustion.
        for j in range(n - 1):
            _emit_up(tris, verts, j, n + j + 1, n + j)
            _emit_up(tris, verts, j, j + 1, n + j + 1)
        # stub caps (fan over the dead-end section)
        for stub in bj.get("stubs", []):
            E = geo["edges"][stub["edge"]]
            st = E["stations"]
            p = st[-1] if stub["side"] == "to" else st[0]
            cc = station_cols(E["meta"]["columns"], E["meta"]["lift"],
                              E["meta"]["crown"], E["meta"]["fall"], p, nmin)
            cx = sum(c["x"] for c in cc) / len(cc)
            cy = sum(c["y"] for c in cc) / len(cc)
            cz = sum(c["z"] for c in cc) / len(cc)
            base = len(verts)
            verts.append([cx, cy, cz, 0.0, 1.0, 0.0])
            for c in cc:
                verts.append([c["x"], c["y"], c["z"], c["nx"], c["ny"], c["nz"]])
            for j in range(len(cc) - 1):
                _emit_up(tris, verts, base, base + 1 + j, base + 1 + j + 1)
        parts.append({"id": "butt-" + bj["node"], "kind": "butt", "ref": bj["node"],
                      "verts": verts, "tris": tris, "skirt": [],
                      "semantic": {"node": bj["node"], "kind": "butt",
                                   "access": E0["access"]}})
    geo_mesh_note = {"skipped_degenerate": skipped[0]}
    for p in parts:
        p["mesh_note"] = geo_mesh_note
    return parts, steep, contested_all


# ---------- profiles ----------
class ProfileRegistry:
    def __init__(self, gc):
        self.gc = gc
        self.classes = gc["profiles"]

    def select(self, cls, width):
        if cls not in self.classes:
            raise GeometryError("unknown road class " + cls)
        p = self.classes[cls]
        for vname, b in p["variants"].items():
            tot = (b["lanes"] * b["lane_width_m"] + b["median_width_m"]
                   + 2 * b["shoulder_width_m"] + 2 * b["margin_width_m"])
            if abs(tot - width) < 1e-9:
                return vname, p, b
        raise GeometryError("class %s has no variant for locked width %.1f"
                            % (cls, width))

    def columns(self, cls, width):
        """Band-boundary lateral offsets (left+), always including 0."""
        _, p, b = self.select(cls, width)
        half = width / 2.0
        offs = {0.0, -half, half}
        n2 = b["lanes"] // 2
        x = b["median_width_m"] / 2.0
        offs.add(x)
        offs.add(-x)
        for _ in range(n2):
            x += b["lane_width_m"]
            offs.add(round(x, 9))
            offs.add(round(-x, 9))
        if b["lanes"] % 2 == 1:  # single bidirectional path: lane edge = travel edge
            x += b["lane_width_m"] / 2.0
            offs.add(round(x, 9))
            offs.add(round(-x, 9))
        x += b["shoulder_width_m"]
        offs.add(round(min(x, half), 9))
        offs.add(round(max(-x, -half), 9))
        return sorted(offs), p, b

    def lane_centers(self, cls, width):
        """[(offset, direction)] direction +1 = edge from->to, -1 reversed."""
        _, _, b = self.select(cls, width)
        n = b["lanes"]
        if n == 1:
            return [(0.0, 0)]
        out = []
        x0 = b["median_width_m"] / 2.0
        for k in range(n // 2):
            c = x0 + b["lane_width_m"] * (k + 0.5)
            out.append((-c, +1))  # right side travels forward (right-hand traffic)
            out.append((c, -1))
        return sorted(out)

    def surface_material(self, cls, p03_surface):
        rule = self.gc["surface_map"].get(p03_surface)
        if rule is None:
            raise GeometryError("unmapped P03 surface " + p03_surface)
        if rule.startswith("class:"):
            return "asphalt_primary" if cls == "primary" else "asphalt_secondary"
        return rule


# ---------- geometry build ----------
TERMINAL_TYPES = ("terminal", "trailhead")


class RoadGeometry:
    def __init__(self):
        self.timers = {}
        self.gc = json.load(open(GEO_CC))
        self.roads = json.load(open(ROADS_JSON))
        self.tau = json.load(open(TERRAIN_AUTH))
        self.f = Field()
        self.prof = ProfileRegistry(self.gc)
        self.arms = {}       # nid -> [arm...]
        self.envelopes = {}  # nid -> R
        self.edge_st = {}    # eid -> stations [...]
        self.edge_meta = {}  # eid -> {trim, profile, material, ...}
        self.junctions = {}  # nid -> platform params
        self.roundabout = None
        self.connectors = {}  # cid -> connector
        self.movements = []   # movement table rows
        self.bridges = {}     # bid -> deck params
        self.fillets = []     # hairpin fillet records
        self.tunnel = {}      # portal chain
        self.fragments = []   # sector fragments
        self.reservations = []  # reservation records
        self.lanes = {}       # eid -> lane paths (traffic handoff)
        self.collision = {}   # collision input
        self.nav = {}         # nav input

    def _t(self, name):
        t0 = self.timers.get(name + ":t0")
        if t0 is None:
            self.timers[name + ":t0"] = time.perf_counter()
        else:
            self.timers[name] = self.timers.get(name, 0.0) + time.perf_counter() - t0
            del self.timers[name + ":t0"]

    # ---- phase 1: pins ----
    def phase_pins(self):
        self._t("pins")
        m = self.roads["meta"]
        pins = {"road_version": self.gc["road_version"],
                "terrain_version": self.gc["terrain_version_reference"],
                "coast_version": self.gc["coast_version_reference"],
                "world_version": self.gc["world_version"]}
        for k, want in pins.items():
            if m.get(k) != want:
                raise GeometryError("stale P03 export: %s %s != %s"
                                    % (k, m.get(k), want))
        if self.roads["checksum"] != self.gc["road_checksum_reference"]:
            raise GeometryError("P03 checksum drift: %s (graph changed?)"
                                % self.roads["checksum"])
        live_t = json.load(open(os.path.join(ROOT, "data/world/terrain_contract.json")))
        live_c = json.load(open(os.path.join(ROOT, "data/world/coast_contract.json")))
        live_w = json.load(open(os.path.join(ROOT, "data/world/world_contract.json")))
        if live_t["terrain_version"] != pins["terrain_version"]:
            raise GeometryError("stale terrain contract")
        if live_c["coast_version"] != pins["coast_version"]:
            raise GeometryError("stale coast contract")
        if live_w["world_version"] != pins["world_version"]:
            raise GeometryError("stale world contract")
        self._t("pins")

    # ---- phase 2: arms + bearings (derived from P03 endpoint tangents) ----
    def phase_arms(self):
        self._t("arms")
        nodes, edges = self.roads["nodes"], self.roads["edges"]
        for nid in sorted(nodes):
            self.arms[nid] = []
        for eid in sorted(edges):
            e = edges[eid]
            sl = e["samples"]
            t0 = norm2(sub((sl[1]["x"], sl[1]["z"]), (sl[0]["x"], sl[0]["z"])))
            t1 = norm2(sub((sl[-1]["x"], sl[-1]["z"]), (sl[-2]["x"], sl[-2]["z"])))
            # bearing of travel INTO the node along this arm
            b0 = compass(-t0[0], -t0[1])  # at from_node, arriving heading = -tangent
            b1 = compass(t1[0], t1[1])    # at to_node, arriving heading = +tangent
            self.arms[e["from_node"]].append(
                {"edge": eid, "side": "from", "arrive": b0,
                 "out_dir": t0, "class": e["class"], "width": e["width_m"],
                 "access": e["access"]})
            self.arms[e["to_node"]].append(
                {"edge": eid, "side": "to", "arrive": b1,
                 "out_dir": (-t1[0], -t1[1]), "class": e["class"],
                 "width": e["width_m"], "access": e["access"]})
        for nid in self.arms:
            self.arms[nid].sort(key=lambda a: a["arrive"])
        self._t("arms")

    # ---- phase 3: envelopes ----
    def phase_envelopes(self):
        self._t("envelopes")
        je = self.gc["junction_envelope"]
        resv = je["turn_reservation_m"]
        for nid in sorted(self.roads["nodes"]):
            n = self.roads["nodes"][nid]
            if n["type"] in TERMINAL_TYPES and n["degree"] != 1:
                continue  # pass-through (butt joint), no envelope
            if n["type"] == "roundabout":
                self.envelopes[nid] = float(self.gc["roundabout"]["flare_outer_R_m"])
                continue
            if n["type"] in TERMINAL_TYPES:
                if n["degree"] == 1:
                    # turnaround bulb (dead end): R fits a single-arc U-turn
                    arm = self.arms[nid][0]
                    jt = self.classes(arm["class"])["junction_turn_min_m"]
                    self.envelopes[nid] = jt / 2.0 + arm["width"] / 2.0 + 1.0
                # degree>=2 terminal-typed nodes are pass-throughs (butt joint)
                continue
            if n["type"] == "gate":
                self.envelopes[nid] = float(je["gate_R_m"])
                continue
            if n["type"] == "merge" and n["degree"] == 2:
                self.envelopes[nid] = float(je["degree2_merge_R_m"])
                continue
            arms = self.arms[nid]
            half = max(a["width"] for a in arms) / 2.0
            need = 0.0
            for a in arms:
                for b in arms:
                    if a["edge"] == b["edge"]:
                        continue
                    need = max(need, max(resv[a["class"]], resv[b["class"]]))
            R = half + need + float(je["margin_m"])
            self.envelopes[nid] = clamp(R, float(je["min_R_m"]), float(je["max_R_m"]))
        self._t("envelopes")

    def classes(self, c):
        return self.gc["profiles"][c]

    # ---- phase 4: edge stations (inserts + trim + structure + verify) ----
    def _insert_at(self, sl, d_star):
        """Station lerped at exact edge-local chainage d_star.

        sl carries P03 ROUTE chainage in s['d']; d_star is edge-local.
        Returned station uses edge-local 'd'.
        """
        rs = d_star + sl[0]["d"]
        for i in range(len(sl) - 1):
            if sl[i]["d"] <= rs <= sl[i + 1]["d"]:
                a, b = sl[i], sl[i + 1]
                t = 0.0 if b["d"] == a["d"] else (rs - a["d"]) / (b["d"] - a["d"])
                x = a["x"] + (b["x"] - a["x"]) * t
                z = a["z"] + (b["z"] - a["z"]) * t
                # NOTE: insert elevation comes from the terrain (the same source
                # P03 sampled); linear-elev lerp would deviate on curved ground.
                # Tunnel inserts keep lerped BORE elevation (see phase_stations).
                return {"d": d_star, "x": x, "z": z,
                        "elev": a["elev"] + (b["elev"] - a["elev"]) * t,
                        "elev_terrain": self.f.height(x, z),
                        "region": a["region"], "coast_d": a["coast_d"]}
        raise GeometryError("chainage %.2f outside edge samples" % d_star)

    def _wet_span(self, eid):
        """Wet-span chainages (EDGE-LOCAL) via the P03 ribbon rule re-derive."""
        e = self.roads["edges"][eid]
        sl = e["samples"]
        dd0 = sl[0]["d"]
        hits = []
        for rv in self.tau["drainage"]["rivers"]:
            pts, hw = rv["points"], rv["width_m"] / 2.0
            cur = []
            for s in sl:
                md = min(seg_dist(s["x"], s["z"], pts[i][0], pts[i][1],
                                  pts[i + 1][0], pts[i + 1][1])
                         for i in range(len(pts) - 1))
                if md <= hw:
                    cur.append(s)
            if cur:
                hits.append((rv["id"], cur[0]["d"] - dd0, cur[-1]["d"] - dd0))
        for lk in self.tau["drainage"]["lakes"]:
            cur = [s for s in sl
                   if ((s["x"] - lk["cx"]) / lk["rx"]) ** 2
                   + ((s["z"] - lk["cz"]) / lk["rz"]) ** 2 <= 1.0
                   and s["elev"] < lk["level_m"] + 0.5]
            if cur:
                hits.append((lk["id"], cur[0]["d"] - dd0, cur[-1]["d"] - dd0))
        return hits

    def _chord_trim(self, sl, node_xy, R):
        """Edge-local chainage where chord(node, station) first reaches R.

        Trims by chord (not arc) so ribbon mouths land exactly ON the
        platform rim circle even when the edge curves near the node.
        Walks from the node end; stations must start/end at the node.
        Returns edge-local dd (caller normalizes P03 route chainage first).
        """
        nx, nz = node_xy
        dd0 = sl[0]["d"]
        best = None
        for i in range(len(sl) - 1):
            ax, az = sl[i]["x"] - nx, sl[i]["z"] - nz
            bx, bz = sl[i + 1]["x"] - nx, sl[i + 1]["z"] - nz
            ca, cb = math.hypot(ax, az), math.hypot(bx, bz)
            if (ca - R) * (cb - R) <= 0.0 and abs(cb - ca) > 1e-9:
                t = (R - ca) / (cb - ca)
                if 0.0 <= t <= 1.0:
                    # walked distance from the node end (walk may run either way)
                    best = abs(sl[i]["d"] + (sl[i + 1]["d"] - sl[i]["d"]) * t - dd0)
                    break
            if min(ca, cb) > R and best is None and i > 2:
                break  # already outside without crossing (should not happen)
        if best is None:
            raise GeometryError("no chord crossing at R=%.1f" % R)
        return best

    def phase_stations(self):
        self._t("stations")
        nodes, edges = self.roads["nodes"], self.roads["edges"]
        for eid in sorted(edges):
            e = edges[eid]
            sl = e["samples"]
            L = e["length_m"]
            dd0 = sl[0]["d"]  # P03 d is ROUTE chainage; normalize to edge-local
            # trim chainages (edge-local): chord trim at platform nodes
            n_from, n_to = nodes[e["from_node"]], nodes[e["to_node"]]
            R_from = self.envelopes.get(e["from_node"])
            R_to = self.envelopes.get(e["to_node"])
            if R_from is None:
                d0 = 0.0  # pass-through node (butt joint), no trim
            else:
                d0 = self._chord_trim(sl, (n_from["x"], n_from["z"]), R_from)
            if R_to is None:
                d1 = L
            else:
                rev = list(reversed(sl))
                back = self._chord_trim(rev, (n_to["x"], n_to["z"]), R_to)
                d1 = L - back
            if d1 - d0 < 20.0:
                raise GeometryError("edge %s over-trimmed (%.1f left)" % (eid, d1 - d0))
            marks = {d0: "bore" if e["tunnel"] else "terrain",
                     d1: "bore" if e["tunnel"] else "terrain"}
            struct_spans = []  # (d_a, d_b, kind, ref)
            if e["tunnel"]:
                pt = float(self.gc["tunnel"]["portal_transition_m"])
                marks[pt] = "bore"
                marks[L - pt] = "bore"
                struct_spans.append((pt, L - pt, "TUNNEL", "bore"))
                struct_spans.append((d0, pt, "SPECIAL_STRUCTURE", "portal_E"))
                struct_spans.append((L - pt, d1, "SPECIAL_STRUCTURE", "portal_W"))
            for bid in [b for b in self.roads["bridges"] if b["road_edge"] == eid]:
                for feat, w0, w1 in self._wet_span(eid):
                    if feat != bid["water_feature"]:
                        continue
                    T = max(40.0, 2.0 * e["width_m"])
                    a, b = max(d0, w0 - T), min(d1, w1 + T)
                    for m in (a, w0, w1, b):
                        marks[m] = "terrain"
                    struct_spans.append((w0, w1, "BRIDGE", bid["id"]))
                    struct_spans.append((a, w0, "SPECIAL_STRUCTURE", bid["id"] + "_appr0"))
                    struct_spans.append((w1, b, "SPECIAL_STRUCTURE", bid["id"] + "_appr1"))
                    self.bridges[bid["id"]] = {"edge": eid, "water": feat,
                                               "wet0": w0, "wet1": w1,
                                               "appr0": a, "appr1": b}
            # assemble stations: kept samples + exact inserts, sorted, deduped
            # (all P04 chainages are EDGE-LOCAL; P03 route chainage normalized)
            keep = [s for s in sl if d0 - 1e-9 <= s["d"] - dd0 <= d1 + 1e-9]
            pts = [{"d": s["d"] - dd0, "x": s["x"], "z": s["z"], "elev": s["elev"],
                    "region": s["region"], "coast_d": s["coast_d"]} for s in keep]
            for m in sorted(marks):
                if all(abs(p["d"] - m) > 1e-6 for p in pts):
                    ins = self._insert_at(sl, m)
                    ins["insert_mode"] = marks[m]
                    if marks[m] == "terrain":
                        ins["elev"] = ins.pop("elev_terrain")
                    else:
                        ins.pop("elev_terrain")
                    pts.append(ins)
            pts.sort(key=lambda p: p["d"])
            # marks win within 1 mm (drop P03 samples under exact inserts)
            mark_ds = sorted(marks)
            pts = [q for q in pts
                   if "insert_mode" in q or all(
                       abs(q["d"] - m) > 1e-3 for m in mark_ds)]
            # hairpin fillets (ruled corner arcs at impossible P03 vertices)
            pts = self._fillet_hairpins(eid, e["class"], pts)
            pts.sort(key=lambda p: p["d"])
            # structure classify + terrain verify + deck/tangent/grade fill (deck later)
            for p in pts:
                p["structure"] = "ORDINARY_TERRAIN_CONTACT"
                p["struct_ref"] = None
                for a, b, kind, ref in struct_spans:
                    if a - 1e-9 <= p["d"] <= b + 1e-9:
                        p["structure"] = kind
                        p["struct_ref"] = ref
                        break
                if p["structure"] == "ORDINARY_TERRAIN_CONTACT":
                    terr = self.f.height(p["x"], p["z"])
                    if abs(p["elev"] - terr) > 1e-6:
                        raise GeometryError(
                            "terrain drift at %s d=%.1f (P03 %.3f vs terrain %.3f)"
                            % (eid, p["d"], p["elev"], terr))
                p["terrain"] = self.f.height(p["x"], p["z"])
            # tangents + grades (central differences on kept+insert chain)
            for i, p in enumerate(pts):
                a = pts[max(0, i - 1)]
                b = pts[min(len(pts) - 1, i + 1)]
                t = norm2((b["x"] - a["x"], b["z"] - a["z"]))
                p["tx"], p["tz"] = t
                dd = b["d"] - a["d"]
                p["grade"] = (b["elev"] - a["elev"]) / dd * 100.0 if dd > 0 else 0.0
            cols, prof, bands = self.prof.columns(e["class"], e["width_m"])
            mat = self.prof.surface_material(e["class"], e["surface"])
            self.edge_st[eid] = pts
            self.edge_meta[eid] = {"d0": d0, "d1": d1,
                                   "columns": cols, "profile": prof,
                                   "bands": bands, "material": mat,
                                   "lift": prof["surface_lift_m"],
                                   "crown": prof["crown_height_m"],
                                   "fall": prof["crossfall_percent"] / 100.0}
        self._t("stations")

    def _fillet_hairpins(self, eid, cls, pts):
        from collections import deque
        trig = float(self.gc["hairpin_fillet"]["trigger_deg"])
        sample = float(self.gc["hairpin_fillet"]["sample_m"])
        rmin = float(self.gc["profiles"][cls]["junction_turn_min_m"])
        half_w = None
        for _e2 in (self.roads["edges"][eid],):
            half_w = _e2["width_m"] / 2.0
        work = list(pts)
        fillets_done = []
        # iterate: each fillet consumes stations, rescan after each
        while True:
            kink = None
            for i in range(1, len(work) - 1):
                a, k, b = work[i - 1], work[i], work[i + 1]
                v0 = (k["x"] - a["x"], k["z"] - a["z"])
                v1 = (b["x"] - k["x"], b["z"] - k["z"])
                l0, l1 = math.hypot(*v0), math.hypot(*v1)
                if l0 < 1e-9 or l1 < 1e-9:
                    continue
                dot = max(-1.0, min(1.0, (v0[0] * v1[0] + v0[1] * v1[1])
                                         / (l0 * l1)))
                delta = math.degrees(math.acos(dot))
                if delta > trig:
                    kink = (i, delta, l0, l1, v0, v1)
                    break
            if kink is None:
                break
            i, delta, l0, l1, v0, v1 = kink
            a, k, b = work[i - 1], work[i], work[i + 1]
            half = math.radians(delta) / 2.0
            # radius must fit the road (R > half width) and the legs
            Rneed = half_w + 2.0
            R = min(rmin, Rneed if Rneed < rmin else rmin)
            R = max(R, Rneed)
            if R > rmin:
                # leg/walk-limited below may still shrink; class min yields
                # to fit (documented exception: switchback)
                pass
            T = R * math.tan(half)
            u0 = (v0[0] / l0, v0[1] / l0)
            u1 = (v1[0] / l1, v1[1] / l1)
            # walk the polyline back/forward by arc-length T (straight legs:
            # consumed stations must continue the leg bearing within 10 deg)
            def _walk(start_idx, step, dist):
                j = start_idx
                dx, dz = (k["x"], k["z"]) if step < 0 else (k["x"], k["z"])
                # anchor leg bearing
                bx, bz = (-u0[0], -u0[1]) if step < 0 else (u1[0], u1[1])
                rem = dist
                px, pz = k["x"], k["z"]
                pd = k["d"]
                while rem > 1e-9:
                    q = work[j] if 0 <= j < len(work) else None
                    if q is None:
                        return None
                    seg = math.hypot(q["x"] - px, q["z"] - pz)
                    if seg > 1e-9:
                        sx, sz = (q["x"] - px) / seg, (q["z"] - pz) / seg
                        ang = math.degrees(math.acos(max(-1.0, min(
                            1.0, sx * bx + sz * bz))))
                        if ang > 10.0:
                            return None
                    if seg >= rem:
                        f = rem / seg
                        return (px + (q["x"] - px) * f,
                                pz + (q["z"] - pz) * f,
                                pd + (q["d"] - pd) * f, j)
                    rem -= seg
                    px, pz, pd = q["x"], q["z"], q["d"]
                    j += step
                return (px, pz, pd, j - step)
            w0 = _walk(i - 1, -1, T)
            w1 = _walk(i + 1, 1, T)
            if w0 is None or w1 is None:
                raise GeometryError(
                    "HAIRPIN_BULB %s d=%.0f delta=%.0f: legs too short/"
                    "curved for R%.1f fillet (needs turnaround junction)"
                    % (eid, k["d"], delta, R))
            (t0x, t0z, t0d, j0), (t1x, t1z, t1d, j1) = w0, w1
            # arc center: perpendiculars from tangent points
            n0 = (-u0[1], u0[0])
            n1 = (-u1[1], u1[0])
            # pick normal signs pointing to the same side (turn interior)
            mid = ((t0x + t1x) / 2.0, (t0z + t1z) / 2.0)
            to_mid0 = (mid[0] - t0x, mid[1] - t0z)
            to_mid1 = (mid[0] - t1x, mid[1] - t1z)
            if n0[0] * to_mid0[0] + n0[1] * to_mid0[1] < 0:
                n0 = (-n0[0], -n0[1])
            if n1[0] * to_mid1[0] + n1[1] * to_mid1[1] < 0:
                n1 = (-n1[0], -n1[1])
            cx, cz = t0x + n0[0] * R, t0z + n0[1] * R
            # arc sweep from t0 to t1 around center (turn angle = delta)
            a0 = math.atan2(t0z - cz, t0x - cx)
            a1 = math.atan2(t1z - cz, t1x - cx)
            # sweep direction: through the arc midpoint (bulge side = kink side)
            mid_k = ((t0x + t1x) / 2.0, (t0z + t1z) / 2.0)
            to_k = (k["x"] - mid_k[0], k["z"] - mid_k[1])
            sweep = (a1 - a0) % (2.0 * math.pi)
            mid_sweep = (a0 + sweep / 2.0)
            mx, mz = cx + R * math.cos(mid_sweep), cz + R * math.sin(mid_sweep)
            if (mx - mid_k[0]) * to_k[0] + (mz - mid_k[1]) * to_k[1] < 0:
                sweep = sweep - 2.0 * math.pi
            arc_len = abs(sweep) * R
            narcs = max(2, int(math.ceil(arc_len / sample)))
            new_pts = [{"d": t0d, "x": t0x, "z": t0z,
                        "elev": self.f.height(t0x, t0z),
                        "region": k["region"], "coast_d": k["coast_d"],
                        "fillet": True}]
            for s_i in range(1, narcs):
                f = s_i / narcs
                ang = a0 + sweep * f
                px, pz = cx + R * math.cos(ang), cz + R * math.sin(ang)
                new_pts.append({"d": t0d + (t1d - t0d) * f, "x": px, "z": pz,
                                "elev": self.f.height(px, pz),
                                "region": k["region"], "coast_d": k["coast_d"],
                                "fillet": True})
            new_pts.append({"d": t1d, "x": t1x, "z": t1z,
                            "elev": self.f.height(t1x, t1z),
                            "region": k["region"], "coast_d": k["coast_d"],
                            "fillet": True})
            self.fillets.append({"edge": eid, "station_d": k["d"],
                                 "delta_deg": delta, "R": R, "Rmin": rmin,
                                 "R_fit": Rneed,
                                 "class_exception": R > rmin,
                                 "arc_len": arc_len,
                                 "n_samples": len(new_pts),
                                 "consumed": (j0, j1)})
            # splice: keep stations outside [j0..j1], fillet between
            lo, hi = (j0, j1) if j0 < j1 else (j1, j0)
            work = work[:lo] + new_pts + work[hi + 1:]
        return work

    # ---- phase 5: bridge decks (road_elev profile) ----
    def phase_decks(self):
        self._t("decks")
        bc = self.gc["bridges"]
        for eid in sorted(self.edge_st):
            pts = self.edge_st[eid]
            for p in pts:
                p["road_elev"] = p["elev"]
        for bid, bp in sorted(self.bridges.items()):
            eid = bp["edge"]
            pts = self.edge_st[eid]
            a, w0, w1, b = bp["appr0"], bp["wet0"], bp["wet1"], bp["appr1"]
            Ea = self._at_d(pts, a)["elev"]
            Eb = self._at_d(pts, b)["elev"]
            wet_terr = [p["terrain"] for p in pts if w0 - 1e-9 <= p["d"] <= w1 + 1e-9]
            if not wet_terr:
                raise GeometryError("bridge %s wet span holds no stations" % bid)
            water = min(wet_terr) + 1.0  # documented water estimate
            floor = water + float(bc["clearance_min_m"])
            bp["water_est"] = water
            bp["deck_floor"] = floor
            bp["anchor_a"] = {"d": a, "elev": Ea}
            bp["anchor_b"] = {"d": b, "elev": Eb}
            clr = []
            for p in pts:
                if not (a - 1e-9 <= p["d"] <= b + 1e-9):
                    continue
                line = Ea + (Eb - Ea) * ((p["d"] - a) / (b - a) if b > a else 0.0)
                target = max(line, floor)
                if p["d"] < w0:
                    w = smoothstep((p["d"] - a) / (w0 - a) if w0 > a else 1.0)
                elif p["d"] > w1:
                    w = smoothstep((b - p["d"]) / (b - w1) if b > w1 else 1.0)
                else:
                    w = 1.0
                p["road_elev"] = p["elev"] * (1.0 - w) + target * w
                if w0 - 1e-9 <= p["d"] <= w1 + 1e-9:
                    clr.append(p["road_elev"] - water)
            bp["clearance_min"] = min(clr) if clr else None
            if bp["clearance_min"] is not None and \
               bp["clearance_min"] < float(bc["clearance_min_m"]) - 1e-9:
                raise GeometryError("bridge %s clearance %.2f < minimum"
                                    % (bid, bp["clearance_min"]))
        self._t("decks")

    @staticmethod
    def _at_d(pts, d):
        for i in range(len(pts) - 1):
            if pts[i]["d"] - 1e-9 <= d <= pts[i + 1]["d"] + 1e-9:
                a, b = pts[i], pts[i + 1]
                t = 0.0 if b["d"] == a["d"] else (d - a["d"]) / (b["d"] - a["d"])
                t = clamp(t, 0.0, 1.0)
                return {"d": d, "x": a["x"] + (b["x"] - a["x"]) * t,
                        "z": a["z"] + (b["z"] - a["z"]) * t,
                        "elev": a["elev"] + (b["elev"] - a["elev"]) * t}
        raise GeometryError("chainage %.2f outside stations" % d)

    # ---- phase 6: cross-section surfacing (columns -> world + normals) ----
    @staticmethod
    def _span_ok(C0, C1, skip_area=1e-9):
        for j in range(len(C0) - 1):
            A = (C0[j]["x"], C0[j]["y"], C0[j]["z"])
            B = (C1[j]["x"], C1[j]["y"], C1[j]["z"])
            Cc = (C1[j + 1]["x"], C1[j + 1]["y"], C1[j + 1]["z"])
            D = (C0[j + 1]["x"], C0[j + 1]["y"], C0[j + 1]["z"])
            for (P, Q, R) in ((A, B, Cc), (A, Cc, D)):
                ux, uy, uz = Q[0] - P[0], Q[1] - P[1], Q[2] - P[2]
                vx, vy, vz = R[0] - P[0], R[1] - P[1], R[2] - P[2]
                nx = uy * vz - uz * vy
                ny = uz * vx - ux * vz
                nz = ux * vy - uy * vx
                area = math.sqrt(nx * nx + ny * ny + nz * nz) / 2.0
                if area > skip_area and ny <= 0:
                    return False
        return True

    def _window_ok(self, eid, pts, a, b, scale):
        meta = self.edge_meta[eid]
        nmin = float(self.gc["mesh_quality"]["normal_up_min_y"])
        old = [pts[k].get("squeeze", 1.0) for k in range(a, b + 1)]
        for k in range(a, b + 1):
            pts[k]["squeeze"] = scale
        try:
            C = [station_cols(meta["columns"], meta["lift"], meta["crown"],
                              meta["fall"], pts[k], nmin)
                 for k in range(max(0, a - 1), min(len(pts), b + 2))]
        finally:
            for t, k in enumerate(range(a, b + 1)):
                pts[k]["squeeze"] = old[t]
        skip_area = float(self.gc["mesh_rules"]["skip_area_m2"])
        for r in range(len(C) - 1):
            if not self._span_ok(C[r], C[r + 1], skip_area):
                return False
        return True

    def _surf_station(self, eid, p):
        meta = self.edge_meta[eid]
        try:
            return station_cols(meta["columns"], meta["lift"], meta["crown"],
                                meta["fall"], p,
                                float(self.gc["mesh_quality"]["normal_up_min_y"]))
        except GeometryError as ex:
            raise GeometryError("%s at %s d=%.1f" % (ex, eid, p["d"]))

    def phase_surface(self):
        self._t("surface")
        mz = self.gc["miter_squeeze"]
        thresh = float(mz["defl_thresh_deg"])
        hwf = float(mz["hw_factor"])
        floor = float(mz["floor"])
        self.squeezes = []
        for eid in sorted(self.edge_st):
            pts = self.edge_st[eid]
            hw = self.roads["edges"][eid]["width_m"] / 2.0
            # re-grade on road_elev (decks differ from terrain profile)
            for i, p in enumerate(pts):
                a = pts[max(0, i - 1)]
                b = pts[min(len(pts) - 1, i + 1)]
                dd = b["d"] - a["d"]
                p["grade_re"] = (b["road_elev"] - a["road_elev"]) / dd if dd > 0 else 0.0
            # miter squeeze at sharp kinks (keeps ribbon from folding):
            # bisect the widest UNIFORM window scale whose spans stay
            # up-facing (same predicate as mesh emission: area>1e-12 => ny>0).
            # Windows cover the kink +-1 station (neighbors poke through the
            # kink plane at full width); overlapping windows merge; a window
            # that fails at floor grows by 1 station per side (up to +-3).
            kinks = []
            for i in range(1, len(pts) - 1):
                a, p, b = pts[i - 1], pts[i], pts[i + 1]
                vin = (p["x"] - a["x"], p["z"] - a["z"])
                vout = (b["x"] - p["x"], b["z"] - p["z"])
                rin, rout = math.hypot(*vin), math.hypot(*vout)
                if rin < 1e-9 or rout < 1e-9:
                    continue
                cosd = (vin[0] * vout[0] + vin[1] * vout[1]) / (rin * rout)
                delta = math.degrees(math.acos(clamp(cosd, -1.0, 1.0)))
                p["squeeze"] = 1.0
                if delta > thresh:
                    kinks.append((i, delta))
            wins = []
            for i, delta in kinks:
                if wins and i - wins[-1][1] <= 2:
                    wins[-1][1] = i
                    wins[-1][2].append((i, delta))
                else:
                    wins.append([i, i, [(i, delta)]])
            for w0, w1, ks in wins:
                a, b = max(1, w0 - 1), min(len(pts) - 2, w1 + 1)
                grown = 1
                while not self._window_ok(eid, pts, a, b, floor):
                    grown += 1
                    if grown > 3:
                        raise GeometryError(
                            "kink at %s d=%.0f too sharp for miter (%.1f deg)"
                            % (eid, pts[ks[0][0]]["d"], ks[0][1]))
                    a, b = max(1, w0 - grown), min(len(pts) - 2, w1 + grown)
                lo, hi = floor, 1.0
                for _ in range(40):
                    mid = (lo + hi) / 2.0
                    if self._window_ok(eid, pts, a, b, mid):
                        lo = mid
                    else:
                        hi = mid
                for k in range(a, b + 1):
                    pts[k]["squeeze"] = lo
                self.squeezes.append({"edge": eid, "d0": pts[a]["d"],
                                      "d1": pts[b]["d"], "scale": lo,
                                      "kinks": [{"d": pts[i]["d"],
                                                 "defl_deg": dl}
                                                for i, dl in ks]})
            pts[0].setdefault("squeeze", 1.0)
            pts[-1].setdefault("squeeze", 1.0)
            for p in pts:
                p["cols"] = self._surf_station(eid, p)
        self._t("surface")

    # ---- phase 7: mouths (ribbon ends at platform rims) ----
    def phase_mouths(self):
        self._t("mouths")
        nodes = self.roads["nodes"]
        for nid in sorted(self.envelopes):
            n = nodes[nid]
            R = self.envelopes[nid]
            mouths = []
            for arm in self.arms[nid]:
                eid = arm["edge"]
                pts = self.edge_st[eid]
                p = pts[0] if arm["side"] == "from" else pts[-1]
                chord = math.hypot(p["x"] - n["x"], p["z"] - n["z"])
                if abs(chord - R) > 0.5:
                    raise GeometryError(
                        "mouth of %s at %s misses rim (chord %.2f vs R %.2f)"
                        % (eid, nid, chord, R))
                g_out = p["grade_re"] if arm["side"] == "from" else -p["grade_re"]
                # arrive = travel heading INTO the node; pos = mouth position
                # angle FROM the node (opposite side; tents/sectors use pos).
                mouths.append({"edge": eid, "side": arm["side"],
                               "bearing": arm["arrive"],
                               "pos": compass(p["x"] - n["x"], p["z"] - n["z"]),
                               "x": p["x"], "z": p["z"],
                               "E": p["road_elev"] + self.edge_meta[eid]["lift"],
                               "g_out": g_out, "width": arm["width"],
                               "class": arm["class"], "access": arm["access"],
                               "station_d": p["d"]})
            mouths.sort(key=lambda m: m["bearing"])
            self.junctions[nid] = {"R": R, "mouths": mouths,
                                   "node": {"x": n["x"], "z": n["z"],
                                            "elev": n["elev"]},
                                   "type": n["type"], "degree": n["degree"]}
        self._t("mouths")

    # ---- junction platform elevation function (delegates to shared recipe) ----
    def platform_elev(self, nid, x, z):
        return platform_elev_at(self.junctions[nid], x, z)

    def _adaptive_angles(self, nid, fill_deg=5.0):
        """Rim angles: mouth positions + mouth-column angles + fill."""
        J = self.junctions[nid]
        nx, nz = J["node"]["x"], J["node"]["z"]
        col_angles = []
        for m in J["mouths"]:
            eid = m["edge"]
            pts = self.edge_st[eid]
            p = pts[0] if m["side"] == "from" else pts[-1]
            for c in p["cols"]:
                col_angles.append(compass(c["x"] - nx, c["z"] - nz))
        return adaptive_angles((nx, nz), J["R"], J["mouths"], col_angles, fill_deg)

    # ---- phase 8: roundabout ring functions ----
    def phase_roundabout(self):
        self._t("roundabout")
        hubs = [nid for nid, n in self.roads["nodes"].items()
                if n["type"] == "roundabout"]
        if len(hubs) != 1:
            raise GeometryError("expected exactly 1 roundabout hub")
        nid = hubs[0]
        rb = self.gc["roundabout"]
        J = self.junctions[nid]
        if abs(J["R"] - float(rb["flare_outer_R_m"])) > 1e-9:
            raise GeometryError("roundabout envelope != flare outer")
        if not (float(rb["island_R_m"]) < float(rb["ring_centerline_R_m"])
                < float(rb["outer_R_m"]) < float(rb["flare_outer_R_m"])):
            raise GeometryError("roundabout radii not nested")
        ms = sorted(J["mouths"], key=lambda m: m["bearing"])
        E_avg = sum(m["E"] for m in ms) / len(ms)
        self.roundabout = {"node": nid, "params": rb, "E_avg": E_avg,
                           "arcs": []}
        self._t("roundabout")

    def ring_angular_elev(self, theta_deg):
        """Cosine interpolation of mouth elevs around the ring."""
        nid = self.roundabout["node"]
        ms = sorted(self.junctions[nid]["mouths"], key=lambda m: m["pos"])
        return ring_angular_elev_at(ms, self.roundabout["E_avg"], theta_deg)

    def ring_elev(self, r, theta_deg):
        nid = self.roundabout["node"]
        ms = sorted(self.junctions[nid]["mouths"], key=lambda m: m["pos"])
        return ring_elev_at(self.roundabout["params"], ms,
                            self.roundabout["E_avg"], r, theta_deg)

    # ---- phase 9: turn connectors + movement table ----
    @staticmethod
    def _required_profile(accs):
        if "RESTRICTED" in accs:
            return "restricted"
        if "SERVICE" in accs:
            return "service"
        return "public"

    @staticmethod
    def _defl_type(defl):
        a = abs(defl)
        if a < 30.0:
            return "STRAIGHT"
        if a <= 100.0:
            return "RIGHT" if defl > 0 else "LEFT"
        if a <= 150.0:
            return "RIGHT" if defl > 0 else "LEFT"  # sharp, subtype notes it
        return "UTURN"

    def _bezier(self, p0, p1, p2, p3, n):
        pts = []
        for k in range(n):
            t = k / (n - 1)
            u = 1.0 - t
            pts.append([u**3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t**3 * p3[0],
                        u**3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t**3 * p3[1]])
        return pts

    def _path_radius(self, pts):
        r = float("inf")
        for i in range(1, len(pts) - 1):
            r = min(r, circum_r(pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1],
                                pts[i + 1][0], pts[i + 1][1]))
        return r

    def _crown_of(self, eid):
        return self.edge_meta[eid]["crown"]

    def phase_connectors(self):
        self._t("connectors")
        nodes = self.roads["nodes"]
        for nid in sorted(self.junctions):
            n = nodes[nid]
            if n["type"] in TERMINAL_TYPES:
                self.junctions[nid]["kind"] = "bulb"
            elif n["type"] == "gate":
                self.junctions[nid]["kind"] = "gate"
            elif n["type"] == "roundabout":
                self.junctions[nid]["kind"] = "ring"
            else:
                self.junctions[nid]["kind"] = "platform"
        for nid in sorted(self.junctions):
            if self.junctions[nid]["kind"] == "ring":
                self._rb_connectors(nid)
            else:
                self._ordinary_connectors(nid)
        self._structure_connectors()
        self._t("connectors")

    def _forecourt_loop(self, nid, P0, P3):
        """Hairpin connector: spiral in (radial->tangential), circle at
        r_loop CCW, spiral out (tangential->radial). Asymmetric easing gives
        C1 joints: spiral-in uses ease-out radius + ease-in angle; spiral-out
        mirrors. Loop radius = 0.6 * R_env (documented forecourt strategy)."""
        J = self.junctions[nid]
        nx, nz, R = J["node"]["x"], J["node"]["z"], J["R"]
        rl = R * 0.6
        d = 35.0
        b0 = compass(P0[0] - nx, P0[1] - nz)
        b1 = compass(P3[0] - nx, P3[1] - nz)
        pts = []
        for k in range(9):
            t = k / 8.0
            th = math.radians((b0 - d * t * t) % 360.0)
            rr = R + (rl - R) * (1.0 - (1.0 - t) ** 2)
            pts.append([nx + rr * math.sin(th), nz - rr * math.cos(th)])
        a0 = (b0 - d) % 360.0
        a1 = (b1 + d) % 360.0
        sweep = (a0 - a1) % 360.0
        n = max(8, int(sweep / 4.0) + 1)
        for k in range(1, n):
            th = math.radians((a0 - sweep * k / (n - 1)) % 360.0)
            pts.append([nx + rl * math.sin(th), nz - rl * math.cos(th)])
        for k in range(1, 9):
            t = k / 8.0
            th = math.radians((a1 - d * (1.0 - (1.0 - t) ** 2)) % 360.0)
            rr = rl + (R - rl) * t * t
            pts.append([nx + rr * math.sin(th), nz - rr * math.cos(th)])
        return pts

    def _ordinary_connectors(self, nid):
        J = self.junctions[nid]
        n = self.roads["nodes"][nid]
        nx, nz, R = J["node"]["x"], J["node"]["z"], J["R"]
        ms = J["mouths"]
        jtmin = {c: self.classes(c)["junction_turn_min_m"] for c in
                 set(m["class"] for m in ms)}
        pairs = [(a, b) for a in ms for b in ms if a["edge"] != b["edge"]]
        for mi, mo in pairs:
            P0 = (mi["x"], mi["z"])
            P3 = (mo["x"], mo["z"])
            u0 = norm2((nx - P0[0], nz - P0[1]))
            u1 = norm2((P3[0] - nx, P3[1] - nz))
            h0 = compass(u0[0], u0[1])
            h1 = compass(u1[0], u1[1])
            pre_d = ang_diff(h0, h1)
            if abs(pre_d) > 100.0 and J["kind"] == "platform":
                # hairpin fork: forecourt loop (spiral in, circle, spiral out)
                flat = self._forecourt_loop(nid, P0, P3)
            else:
                dist = math.hypot(P3[0] - P0[0], P3[1] - P0[1])
                k = clamp(dist / 3.0, 5.0, R)
                P1 = (P0[0] + u0[0] * k, P0[1] + u0[1] * k)
                P2 = (P3[0] - u1[0] * k, P3[1] - u1[1] * k)
                flat = self._bezier(P0, P1, P2, P3, 17)
            ci, co = self._crown_of(mi["edge"]), self._crown_of(mo["edge"])
            pts = [[x, z, self.platform_elev(nid, x, z)
                    + ci + (co - ci) * (k2 / (len(flat) - 1))]
                   for k2, (x, z) in enumerate(flat)]
            radius = self._path_radius(flat)
            h_in = compass(flat[1][0] - flat[0][0], flat[1][1] - flat[0][1])
            h_out = compass(flat[-1][0] - flat[-2][0], flat[-1][1] - flat[-2][1])
            defl = ang_diff(h_in, h_out)
            tun = self.roads["edges"][mi["edge"]]["tunnel"] or \
                self.roads["edges"][mo["edge"]]["tunnel"]
            if n["type"] == "merge" and n["degree"] == 2:
                typ = "MERGE"
            elif tun:
                typ = "TUNNEL_TRANSITION"
            else:
                typ = self._defl_type(defl)
            if tun:
                base = float(self.gc["turn_movements"]["portal_turn_min_m"])
            else:
                base = max(jtmin[mi["class"]], jtmin[mo["class"]])
            # hairpins (|defl|>140) are crawl maneuvers judged at half minimum
            need = base / 2.0 if abs(defl) > 140.0 else base
            ok = radius >= need
            cid = "CN-%s-%s-to-%s" % (nid, mi["edge"], mo["edge"])
            self.connectors[cid] = {
                "id": cid, "junction": nid, "from_edge": mi["edge"],
                "to_edge": mo["edge"], "type": typ,
                "subtype": self._defl_type(defl),
                "construction": "loop" if abs(pre_d) > 100.0 and J["kind"] == "platform" else "bezier",
                "entry_bearing": h_in, "exit_bearing": h_out,
                "deflection_deg": defl, "turn_radius": radius,
                "sample_count": len(pts), "access": self._required_profile(
                    [mi["access"], mo["access"]]),
                "allowed": ok, "reason": None if ok else
                "radius %.1f < class minimum %.1f" % (radius, need),
                "width_in": mi["width"], "width_out": mo["width"], "pts": pts}
            self.movements.append({
                "junction_id": nid, "incoming_edge": mi["edge"],
                "outgoing_edge": mo["edge"], "movement": typ,
                "allowed": ok, "connector_id": cid, "turn_radius": radius,
                "access": self._required_profile([mi["access"], mo["access"]]),
                "priority": n.get("priority")})
        # U-turns (semicircle bulbs on the platform / bulb / gate disc)
        for m in ms:
            P0 = (m["x"], m["z"])
            u0 = norm2((nx - P0[0], nz - P0[1]))
            e2 = (u0[1], -u0[0])
            jt = jtmin[m["class"]]
            if J["kind"] == "bulb":
                r_u = jt / 2.0 + 1.0
            else:
                r_u = min(max(m["width"] / 2.0 + 3.0, jt / 2.0 + 1.0), R - 3.0)
            O = (P0[0] + r_u * e2[0], P0[1] + r_u * e2[1])
            flat = []
            for k2 in range(13):
                ph = -math.pi / 2.0 + math.pi * k2 / 12.0
                flat.append([O[0] + r_u * (math.cos(ph) * u0[0] + math.sin(ph) * e2[0]),
                             O[1] + r_u * (math.cos(ph) * u0[1] + math.sin(ph) * e2[1])])
            c = self._crown_of(m["edge"])
            pts = [[x, z, self.platform_elev(nid, x, z) + c] for x, z in flat]
            radius = self._path_radius(flat)
            ok = radius >= jt / 2.0
            cid = "CN-%s-%s-UTURN" % (nid, m["edge"])
            self.connectors[cid] = {
                "id": cid, "junction": nid, "from_edge": m["edge"],
                "to_edge": m["edge"], "type": "UTURN", "subtype": "UTURN",
                "entry_bearing": compass(u0[0], u0[1]),
                "exit_bearing": compass(-u0[0], -u0[1]),
                "deflection_deg": 180.0, "turn_radius": radius,
                "sample_count": len(pts), "access": self._required_profile([m["access"]]),
                "allowed": ok, "reason": None if ok else
                "requires multi-point turn (single-arc radius %.1f < %.1f)"
                % (radius, jt / 2.0),
                "width_in": m["width"], "width_out": m["width"], "pts": pts}
            self.movements.append({
                "junction_id": nid, "incoming_edge": m["edge"],
                "outgoing_edge": m["edge"], "movement": "UTURN",
                "allowed": ok, "connector_id": cid, "turn_radius": radius,
                "access": self._required_profile([m["access"]]),
                "priority": n.get("priority")})

    def _polar(self, nid, r, theta_deg):
        J = self.junctions[nid]
        x, z = polar_at(J["node"]["x"], J["node"]["z"], r, theta_deg)
        return [x, z]

    def _rb_connectors(self, nid):
        J = self.junctions[nid]
        n = self.roads["nodes"][nid]
        rb = self.gc["roundabout"]
        rc = float(rb["ring_centerline_R_m"])
        ms = sorted(J["mouths"], key=lambda m: m["pos"])
        SW = float(self.gc["roundabout"]["join_offset_deg"])
        legs = {}  # edge -> {entry:{...}, exit:{...}} (per arm, shared by pairs)
        for m in ms:
            thi = (m["pos"] - SW) % 360.0
            tho = (m["pos"] + SW) % 360.0
            # Entry/exit are beziers: arm tangent at the mouth, ring tangent
            # at the join (CCW travel => tangent (-cos th, -sin th)).
            P0 = [m["x"], m["z"]]
            Ji = self._polar(nid, rc, thi)
            Jo = self._polar(nid, rc, tho)
            u0 = norm2([J["node"]["x"] - P0[0], J["node"]["z"] - P0[1]])
            u1 = norm2([P0[0] - J["node"]["x"], P0[1] - J["node"]["z"]])
            ti = norm2([-math.cos(math.radians(thi)), -math.sin(math.radians(thi))])
            to = norm2([-math.cos(math.radians(tho)), -math.sin(math.radians(tho))])
            ki = clamp(math.hypot(Ji[0] - P0[0], Ji[1] - P0[1]) / 3.0, 4.0, 12.0)
            ko = clamp(math.hypot(P0[0] - Jo[0], P0[1] - Jo[1]) / 3.0, 4.0, 12.0)
            ein = self._bezier(P0, [P0[0] + u0[0] * ki, P0[1] + u0[1] * ki],
                               [Ji[0] - ti[0] * ki, Ji[1] - ti[1] * ki], Ji, 11)
            eout = self._bezier(Jo, [Jo[0] + to[0] * ko, Jo[1] + to[1] * ko],
                                [P0[0] - u1[0] * ko, P0[1] - u1[1] * ko], P0, 11)
            c = self._crown_of(m["edge"])
            ein3 = [[x, z, self.ring_elev(math.hypot(x - J["node"]["x"], z - J["node"]["z"]),
                                          compass(x - J["node"]["x"], z - J["node"]["z"]))
                     + c * (1.0 - k2 / (len(ein) - 1))] for k2, (x, z) in enumerate(ein)]
            eout3 = [[x, z, self.ring_elev(math.hypot(x - J["node"]["x"], z - J["node"]["z"]),
                                           compass(x - J["node"]["x"], z - J["node"]["z"]))
                      + c * (k2 / (len(eout) - 1))] for k2, (x, z) in enumerate(eout)]
            rin, rout = self._path_radius(ein), self._path_radius(eout)
            jt = float(self.gc["roundabout"]["entry_turn_min_m"])
            ok_in, ok_out = rin >= jt, rout >= jt
            prof = self._required_profile([m["access"]])
            h_in = compass(ein[1][0] - ein[0][0], ein[1][1] - ein[0][1])
            h_out = compass(eout[-1][0] - eout[-2][0], eout[-1][1] - eout[-2][1])
            cid_in = "CN-%s-%s-ENTRY" % (nid, m["edge"])
            cid_out = "CN-%s-%s-EXIT" % (nid, m["edge"])
            self.connectors[cid_in] = {
                "id": cid_in, "junction": nid, "from_edge": m["edge"],
                "to_edge": "RING", "type": "ROUNDABOUT_ENTRY",
                "subtype": "ENTRY", "entry_bearing": h_in,
                "exit_bearing": h_in, "deflection_deg": 0.0,
                "turn_radius": rin, "sample_count": len(ein3),
                "access": prof, "allowed": ok_in, "reason": None if ok_in else
                "entry radius %.1f < %.1f" % (rin, jt),
                "width_in": m["width"], "width_out": 12.0, "pts": ein3}
            self.connectors[cid_out] = {
                "id": cid_out, "junction": nid, "from_edge": "RING",
                "to_edge": m["edge"], "type": "ROUNDABOUT_EXIT",
                "subtype": "EXIT", "entry_bearing": h_out,
                "exit_bearing": h_out, "deflection_deg": 0.0,
                "turn_radius": rout, "sample_count": len(eout3),
                "access": prof, "allowed": ok_out, "reason": None if ok_out else
                "exit radius %.1f < %.1f" % (rout, jt),
                "width_in": 12.0, "width_out": m["width"], "pts": eout3}
            legs[m["edge"]] = {"thi": thi, "tho": tho, "cid_in": cid_in,
                               "cid_out": cid_out, "ok_in": ok_in,
                               "ok_out": ok_out, "rin": rin, "rout": rout}
        for mi in ms:
            for mo in ms:
                thi = legs[mi["edge"]]["thi"]
                tho = legs[mo["edge"]]["tho"]
                sweep = (thi - tho) % 360.0
                if mi["edge"] == mo["edge"]:
                    sweep = 360.0 - 2 * SW  # full circle minus spirals
                narc = max(8, int(sweep / 4.0) + 1)
                arc = [self._polar(nid, rc, (thi - sweep * k2 / (narc - 1)) % 360.0)
                       for k2 in range(narc)]
                arc3 = [[x, z, self.ring_elev(rc, compass(x - J["node"]["x"], z - J["node"]["z"]))]
                        for x, z in arc]
                # chain exactness: entry end == arc start, arc end == exit start
                ein3 = self.connectors[legs[mi["edge"]]["cid_in"]]["pts"]
                eout3 = self.connectors[legs[mo["edge"]]["cid_out"]]["pts"]
                arc3[0][0], arc3[0][1], arc3[0][2] = ein3[-1]
                arc3[-1][0], arc3[-1][1], arc3[-1][2] = eout3[0]
                ok = legs[mi["edge"]]["ok_in"] and legs[mo["edge"]]["ok_out"]
                prof = self._required_profile([mi["access"], mo["access"]])
                self.roundabout["arcs"].append({
                    "from_edge": mi["edge"], "to_edge": mo["edge"],
                    "sweep_deg": sweep,
                    "entry_cid": legs[mi["edge"]]["cid_in"],
                    "exit_cid": legs[mo["edge"]]["cid_out"],
                    "allowed": ok, "pts": arc3})
                self.movements.append({
                    "junction_id": nid, "incoming_edge": mi["edge"],
                    "outgoing_edge": mo["edge"],
                    "movement": "UTURN" if mi["edge"] == mo["edge"] else "ROUNDABOUT",
                    "allowed": ok,
                    "connector_id": [legs[mi["edge"]]["cid_in"],
                                     legs[mo["edge"]]["cid_out"]],
                    "turn_radius": min(legs[mi["edge"]]["rin"], legs[mo["edge"]]["rout"]),
                    "access": prof, "priority": n.get("priority")})

    def _structure_connectors(self):
        # along-edge structure transitions (from_edge == to_edge by design)
        for bid, bp in sorted(self.bridges.items()):
            eid = bp["edge"]
            pts = self.edge_st[eid]
            e = self.roads["edges"][eid]
            sub0 = [p for p in pts if bp["appr0"] - 1e-9 <= p["d"] <= bp["wet1"] + 1e-9]
            sub1 = [p for p in pts if bp["wet0"] - 1e-9 <= p["d"] <= bp["appr1"] + 1e-9]
            for tag, sub in (("ENTER", sub0), ("EXIT", sub1)):
                c = self._crown_of(eid)
                path = [[p["x"], p["z"], p["road_elev"]
                         + self.edge_meta[eid]["lift"] + c] for p in sub]
                cid = "CN-%s-%s" % (bid, tag)
                r = self._path_radius([[p["x"], p["z"]] for p in sub])
                self.connectors[cid] = {
                    "id": cid, "junction": None, "from_edge": eid, "to_edge": eid,
                    "type": "BRIDGE_TRANSITION", "subtype": tag,
                    "entry_bearing": None, "exit_bearing": None,
                    "deflection_deg": 0.0, "turn_radius": r,
                    "sample_count": len(path), "access": self._required_profile([e["access"]]),
                    "allowed": True, "reason": None,
                    "width_in": e["width_m"], "width_out": e["width_m"],
                    "pts": path, "structure": bid}
                self.movements.append({
                    "junction_id": None, "incoming_edge": eid, "outgoing_edge": eid,
                    "movement": "BRIDGE_TRANSITION", "allowed": True,
                    "connector_id": cid, "turn_radius": r,
                    "access": self._required_profile([e["access"]]),
                    "priority": None, "structure": bid})
        te = [eid for eid, e in self.roads["edges"].items() if e["tunnel"]]
        for eid in te:
            pts = self.edge_st[eid]
            e = self.roads["edges"][eid]
            pt = float(self.gc["tunnel"]["portal_transition_m"])
            L = e["length_m"]
            spans = [("PORTAL_E", self.edge_meta[eid]["d0"], pt),
                     ("PORTAL_W", L - pt, self.edge_meta[eid]["d1"])]
            for tag, a, b in spans:
                sub = [p for p in pts if a - 1e-9 <= p["d"] <= b + 1e-9]
                c = self._crown_of(eid)
                path = [[p["x"], p["z"], p["road_elev"]
                         + self.edge_meta[eid]["lift"] + c] for p in sub]
                cid = "CN-TUNNEL-%s" % tag
                r = self._path_radius([[p["x"], p["z"]] for p in sub])
                self.connectors[cid] = {
                    "id": cid, "junction": None, "from_edge": eid, "to_edge": eid,
                    "type": "TUNNEL_TRANSITION", "subtype": tag,
                    "entry_bearing": None, "exit_bearing": None,
                    "deflection_deg": 0.0, "turn_radius": r,
                    "sample_count": len(path), "access": self._required_profile([e["access"]]),
                    "allowed": True, "reason": None,
                    "width_in": e["width_m"], "width_out": e["width_m"],
                    "pts": path, "structure": "TN-RING-HW-NORTH-TUNNEL"}
                self.movements.append({
                    "junction_id": None, "incoming_edge": eid, "outgoing_edge": eid,
                    "movement": "TUNNEL_TRANSITION", "allowed": True,
                    "connector_id": cid, "turn_radius": r,
                    "access": self._required_profile([e["access"]]),
                    "priority": None, "structure": "TN-RING-HW-NORTH-TUNNEL"})

    # ---- phase 10: tunnel cover ----
    def phase_tunnel_cover(self):
        self._t("tunnel")
        te = [eid for eid, e in self.roads["edges"].items() if e["tunnel"]]
        assert len(te) == 1
        eid = te[0]
        covers = []
        for p in self.edge_st[eid]:
            cover = p["terrain"] - p["road_elev"]
            covers.append(cover)
            if p["structure"] == "TUNNEL" and cover < 0.5:
                raise GeometryError("bore daylights at d=%.0f (cover %.2f)"
                                    % (p["d"], cover))
        e = self.roads["edges"][eid]
        self.tunnel = {"edge": eid, "cover_min": min(covers),
                       "cover_max": max(covers),
                       "portal_E_node": e["from_node"],
                       "portal_W_node": e["to_node"],
                       "portal_transition_m": float(self.gc["tunnel"]["portal_transition_m"])}
        self._t("tunnel")

    # ---- phase 11: sectors ----
    def sector_id(self, x, z):
        s = self.gc["sectors"]
        ix = math.floor((x - float(s["grid_min_m"])) / float(s["size_m"]))
        iz = math.floor((z - float(s["grid_min_m"])) / float(s["size_m"]))
        return "SX%02dZ%02d" % (ix, iz)

    def phase_sectors(self):
        self._t("sectors")
        for eid in sorted(self.edge_st):
            pts = self.edge_st[eid]
            secs = [self.sector_id(p["x"], p["z"]) for p in pts]
            run, start = secs[0], 0
            for i in range(1, len(pts) + 1):
                if i == len(pts) or secs[i] != run:
                    self.fragments.append({
                        "kind": "ribbon", "edge": eid, "sector": run,
                        "s0": start, "s1": i - 1, "n": i - start})
                    if i < len(pts):
                        run, start = secs[i], i
            # boundary probes: exact grid-line crossings + quad ownership rule
            s = self.gc["sectors"]
            size, gmin = float(s["size_m"]), float(s["grid_min_m"])
            for i in range(len(pts) - 1):
                a, b = pts[i], pts[i + 1]
                if secs[i] == secs[i + 1]:
                    continue
                cand = []
                for axis in (0, 1):
                    va, vb = (a["x"], b["x"]) if axis == 0 else (a["z"], b["z"])
                    ka0 = math.floor((va - gmin) / size)
                    ka1 = math.floor((vb - gmin) / size)
                    if ka0 != ka1 and vb != va:
                        line = gmin + max(ka0, ka1) * size
                        t = (line - va) / (vb - va)
                        if 0.0 <= t <= 1.0:
                            cand.append((t, axis, line))
                if not cand:
                    continue
                cand.sort()
                t, axis, line = cand[0]
                self.fragments.append({
                    "kind": "seam_probe", "edge": eid,
                    "sector_a": secs[i], "sector_b": secs[i + 1],
                    "station_i": i, "t": t, "axis": axis, "line": line,
                    "d_star": a["d"] + (b["d"] - a["d"]) * t,
                    "x": a["x"] + (b["x"] - a["x"]) * t,
                    "z": a["z"] + (b["z"] - a["z"]) * t})
        for nid in sorted(self.junctions):
            J = self.junctions[nid]
            nx, nz, R = J["node"]["x"], J["node"]["z"], J["R"]
            root = self.sector_id(nx, nz)
            over = set()
            for sx in (nx - R, nx + R):
                for sz in (nz - R, nz + R):
                    over.add(self.sector_id(sx, sz))
            self.fragments.append({
                "kind": "junction", "node": nid, "sector": root,
                "sectors_overlapped": sorted(over),
                "crosses_boundary": len(over) > 1})
        self._t("sectors")

    # ---- phase 12: reservations ----
    def phase_reservations(self):
        self._t("reservations")
        rv = self.gc["reservations"]
        for eid in sorted(self.edge_st):
            e = self.roads["edges"][eid]
            meta = self.edge_meta[eid]
            hw = e["width_m"] / 2.0
            bands = meta["bands"]
            prof = meta["profile"]
            recs = []
            sh = bands["shoulder_width_m"]
            if sh > 0:
                recs.append(("shoulder", hw - bands["margin_width_m"] - sh,
                             hw - bands["margin_width_m"]))
            else:
                recs.append(("shoulder", hw - bands["margin_width_m"],
                             hw - bands["margin_width_m"]))
            if prof["sidewalk"]:
                sw = prof["sidewalk"]
                recs.append(("sidewalk", hw + sw["offset_m"],
                             hw + sw["offset_m"] + sw["width_m"]))
            x = hw
            recs.append(("utility", x, x + float(rv["utility_corridor_m"])))
            x += float(rv["utility_corridor_m"])
            recs.append(("drainage", x, x + float(rv["drainage_strip_m"])))
            recs.append(("vegetation", hw, hw + float(rv["vegetation_setback_m"])))
            recs.append(("building", hw, hw + float(rv["building_setback_m"])))
            recs.append(("barrier", hw, hw + float(rv["barrier_zone_m"])))
            for kind, inner, outer in recs:
                self.reservations.append({
                    "kind": kind, "edge": eid, "side": "both",
                    "inner_off": round(inner, 6), "outer_off": round(outer, 6)})
        for nid in sorted(self.junctions):
            J = self.junctions[nid]
            self.reservations.append({
                "kind": "junction_envelope", "node": nid,
                "R": J["R"] + 3.0})
        for bid, bp in sorted(self.bridges.items()):
            e = self.roads["edges"][bp["edge"]]
            self.reservations.append({
                "kind": "bridge_envelope", "structure": bid,
                "edge": bp["edge"], "d0": bp["appr0"] - 5.0,
                "d1": bp["appr1"] + 5.0, "halfwidth": e["width_m"] / 2.0 + 3.0})
        te = self.tunnel["edge"]
        e = self.roads["edges"][te]
        pt = self.tunnel["portal_transition_m"]
        self.reservations.append({
            "kind": "tunnel_envelope", "structure": "TN-RING-HW-NORTH-TUNNEL",
            "edge": te, "spans": [[0.0, pt + 10.0],
                                  [e["length_m"] - pt - 10.0, e["length_m"]]],
            "halfwidth": e["width_m"] / 2.0 + 5.0})
        self._t("reservations")

    # ---- phase 13: lanes + handoffs ----
    def phase_handoffs(self):
        self._t("handoffs")
        # lane paths (traffic input): per-station lane centers
        for eid in sorted(self.edge_st):
            e = self.roads["edges"][eid]
            meta = self.edge_meta[eid]
            centers = self.prof.lane_centers(e["class"], e["width_m"])
            paths = []
            for off, direc in centers:
                pts = []
                for p in self.edge_st[eid]:
                    lx, lz = p["tz"], -p["tx"]
                    rise = max(0.0, meta["crown"] - abs(off) * meta["fall"])
                    pts.append([p["x"] + off * lx,
                                p["road_elev"] + meta["lift"] + rise,
                                p["z"] + off * lz])
                paths.append({"offset": off, "direction": direc, "pts": pts})
            self.lanes[eid] = paths
        edges = self.roads["edges"]
        self.nav = {
            "label": "NAVIGATION INPUT (not final navigation)",
            "edges": [{"id": eid, "from": e["from_node"], "to": e["to_node"],
                       "length_m": e["length_m"], "class": e["class"],
                       "access": e["access"], "speed_kph": e["effective_speed_kph"],
                       "grade_max": e["max_grade_short"],
                       "surface": self.edge_meta[eid]["material"]} for eid, e in sorted(edges.items())],
            "movements": [m for m in self.movements if m["allowed"]],
            "movements_all": len(self.movements),
            "structures": {
                "bridges": sorted(self.bridges),
                "tunnel": "TN-RING-HW-NORTH-TUNNEL"},
            "restricted": {
                "edges": sorted(eid for eid, e in edges.items() if e["access"] == "RESTRICTED"),
                "gates": ["gate_restricted"]},
            "pedestrian_boundaries": [
                r for r in self.reservations if r["kind"] == "sidewalk"]}
        traf = {"label": "TRAFFIC INPUT (not a traffic system)", "lanes": self.lanes,
                "movements": self.movements,
                "speeds": {eid: e["effective_speed_kph"] for eid, e in sorted(edges.items())},
                "priority": {nid: n.get("priority") for nid, n in sorted(self.roads["nodes"].items())},
                "access": {eid: e["access"] for eid, e in sorted(edges.items())},
                "classes": {eid: e["class"] for eid, e in sorted(edges.items())}}
        self.traffic = traf
        sections = []
        for eid in sorted(self.edge_st):
            e = edges[eid]
            for p in self.edge_st[eid]:
                sections.append({
                    "edge": eid, "d": p["d"], "x": p["x"],
                    "y": p["road_elev"] + self.edge_meta[eid]["lift"],
                    "z": p["z"], "yaw": compass(p["tx"], p["tz"]),
                    "halfwidth": e["width_m"] / 2.0,
                    "structure": p["structure"], "access": e["access"]})
        self.collision = {
            "label": "COLLISION INPUT (final physics baking: future prompt)",
            "status": "INPUT ONLY",
            "sections": sections,
            "discs": [{"node": nid, "x": J["node"]["x"], "z": J["node"]["z"],
                       "R": J["R"], "kind": J["kind"]} for nid, J in sorted(self.junctions.items())],
            "note": "sections+discs bound the authoritative surface; rigid-body baking not in P04"}
        self._t("handoffs")

    # ---- phase 14: export + checksum ----
    def _butt_joints(self):
        out = []
        edges = self.roads["edges"]
        for nid in sorted(self.roads["nodes"]):
            n = self.roads["nodes"][nid]
            if n["type"] in TERMINAL_TYPES and n["degree"] >= 2 \
               and nid not in self.junctions:
                arms = sorted(self.arms[nid], key=lambda a: a["edge"])
                # through pair = arms sharing a P03 route; the rest are stubs
                by_route = {}
                for a in arms:
                    by_route.setdefault(edges[a["edge"]]["route"], []).append(a)
                pairs = [v for v in by_route.values() if len(v) == 2]
                if len(pairs) != 1 or sum(len(v) for v in by_route.values()) != len(arms):
                    raise GeometryError(
                        "pass-through %s needs a real junction (%d arms, no route pair)"
                        % (nid, len(arms)))
                through = sorted(pairs[0], key=lambda a: a["edge"])
                stubs = [a for v in by_route.values() if len(v) != 2 for a in v]
                out.append({"node": nid, "edge_a": through[0]["edge"],
                            "side_a": through[0]["side"],
                            "edge_b": through[1]["edge"],
                            "side_b": through[1]["side"],
                            "stubs": [{"edge": a["edge"], "side": a["side"]}
                                      for a in sorted(stubs, key=lambda a: a["edge"])]})
        return out

    def phase_export(self):
        self._t("export")
        fill = float(self.gc["roundabout"]["mesh_fill_deg"])
        junctions = {}
        for nid in sorted(self.junctions):
            J = self.junctions[nid]
            junctions[nid] = {
                "node": J["node"], "R": J["R"], "kind": J["kind"],
                "type": J["type"], "degree": J["degree"],
                "access": self.roads["nodes"][nid]["access"],
                "mouths": J["mouths"],
                "sector_angles": self._adaptive_angles(
                    nid, fill if J["kind"] == "ring" else 5.0)}
        edges = {}
        for eid in sorted(self.edge_st):
            e = self.roads["edges"][eid]
            meta = self.edge_meta[eid]
            edges[eid] = {
                "meta": {"d0": meta["d0"], "d1": meta["d1"],
                         "columns": meta["columns"], "material": meta["material"],
                         "lift": meta["lift"], "crown": meta["crown"],
                         "fall": meta["fall"]},
                "class": e["class"], "access": e["access"],
                "width_m": e["width_m"], "length_m": e["length_m"],
                "tunnel": e["tunnel"], "route": e["route"],
                "from_node": e["from_node"], "to_node": e["to_node"],
                "stations": [{k: p[k] for k in
                              ("d", "x", "z", "elev", "road_elev", "terrain",
                               "tx", "tz", "grade", "grade_re", "structure",
                               "struct_ref", "region", "coast_d", "squeeze")}
                             for p in self.edge_st[eid]]}
        geo = {
            "meta": {
                "geometry_version": self.gc["geometry_version"],
                "profile_version": self.gc["profile_version"],
                "road_version": self.gc["road_version"],
                "terrain_version": self.gc["terrain_version_reference"],
                "coast_version": self.gc["coast_version_reference"],
                "world_version": self.gc["world_version"],
                "road_checksum": self.roads["checksum"],
                "generator": "road_geometry.py"},
            "edges": edges, "junctions": junctions,
            "roundabout": {"node": self.roundabout["node"],
                           "E_avg": self.roundabout["E_avg"],
                           "arcs": self.roundabout["arcs"]},
            "connectors": {k: (dict(v, turn_radius=None)
                               if isinstance(v, dict) and
                               isinstance(v.get("turn_radius"), float) and
                               math.isinf(v["turn_radius"]) else v)
                           for k, v in self.connectors.items()},
            "movements": [dict(m, turn_radius=None)
                          if isinstance(m.get("turn_radius"), float) and
                          math.isinf(m["turn_radius"]) else m
                          for m in self.movements],
            "bridges": self.bridges, "tunnel": self.tunnel,
            "fragments": self.fragments, "reservations": self.reservations,
            "butt_joints": self._butt_joints(),
            "fillets": self.fillets}
        mesh, steep, contested_all = build_mesh(geo, self.gc)
        lips = self._classify_lips(geo, mesh, steep, contested_all)
        cuts = self._cut_inventory(geo)
        deck_edges = self._deck_edge_inventory(geo)
        nv = sum(len(p["verts"]) for p in mesh)
        nt = sum(len(p["tris"]) for p in mesh)
        digest = self._checksum(geo, mesh)
        geo["mesh_counts"] = {"parts": len(mesh), "verts": nv, "tris": nt}
        geo["parts"] = mesh
        geo["lips"] = lips
        geo["contested"] = contested_all
        geo["cuts"] = cuts
        geo["deck_edges"] = deck_edges
        geo["checksum"] = digest
        json.dump(geo, open(GEO_JSON, "w"), indent=1)
        json.dump(self.nav, open(NAV_JSON, "w"), indent=1)
        json.dump(self.traffic, open(TRAFFIC_JSON, "w"), indent=1)
        json.dump(self.collision, open(COLLISION_JSON, "w"), indent=1)
        self.geo = geo
        self.mesh = mesh
        self._t("export")

    def _classify_lips(self, geo, mesh, steep, contested_all):
        skirts = {p["id"]: set(p.get("skirt", [])) for p in mesh}
        tun_edges = {eid for eid, E in geo["edges"].items() if E["tunnel"]}
        lips = []
        for ctx, tri, nyu, area, h, pa in steep:
            if any(i in skirts.get(ctx, set()) for i in tri):
                continue  # skirt wall face, not a lip
            nid = None
            for pre in ("platform-", "ring-", "gore-", "butt-", "ribbon-",
                        "island-"):
                if ctx.startswith(pre):
                    nid = ctx[len(pre):]
                    break
            cls = None
            if h <= 0.05:
                cls = "curb"
            elif nid in contested_all:
                cls = "gore" if h <= 1.0 else None
            if cls is None and nid is not None:
                J = geo["junctions"].get(nid)
                if J is not None and any(
                        m["edge"] in tun_edges or
                        geo["edges"][m["edge"]]["tunnel"]
                        for m in J["mouths"]):
                    cls = "retained" if h <= 5.0 else None
                elif nid in contested_all and h <= 1.0:
                    cls = "gore"
            if cls is None:
                # butt-node lips inherit the through-edge context: trailhead
                # cutting lips are gore-class (bounded, open terrain behind)
                if ctx.startswith("butt-") and h <= 1.0:
                    cls = "gore"
            if cls is None:
                raise GeometryError(
                    "unclassified steep face in %s tri %s h=%.3f "
                    "(defect: not curb/gore/retained)" % (ctx, tri, h))
            lips.append({"part": ctx, "tri": tri, "class": cls,
                         "ny": nyu, "area": area, "height": h,
                         "plan_area": pa})
        return lips

    def _cut_inventory(self, geo):
        cuts = []
        for eid in sorted(geo["edges"]):
            E = geo["edges"][eid]
            if E["tunnel"]:
                continue  # bore: lining scope, not cutting
            run, runs = [], []
            for p in E["stations"]:
                c = p["terrain"] - p["road_elev"]
                if c > 0.3:
                    run.append((p["d"], c))
                elif run:
                    runs.append(run)
                    run = []
            if run:
                runs.append(run)
            for r in runs:
                cuts.append({"edge": eid, "d0": r[0][0], "d1": r[-1][0],
                             "max_depth": max(c for _, c in r),
                             "class": "cutting"})
        for nid in sorted(geo["junctions"]):
            J = geo["junctions"][nid]
            n = self.roads["nodes"][nid]
            sect = J["sector_angles"]
            prof = self.prof.columns(
                geo["edges"][J["mouths"][0]["edge"]]["class"],
                geo["edges"][J["mouths"][0]["edge"]]["width_m"]) \
                if J["mouths"] else None
            depths = []
            for a in sect:
                for rr in (0.0, J["R"] / 2.0, J["R"]):
                    import math as _m
                    x = n["x"] + rr * _m.cos(_m.radians(a))
                    z = n["z"] + _m.sin(_m.radians(a)) * rr
                    depths.append(self.f.height(x, z))
            # junction cut vs platform elev: use mouth road_elev min
            if J["mouths"]:
                pe = min(self._mouth_elev(geo, m) for m in J["mouths"])
                md = max(depths) - pe
                if md > 0.3:
                    cuts.append({"node": nid, "max_depth": md,
                                 "class": "cutting"})
        return cuts

    def _mouth_elev(self, geo, m):
        E = geo["edges"][m["edge"]]
        st = E["stations"]
        p = st[-1] if m["side"] == "to" else st[0]
        return p["road_elev"]

    def _deck_edge_inventory(self, geo):
        out = []
        for bid, b in sorted(self.bridges.items()):
            out.append({"bridge": bid, "edge": b["edge"],
                        "d0": b["wet0"], "d1": b["wet1"],
                        "sides": ["left", "right"],
                        "scope": "P05 parapet/fascia"})
        return out

    def _checksum(self, geo, mesh):
        a = []
        m = geo["meta"]
        a.append("geo=%s prof=%s road=%s terra=%s coast=%s world=%s rchk=%s" % (
            m["geometry_version"], m["profile_version"], m["road_version"],
            m["terrain_version"], m["coast_version"], m["world_version"],
            m["road_checksum"]))
        for eid in sorted(geo["edges"]):
            E = geo["edges"][eid]
            a.append("E|%s|%s|%s|%s|%d|%d|%d|%d|%s|%s|%s|%s" % (
                eid, E["class"], E["access"], E["route"], q(E["width_m"] * 10),
                q(E["length_m"] * 1000), q(E["meta"]["d0"] * 1000),
                q(E["meta"]["d1"] * 1000), E["from_node"], E["to_node"],
                E["meta"]["material"], "T" if E["tunnel"] else "S"))
            for i, p in enumerate(E["stations"]):
                a.append("S|%s|%d|%d|%d|%d|%d|%d|%d|%d|%s|%s|%s" % (
                    eid, i, q(p["d"] * 1000), q(p["x"] * 1000), q(p["z"] * 1000),
                    q(p["road_elev"] * 1000), q(p["terrain"] * 1000),
                    q(p["grade_re"] * 1000000), q(p["coast_d"] * 1000),
                    p["structure"], p["struct_ref"] or "-", p["region"]))
        for nid in sorted(geo["junctions"]):
            J = geo["junctions"][nid]
            a.append("J|%s|%d|%s|%s|%d|%d" % (
                nid, q(J["R"] * 100), J["kind"], J["type"],
                q(J["node"]["x"] * 1000), q(J["node"]["z"] * 1000)))
            for mo in J["mouths"]:
                a.append("M|%s|%s|%s|%d|%d|%d|%d|%d|%d|%s|%s" % (
                    nid, mo["edge"], mo["side"], q(mo["bearing"] * 1000),
                    q(mo["pos"] * 1000), q(mo["x"] * 1000), q(mo["z"] * 1000),
                    q(mo["E"] * 1000), q(mo["g_out"] * 1000000),
                    mo["class"], mo["access"]))
            for an in J["sector_angles"]:
                a.append("A|%s|%d" % (nid, q(an * 1000000)))
        for cid in sorted(geo["connectors"]):
            c = geo["connectors"][cid]
            a.append("C|%s|%s|%s|%s|%s|%d|%d|%d" % (
                cid, c["junction"] or "-", c["from_edge"], c["to_edge"],
                c["type"], 1 if c["allowed"] else 0,
                q(min(c["turn_radius"] if c["turn_radius"] is not None
                        else 1e6, 1e6) * 100), c["sample_count"]))
            for pt in c["pts"]:
                a.append("P|%s|%d|%d|%d" % (
                    cid, q(pt[0] * 1000), q(pt[2] * 1000), q(pt[1] * 1000)))
        for arc in sorted(geo["roundabout"]["arcs"],
                          key=lambda r: (r["from_edge"], r["to_edge"])):
            a.append("R|%s|%s|%d|%d" % (
                arc["from_edge"], arc["to_edge"], q(arc["sweep_deg"] * 1000),
                1 if arc["allowed"] else 0))
            for pt in arc["pts"]:
                a.append("Q|%s|%s|%d|%d|%d" % (
                    arc["from_edge"], arc["to_edge"], q(pt[0] * 1000),
                    q(pt[2] * 1000), q(pt[1] * 1000)))
        for bid in sorted(geo["bridges"]):
            b = geo["bridges"][bid]
            a.append("B|%s|%s|%s|%d|%d|%d|%d|%d|%d" % (
                bid, b["edge"], b["water"], q(b["wet0"] * 1000),
                q(b["wet1"] * 1000), q(b["appr0"] * 1000), q(b["appr1"] * 1000),
                q(b["water_est"] * 1000), q(b["clearance_min"] * 1000)))
        t = geo["tunnel"]
        a.append("T|%s|%d|%d|%s|%s" % (
            t["edge"], q(t["cover_min"] * 1000), q(t["cover_max"] * 1000),
            t["portal_E_node"], t["portal_W_node"]))
        for f in geo["fragments"]:
            if f["kind"] == "ribbon":
                a.append("F|r|%s|%s|%d|%d" % (
                    f["edge"], f["sector"], f["s0"], f["s1"]))
            elif f["kind"] == "seam_probe":
                a.append("F|s|%s|%s|%s|%d" % (
                    f["edge"], f["sector_a"], f["sector_b"], f["station_i"]))
            else:
                a.append("F|j|%s|%s|%d" % (
                    f["node"], f["sector"], 1 if f["crosses_boundary"] else 0))
        for mv in sorted(geo["movements"],
                         key=lambda r: (r["junction_id"] or "-",
                                        r["incoming_edge"], r["outgoing_edge"])):
            a.append("V|%s|%s|%s|%s|%d" % (
                mv["junction_id"] or "-", mv["incoming_edge"],
                mv["outgoing_edge"], mv["movement"], 1 if mv["allowed"] else 0))
        for bj in geo.get("butt_joints", []):
            a.append("U|%s|%s|%s" % (bj["node"], bj["edge_a"], bj["edge_b"]))
        canon_a = ";".join(a) + ";"
        b = []
        for part in sorted(mesh, key=lambda p: p["id"]):
            b.append("P|%s|%s|%s|%d|%d|%s|%s" % (
                part["id"], part["kind"], part["ref"], len(part["verts"]),
                len(part["tris"]), part["semantic"].get("material", "-"),
                part["semantic"].get("access", "-")))
            for v in part["verts"]:
                b.append("V|%d|%d|%d|%d|%d|%d" % (
                    q(v[0] * 1000), q(v[1] * 1000), q(v[2] * 1000),
                    q(v[3] * 10000), q(v[4] * 10000), q(v[5] * 10000)))
            for t3 in part["tris"]:
                b.append("I|%d|%d|%d" % (t3[0], t3[1], t3[2]))
        canon_m = ";".join(b) + ";"
        return {"analytic": fnv1a_hex(canon_a), "mesh": fnv1a_hex(canon_m),
                "geometry": fnv1a_hex(canon_a + "|MESH|" + canon_m)}

    def build_all(self):
        for ph in ("pins", "arms", "envelopes", "stations", "decks", "surface",
                   "mouths", "roundabout", "connectors", "tunnel_cover",
                   "sectors", "reservations", "handoffs", "export"):
            getattr(self, "phase_" + ph)()
        return self.timers


class RoadGeometryQuery:
    """Future-safe query API (§45) over exported geometry + handoffs."""

    def __init__(self, geo, traffic=None):
        self.geo = geo
        self.traffic = traffic

    def _stations(self):
        for eid in sorted(self.geo["edges"]):
            E = self.geo["edges"][eid]
            for i, p in enumerate(E["stations"]):
                yield eid, E, i, p

    def junction_at(self, x, z):
        best = None
        for nid in sorted(self.geo["junctions"]):
            J = self.geo["junctions"][nid]
            d = math.hypot(x - J["node"]["x"], z - J["node"]["z"])
            if d <= J["R"] and (best is None or d < best[1]):
                best = (nid, d)
        return best[0] if best else None

    def nearest_road_surface(self, x, z):
        nid = self.junction_at(x, z)
        if nid is not None:
            J = self.geo["junctions"][nid]
            return {"kind": "junction", "node": nid, "x": x, "z": z,
                    "distance": 0.0}
        best = None
        for eid, E, i, p in self._stations():
            d = math.hypot(x - p["x"], z - p["z"])
            if best is None or d < best[0]:
                best = (d, eid, E, i, p)
        d, eid, E, i, p = best
        return {"kind": "ribbon", "edge": eid, "station": i, "x": p["x"],
                "z": p["z"], "distance": d}

    def road_surface_height(self, x, z):
        nid = self.junction_at(x, z)
        if nid is not None:
            J = self.geo["junctions"][nid]
            if J["kind"] == "ring":
                ms = sorted(J["mouths"], key=lambda m: m["pos"])
                rb = {"flare_outer_R_m": 37.0}
                r = math.hypot(x - J["node"]["x"], z - J["node"]["z"])
                return ring_elev_at(rb, ms, self.geo["roundabout"]["E_avg"], r,
                                    compass(x - J["node"]["x"], z - J["node"]["z"]))
            return platform_elev_at(J, x, z)
        best = min(self._stations(),
                   key=lambda t: math.hypot(x - t[3]["x"], z - t[3]["z"]))
        eid, E, i, p = best
        # lateral projection on the section line + crown leaf
        lx, lz = p["tz"], -p["tx"]
        off = (x - p["x"]) * lx + (z - p["z"]) * lz
        meta = E["meta"]
        hw_s = E["width_m"] / 2.0 * p.get("squeeze", 1.0)
        off_c = clamp(off, -hw_s, hw_s)
        rise = max(0.0, meta["crown"] - abs(off_c) * meta["fall"])
        return p["road_elev"] + meta["lift"] + rise

    def road_surface_normal(self, x, z):
        nid = self.junction_at(x, z)
        if nid is not None:
            J = self.geo["junctions"][nid]
            if J["kind"] == "ring":
                ms = sorted(J["mouths"], key=lambda m: m["pos"])
                rb = {"flare_outer_R_m": 37.0}
                fn = lambda ax, az: ring_elev_at(
                    rb, ms, self.geo["roundabout"]["E_avg"],
                    math.hypot(ax - J["node"]["x"], az - J["node"]["z"]),
                    compass(ax - J["node"]["x"], az - J["node"]["z"]))
            else:
                fn = lambda ax, az: platform_elev_at(J, ax, az)
            return surf_normal(fn, x, z)
        best = min(self._stations(),
                   key=lambda t: math.hypot(x - t[3]["x"], z - t[3]["z"]))
        eid, E, i, p = best
        cols = station_cols(E["meta"]["columns"], E["meta"]["lift"],
                            E["meta"]["crown"], E["meta"]["fall"], p)
        c = min(cols, key=lambda c: math.hypot(x - c["x"], z - c["z"]))
        return (c["nx"], c["ny"], c["nz"])

    def road_surface_width(self, eid, d):
        E = self.geo["edges"][eid]
        if not (E["stations"][0]["d"] <= d <= E["stations"][-1]["d"]):
            return None
        return E["width_m"]

    def road_edge_distance(self, x, z):
        best = float("inf")
        for eid in sorted(self.geo["edges"]):
            st = self.geo["edges"][eid]["stations"]
            for i in range(len(st) - 1):
                a, b = st[i], st[i + 1]
                dd = seg_dist(x, z, a["x"], a["z"], b["x"], b["z"])
                best = min(best, dd)
        return best

    def turn_connectors(self, nid):
        return sorted(cid for cid, c in self.geo["connectors"].items()
                      if c["junction"] == nid)

    def lane_paths(self, eid):
        if self.traffic is None:
            raise GeometryError("traffic handoff not loaded")
        return self.traffic["lanes"][eid]

    def road_surface_region(self, x, z):
        best = min(self._stations(),
                   key=lambda t: math.hypot(x - t[3]["x"], z - t[3]["z"]))
        return best[3]["region"]

    def is_road_reserved(self, x, z):
        for r in self.geo["reservations"]:
            if r["kind"] == "junction_envelope":
                J = self.geo["junctions"][r["node"]]
                if math.hypot(x - J["node"]["x"], z - J["node"]["z"]) <= r["R"]:
                    return {"reserved": True, "kind": r["kind"],
                            "ref": r["node"]}
        for eid in sorted(self.geo["edges"]):
            E = self.geo["edges"][eid]
            st = E["stations"]
            for i in range(len(st) - 1):
                a, b = st[i], st[i + 1]
                dd = seg_dist(x, z, a["x"], a["z"], b["x"], b["z"])
                if dd <= E["width_m"] / 2.0 + 10.0:
                    return {"reserved": True, "kind": "carriageway_setback",
                            "ref": eid}
        return {"reserved": False, "kind": None, "ref": None}


def main():
    t0 = time.perf_counter()
    g = RoadGeometry()
    timers = g.build_all()
    wall = time.perf_counter() - t0
    geo = g.geo
    mc = geo["mesh_counts"]
    print("geometry: %d edges %d junctions %d connectors %d fragments "
          "%d verts %d tris -> %s" % (
              len(geo["edges"]), len(geo["junctions"]), len(geo["connectors"]),
              len(geo["fragments"]), mc["verts"], mc["tris"], GEO_JSON))
    print("checksum:", geo["checksum"]["geometry"])
    print("timers:", " ".join("%s=%.2f" % (k, v) for k, v in sorted(timers.items())
                              if not k.endswith(":t0")))
    print("wall: %.2fs" % wall)


if __name__ == "__main__":
    main()
