#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 01 — foundation validation tool (independent Python layer).

Subcommands:
  static              No-engine checks: contract schema+relations, locked constants,
                      AAA record schemas, golden format. (L0/L1-data)
  cross DUMP.json     Cross-layer: GDScript registry dump vs contract JSON —
                      field equality, canonical+checksum recompute, seed recompute,
                      census goldens. (L3)
  inject              Failure injection: mutated contracts must fail loudly via
                      contract_check.gd; repo files untouched (/tmp only). (§38)
  reproduce           Determinism: two dumps must agree on canonical/checksum/
                      seeds/census/dump (timestamps excluded). (§37)
  audit-log LOG [ERR] Log audit: unexpected ERROR/FATAL fails; WARNINGs listed;
                      deliberate diag-test lines allowlisted by exact match. (§44)
  bench-macro         Cold-start wall time x5 + frame-stats x3 -> runtime_baseline.json
                      + bootstrap_baseline.json. (L5-macro)

Godot binary: $GODOT_BIN, else tools/.godot/godot, else PATH lookup.
Exit code 0 = all checks passed; 1 = failure. No fakes: every number measured.
"""
import json, os, subprocess, sys, time, shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTRACT = os.path.join(ROOT, "data/world/world_contract.json")
GOLDEN = os.path.join(ROOT, "data/world/contract_checksum.txt")
AAA_DIR = os.path.join(ROOT, "data/aaa_reference")
PASS, FAIL = "PASS", "FAIL"

# Locked constants transcribed from WORLD_MASTER_CONTRACT.md v1.0.0 + Prompt 00.
# Any revision of the locked contract updates these TOGETHER with the docs.
LOCKED = {
    "world_id": "island_strike:strike_island", "schema_version": "1.0.0",
    "world_version": "0.1.0", "contract_version": "1.0.0",
    "radius_m": 2000.0, "diameter_m": 4000.0, "origin": [0, 0, 0],
    "axes": {"east": "+X", "west": "-X", "up": "+Y", "north": "-Z", "south": "+Z"},
    "coordinate_convention": "right-handed-y-up", "ocean_level_m": 0.0,
    "terrain_min_m": -25.0, "terrain_target_max_m": 220.0,
    "terrain_absolute_cap_m": 250.0,
    "boundary": {"r_world_m": 2000.0, "r_land_m": 1950.0, "r_shore_m": 1975.0,
                 "r_beach0_m": 1850.0, "r_coast0_m": 1700.0,
                 "r_play_limit_m": 4000.0, "r_ocean_visual_m": 6000.0},
    "gps_origin_offset": [2000, 2000], "sector_size_m": 256,
    "sector_grid_min_m": -2048.0, "sector_grid_count": 16,
    "sector_status": "candidate", "master_seed": 13371337,
    "seed_scheme": "IS-SEED/1",
}
AAA_REQUIRED_KEYS = ["id", "title", "developer", "publisher", "release", "engine",
                     "world_type", "dimensions", "area", "environments", "coastal",
                     "urban", "rural", "roads", "vehicles", "pedestrian", "water",
                     "weather", "day_night", "npc", "traffic", "streaming",
                     "confidence", "lesson", "originality"]

MASK64 = (1 << 64) - 1

def fnv1a_hex(text: str) -> str:
    h = 14695981039346656037
    for b in text.encode("utf-8"):
        h = ((h ^ b) * 1099511628211) & MASK64
    return format(h, "016x")

def derive_hex(world_version, master, domain, key) -> str:
    return fnv1a_hex(f"IS-SEED/1|v={world_version}|m={master}|d={domain}|k={key}")

def checksum_core(contract: dict) -> dict:
    mm = lambda v: int(round(v * 1000))
    b = contract["boundary"]
    return {"axes": "E:+X,W:-X,U:+Y,N:-Z,S:+Z",
            "b_beach0_mm": mm(b["r_beach0_m"]), "b_coast0_mm": mm(b["r_coast0_m"]),
            "b_land_mm": mm(b["r_land_m"]), "b_ocean_mm": mm(b["r_ocean_visual_m"]),
            "b_play_mm": mm(b["r_play_limit_m"]), "b_shore_mm": mm(b["r_shore_m"]),
            "b_world_mm": mm(b["r_world_m"]),
            "contract_version": contract["contract_version"],
            "diameter_mm": mm(contract["diameter_m"]), "gps": "2000,2000",
            "grid_count": contract["sector_grid_count"],
            "grid_min_mm": mm(contract["sector_grid_min_m"]),
            "master_seed": contract["master_seed"],
            "ocean_mm": mm(contract["ocean_level_m"]), "origin": "0,0,0",
            "radius_mm": mm(contract["radius_m"]),
            "schema_version": contract["schema_version"],
            "sector_size": contract["sector_size_m"],
            "terrain_cap_mm": mm(contract["terrain_absolute_cap_m"]),
            "terrain_max_mm": mm(contract["terrain_target_max_m"]),
            "terrain_min_mm": mm(contract["terrain_min_m"]),
            "world_id": contract["world_id"],
            "world_version": contract["world_version"]}

def canonical(core: dict) -> str:
    return json.dumps(core, sort_keys=True, separators=(",", ":"), ensure_ascii=True)

def godot_bin() -> str:
    for cand in [os.environ.get("GODOT_BIN"), os.path.join(ROOT, "tools/.godot/godot"),
                 shutil.which("godot")]:
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    raise SystemExit("Godot binary not found (set GODOT_BIN or run tools/fetch_godot.py)")

def run_godot(args, timeout=180):
    cmd = [godot_bin(), "--headless", "--path", ROOT] + args
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout, p.stderr

class Tally:
    def __init__(self): self.rows = []
    def check(self, name, cond, detail=""):
        self.rows.append((name, PASS if cond else FAIL, str(detail)))
    def report(self, title):
        fails = [r for r in self.rows if r[1] == FAIL]
        print(f"{title}: {len(self.rows)-len(fails)}/{len(self.rows)} passed")
        for n, s, d in self.rows:
            print(f"  [{s}] {n}  {d}")
        return len(fails) == 0

# ---------------- static ----------------
def cmd_static():
    t = Tally()
    try:
        c = json.load(open(CONTRACT))
    except Exception as e:
        t.check("S-JSON-parse", False, e); return t.report("STATIC")
    t.check("S-JSON-parse", True)
    # FNV self-test (validates THIS tool before it validates anything else).
    t.check("S-FNV-empty", fnv1a_hex("") == "cbf29ce484222325")
    t.check("S-FNV-a", fnv1a_hex("a") == "af63dc4c8601ec8c")
    t.check("S-FNV-foobar", fnv1a_hex("foobar") == "85944171f73967e8")
    # Shape: reuse LOCKED key set as required-field oracle (independent of GDScript list).
    missing = [k for k in LOCKED if k not in c]
    t.check("S-required-keys", not missing, f"missing={missing}")
    # Types / finiteness / ranges.
    nums = ["radius_m", "diameter_m", "ocean_level_m", "terrain_min_m",
            "terrain_target_max_m", "terrain_absolute_cap_m", "sector_grid_min_m"]
    import math
    for k in nums:
        v = c.get(k)
        t.check(f"S-num:{k}", isinstance(v, (int, float)) and math.isfinite(v), v)
    for k in ["sector_size_m", "sector_grid_count", "master_seed"]:
        v = c.get(k)
        t.check(f"S-int:{k}", isinstance(v, int) and not isinstance(v, bool), v)
    for k in ["world_id", "world_name", "schema_version", "world_version",
              "contract_version", "engine_target", "coordinate_convention",
              "sector_status", "seed_scheme"]:
        v = c.get(k)
        t.check(f"S-str:{k}", isinstance(v, str) and len(v) > 0, v)
    # Relations.
    try:
        t.check("S-rel-diameter", c["diameter_m"] == 2 * c["radius_m"])
        t.check("S-rel-radius-pos", c["radius_m"] > 0)
        b = c["boundary"]
        t.check("S-rel-world-eq", b["r_world_m"] == c["radius_m"])
        t.check("S-rel-nest", b["r_coast0_m"] < b["r_beach0_m"] < b["r_land_m"]
                < b["r_shore_m"] <= b["r_world_m"])
        t.check("S-rel-play", b["r_play_limit_m"] > b["r_world_m"])
        t.check("S-rel-visual", b["r_ocean_visual_m"] >= b["r_play_limit_m"])
        t.check("S-rel-terrain", c["terrain_min_m"] < 0 < c["terrain_target_max_m"]
                <= c["terrain_absolute_cap_m"])
        t.check("S-rel-status", c["sector_status"] == "candidate")
        t.check("S-rel-scheme", c["seed_scheme"] == "IS-SEED/1")
        t.check("S-rel-origin", c["origin"] == [0, 0, 0])
        t.check("S-rel-axes", c["axes"] == LOCKED["axes"])
        t.check("S-rel-gps", c["gps_origin_offset"] == [2000, 2000])
    except KeyError as e:
        t.check("S-relations", False, f"missing {e}")
    # Locked values (docs -> JSON transcription guard).
    for k, v in LOCKED.items():
        t.check(f"S-locked:{k}", c.get(k) == v, f"json={c.get(k)}")
    # AAA records.
    try:
        files = sorted(f for f in os.listdir(AAA_DIR) if f.endswith(".json"))
        t.check("S-AAA-count", len(files) == 18, f"{len(files)} files")
        for f in files:
            try:
                r = json.load(open(os.path.join(AAA_DIR, f)))
                miss = [k for k in AAA_REQUIRED_KEYS if k not in r]
                okc = r.get("confidence") in ("VERIFIED", "REPORTED", "UNKNOWN")
                t.check(f"S-AAA:{f}", not miss and okc,
                        f"missing={miss} conf={r.get('confidence')}")
            except Exception as e:
                t.check(f"S-AAA:{f}", False, e)
    except FileNotFoundError:
        t.check("S-AAA-dir", False, "missing dir")
    # Golden format.
    try:
        g = open(GOLDEN).read().strip().lower()
        t.check("S-golden-format", len(g) == 16 and all(ch in "0123456789abcdef" for ch in g), g)
    except FileNotFoundError:
        t.check("S-golden-exists", False, "missing golden file")
    # Checksum agreement JSON-side (python core -> golden).
    try:
        py_sum = fnv1a_hex(canonical(checksum_core(c)))
        t.check("S-checksum-vs-golden", py_sum == g, f"py={py_sum} golden={g}")
    except Exception as e:
        t.check("S-checksum-vs-golden", False, e)
    return t.report("STATIC")

# ---------------- cross ----------------
def cmd_cross(dump_path):
    t = Tally()
    try:
        dump = json.load(open(dump_path))
        c = json.load(open(CONTRACT))
        g = open(GOLDEN).read().strip().lower()
    except Exception as e:
        t.check("X-load", False, e); return t.report("CROSS")
    t.check("X-load", True)
    d = dump["dump"]
    for k, v in LOCKED.items():
        dv = d.get(k)
        same = (abs(dv - v) < 1e-9) if isinstance(v, float) else (dv == v)
        t.check(f"X-dump:{k}", same, f"dump={dv}")
    t.check("X-area", abs(d["area_m2"] - 12566370.614359172) < 1.0, d["area_m2"])
    t.check("X-circ", abs(d["circumference_m"] - 12566.370614359172) < 0.01, d["circumference_m"])
    py_canon = canonical(checksum_core(c))
    t.check("X-canonical-identical", py_canon == dump["canonical"])
    t.check("X-checksum-recompute", fnv1a_hex(dump["canonical"]) == dump["checksum_hex"])
    t.check("X-checksum-golden", dump["checksum_hex"] == g, dump["checksum_hex"])
    for key, (dom, kk) in {"sector:7,9": ("sector", "7,9"), "region:R1": ("region", "R1"),
                            "terrain:8,8": ("terrain", "8,8")}.items():
        exp = derive_hex(c["world_version"], c["master_seed"], dom, kk)
        t.check(f"X-seed:{key}", dump["seeds"][key]["seed_hex"] == exp,
                dump["seeds"][key]["seed_hex"])
    t.check("X-census", dump["census"] == {"grid_count": 16, "total": 256,
            "fully_inside": 164, "partial": 60, "fully_outside": 32,
            "intersecting": 224}, dump["census"])
    return t.report("CROSS")

# ---------------- inject ----------------
def _mutate(base, path, value):
    import copy
    c = copy.deepcopy(base)
    node = c
    for k in path[:-1]:
        node = node[k]
    if value is None and len(path) == 1 and path[0].startswith("!"):
        c.pop(path[0][1:], None)
    else:
        node[path[-1]] = value
    return c

def cmd_inject():
    t = Tally()
    base = json.load(open(CONTRACT))
    cases = [
        ("neg-radius", ["radius_m"], -5.0),
        ("zero-radius", ["radius_m"], 0.0),
        ("diameter-mismatch", ["diameter_m"], 3999.0),
        ("wrong-axes", ["axes"], {"east": "+X", "west": "-X", "up": "+Y", "north": "+Z", "south": "-Z"}),
        ("wrong-origin", ["origin"], [1, 0, 0]),
        ("final-status", ["sector_status"], "final"),
        ("frac-seed", ["master_seed"], 1.5),
        ("locked-radius-2500", ["radius_m"], 2500.0),  # +diameter/world fix below
        ("locked-seed-999", ["master_seed"], 999),
        ("locked-sector-128", ["sector_size_m"], 128),
        ("unordered-rings", ["boundary"], dict(base["boundary"], r_coast0_m=1900.0, r_beach0_m=1800.0)),
    ]
    for name, path, value in cases:
        c = _mutate(base, path, value)
        if name == "locked-radius-2500":
            c["diameter_m"] = 5000.0
            c["boundary"]["r_world_m"] = 2500.0
            c["boundary"]["r_play_limit_m"] = 5000.0
            c["boundary"]["r_ocean_visual_m"] = 6000.0
        p = f"/tmp/is_inject_{name}.json"
        json.dump(c, open(p, "w"))
        ec, out, _ = run_godot(["--script", "res://tests/godot/tools/contract_check.gd",
                                "--", "--contract", p])
        detected = (ec != 0) and ("CONTRACT_FAIL" in out)
        t.check(f"I-{name}", detected, f"exit={ec}")
        os.remove(p)
    ec, out, _ = run_godot(["--script", "res://tests/godot/tools/contract_check.gd",
                            "--", "--contract", "/tmp/is_inject_nope.json"])
    t.check("I-missing-file", ec != 0 and "CONTRACT_FAIL" in out, f"exit={ec}")
    # Repo untouched: contract + golden byte-identical to pre-run state.
    t.check("I-repo-clean", json.load(open(CONTRACT)) == base)
    return t.report("INJECT")

# ---------------- reproduce ----------------
def cmd_reproduce():
    t = Tally()
    outs = []
    for i in (1, 2):
        p = f"/tmp/is_repro_{i}.json"
        ec, out, _ = run_godot(["--script", "res://tests/godot/tools/contract_check.gd",
                                "--", "--dump", p])
        t.check(f"R-run{i}-exit", ec == 0 and "CONTRACT_OK" in out, f"exit={ec}")
        if ec != 0:
            return t.report("REPRODUCE")
        d = json.load(open(p)); d.pop("generated_at", None); d.get("engine", {}).pop("version", None)
        outs.append(d)
    a, b = outs
    for k in ["canonical", "checksum_hex", "dump", "seeds", "census"]:
        t.check(f"R-stable:{k}", a[k] == b[k])
    return t.report("REPRODUCE")

# ---------------- audit-log ----------------
ALLOW_EXACT = {"[ERROR][TEST] e1", "[FATAL][TEST] f1"}  # deliberate diag-service test emissions
ERROR_PATTERNS = ["ERROR", "FATAL", "SCRIPT ERROR", "Parse Error", "Parse error",
                  "Failed to", "failed to load", "Invalid", "invalid UID", "orphan",
                  "missing class", "MISSING", "Nonexistent", "nonexistent",
                  "CONTRACT_FAIL", "TEST_RUN FAILED", "BENCH_FAIL"]

def cmd_audit_log(log_path, err_path=None):
    t = Tally()
    try:
        lines = open(log_path, errors="replace").read().splitlines()
    except FileNotFoundError:
        t.check("A-log-exists", False, log_path); return t.report("AUDIT")
    if err_path and os.path.exists(err_path):
        lines += open(err_path, errors="replace").read().splitlines()
    t.check("A-log-exists", True, f"{len(lines)} lines")
    unexpected, warnings = [], []
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("Godot Engine"):
            continue
        if s in ALLOW_EXACT:
            continue
        if "WARNING" in s or s.startswith("[WARNING]"):
            warnings.append(s)
        elif any(pat in s for pat in ERROR_PATTERNS):
            unexpected.append(s)
    t.check("A-no-unexpected-errors", not unexpected,
            f"{len(unexpected)} unexpected" + (f": {unexpected[:5]}" if unexpected else ""))
    print(f"  [INFO] warnings listed (non-blocking): {len(warnings)}")
    for w in warnings[:15]:
        print(f"    WARN | {w}")
    return t.report("AUDIT")

# ---------------- bench-macro ----------------
def _stats(vals):
    vals = sorted(vals)
    n = len(vals)
    mean = sum(vals) / n
    med = vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2
    return {"samples": n, "min": vals[0], "mean": mean, "median": med, "max": vals[-1]}

def cmd_bench_macro():
    import re
    t = Tally()
    walls, boots = [], []
    for i in range(5):
        t0 = time.monotonic()
        ec, out, err = run_godot(["--quit-after", "30"], timeout=120)
        walls.append(time.monotonic() - t0)
        m = re.search(r'"boot_ms":([0-9.]+)', out)
        t.check(f"M-smoke{i}-exit", ec == 0, f"exit={ec}")
        if m:
            boots.append(float(m.group(1)))
    t.check("M-boot-captured", len(boots) == 5, boots)
    frames = []
    for i in range(3):
        ec, out, _ = run_godot(["--quit-after", "120", "--", "--benchmark-frames", "60"], timeout=120)
        m = re.search(r"FRAME_STATS_JSON (\{.*\})", out)
        t.check(f"M-frames{i}", ec == 0 and m is not None, f"exit={ec}")
        if m:
            frames.append(json.loads(m.group(1)))
    perf = os.path.join(ROOT, "reports/performance")
    os.makedirs(perf, exist_ok=True)
    vi_out = subprocess.run([godot_bin(), "--version"], capture_output=True, text=True).stdout.strip()
    boot_report = {"generated_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + "Z",
                   "mode": "COLD_START_HEADLESS_DUMMY", "gating": "NON-GATING",
                   "engine": vi_out,
                   "process_wall_s": dict(_stats(walls), unit="s"),
                   "bootstrap_boot_ms": dict(_stats(boots), unit="ms")}
    json.dump(boot_report, open(os.path.join(perf, "bootstrap_baseline.json"), "w"), indent=2)
    means = [f["mean"] for f in frames]
    run_report = {"generated_at": boot_report["generated_at"], "mode": "HEADLESS_DUMMY",
                  "gating": "NON-GATING", "engine": vi_out,
                  "steady_state_frame_s": dict(_stats(means), unit="s",
                                                note="mean-of-run-means, 60 frames/run"),
                  "runs": frames}
    json.dump(run_report, open(os.path.join(perf, "runtime_baseline.json"), "w"), indent=2)
    t.check("M-reports-written", True, "bootstrap_baseline.json + runtime_baseline.json")
    return t.report("BENCH-MACRO")

# ---------------- main ----------------
def main(argv):
    if len(argv) < 2:
        print(__doc__); return 2
    cmd = argv[1]
    ok = {"static": cmd_static, "inject": cmd_inject, "reproduce": cmd_reproduce,
          "bench-macro": cmd_bench_macro}.get(cmd, lambda: None)
    if cmd == "cross":
        if len(argv) < 3:
            print("usage: validate_foundation.py cross DUMP.json"); return 2
        return 0 if cmd_cross(argv[2]) else 1
    if cmd == "audit-log":
        if len(argv) < 3:
            print("usage: validate_foundation.py audit-log LOG [ERRLOG]"); return 2
        return 0 if cmd_audit_log(argv[2], argv[3] if len(argv) > 3 else None) else 1
    if ok is None:
        print(__doc__); return 2
    return 0 if ok() else 1

if __name__ == "__main__":
    sys.exit(main(sys.argv))
