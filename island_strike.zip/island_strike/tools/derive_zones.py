#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 02 — derive the urban platform zones grid.

Authored rule (authoring.json urban_platform_zones): owner urban_core +
grade <= 2% + d > 150 m, 8 m cells, keep components >= 4000 m2. Geometry is
DERIVED (inscribed ellipses only covered 42-49% of the non-convex urban
components; tuning decision): this tool writes data/derived/urban_zones.json
(labeled grid + checksum) for the P05 pad search (section 31).

Deterministic: extent snaps from the urban_core ellipse bbox, cells are
evaluated on a fixed grid, components are labeled in scan order, output ids
are sorted by size. Same data -> same bytes (modulo the generated_at stamp,
which is excluded from the checksum).
"""
import json, math, os, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import Field, fnv1a_hex  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CELL = 8.0
MARGIN = 100.0


def canonical(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def main() -> int:
    f = Field()
    urb = next(r for r in f.au["regions"] if r["id"] == "urban_core")
    s = urb["shapes"][0]
    x0 = math.floor((s["cx"] - s["rx"] - MARGIN) / CELL) * CELL
    x1 = math.ceil((s["cx"] + s["rx"] + MARGIN) / CELL) * CELL
    z0 = math.floor((s["cz"] - s["rz"] - MARGIN) / CELL) * CELL
    z1 = math.ceil((s["cz"] + s["rz"] + MARGIN) / CELL) * CELL
    nx, nz = int(round((x1 - x0) / CELL)), int(round((z1 - z0) / CELL))

    good = set()
    for j in range(nz):
        z = z0 + j * CELL + CELL / 2
        for i in range(nx):
            x = x0 + i * CELL + CELL / 2
            if x * x + z * z > 2000.0 * 2000.0:
                continue
            if f.region_at(x, z) != "urban_core":
                continue
            _, grade = f.slope_grade(x, z)
            if grade > 2.0:
                continue
            r = math.hypot(x, z)
            d = f.loop.rs(math.atan2(x, -z) % (2 * math.pi)) - r
            if d <= 150.0:
                continue
            good.add((i, j))

    # Connected components, 4-connectivity, scan-order labeling.
    seen, comps = set(), []
    for cell in sorted(good, key=lambda c: (c[1], c[0])):
        if cell in seen:
            continue
        stack, comp = [cell], []
        seen.add(cell)
        while stack:
            c0 = stack.pop()
            comp.append(c0)
            for nb in ((c0[0] + 1, c0[1]), (c0[0] - 1, c0[1]),
                       (c0[0], c0[1] + 1), (c0[0], c0[1] - 1)):
                if nb in good and nb not in seen:
                    seen.add(nb)
                    stack.append(nb)
        comps.append(sorted(comp))

    zone_rec = f.au["urban_platform_zones"][0]
    min_cells = int(math.ceil(zone_rec["min_component_m2"] / (CELL * CELL)))
    comps = [c for c in comps if len(c) >= min_cells]
    comps.sort(key=len, reverse=True)

    out_comps = []
    for k, comp in enumerate(comps):
        xs = [x0 + c[0] * CELL + CELL / 2 for c in comp]
        zs = [z0 + c[1] * CELL + CELL / 2 for c in comp]
        out_comps.append({
            "id": "UP-%02d" % (k + 1),
            "n_cells": len(comp),
            "area_m2": round(len(comp) * CELL * CELL, 1),
            "bbox": [round(min(xs), 1), round(min(zs), 1),
                     round(max(xs), 1), round(max(zs), 1)],
            "cells": [[c[0], c[1]] for c in comp],
        })
    payload = {
        "rule": zone_rec["rule"],
        "cell_m": CELL,
        "extent": [x0, z0, x1, z1],
        "min_component_m2": zone_rec["min_component_m2"],
        "versions": {
            "terrain_version": f.tc["terrain_version"],
            "coast_version": f.cc["coast_version"],
            "authoring_version": f.au["meta"]["authoring_version"],
            "world_version": f.wc["world_version"],
        },
        "components": out_comps,
    }
    doc = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "generator": "tools/derive_zones.py",
        "payload": payload,
        "checksum_hex": fnv1a_hex(canonical(payload)),
    }
    os.makedirs(os.path.join(ROOT, "data/derived"), exist_ok=True)
    path = os.path.join(ROOT, "data/derived/urban_zones.json")
    json.dump(doc, open(path, "w"), indent=2)
    print("zones: %d components, %d cells -> %s" % (
        len(out_comps), sum(c["n_cells"] for c in out_comps), path))
    print("checksum: %s" % doc["checksum_hex"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
