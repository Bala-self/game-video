#!/usr/bin/env python3
"""P06 Gen-G: massing meshes, LOD, batching, streaming deps, spatial index,
handoffs.

Reads: contracts, districts, blocks, parcels, buildings, places, roads,
       geometry, structures, terrain.
Writes: data/derived/urban_mesh.json (meshes + batches + streaming +
        index report), data/derived/p06_handoff_{nav,ai,missions,
        economy}.json.

Meshes: deterministic rect mass + roof prism per roof_family. LOD near
(mass+roof) / mid (mass box) / far (bounds + landmark proxy flag).
Batches keyed (sector, material, lod) with per-building ranges.
Sectors reuse the P05 sector_of() convention exactly.
"""
import json
import math
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from districts import seed_for, q6  # noqa: E402
from terrain_model import Field  # noqa: E402
from transport_structures import sector_of  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P06D = os.environ.get("P06_OUT_DIR") or os.path.join(ROOT, "data/derived")

AI_ROLE = {
    "residential": "reside", "commercial": "shop_work",
    "civic": "civic_visit", "industrial": "work_logistics",
}
ECON_ROLE = {
    "retail": "shop", "restaurant": "dine", "hotel": "lodge",
    "office": "work", "mixed_use": "mixed_trade", "market": "shop",
    "rural_shop": "shop", "rural_service": "service_trade",
    "service": "service_trade", "warehouse": "freight",
    "factory": "manufacture", "distribution": "freight",
    "workshop": "craft", "port_support": "freight",
    "airport_support": "aviation_svc", "hangar": "aviation_svc",
    "marina_service": "marine_svc", "resort": "lodge",
    "waterfront_commercial": "mixed_trade", "farmhouse": "farmstead",
    "barn": "farm_ops", "silo": "farm_ops",
}


class MeshError(Exception):
    pass


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def norm(v):
    L = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) or 1.0
    return (v[0] / L, v[1] / L, v[2] / L)


def tri_area(a, b, c):
    return math.sqrt(sum(x * x for x in cross(sub(b, a), sub(c, a)))) / 2.0


class Registry:
    def __init__(self):
        t0 = time.time()
        self.timers = {}
        dd = os.path.join(ROOT, "data/derived")
        dw = os.path.join(ROOT, "data/world")
        self.dc = json.load(open(os.path.join(dw, "district_contract.json")))
        self.bc = json.load(open(os.path.join(dw, "building_contract.json")))
        self.dist = json.load(open(os.path.join(P06D, "districts.json")))
        self.blk = json.load(open(os.path.join(P06D, "blocks.json")))
        self.par = json.load(open(os.path.join(P06D, "parcels.json")))
        self.bld = json.load(open(os.path.join(P06D, "buildings.json")))
        self.plc = json.load(open(os.path.join(P06D, "places.json")))
        self.f = Field()
        self.meshes = []
        self.batches = []
        self.stream_nodes = []
        self.timers["load"] = time.time() - t0

    def _t(self, name):
        if name is None:
            self.timers[self._cur] = time.time() - self._t0
        else:
            self._cur = name
            self._t0 = time.time()

    @staticmethod
    def checksum_scope(items):
        from districts import canon, fnv1a_hex
        lines = sorted(canon(it) for it in items)
        return fnv1a_hex("\n".join(lines))

    def phase_preflight(self):
        self._t("preflight")
        if self.checksum_scope(self.bld["buildings"]) != \
                self.bld["checksum"]:
            raise MeshError("stale buildings.json")
        pl = self.plc
        items = pl["landmarks"] + pl["open_spaces"] + pl["arrivals"] + \
            pl["corridors"]
        if self.checksum_scope(items) != pl["checksum"]:
            raise MeshError("stale places.json")
        self._t(None)

    # ---------- massing ----------
    def mass_mesh(self, fp, base, h, roof):
        """fp: 4 plan corners (x,z). Returns (verts, tris) near-LOD."""
        (x0, z0), (x1, z1), (x2, z2), (x3, z3) = fp
        # basis: u along edge0, v along edge3
        ux, uz = x1 - x0, z1 - z0
        vx, vz = x3 - x0, z3 - z0
        w = math.hypot(ux, uz)
        d = math.hypot(vx, vz)
        ux, uz = ux / w, uz / w
        vx, vz = vx / d, vz / d

        def P(s, t, y):
            return (x0 + ux * s * w + vx * t * d, y,
                    z0 + uz * s * w + vz * t * d)

        V = [P(0, 0, base), P(1, 0, base), P(1, 1, base), P(0, 1, base),
             P(0, 0, base + h), P(1, 0, base + h),
             P(1, 1, base + h), P(0, 1, base + h)]
        T = [(0, 2, 1), (0, 3, 2),  # base (down)
             (4, 5, 6), (4, 6, 7),  # top cap (up)
             (0, 1, 5), (0, 5, 4), (1, 2, 6), (1, 6, 5),
             (2, 3, 7), (2, 7, 6), (3, 0, 4), (3, 4, 7)]
        if roof in ("flat", "parapet"):
            if roof == "parapet":
                # rim: 4 thin quads 0.6m tall on the cap edge
                r0 = len(V)
                ph = base + h
                V += [P(0, 0, ph), P(1, 0, ph), P(1, 1, ph),
                      P(0, 1, ph), P(0, 0, ph + 0.6),
                      P(1, 0, ph + 0.6), P(1, 1, ph + 0.6),
                      P(0, 1, ph + 0.6)]
                for i in range(4):
                    j = (i + 1) % 4
                    T += [(r0 + i, r0 + j, r0 + 4 + j),
                          (r0 + i, r0 + 4 + j, r0 + 4 + i)]
        elif roof == "shed":
            r = len(V)
            V += [P(0, 0, base + h), P(1, 0, base + h + 1.5),
                  P(1, 1, base + h + 1.5), P(0, 1, base + h)]
            T += [(r, r + 1, r + 2), (r, r + 2, r + 3)]
        elif roof in ("gable", "hip"):
            r = len(V)
            ridge = min(w, d) * 0.18 + 1.0
            if w >= d:
                V += [P(0.5, 0, base + h + ridge),
                      P(0.5, 1, base + h + ridge)]
                T += [(4, r, r + 1), (4, r + 1, 7),
                      (6, r + 1, r), (6, r, 5),
                      (4, 5, r), (7, r + 1, 6)]
            else:
                V += [P(0, 0.5, base + h + ridge),
                      P(1, 0.5, base + h + ridge)]
                T += [(5, r + 1, r), (5, 4, r + 1),
                      (7, r, r + 1), (7, r + 1, 6),
                      (4, 7, r), (5, r + 1, 6)]
        elif roof == "curved_hangar":
            r = len(V)
            segs = 8
            for i in range(segs + 1):
                a = math.pi * i / segs
                s = 0.5 - 0.5 * math.cos(a)
                y = base + h + math.sin(a) * min(w, d) * 0.25
                V += [P(s, 0, y), P(s, 1, y)]
            for i in range(segs):
                a0, b0 = r + 2 * i, r + 2 * i + 1
                a1, b1 = r + 2 * i + 2, r + 2 * i + 3
                T += [(a0, a1, b1), (a0, b1, b0)]
        elif roof == "monitor":
            r = len(V)
            V += [P(0.3, 0.3, base + h), P(0.7, 0.3, base + h),
                  P(0.7, 0.7, base + h), P(0.3, 0.7, base + h),
                  P(0.3, 0.3, base + h + 1.8),
                  P(0.7, 0.3, base + h + 1.8),
                  P(0.7, 0.7, base + h + 1.8),
                  P(0.3, 0.7, base + h + 1.8)]
            T += [(r + 4, r + 5, r + 6), (r + 4, r + 6, r + 7),
                  (r, r + 1, r + 5), (r, r + 5, r + 4),
                  (r + 1, r + 2, r + 6), (r + 1, r + 6, r + 5),
                  (r + 2, r + 3, r + 7), (r + 2, r + 7, r + 6),
                  (r + 3, r, r + 4), (r + 3, r + 4, r + 7)]
        else:
            raise MeshError("unknown roof %s" % roof)
        return V, T

    def box_mesh(self, fp, base, h):
        (x0, z0), (x1, z1), (x2, z2), (x3, z3) = fp
        V = [(x0, base, z0), (x1, base, z1), (x2, base, z2),
             (x3, base, z3), (x0, base + h, z0), (x1, base + h, z1),
             (x2, base + h, z2), (x3, base + h, z3)]
        T = [(0, 2, 1), (0, 3, 2), (4, 5, 6), (4, 6, 7),
             (0, 1, 5), (0, 5, 4), (1, 2, 6), (1, 6, 5),
             (2, 3, 7), (2, 7, 6), (3, 0, 4), (3, 4, 7)]
        return V, T

    @staticmethod
    def normals_of(V, T):
        acc = [[0.0, 0.0, 0.0] for _ in V]
        for (a, b, c) in T:
            n = norm(cross(sub(V[b], V[a]), sub(V[c], V[a])))
            for i in (a, b, c):
                acc[i][0] += n[0]
                acc[i][1] += n[1]
                acc[i][2] += n[2]
        return [norm(tuple(v)) for v in acc]

    def phase_mesh(self):
        self._t("mesh")
        land_ids = {l["building"] for l in self.plc["landmarks"]
                    if l["building"]}
        for b in self.bld["buildings"]:
            fp = [tuple(v) for v in b["footprint"][:4]]
            base = b["foundation"]["base_elev"]
            h = b["height_m"]
            roof = b["roof"]["family"]
            Vn, Tn = self.mass_mesh(fp, base, h, roof)
            Vm, Tm = self.box_mesh(fp, base, h)
            for V, T in ((Vn, Tn), (Vm, Tm)):
                for v in V:
                    if any(math.isnan(c) or math.isinf(c) for c in v):
                        raise MeshError("NaN vertex %s" % b["id"])
                for (a, c, d) in T:
                    if tri_area(V[a], V[c], V[d]) < 1e-6:
                        raise MeshError("degenerate tri %s" % b["id"])
            Nn = self.normals_of(Vn, Tn)
            xs = [v[0] for v in Vn]
            ys = [v[1] for v in Vn]
            zs = [v[2] for v in Vn]
            # terrain contact: base vs corner ground
            grounds = [self.f.height(x, z) for (x, z) in fp]
            contact = "embedded" if base <= min(grounds) + 0.5 else \
                ("terraced" if b["foundation"]["method"] == "terraced"
                 else "raised")
            secs = sorted(set(sector_of(v[0], v[2]) for v in Vn))
            self.meshes.append({
                "building": b["id"], "sector": secs[0], "sectors": secs,
                "material": "%s+%s" % (b["facade"]["family"],
                                       b["roof"]["family"]),
                "near": {"verts": [[round(c, 3) for c in v] for v in Vn],
                         "tris": [list(t) for t in Tn],
                         "normals": [[round(c, 4) for c in n]
                                     for n in Nn]},
                "mid": {"verts": [[round(c, 3) for c in v] for v in Vm],
                        "tris": [list(t) for t in Tm]},
                "far": {"bbox": [[round(min(xs), 2),
                                  round(min(ys), 2),
                                  round(min(zs), 2)],
                                 [round(max(xs), 2),
                                  round(max(ys), 2),
                                  round(max(zs), 2)]],
                        "proxy": b["id"] in land_ids},
                "contact": contact,
                "tris_near": len(Tn), "tris_mid": len(Tm)})
        self._t(None)

    # ---------- batching (63) ----------
    def phase_batch(self):
        self._t("batch")
        groups = {}
        for m in self.meshes:
            for lod in ("near", "mid"):
                key = (m["sector"], m["material"], lod)
                groups.setdefault(key, []).append(m)
        for (sec, mat, lod), members in sorted(groups.items()):
            members.sort(key=lambda m: m["building"])
            ranges = []
            vo, to = 0, 0
            for m in members:
                nv = len(m[lod]["verts"])
                nt = len(m[lod]["tris"])
                ranges.append({"building": m["building"],
                               "vert_start": vo, "vert_count": nv,
                               "tri_start": to, "tri_count": nt})
                vo += nv
                to += nt
            self.batches.append({"id": "BAT-%s-%s-%s" % (
                sec, mat.replace("+", "_"), lod),
                "sector": sec, "material": mat, "lod": lod,
                "members": ranges, "vert_count": vo,
                "tri_count": to})
        self._t(None)

    # ---------- streaming (65) + sectors ----------
    def phase_streaming(self):
        self._t("streaming")
        pri = {"MAJOR_CITY": 100, "PORT_COMPLEX": 90,
               "AIRFIELD_COMPLEX": 90, "SECONDARY_TOWN": 70,
               "RESORT_CLUSTER": 70, "RESTRICTED_COMPLEX": 60,
               "VILLAGE": 50, "RURAL_CLUSTER": 40}
        for s in self.dist["settlements"]:
            self.stream_nodes.append({
                "id": "STR-%s" % s["id"], "type": "SETTLEMENT",
                "ref": s["id"], "deps": ["STR-REGION"],
                "priority": pri.get(s["class"], 30)})
        for d in self.dist["districts"]:
            s = [x for x in self.dist["settlements"]
                 if x["id"] == d["settlement"]][0]
            self.stream_nodes.append({
                "id": "STR-%s" % d["id"], "type": "DISTRICT",
                "ref": d["id"], "deps": ["STR-%s" % d["settlement"]],
                "priority": pri.get(s["class"], 30)})
        for b in self.blk["blocks"]:
            self.stream_nodes.append({
                "id": "STR-%s" % b["id"], "type": "BLOCK_PARCEL",
                "ref": b["id"], "deps": ["STR-%s" % b["district_id"]],
                "priority": 20})
        for m in self.meshes:
            b = [x for x in self.bld["buildings"]
                 if x["id"] == m["building"]][0]
            dep = "STR-%s" % (b["parcel"] if b["block"] is None else
                              b["block"])
            if b["block"] is None:
                # direct parcels hang off the district node
                dep = "STR-%s" % b["district"]
            shell = {"id": "STR-%s-shell" % b["id"], "type": "SHELL",
                     "ref": b["id"], "deps": [dep], "priority": 10}
            det = {"id": "STR-%s-detail" % b["id"], "type": "DETAIL",
                   "ref": b["id"], "deps": [shell["id"]], "priority": 5}
            self.stream_nodes += [shell, det]
            if b["interior"]["state"] in ("INTERIOR_READY",
                                          "INTERIOR_REQUIRED",
                                          "MISSION_INTERIOR_CANDIDATE"):
                self.stream_nodes.append({
                    "id": "STR-%s-interior" % b["id"], "type": "INTERIOR",
                    "ref": b["id"], "deps": [det["id"]], "priority": 1})
        self.stream_nodes.insert(
            0, {"id": "STR-REGION", "type": "REGION", "ref": "world",
                "deps": [], "priority": 200})
        # sector table
        by_sec = {}
        for m in self.meshes:
            by_sec.setdefault(m["sector"], []).append(m["building"])
        self.sectors = []
        for sec, ids in sorted(by_sec.items()):
            xs, zs = [], []
            for m in self.meshes:
                if m["building"] in ids:
                    bb = m["far"]["bbox"]
                    xs += [bb[0][0], bb[1][0]]
                    zs += [bb[0][2], bb[1][2]]
            self.sectors.append({"id": sec, "buildings": sorted(ids),
                                 "count": len(ids),
                                 "bounds": [[round(min(xs), 1),
                                             round(min(zs), 1)],
                                            [round(max(xs), 1),
                                             round(max(zs), 1)]]})
        self._t(None)

    # ---------- spatial index agreement (66) ----------
    def phase_index(self):
        self._t("index")
        cells = {}
        for m in self.meshes:
            bb = m["far"]["bbox"]
            x0, z0 = bb[0][0], bb[0][2]
            x1, z1 = bb[1][0], bb[1][2]
            for ix in range(int(x0 // 100), int(x1 // 100) + 1):
                for iz in range(int(z0 // 100), int(z1 // 100) + 1):
                    cells.setdefault((ix, iz), []).append(m["building"])
        bmap = {b["id"]: b for b in self.bld["buildings"]}

        def pip(x, z, poly):
            inside = False
            for i in range(len(poly)):
                x0, z0 = poly[i]
                x1, z1 = poly[(i + 1) % len(poly)]
                if (z0 > z) != (z1 > z):
                    if x < x0 + (x1 - x0) * (z - z0) / (z1 - z0):
                        inside = not inside
            return inside

        def indexed(x, z):
            out = set()
            for bid in cells.get((int(x // 100), int(z // 100)), ()):
                if pip(x, z, bmap[bid]["footprint"][:4]):
                    out.add(bid)
            return out

        def brute(x, z):
            out = set()
            for b in self.bld["buildings"]:
                if pip(x, z, b["footprint"][:4]):
                    out.add(b["id"])
            return out

        pts = []
        for b in self.bld["buildings"][:60]:
            fp = b["footprint"][:4]
            pts.append((sum(v[0] for v in fp) / 4,
                        sum(v[1] for v in fp) / 4, "center"))
            pts.append((fp[0][0], fp[0][1], "building_edge"))
        for p in self.par["parcels"][:60]:
            qp = p["polygon"]
            pts.append((qp[0][0], qp[0][1], "parcel_edge"))
        for d in self.dist["districts"]:
            bb = d["bounds"]
            if "disc" in bb:
                pts.append((bb["disc"][0] + bb["disc"][2], bb["disc"][1],
                            "district_edge"))
        for a in self.plc["arrivals"]:
            pts.append((a["entry"][0], a["entry"][1], "arrival"))
        for o in self.plc["open_spaces"][:20]:
            pts.append((o["bounds"][0][0], o["bounds"][0][1], "open"))
        for s in self.sectors[:10]:
            pts.append((s["bounds"][0][0], s["bounds"][0][1],
                        "sector_edge"))
        mism = 0
        for (x, z, kind) in pts:
            if indexed(x, z) != brute(x, z):
                mism += 1
        self.index_report = {"points": len(pts), "mismatches": mism,
                             "tolerance": "exact",
                             "verdict": "AGREE" if mism == 0 else
                             "MISMATCH"}
        if mism:
            raise MeshError("spatial index mismatches: %d" % mism)
        self._t(None)

    # ---------- handoffs (67) ----------
    def phase_handoffs(self):
        self._t("handoffs")
        nav, ai, miss, econ = [], [], [], []
        for b in self.bld["buildings"]:
            p = [x for x in self.par["parcels"]
                 if x["id"] == b["parcel"]][0]
            nav.append({"building": b["id"],
                        "entrance": b["entrance"]["at"],
                        "connects_to": b["entrance"]["connects_to"],
                        "access_type": p["access"]["type"],
                        "service": b["service"]["side"]
                        if b["service"] else None})
            ai.append({"building": b["id"], "class": b["class"],
                       "activity": AI_ROLE[b["occupancy"]]})
            if b["interior"]["state"] in ("INTERIOR_REQUIRED",
                                          "MISSION_INTERIOR_CANDIDATE"):
                miss.append({"zone": "MZ-%s" % b["id"][4:],
                             "building": b["id"],
                             "state": b["interior"]["state"]})
            if b["class"] in ECON_ROLE:
                econ.append({"building": b["id"], "class": b["class"],
                             "business": ECON_ROLE[b["class"]]})
        # orphan check
        ids = {b["id"] for b in self.bld["buildings"]}
        for rec in nav + ai + miss + econ:
            if rec["building"] not in ids:
                raise MeshError("orphan handoff %s" % rec)
        dd = P06D
        for name, rows in (("nav", nav), ("ai", ai),
                           ("missions", miss), ("economy", econ)):
            doc = {"meta": {"generator": "urban_mesh.py",
                            "count": len(rows)},
                   "rows": rows, "checksum": ""}
            doc["checksum"] = self.checksum_scope(rows)
            json.dump(doc, open(os.path.join(
                dd, "p06_handoff_%s.json" % name), "w"))
        self.handoff_counts = {"nav": len(nav), "ai": len(ai),
                               "missions": len(miss),
                               "economy": len(econ)}
        self._t(None)

    # ---------- export ----------
    def phase_export(self):
        self._t("export")
        outdir = os.environ.get("P06_OUT_DIR",
                                os.path.join(ROOT, "data/derived"))
        doc = {"meta": {"generator": "urban_mesh.py",
                        "mesh_count": len(self.meshes),
                        "batch_count": len(self.batches)},
               "meshes": self.meshes, "batches": self.batches,
               "streaming": self.stream_nodes, "sectors": self.sectors,
               "index_report": self.index_report,
               "handoffs": self.handoff_counts,
               "checksum": ""}
        doc["checksum"] = self.checksum_scope(self.meshes)
        json.dump(doc, open(os.path.join(outdir, "urban_mesh.json"), "w"))
        self._t(None)


def main():
    reg = Registry()
    reg.phase_preflight()
    reg.phase_mesh()
    reg.phase_batch()
    reg.phase_streaming()
    reg.phase_index()
    reg.phase_handoffs()
    reg.phase_export()
    print("gen-g ok: %d meshes %d batches %d stream nodes "
          "(index %s, handoffs %s)" % (
              len(reg.meshes), len(reg.batches),
              len(reg.stream_nodes), reg.index_report["verdict"],
              reg.handoff_counts))
    print("timers: %s" % " ".join("%s=%.2f" % kv for kv in
                                  sorted(reg.timers.items())))


if __name__ == "__main__":
    main()
