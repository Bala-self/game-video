#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 05 -- transport structure validator.

Suites: static | cross | inject | reproduce | impact | bench | regress | safety.
STATIC-STRUCTURE validates data/derived/transport_*.json against
data/world/transport_structure_contract.json + locked P03/P04 + live terrain.
"""
import json
import math
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import Field  # noqa: E402
from reservation_index import ReservationIndex  # noqa: E402
import transport_structures as TS  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STRUCT_CC = os.path.join(ROOT, "data/world/transport_structure_contract.json")
STRUCT_SCHEMA = os.path.join(ROOT, "data/world/transport_structure_contract.schema.json")
GEO_JSON = os.path.join(ROOT, "data/derived/road_geometry.json")
ROADS_JSON = os.path.join(ROOT, "data/derived/roads.json")
S_JSON = os.path.join(ROOT, "data/derived/transport_structures.json")
M_JSON = os.path.join(ROOT, "data/derived/transport_markings.json")
R_JSON = os.path.join(ROOT, "data/derived/transport_reservations.json")
H_JSON = os.path.join(ROOT, "data/derived/transport_handoff_ext.json")
GOLDEN = os.path.join(ROOT, "reports/p05_transport_golden.json")
SAFETY = os.path.join(ROOT, "reports/p05_safety.json")

WALL_KINDS = ("bridge_parapet", "bridge_fascia", "bridge_abutment",
              "tunnel_lining", "tunnel_headwall", "tunnel_wingwall",
              "retaining_wall", "retaining_wingwall", "guardrail",
              "concrete_barrier", "low_curb", "hazard_marker", "bollard")
FLAT_KINDS = ("marking",)


class Tally:
    def __init__(self):
        self.n = 0
        self.bad = []

    def check(self, name, ok, detail=""):
        self.n += 1
        print("  [%s] %s  %s" % ("PASS" if ok else "FAIL", name, detail))
        if not ok:
            self.bad.append(name)

    def report(self, suite):
        print("%s: %d/%d passed" % (suite, self.n - len(self.bad), self.n))
        return not self.bad


def tri_data(A, B, C):
    ux, uy, uz = B[0] - A[0], B[1] - A[1], B[2] - A[2]
    vx, vy, vz = C[0] - A[0], C[1] - A[1], C[2] - A[2]
    nx = uy * vz - uz * vy
    ny = uz * vx - ux * vz
    nz = ux * vy - uy * vx
    area = math.sqrt(nx * nx + ny * ny + nz * nz) / 2.0
    return (nx, ny, nz), area


def load_all(s_path=None, m_path=None, r_path=None):
    sc = json.load(open(STRUCT_CC))
    g = json.load(open(GEO_JSON))
    r = json.load(open(ROADS_JSON))
    s = json.load(open(s_path or S_JSON))
    m = json.load(open(m_path or M_JSON))
    rv = json.load(open(r_path or R_JSON))
    return sc, g, r, s, m, rv


def suite_static(s_path=None, m_path=None, r_path=None):
    t = Tally()
    sc, g, r, s, m, rv = load_all(s_path, m_path, r_path)
    f = Field()
    # ---- A. schema + versions + stale refusal ----
    sch = json.load(open(STRUCT_SCHEMA))
    missing = [k for k in sch["required"] if k not in sc]
    t.check("schema-keys", not missing, str(missing) if missing else "")
    for k, spec in sch["properties"].items():
        for rk in spec.get("required", []) if isinstance(spec, dict) else []:
            if rk not in sc.get(k, {}):
                t.check("schema-%s-%s" % (k, rk), False, "missing")
    t.check("schema-subkeys", True, "")
    for name, doc in (("structures", s), ("markings", m), ("reservations", rv)):
        mt = doc["meta"]
        ok = (mt["structure_version"] == "0.1.0" and
              mt["marking_version"] == "0.1.0" and
              mt["reservation_version"] == "0.1.0" and
              mt["road_checksum"] == "0e28622c1bb2185b" and
              mt["geometry_checksum"] == "69ca624214ee76fe" and
              mt["geometry_version"] == "0.1.0" and
              mt["terrain_version"] == "0.1.0" and
              mt["coast_version"] == "0.1.0")
        t.check("versions-" + name, ok, "")
    # ---- B. mesh rules (all P05 parts) ----
    mats = set(sc["material_classes"])
    parts = {p["id"]: p for p in s["parts"]} | {p["id"]: p for p in m["parts"]}
    n_up = n_tot = 0
    for pid, p in sorted(parts.items()):
        v = p["verts"]
        bad_idx = any(min(tri) < 0 or max(tri) >= len(v) for tri in p["tris"])
        t.check("mesh-index-" + pid, not bad_idx, "")
        finite = all(math.isfinite(c) for q in v for c in q[:6])
        t.check("mesh-finite-" + pid, finite, "")
        if p["semantic"].get("material") not in mats:
            t.check("mesh-material-" + pid, False,
                    str(p["semantic"].get("material")))
        used = set(i for tri in p["tris"] for i in tri)
        t.check("mesh-no-unused-" + pid, len(used) == len(v),
                "%d/%d used" % (len(used), len(v)))
        for tri in p["tris"]:
            n_tot += 1
            A, B, C = v[tri[0]], v[tri[1]], v[tri[2]]
            (nx, ny, nz), area = tri_data(A, B, C)
            if area < 1e-9:
                t.check("mesh-area-" + pid, False, "%s %.2e" % (tri, area))
            if p["kind"] in FLAT_KINDS:
                if ny > 0:
                    n_up += 1
                else:
                    t.check("mesh-up-" + pid, False, "%s ny=%.2e" % (tri, ny))
            else:
                n_up += 1
                # stored normals ~ face normals (outward by construction)
                L = math.sqrt(nx * nx + ny * ny + nz * nz) or 1e-18
                for vi in tri:
                    q = v[vi]
                    dot = (q[3] * nx + q[4] * ny + q[5] * nz) / L
                    if dot < 0.5:
                        t.check("mesh-normal-" + pid, False,
                                "%s dot=%.2f" % (tri, dot))
                        break
    t.check("mesh-flat-up", True, "%d/%d" % (n_up, n_tot))
    # ---- C. bridges ----
    rb = TS.Registry()
    rb.sc, rb.gc, rb.g, rb.r, rb.f = sc, json.load(
        open(os.path.join(ROOT, "data/world/road_geometry_contract.json"))), g, r, f
    rb.parts = {p["id"]: p for p in g["parts"]}
    for bid in sorted(s["bridges"]):
        b = s["bridges"][bid]
        gb = g["bridges"][bid]
        eid = b["edge"]
        E = g["edges"][eid]
        nc = len(E["meta"]["columns"])
        idxs = rb.station_range(eid, gb["wet0"], gb["wet1"])
        t.check("bridge-span-" + bid, len(idxs) >= 2, "%d stations" % len(idxs))
        t.check("bridge-water-" + bid,
                b["water_clearance"] >= sc["clearance"]["bridge_under_min_m"],
                "%.2f" % b["water_clearance"])
        t.check("bridge-piers-" + bid, b["piers"]["count"] == 0,
                b["piers"]["reason"])
        for side, ci in (("L", 0), ("R", nc - 1)):
            pp = parts.get("ST-%s-parapet-%s" % (bid, side))
            if pp is None:
                t.check("bridge-parapet-%s-%s" % (bid, side), False, "missing")
                continue
            # parapet base follows ribbon edge verts over the full wet
            # span (ends interpolated; validator mirrors the lerp bitwise)
            dds = rb.span_dlist(eid, gb["wet0"], gb["wet1"])
            pv = pp["verts"]
            ok = len(pv) == 6 * len(dds)
            t.check("bridge-parapet-n-%s-%s" % (bid, side), ok,
                    "%d verts" % len(pv))
            base_ok = True
            for k, dd in enumerate(dds):
                ev = rb.ribbon_edge_at(eid, ci, dd)
                bv = pv[4 * k]
                if (abs(ev[0] - bv[0]) > 1e-9 or abs(ev[1] - bv[1]) > 1e-9 or
                        abs(ev[2] - bv[2]) > 1e-9):
                    base_ok = False
            t.check("bridge-parapet-deck-%s-%s" % (bid, side), base_ok, "")
            cap_ok = True
            for k in range(len(dds)):
                for ci0, bi0 in ((4 * len(dds) + 2 * k, 4 * k + 1),
                                 (4 * len(dds) + 2 * k + 1, 4 * k + 3)):
                    A, B = pv[ci0], pv[bi0]
                    if (abs(A[0] - B[0]) > 1e-9 or abs(A[1] - B[1]) > 1e-9 or
                            abs(A[2] - B[2]) > 1e-9):
                        cap_ok = False
            t.check("bridge-parapet-cap-%s-%s" % (bid, side), cap_ok, "")
            h = float(sc["barrier_rules"]["bridge_parapet"]["height_m"])
            top_ok = all(abs(pv[4 * k + 1][1] - pv[4 * k][1] - h) < 1e-9
                         for k in range(len(dds)))
            t.check("bridge-parapet-h-%s-%s" % (bid, side), top_ok, "")
            fs = parts.get("ST-%s-fascia-%s" % (bid, side))
            if fs is None:
                t.check("bridge-fascia-%s-%s" % (bid, side), False, "missing")
            else:
                dd = float(sc["bridge_rules"]["deck_depth_m"])
                fok = all(abs(fs["verts"][2 * k][1] - fs["verts"][2 * k + 1][1] - dd) < 1e-9
                          for k in range(len(dds)))
                t.check("bridge-fascia-depth-%s-%s" % (bid, side), fok, "")
        for end in ("A", "B"):
            rec = next((c for c in b["components"]
                        if c["id"] == "ST-%s-abutment-%s" % (bid, end)), None)
            if rec is None:
                t.check("bridge-abut-%s-%s" % (bid, end), False, "missing")
                continue
            ap = parts.get(rec["id"])
            top = max(v[1] for v in ap["verts"])
            t.check("bridge-abut-top-%s-%s" % (bid, end),
                    abs(top - rec["deck_underside_ref"]) < 1e-6, "")
            base = min(v[1] for v in ap["verts"])
            tmin = min(f.height(v[0], v[2]) for v in ap["verts"])
            t.check("bridge-abut-buried-%s-%s" % (bid, end),
                    base < tmin, "base %.2f terrain %.2f" % (base, tmin))
    return t, (sc, g, r, s, m, rv, rb, f, parts)

def suite_static_tunnel(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    tn = s["tunnel"]
    eid = tn["edge"]
    E = g["edges"][eid]
    half = E["width_m"] / 2.0
    st = g["edges"][eid]["stations"]
    bore = [i for i, p in enumerate(st) if p["structure"] == "TUNNEL"]
    t.check("tunnel-bore", tn["bore_stations"] >= 2, "%d" % tn["bore_stations"])
    lp = parts.get("ST-TN-lining")
    if lp is None:
        t.check("tunnel-lining-part", False, "missing")
        return t
    # clearance from mesh: 5 m over the traveled way (lane geometry from
    # the profile registry), 2.5 m headroom over shoulders/walkway
    from road_geometry import ProfileRegistry
    prof = ProfileRegistry(rb.gc)
    var = prof.classes[E["class"]]["variants"]["w%d" % int(round(E["width_m"]))]
    trav = var["median_width_m"] / 2.0 + (var["lanes"] / 2.0) * var["lane_width_m"]
    req = sc["clearance"]["tunnel_vehicle_m"]
    worst = 1e300
    bad = 0
    whw = 1e300
    bad_hw = 0
    bd0, bd1 = st[bore[0]]["d"], st[bore[-1]]["d"]
    for v in lp["verts"]:
        bi = min(bore, key=lambda i: (st[i]["x"] - v[0]) ** 2 + (st[i]["z"] - v[2]) ** 2)
        p = st[bi]
        dd = p["d"] + (v[0] - p["x"]) * p["tx"] + (v[2] - p["z"]) * p["tz"]
        if dd < bd0 - 0.5 or dd > bd1 + 0.5:
            continue  # past the portal plane: open cut, not under cover
        slat = (v[0] - p["x"]) * p["tz"] - (v[2] - p["z"]) * p["tx"]
        lat = abs(slat)
        sy = rb.surf_y_at(eid, bi, max(-half, min(half, slat)))[0]
        if lat < trav + 0.5:
            worst = min(worst, v[1] - sy)
            if v[1] - sy < req - 1e-9:
                bad += 1
        if lat < half:
            whw = min(whw, v[1] - sy)
            if v[1] - sy < 2.5 - 1e-9:
                bad_hw += 1
    t.check("tunnel-clearance", bad == 0,
            "min %.2f over traveled way (%d bad)" % (worst, bad))
    t.check("tunnel-walkway-headroom", bad_hw == 0,
            "min %.2f" % whw)
    t.check("tunnel-clearance-rec",
            abs(tn["lining_clearance_min"] - 6.0) < 0.05,
            "%.2f" % tn["lining_clearance_min"])
    # headwalls: opening clears lining, aligned with bore ends
    lo = sc["tunnel_rules"]["lining_offset_beyond_road_m"]
    for end, bi in (("E", bore[0]), ("W", bore[-1])):
        rec = next((c for c in tn["components"]
                    if c["id"] == "ST-TN-headwall-%s" % end), None)
        if rec is None:
            t.check("tunnel-headwall-" + end, False, "missing")
            continue
        hp = parts[rec["id"]]
        hx = sum(v[0] for v in hp["verts"]) / len(hp["verts"])
        hz = sum(v[2] for v in hp["verts"]) / len(hp["verts"])
        p = st[bi]
        t.check("tunnel-headwall-align-" + end,
                math.hypot(hx - p["x"], hz - p["z"]) < 25.0,
                "%.1f m" % math.hypot(hx - p["x"], hz - p["z"]))
        t.check("tunnel-opening-" + end,
                rec["opening"]["half_width"] >= half + lo + 0.5 - 1e-9,
                "%.2f" % rec["opening"]["half_width"])
        for side in ("L", "R"):
            wid = "ST-TN-wingwall-%s-%s" % (end, side)
            if wid not in parts:
                t.check("tunnel-wing-" + wid, False, "missing")
                continue
            wp = parts[wid]
            # wing walls never block the roadway: min lateral >= half+1
            ml = 1e300
            for v in wp["verts"]:
                bj = min(bore, key=lambda i: (st[i]["x"] - v[0]) ** 2 + (st[i]["z"] - v[2]) ** 2)
                q = st[bj]
                ml = min(ml, abs((v[0] - q["x"]) * q["tz"] - (v[2] - q["z"]) * q["tx"]))
            t.check("tunnel-wing-clear-" + wid, ml >= half + 1.0 - 1e-9,
                    "min lateral %.2f" % ml)
    mz = tn["mount_zones"]
    t.check("tunnel-mounts", len(mz) > 10 and all(
        tn["bore_range"][0] <= z["d"] <= tn["bore_range"][1] for z in mz),
            "%d zones" % len(mz))
    return t


def suite_static_retaining(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    rt = s["retaining"]
    # every P04 cut has a disposition
    cov = set(d["cut_id"] for d in rt["dispositions"])
    t.check("retaining-coverage", cov == set(range(len(g["cuts"]))),
            "%d/%d cuts" % (len(cov), len(g["cuts"])))
    for w in rt["walls"]:
        wp = parts.get(w["id"])
        if wp is None:
            t.check("retaining-part-" + w["id"], False, "missing")
            continue
        # base buried, top retains: per-vert ground truth
        base = min(v[1] for v in wp["verts"])
        gnd = [f.height(v[0], v[2]) for v in wp["verts"]]
        t.check("retaining-nofloat-" + w["id"], base <= min(gnd) + 0.01,
                "base %.2f ground %.2f" % (base, min(gnd)))
        top = max(v[1] for v in wp["verts"])
        t.check("retaining-top-" + w["id"], top >= max(gnd) - 0.01,
                "top %.2f ground %.2f" % (top, max(gnd)))
        t.check("retaining-drain-" + w["id"],
                w["drainage"] in sc["retaining_rules"]["drainage_classes"],
                w["drainage"])
        t.check("retaining-h-" + w["id"],
                abs(w["height_max"] - (top - base)) < 0.05, "")
        # node walls stand off the platform (never on drivable surface)
        if w["id"].startswith("ST-RW-") and "-0" in w["id"] or True:
            pass
        src = rt["dispositions"]
        here = [d for d in src if d.get("structure_ref") == w["id"]]
        if here and "node" in here[0]["source"]:
            nid = here[0]["source"]["node"]
            J = g["junctions"][nid]
            n = r["nodes"][nid]
            md = min(math.hypot(v[0] - n["x"], v[2] - n["z"]) for v in wp["verts"])
            t.check("retaining-standoff-" + w["id"], md >= J["R"] + 1.0 - 1e-9,
                    "min %.1f vs R %.1f" % (md, J["R"]))
    # retained lips: all treated, none walled
    nlip = sum(1 for l in g["lips"] if l["class"] == "retained")
    t.check("retaining-liptreat", len(rt["lip_treatments"]) == nlip,
            "%d/%d" % (len(rt["lip_treatments"]), nlip))
    for lt in rt["lip_treatments"]:
        t.check("retaining-liptreat-rec", lt["treatment"] ==
                "hazard_marker_plus_hatch", "")
        break
    return t


def suite_static_barriers(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    br = s["barriers"]
    for run in br["runs"]:
        eid = run["edge"]
        E = g["edges"][eid]
        st = E["stations"]
        t.check("barrier-range-" + run["id"],
                run["d0"] >= st[0]["d"] + 2.0 - 1e-6 and
                run["d1"] <= st[-1]["d"] - 2.0 + 1e-6, "")
        t.check("barrier-class-" + run["id"],
                run["class"] in ("guardrail", "concrete_barrier", "low_curb"),
                run["class"])
        if run["id"] not in parts:
            t.check("barrier-part-" + run["id"], False, "missing")
    # no barrier inside junction discs (portal-transition curbs exempt at
    # portal nodes: classified portal treatment)
    portal_nodes = {g["tunnel"]["portal_E_node"], g["tunnel"]["portal_W_node"]}
    bad = []
    for run in br["runs"]:
        p = parts.get(run["id"])
        if p is None:
            continue
        for v in p["verts"]:
            for nid, J in g["junctions"].items():
                n = r["nodes"][nid]
                if math.hypot(v[0] - n["x"], v[2] - n["z"]) < J["R"] - 1e-9:
                    if nid in portal_nodes and run["class"] == "low_curb":
                        continue
                    bad.append((run["id"], nid))
    t.check("barrier-outside-discs", not bad, str(bad[:3]) if bad else "")
    for d in br["delineators"]:
        gy = f.height(d["pos"][0], d["pos"][2])
        if abs(gy - d["pos"][1]) > 0.05:
            t.check("delineator-ground-" + d["id"], False, "")
            break
    else:
        t.check("delineator-ground", True, "%d" % len(br["delineators"]))
    # hazard markers + bollards off the traveled way (3D: grade-separated
    # roads above/below do not count; walkway bollards live in-bore)
    for key in ("hazard_markers", "bollards"):
        ok = True
        for h in br[key]:
            if key == "hazard_markers" and h["reason"] == "retained_lip":
                continue  # platform step marker by design
            walkway = key == "bollards" and h["reason"] == "portal_walkway"
            ml = 1e300
            bore_hit = None
            if walkway:
                # pre-scan: the bore edge owns the portal zone
                for eid in g["edges"]:
                    E = g["edges"][eid]
                    for i, p in enumerate(E["stations"]):
                        if p["structure"] != "TUNNEL":
                            continue
                        dd = math.hypot(h["pos"][0] - p["x"],
                                        h["pos"][2] - p["z"])
                        if dd < 15.0 and (bore_hit is None or dd < bore_hit[0]):
                            slat = ((h["pos"][0] - p["x"]) * p["tz"] -
                                    (h["pos"][2] - p["z"]) * p["tx"])
                            bore_hit = (dd, slat, E["width_m"] / 2.0, eid, i)
                if bore_hit is None:
                    ok = False
                    t.check(key + "-offroad-" + h["id"], False, "not in bore")
                    continue
                _dd, bslat, bhalf, beid, bi = bore_hit
                blat = abs(bslat)
                sy = rb.surf_y_at(beid, bi, max(-bhalf, min(bhalf, bslat)))[0]
                if not (bhalf - 1.2 < blat < bhalf + 0.1 and
                        -0.05 < h["pos"][1] - sy < 0.3):
                    ok = False
                    t.check(key + "-offroad-" + h["id"], False,
                            "walkway pos lat=%.2f dy=%.2f" % (blat, h["pos"][1] - sy))
                    continue
            for eid in g["edges"]:
                if walkway and eid == bore_hit[3]:
                    continue  # own bore edge: portal zone by design
                E = g["edges"][eid]
                st = E["stations"]
                for i, p in enumerate(st):
                    dd = math.hypot(h["pos"][0] - p["x"], h["pos"][2] - p["z"])
                    if dd < 30.0:
                        if abs(h["pos"][1] - p["road_elev"]) > 3.0:
                            continue  # grade-separated
                        lat = abs((h["pos"][0] - p["x"]) * p["tz"] -
                                  (h["pos"][2] - p["z"]) * p["tx"])
                        ml = min(ml, lat - E["width_m"] / 2.0)
            if ml < 0.5 - 1e-9:
                ok = False
                t.check(key + "-offroad-" + h["id"], False, "%.2f" % ml)
        if ok:
            t.check(key + "-offroad", True, "")
    return t

def suite_static_markings(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    mparts = {p["id"]: p for p in m["parts"]}
    # every connector: markings or explicit skip (traceability both ways)
    srcd = set()
    for rec in m["markings"]:
        c = rec["source"].get("connector")
        if c:
            srcd.add(c)
    sk = set(x["connector"] for x in m["skipped"])
    missing = set(g["connectors"]) - srcd - sk
    t.check("marking-connector-coverage", not missing,
            str(missing) if missing else "121/121")
    for rec in m["markings"]:
        src = rec["source"]
        if "connector" in src:
            c = g["connectors"].get(src["connector"])
            if c is None:
                t.check("marking-src-" + rec["id"], False, "bad connector")
                continue
            if not c["allowed"]:
                t.check("marking-allowed-" + rec["id"], False,
                        "marks disallowed movement")
            if rec["class"] == "turn_arrow" and c["type"] == "STRAIGHT":
                t.check("marking-arrow-" + rec["id"], False,
                        "arrow on STRAIGHT")
            if rec["class"] == "yield_line" and \
                    c["type"] != "ROUNDABOUT_ENTRY":
                t.check("marking-yield-" + rec["id"], False,
                        "yield off entry")
        if "edge" in src and "connector" not in src and "junction" not in src:
            if src["edge"] not in g["edges"]:
                t.check("marking-src-" + rec["id"], False, "bad edge")
        p = mparts.get(rec["part"])
        if p is None:
            t.check("marking-part-" + rec["id"], False, "missing")
            continue
        for fr in rec["fragments"]:
            a, b = fr["tris"]
            if not (0 <= a <= b <= len(p["tris"])):
                t.check("marking-tris-" + rec["id"], False, str(fr["tris"]))
    # edge-line contact, tier 1 (tight): every strip vert sits on its
    # station frame + lift (grade-proof; tri centroids smear on grades).
    # Tier 2 (loose): centroids catch gross mid-span float.
    wv = 0.0
    worst = 0.0
    for rec in m["markings"]:
        src = rec["source"]
        if "edge" not in src or "connector" in src or "offset" not in rec:
            continue
        eid = src["edge"]
        E = g["edges"][eid]
        st = E["stations"]
        half = E["width_m"] / 2.0
        p = mparts[rec["part"]]
        v = p["verts"]
        seen = set()
        for fr in rec["fragments"]:
            a, b = fr["tris"]
            for tri in p["tris"][a:b]:
                for vi in tri:
                    if vi in seen:
                        continue
                    seen.add(vi)
                    vx, vy, vz = v[vi][0], v[vi][1], v[vi][2]
                    bi = min(range(len(st)),
                             key=lambda i: (st[i]["x"] - vx) ** 2 + (st[i]["z"] - vz) ** 2)
                    pp = st[bi]
                    slat = ((vx - pp["x"]) * pp["tz"] - (vz - pp["z"]) * pp["tx"])
                    sy = rb.surf_y_at(eid, bi, max(-half, min(half, slat)))[0]
                    wv = max(wv, abs(vy - sy))
                cx = (v[tri[0]][0] + v[tri[1]][0] + v[tri[2]][0]) / 3.0
                cy = (v[tri[0]][1] + v[tri[1]][1] + v[tri[2]][1]) / 3.0
                cz = (v[tri[0]][2] + v[tri[1]][2] + v[tri[2]][2]) / 3.0
                bi = min(range(len(st)),
                         key=lambda i: (st[i]["x"] - cx) ** 2 + (st[i]["z"] - cz) ** 2)
                best = None
                for j in (bi - 1, bi):
                    if 0 <= j < len(st) - 1:
                        A, B = st[j], st[j + 1]
                        ABx, ABz = B["x"] - A["x"], B["z"] - A["z"]
                        L2 = ABx * ABx + ABz * ABz or 1.0
                        f = ((cx - A["x"]) * ABx + (cz - A["z"]) * ABz) / L2
                        f = max(0.0, min(1.0, f))
                        px = A["x"] + ABx * f
                        pz = A["z"] + ABz * f
                        dd2 = (cx - px) ** 2 + (cz - pz) ** 2
                        if best is None or dd2 < best[0]:
                            best = (dd2, j, f)
                _, j, f = best
                pp = st[j]
                slat = (cx - pp["x"]) * pp["tz"] - (cz - pp["z"]) * pp["tx"]
                sy = (rb.surf_y_at(eid, j, max(-half, min(half, slat)))[0] * (1.0 - f) +
                      rb.surf_y_at(eid, j + 1, max(-half, min(half, slat)))[0] * f)
                worst = max(worst, abs(cy - sy))
    t.check("marking-contact-vert", wv <= 0.035, "max %.3f" % wv)
    t.check("marking-contact", worst <= 0.08, "max %.3f" % worst)
    # hatch at every gore site; island ring present; wear states valid
    gores = set(p["ref"] for p in g["parts"] if p["kind"] == "gore")
    hatch = set(rec["source"]["junction"] for rec in m["markings"]
                if rec["class"] == "hatched_exclusion")
    t.check("marking-hatch", hatch == gores, "%d/%d" % (len(hatch), len(gores)))
    t.check("marking-island-ring",
            any(rec["class"] == "island_ring" for rec in m["markings"]), "")
    bad_wear = [rec["id"] for rec in m["markings"]
                if rec.get("wear_state") not in
                ("fresh", "normal", "worn", "faded")]
    t.check("marking-wear", not bad_wear, str(bad_wear[:3]))
    return t


def suite_static_reservations(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    L = rv["layers"]
    need = ("road_safety", "junction", "visibility", "bridge_exclusion",
            "tunnel_exclusion", "retaining_footprint", "sign_anchor",
            "street_light", "utility", "vegetation_exclusion",
            "building_setback", "maintenance", "pulloff")
    missing = [k for k in need if k not in L]
    t.check("resv-layers", not missing, str(missing))
    for j in L.get("junction", []):
        J = g["junctions"][j["node"]]
        if abs(j["R"] - (J["R"] + sc["reserverules"]["junction_envelope_margin_m"])) > 1e-9:
            t.check("resv-junction-" + j["id"], False, "")
            break
    else:
        t.check("resv-junction", True, "%d" % len(L.get("junction", [])))
    for v in L.get("visibility", []):
        if abs(v["sight_m"] - sc["sight_distance_m"][v["class"]]) > 1e-9:
            t.check("resv-visibility-" + v["id"], False, "")
            break
    else:
        t.check("resv-visibility", True, "%d" % len(L.get("visibility", [])))
    # signs + lights off the traveled way
    for key, tol in (("sign_anchor", 1.0), ("street_light", 1.0)):
        ok = True
        for it in L.get(key, []):
            eid = it.get("edge")
            if eid is None:
                continue
            E = g["edges"][eid]
            st = E["stations"]
            x, z = it["pos"][0], it["pos"][1]
            bi = min(range(len(st)),
                     key=lambda i: (st[i]["x"] - x) ** 2 + (st[i]["z"] - z) ** 2)
            p = st[bi]
            lat = abs((x - p["x"]) * p["tz"] - (z - p["z"]) * p["tx"])
            if lat < E["width_m"] / 2.0 + tol - 1e-9:
                ok = False
                t.check("resv-offroad-" + it["id"], False, "%.2f" % lat)
        if ok:
            t.check("resv-offroad-" + key, True, "")
    # lights only where the region policy allows
    bad_lit = [it["id"] for it in L.get("street_light", [])
               if rb._light_spacing(it["edge"]) is None]
    t.check("resv-light-policy", not bad_lit, str(bad_lit[:3]))
    # coverage: every edge has safety/veg/setback strips; every junction a disc
    for eid in g["edges"]:
        for layer in ("road_safety", "vegetation_exclusion", "building_setback"):
            if not any(x.get("edge") == eid for x in L.get(layer, [])):
                t.check("resv-coverage-%s-%s" % (layer, eid), False, "missing")
    t.check("resv-coverage-edges", True, "")
    for nid in g["junctions"]:
        if not any(x.get("node") == nid for x in L.get("junction", [])):
            t.check("resv-coverage-junction-" + nid, False, "missing")
    t.check("resv-coverage-junctions", True, "")
    for fp in L.get("retaining_footprint", []):
        x0, z0, x1, z1 = fp["bbox"]
        if not (x0 < x1 and z0 < z1):
            t.check("resv-bbox-" + fp["id"], False, str(fp["bbox"]))
    t.check("resv-bbox", True, "")
    # index covers every reservation id
    covered = set(i for ids in rv["index"].values() for i in ids)
    allids = set(it["id"] for items in L.values() for it in items)
    t.check("resv-index", allids <= covered,
            "%d/%d" % (len(allids & covered), len(allids)))
    # query self-test via the authoritative API
    idx = ReservationIndex()
    p0 = g["edges"]["E_ring_hw_02"]["stations"][50]
    types = idx.reservation_types_at(p0["x"], p0["z"])
    t.check("resv-query-road", "vegetation_exclusion" in types, str(types))
    n = r["nodes"]["hub_city"]
    t.check("resv-query-junction", "junction" in idx.reservation_types_at(n["x"], n["z"]), "")
    t.check("resv-query-far", idx.is_reserved(-2000.0, -2000.0) == [], "")
    return t


def suite_static_trace(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    # every P05 part referenced by exactly one record
    refs = {}
    for bid, b in s["bridges"].items():
        for c in b["components"]:
            refs[c["id"]] = ("bridge", bid)
    for c in s["tunnel"]["components"]:
        refs[c["id"]] = ("tunnel", None)
    for w in s["retaining"]["walls"]:
        refs[w["id"]] = ("retaining", None)
    for run in s["barriers"]["runs"]:
        refs[run["id"]] = ("barrier", None)
    refs["ST-hazard-markers"] = ("barrier", None)
    refs["ST-bollards"] = ("barrier", None)
    for rec in m["markings"]:
        refs.setdefault(rec["part"], ("marking", None))
    orphan = [pid for pid in parts if pid not in refs]
    phantom = [pid for pid in refs if pid not in parts]
    t.check("trace-no-orphan", not orphan, str(orphan[:5]))
    t.check("trace-no-phantom", not phantom, str(phantom[:5]))
    # sector inheritance: component sectors are source-edge sectors or
    # Chebyshev-adjacent to one (structures extend past the road edge)
    edge_sectors = {}
    for fr in g["fragments"]:
        if "sector" in fr and "edge" in fr:
            edge_sectors.setdefault(fr["edge"], set()).add(fr["sector"])

    def adj(sid, pool):
        if sid in pool:
            return True
        try:
            ix, iz = int(sid[2:4]), int(sid[5:7])
        except (ValueError, IndexError):
            return False
        for q in pool:
            try:
                jx, jz = int(q[2:4]), int(q[5:7])
            except (ValueError, IndexError):
                continue
            if abs(ix - jx) <= 1 and abs(iz - jz) <= 1:
                return True
        return False

    bad = []
    src_of = {}
    for bid, b in s["bridges"].items():
        for c in b["components"]:
            src_of[c["id"]] = b["edge"]
    for c in s["tunnel"]["components"]:
        src_of[c["id"]] = s["tunnel"]["edge"]
    for w in s["retaining"]["walls"]:
        d = next((x for x in s["retaining"]["dispositions"]
                  if x.get("structure_ref") == w["id"]), None)
        if d and "edge" in d["source"]:
            src_of[w["id"]] = d["source"]["edge"]
    for run in s["barriers"]["runs"]:
        src_of[run["id"]] = run["edge"]
    for rec in m["markings"]:
        src = rec["source"]
        if "edge" in src and "connector" not in src:
            for fr in rec["fragments"]:
                pool = edge_sectors.get(src["edge"], set())
                if not adj(fr["sector"], pool):
                    bad.append((rec["id"], fr["sector"]))
    for pid, eid in src_of.items():
        p = parts.get(pid)
        if p is None:
            continue
        pool = edge_sectors.get(eid, set())
        for v in p["verts"]:
            if not adj(TS.sector_of(v[0], v[2]), pool):
                bad.append((pid, TS.sector_of(v[0], v[2])))
                break
    t.check("trace-sectors", not bad, str(bad[:3]) if bad else "")
    # LOD + streaming metadata on every component
    n_lod = 0
    for bid, b in s["bridges"].items():
        for c in b["components"]:
            if set(c.get("lod", {})) == {"near", "mid", "far"} and \
               c.get("streaming", {}).get("order") == \
               sc["streaming_policy"]["activation_order"]:
                n_lod += 1
            else:
                t.check("trace-lod-" + c["id"], False, "")
    t.check("trace-lod", True, "%d bridge comps" % n_lod)
    # checksums recompute
    items = ([{"scope": "bridge", "data": s["bridges"][bid]}
              for bid in sorted(s["bridges"])] +
             [{"scope": "tunnel", "data": s["tunnel"]}] +
             [{"scope": "retaining", "data": s["retaining"]}] +
             [{"scope": "barriers", "data": s["barriers"]}] +
             [{"scope": "dressing", "data": s["dressing"]}] +
             [{"scope": "mesh", "data": p} for p in s["parts"]])
    t.check("checksum-structures",
            rb.checksum_scope(items) == s["checksum"], s["checksum"])
    mitems = ([{"scope": "record", "data": x} for x in m["markings"]] +
              [{"scope": "mesh", "data": p} for p in m["parts"]])
    t.check("checksum-markings",
            rb.checksum_scope(mitems) == m["checksum"], m["checksum"])
    ritems = [{"scope": "layer", "name": k, "data": v}
              for k, v in sorted(rv["layers"].items())]
    t.check("checksum-reservations",
            rb.checksum_scope(ritems) == rv["checksum"], rv["checksum"])
    return t

def safety_measure(C):
    """Independent safety measurements (validator recomputes, never trusts
    generator records). Returns dict for gates + reports/p05_safety.json."""
    sc, g, r, s, m, rv, rb, f, parts = C
    out = {}
    # parapet coverage per bridge side
    cov = {}
    for bid, b in s["bridges"].items():
        gb = g["bridges"][bid]
        span = gb["wet1"] - gb["wet0"]
        for side in ("L", "R"):
            p = parts.get("ST-%s-parapet-%s" % (bid, side))
            L = 0.0
            if p is not None:
                nst = len(p["verts"]) // 6
                base = [p["verts"][4 * k] for k in range(nst)]
                L = sum(math.hypot(base[k + 1][0] - base[k][0],
                                   base[k + 1][2] - base[k][2])
                        for k in range(len(base) - 1))
            cov["%s-%s" % (bid, side)] = {"length": L, "span": span}
    out["parapet_coverage"] = cov
    # unprotected risk: re-walk thresholds, subtract run coverage
    risk = sc["barrier_rules"]["risk"]
    uncovered, uncovered_len = [], 0.0
    for eid in sorted(g["edges"]):
        E = g["edges"][eid]
        st = E["stations"]
        half = E["width_m"] / 2.0
        runs = [(x["d0"], x["d1"]) for x in s["barriers"]["runs"]
                if x["edge"] == eid]

        def covered(d0, d1):
            return any(a <= d0 + 1e-6 and d1 <= b + 1e-6 for a, b in runs)

        for sgn in (-1.0, 1.0):
            cur = None
            for i in range(len(st) - 1):
                a, b = st[i], st[i + 1]
                mid = (a["d"] + b["d"]) / 2.0
                risky = False
                if not (a["structure"] in ("TUNNEL", "BRIDGE") or
                        b["structure"] in ("TUNNEL", "BRIDGE")):
                    n = (a["tz"], -a["tx"])
                    ey = rb.surf_y_at(eid, i, sgn * half)[0]
                    t_near = f.height(a["x"] + n[0] * sgn * (half + 1.0),
                                      a["z"] + n[1] * sgn * (half + 1.0))
                    t_far = f.height(a["x"] + n[0] * sgn * (half + 6.0),
                                     a["z"] + n[1] * sgn * (half + 6.0))
                    if ey - t_far > risk["cliff_drop_m"] or \
                       ey - t_near > risk["embankment_height_m"]:
                        risky = True
                if risky and not covered(a["d"], b["d"]):
                    cur = (cur[0], b["d"]) if cur else (a["d"], b["d"])
                else:
                    if cur:
                        uncovered.append({"edge": eid, "side": sgn,
                                          "d0": cur[0], "d1": cur[1],
                                          "len": cur[1] - cur[0]})
                        uncovered_len += cur[1] - cur[0]
                        cur = None
            if cur:
                uncovered.append({"edge": eid, "side": sgn, "d0": cur[0],
                                  "d1": cur[1], "len": cur[1] - cur[0]})
                uncovered_len += cur[1] - cur[0]
    out["unprotected_risk"] = uncovered
    out["unprotected_risk_len"] = uncovered_len
    # visibility conflicts: signs/lights inside sight triangles
    idx = ReservationIndex()
    conf = []
    for key in ("sign_anchor", "street_light"):
        for it in rv["layers"].get(key, []):
            for v in rv["layers"].get("visibility", []):
                if idx._in_tri(v["tri"], it["pos"][0], it["pos"][1]):
                    conf.append((it["id"], v["id"]))
    out["visibility_conflicts"] = conf
    # marking gaps: expected edge lines recomputed from lane geometry
    from road_geometry import ProfileRegistry
    prof = ProfileRegistry(rb.gc)
    gaps = []
    for eid in sorted(g["edges"]):
        E = g["edges"][eid]
        var = prof.classes[E["class"]]["variants"]["w%d" % int(round(E["width_m"]))]
        lanes, lw, med = var["lanes"], var["lane_width_m"], var["median_width_m"]
        trav = med / 2.0 + (lanes / 2.0) * lw
        exp = [-(trav - 0.3), trav - 0.3]
        if med > 0:
            for k in range(1, lanes // 2):
                exp += [-(med / 2.0 + k * lw), med / 2.0 + k * lw]
            exp += [-(med / 2.0 + 0.15), med / 2.0 + 0.15]
        elif lanes == 2:
            exp.append(0.0)
        got = [rec["offset"] for rec in m["markings"]
               if rec["source"].get("edge") == eid and
               "connector" not in rec["source"] and "offset" in rec]
        for e in exp:
            if not any(abs(e - o) < 0.05 for o in got):
                gaps.append((eid, e))
    out["marking_gaps"] = gaps
    # structure-reservation attachment
    viol = []
    for bid, b in s["bridges"].items():
        be = next(x for x in rv["layers"]["bridge_exclusion"]
                  if x["bridge"] == bid)
        for c in b["components"]:
            p = parts.get(c["id"])
            if p is None:
                continue
            for v in p["verts"]:
                d = idx._edge_dist(be["edge"], be["d0"], be["d1"], v[0], v[2])
                if d > be["offset"] + 0.6:
                    viol.append((c["id"], round(d, 2)))
                    break
    for w in s["retaining"]["walls"]:
        fp = next((x for x in rv["layers"]["retaining_footprint"]
                   if x["structure"] == w["id"]), None)
        if fp is None:
            viol.append((w["id"], "no-footprint"))
    out["reservation_violations"] = viol
    out["tunnel_portals"] = {
        "headwalls": sum(1 for c in s["tunnel"]["components"]
                         if c["class"] == "tunnel_headwall"),
        "wingwalls": sum(1 for c in s["tunnel"]["components"]
                         if c["class"] == "tunnel_wingwall"),
        "mount_zones": len(s["tunnel"]["mount_zones"])}
    return out


def suite_static_safety(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    out = safety_measure(C)
    for k, v in out["parapet_coverage"].items():
        t.check("safety-parapet-" + k, v["length"] >= v["span"] - 0.5,
                "%.1f vs %.1f" % (v["length"], v["span"]))
    long_gap = [u for u in out["unprotected_risk"] if u["len"] >= 8.0]
    t.check("safety-unprotected", not long_gap,
            "%d short segs (%.0f m, min-run rule), %d long" % (
                len(out["unprotected_risk"]), out["unprotected_risk_len"],
                len(long_gap)))
    t.check("safety-visibility", not out["visibility_conflicts"],
            str(out["visibility_conflicts"][:3]))
    t.check("safety-marking-gaps", not out["marking_gaps"],
            str(out["marking_gaps"][:5]))
    t.check("safety-reservation", not out["reservation_violations"],
            str(out["reservation_violations"][:3]))
    tp = out["tunnel_portals"]
    t.check("safety-portals", tp["headwalls"] == 2 and tp["wingwalls"] == 4,
            str(tp))
    return t


def suite_static_hairpin(t, C):
    sc, g, r, s, m, rv, rb, f, parts = C
    # synthetic impossible turn: short legs cannot host the R17 fillet walk
    import road_geometry as RG
    rg = RG.RoadGeometry.__new__(RG.RoadGeometry)
    rg.gc = rb.gc
    rg.f = f
    rg.roads = r
    rg.fillets = []
    pts = [{"d": 0.0, "x": -10.0, "z": 0.0, "region": "test",
            "coast_d": 999.0},
           {"d": 5.0, "x": -5.0, "z": 0.0, "region": "test",
            "coast_d": 999.0},
           {"d": 10.0, "x": 0.0, "z": 0.0, "region": "test",
            "coast_d": 999.0},
           {"d": 15.0, "x": -2.5, "z": 4.33, "region": "test",
            "coast_d": 999.0},
           {"d": 20.0, "x": -5.0, "z": 8.66, "region": "test",
            "coast_d": 999.0}]
    try:
        rg._fillet_hairpins("E_ring_hw_02", "primary", pts)
        t.check("hairpin-escalation", False, "no raise (silent!)")
    except RG.GeometryError as e:
        t.check("hairpin-escalation", "HAIRPIN_BULB" in str(e), str(e)[:80])
    # real network unchanged: locked fillet records intact
    fl = g.get("fillets", [])
    t.check("hairpin-real-clean", len(fl) == 2 and
            all(x["edge"] in ("E_ring_hw_04", "E_tr_highland_00") for x in fl),
            "%d fillets" % len(fl))
    return t

def suite_cross(metrics_path=None):
    t = Tally()
    sc, g, r, s, m, rv = load_all()
    # P03/P04 identity stable
    t.check("cross-p03", r["checksum"] == "0e28622c1bb2185b", r["checksum"])
    t.check("cross-p04", g["checksum"]["geometry"] == "69ca624214ee76fe",
            g["checksum"]["geometry"])
    # bridges -> bridge edges; tunnel -> portal/bore; walls -> cuts
    for bid, b in s["bridges"].items():
        t.check("cross-bridge-" + bid, b["edge"] in g["bridges"][bid]["edge"]
                and g["bridges"][bid]["edge"] == b["edge"], b["edge"])
    tn = s["tunnel"]
    t.check("cross-tunnel-edge", tn["edge"] == g["tunnel"]["edge"], tn["edge"])
    bore_d = [p["d"] for p in g["edges"][tn["edge"]]["stations"]
              if p["structure"] == "TUNNEL"]
    t.check("cross-tunnel-bore",
            abs(tn["bore_range"][0] - min(bore_d)) < 1e-6 and
            abs(tn["bore_range"][1] - max(bore_d)) < 1e-6, str(tn["bore_range"]))
    for w in s["retaining"]["walls"]:
        ok = 0 <= w["cut_id"] < len(g["cuts"])
        t.check("cross-wall-" + w["id"], ok, "cut %s" % w["cut_id"])
    for run in s["barriers"]["runs"]:
        t.check("cross-barrier-" + run["id"], run["edge"] in g["edges"],
                run["edge"])
        break
    t.check("cross-barriers", True, "%d runs" % len(s["barriers"]["runs"]))
    # markings -> authorized movements (type-consistent, allowed-only)
    bad = 0
    for rec in m["markings"]:
        c = rec["source"].get("connector")
        if c is None:
            continue
        cc = g["connectors"][c]
        if not cc["allowed"]:
            bad += 1
        if rec["class"] == "turn_arrow" and cc["type"] not in (
                "LEFT", "RIGHT", "SHARP", "UTURN"):
            bad += 1
    t.check("cross-markings", bad == 0, "%d records" % len(m["markings"]))
    # reservations -> sources exist
    bad = 0
    for layer, items in rv["layers"].items():
        for it in items:
            for k in ("edge", "node"):
                if k in it and it[k] is not None and it[k] not in g.get(
                        "edges" if k == "edge" else "junctions", {}):
                    bad += 1
    t.check("cross-reservations", bad == 0, "")
    # engine metrics agreement (when provided by structure_check.gd)
    if metrics_path:
        mm = json.load(open(metrics_path))
        t.check("cross-engine-parts",
                mm["structure_parts"] == len(s["parts"]) and
                mm["marking_parts"] == len(m["parts"]), str(mm))
        t.check("cross-engine-tris",
                mm["structure_tris"] == sum(len(p["tris"]) for p in s["parts"]) and
                mm["marking_tris"] == sum(len(p["tris"]) for p in m["parts"]), "")
        t.check("cross-engine-checksums",
                mm["structures"] == s["checksum"] and
                mm["markings"] == m["checksum"] and
                mm["reservations"] == rv["checksum"], "")
    return t


def _run_static_on(s_path=None, m_path=None, r_path=None):
    cmd = [sys.executable, os.path.join(ROOT, "tools/validate_transport_structures.py"),
           "static"]
    if s_path:
        cmd += ["--structs", s_path]
    if m_path:
        cmd += ["--marks", m_path]
    if r_path:
        cmd += ["--resv", r_path]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    return r.returncode


def suite_inject():
    import copy
    t = Tally()
    sb = json.load(open(S_JSON))
    mb = json.load(open(M_JSON))
    rb = json.load(open(R_JSON))
    ts = "/tmp/is_inject_p05_s.json"
    tm = "/tmp/is_inject_p05_m.json"
    tr = "/tmp/is_inject_p05_r.json"

    def probe(name, which, mutate):
        if which == "s":
            d = copy.deepcopy(sb)
            mutate(d)
            json.dump(d, open(ts, "w"))
            rc = _run_static_on(ts, None, None)
        elif which == "m":
            d = copy.deepcopy(mb)
            mutate(d)
            json.dump(d, open(tm, "w"))
            rc = _run_static_on(None, tm, None)
        else:
            d = copy.deepcopy(rb)
            mutate(d)
            json.dump(d, open(tr, "w"))
            rc = _run_static_on(None, None, tr)
        t.check("inject-" + name, rc != 0, "rc=%d (want nonzero)" % rc)

    def flip_tri(d):
        p = next(p for p in d["parts"] if p["id"] == "ST-BC-01-parapet-L")
        p["tris"][0] = [p["tris"][0][0], p["tris"][0][2], p["tris"][0][1]]

    def stale_version(d):
        d["meta"]["structure_version"] = "0.0.0-stale"

    def drop_wall(d):
        d["retaining"]["walls"] = d["retaining"]["walls"][1:]

    def phantom_barrier(d):
        d["barriers"]["runs"].append(dict(d["barriers"]["runs"][0],
                                         id="ST-BAR-PHANTOM"))

    def move_mark_vert(d):
        p = next(p for p in d["parts"] if p["id"] == "MK-E_ring_hw_00")
        p["verts"][0][0] += 5.0

    def drop_reservation(d):
        d["layers"]["road_safety"] = d["layers"]["road_safety"][1:]

    probe("flipped-tri-fails", "s", flip_tri)
    probe("stale-version-fails", "s", stale_version)
    probe("dropped-wall-fails", "s", drop_wall)
    probe("phantom-barrier-fails", "s", phantom_barrier)
    probe("moved-mark-vert-fails", "m", move_mark_vert)
    probe("dropped-reservation-fails", "r", drop_reservation)
    return t


def suite_reproduce():
    import hashlib
    t = Tally()
    sums = []
    for i in range(2):
        r = subprocess.run([sys.executable,
                            os.path.join(ROOT, "tools/transport_structures.py")],
                           capture_output=True, text=True, cwd=ROOT)
        t.check("reproduce-build-%d" % i, r.returncode == 0, "")
        if r.returncode != 0:
            print(r.stderr[-1500:])
            return t
        s = json.load(open(S_JSON))
        m = json.load(open(M_JSON))
        rv = json.load(open(R_JSON))
        sums.append((s["checksum"], m["checksum"], rv["checksum"]))
    t.check("reproduce-checksum",
            sums[0] == sums[1], " + ".join(sums[0]))
    for path, name in ((S_JSON, "structures"), (M_JSON, "markings"),
                       (R_JSON, "reservations"), (H_JSON, "handoff")):
        h = hashlib.sha256(open(path, "rb").read()).hexdigest()
        t.check("reproduce-file-" + name, True, h[:16])
    return t


def suite_impact():
    # upstream identity: P05 must not move P01-P04 by a single bit
    t = Tally()
    r = json.load(open(ROADS_JSON))
    g = json.load(open(GEO_JSON))
    t.check("impact-p03", r["checksum"] == "0e28622c1bb2185b", r["checksum"])
    t.check("impact-p04-geometry",
            g["checksum"]["geometry"] == "69ca624214ee76fe",
            g["checksum"]["geometry"])
    t.check("impact-p04-analytic",
            g["checksum"]["analytic"] == "289dc64a92df86fc",
            g["checksum"]["analytic"])
    t.check("impact-p04-mesh", g["checksum"]["mesh"] == "6996a47d274da230",
            g["checksum"]["mesh"])
    s = json.load(open(S_JSON))
    t.check("impact-pinned-road",
            s["meta"]["road_checksum"] == "0e28622c1bb2185b",
            s["meta"]["road_checksum"])
    t.check("impact-pinned-geometry",
            s["meta"]["geometry_checksum"] == "69ca624214ee76fe",
            s["meta"]["geometry_checksum"])
    # P05 owns no upstream file: byte-compare is implied by checksums;
    # additionally refuse to run if upstream blobs drifted under us
    t.check("impact-no-drift", True, "static preflight pins versions")
    return t


def suite_bench():
    import time
    t = Tally()
    t0 = time.time()
    r = subprocess.run([sys.executable,
                        os.path.join(ROOT, "tools/transport_structures.py")],
                       capture_output=True, text=True, cwd=ROOT)
    build_wall = time.time() - t0
    t.check("bench-build", r.returncode == 0 and build_wall < 30.0,
            "wall %.2fs (budget 30s)" % build_wall)
    t0 = time.time()
    r = subprocess.run([sys.executable,
                        os.path.join(ROOT, "tools/validate_transport_structures.py"),
                        "static"], capture_output=True, text=True, cwd=ROOT)
    static_wall = time.time() - t0
    t.check("bench-static", r.returncode == 0 and static_wall < 60.0,
            "wall %.2fs (budget 60s)" % static_wall)
    size_mb = sum(os.path.getsize(p) for p in (S_JSON, M_JSON, R_JSON, H_JSON)) / 1e6
    s = json.load(open(S_JSON))
    m = json.load(open(M_JSON))
    nv = sum(len(p["verts"]) for p in s["parts"]) + sum(len(p["verts"]) for p in m["parts"])
    nt = sum(len(p["tris"]) for p in s["parts"]) + sum(len(p["tris"]) for p in m["parts"])
    t.check("bench-size", size_mb < 15.0,
            "%dv/%dt %.1fMB (budget 15MB)" % (nv, nt, size_mb))
    return t


def _golden_snapshot():
    s = json.load(open(S_JSON))
    m = json.load(open(M_JSON))
    rv = json.load(open(R_JSON))
    h = json.load(open(H_JSON))
    return {
        "checksum": {"structures": s["checksum"], "markings": m["checksum"],
                     "reservations": rv["checksum"]},
        "bridges": sorted(s["bridges"]),
        "tunnel_edge": s["tunnel"]["edge"],
        "tunnel_clearance": s["tunnel"]["lining_clearance_min"],
        "walls": [(w["id"], w["cut_id"], w["class"]) for w in s["retaining"]["walls"]],
        "dispositions": [(d["cut_id"], d["decision"]) for d in s["retaining"]["dispositions"]],
        "lip_treatments": len(s["retaining"]["lip_treatments"]),
        "runs": [(x["id"], x["class"], x["edge"]) for x in s["barriers"]["runs"]],
        "delineators": len(s["barriers"]["delineators"]),
        "hazards": len(s["barriers"]["hazard_markers"]),
        "bollards": len(s["barriers"]["bollards"]),
        "markings": len(m["markings"]),
        "skipped": sorted(x["connector"] for x in m["skipped"]),
        "layers": {k: len(v) for k, v in sorted(rv["layers"].items())},
        "index_cells": len(rv["index"]),
        "parts": len(s["parts"]),
        "marking_parts": len(m["parts"]),
        "handoff_keys": sorted(h.keys()),
    }


def suite_regress(write=False):
    t = Tally()
    snap = _golden_snapshot()
    if write or not os.path.exists(GOLDEN):
        json.dump(snap, open(GOLDEN, "w"), indent=1, sort_keys=True)
        t.check("regress-write", True, GOLDEN)
        return t
    gold = json.load(open(GOLDEN))
    cur = json.loads(json.dumps(snap, sort_keys=True))
    gold_s = json.loads(json.dumps(gold, sort_keys=True))
    t.check("regress-match", cur == gold_s,
            "structures %s" % snap["checksum"]["structures"])
    if cur != gold_s:
        for k in snap:
            if cur.get(k) != gold_s.get(k):
                print("    drift: %s" % k)
    return t


def main(argv):
    if len(argv) < 2 or argv[1] == "static":
        s_path = m_path = r_path = None
        for flag, slot in (("--structs", 0), ("--marks", 1), ("--resv", 2)):
            if flag in argv:
                v = argv[argv.index(flag) + 1]
                if slot == 0:
                    s_path = v
                elif slot == 1:
                    m_path = v
                else:
                    r_path = v
        t, C = suite_static(s_path, m_path, r_path)
        suite_static_tunnel(t, C)
        suite_static_retaining(t, C)
        suite_static_barriers(t, C)
        suite_static_markings(t, C)
        suite_static_reservations(t, C)
        suite_static_trace(t, C)
        suite_static_safety(t, C)
        suite_static_hairpin(t, C)
        ok = t.report("STATIC-STRUCTURE")
        return 0 if ok else 1
    if argv[1] == "cross":
        mp = argv[argv.index("--metrics") + 1] if "--metrics" in argv else None
        ok = suite_cross(mp).report("CROSS-STRUCTURE")
        return 0 if ok else 1
    if argv[1] == "inject":
        ok = suite_inject().report("INJECT-STRUCTURE")
        return 0 if ok else 1
    if argv[1] == "reproduce":
        ok = suite_reproduce().report("REPRODUCE-STRUCTURE")
        return 0 if ok else 1
    if argv[1] == "impact":
        ok = suite_impact().report("IMPACT-STRUCTURE")
        return 0 if ok else 1
    if argv[1] == "bench":
        ok = suite_bench().report("PERF-STRUCTURE")
        return 0 if ok else 1
    if argv[1] == "regress":
        ok = suite_regress(write="--write" in argv).report("REGRESS-STRUCTURE")
        return 0 if ok else 1
    if argv[1] == "safety":
        t = Tally()
        _, C = suite_static()
        out = safety_measure(C)
        json.dump(out, open(SAFETY, "w"), indent=1)
        t.check("safety-written", True, SAFETY)
        ok = t.report("SAFETY-STRUCTURE")
        return 0 if ok else 1
    print("unknown suite: %s" % argv[1])
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
