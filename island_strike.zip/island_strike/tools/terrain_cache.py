#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 02 — versioned derived-grid cache.

Derived grids (height/region rasters) are expensive; this cache stores them
under data/derived/cache/ as <name>.npz + <name>.json. Every entry is pinned
to the data versions that produced it (terrain/coast/authoring/world) plus a
FNV checksum of the payload bytes, so a stale or corrupted cache can never
be trusted silently:

  * versions differ   -> cache MISS (recompute)
  * checksum mismatch -> cache CORRUPT (recompute; reported, never used)
  * params differ     -> cache MISS (recompute)

Validators never accept cached values without a hit; the invalid-cache test
(validate_terrain.py) corrupts entries on /tmp copies and asserts loud
recompute. Cache files are machine-local speed only and are NOT authoritative.
"""
import json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import fnv1a_hex, load_all  # noqa: E402

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DIR = os.path.join(ROOT, "data/derived/cache")
MODEL_VERSION = "terrain_model/1"


def current_versions() -> dict:
    t, c, a, w = load_all()
    return {
        "model": MODEL_VERSION,
        "terrain_version": t["terrain_version"],
        "coast_version": c["coast_version"],
        "authoring_version": a["meta"]["authoring_version"],
        "world_version": w["world_version"],
    }


def _paths(name: str):
    os.makedirs(CACHE_DIR, exist_ok=True)
    return (os.path.join(CACHE_DIR, name + ".npz"),
            os.path.join(CACHE_DIR, name + ".json"))


def _payload_checksum(arrays: dict) -> str:
    h = 14695981039346656037
    for k in sorted(arrays):
        arr = np.ascontiguousarray(arrays[k])
        blob = (k + arr.dtype.str + str(arr.shape)).encode() + arr.tobytes()
        for b in blob:
            h = ((h ^ b) * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return format(h, "016x")


def cached_grid(name: str, params: dict, compute):
    """Return (arrays_dict, status) where status is HIT/MISS/CORRUPT-recomputed.

    compute() must return a dict of numpy arrays (deterministic). params is
    recorded in the sidecar and must match for a hit.
    """
    npz_path, meta_path = _paths(name)
    want_versions = current_versions()
    if os.path.exists(npz_path) and os.path.exists(meta_path):
        try:
            meta = json.load(open(meta_path))
            if (meta.get("versions") == want_versions
                    and meta.get("params") == params):
                with np.load(npz_path) as z:
                    arrays = {k: z[k] for k in z.files}
                if _payload_checksum(arrays) == meta.get("checksum_hex"):
                    return arrays, "HIT"
                status = "CORRUPT"
            else:
                status = "MISS"
        except Exception:
            status = "CORRUPT"
    else:
        status = "MISS"
    arrays = compute()
    arrays = {k: np.ascontiguousarray(v) for k, v in arrays.items()}
    meta = {"versions": want_versions, "params": params,
            "checksum_hex": _payload_checksum(arrays)}
    np.savez_compressed(npz_path, **arrays)
    json.dump(meta, open(meta_path, "w"), indent=2, sort_keys=True)
    return arrays, status + "-recomputed"


def invalidate(name: str) -> None:
    for p in _paths(name):
        if os.path.exists(p):
            os.remove(p)


if __name__ == "__main__":
    print("cache dir:", CACHE_DIR)
    print("versions:", json.dumps(current_versions(), sort_keys=True))
