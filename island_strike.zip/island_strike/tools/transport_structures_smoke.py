#!/usr/bin/env python3
"""P05 transport structures smoke: rebuild + gate counts + checksums.

Fast CI gate (no engine): runs the builder, asserts bridge/tunnel/wall/
barrier/marking/reservation inventories, and prints the 3 checksums.
Exit 0 = all smoke gates pass.
"""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S_JSON = os.path.join(ROOT, "data/derived/transport_structures.json")
M_JSON = os.path.join(ROOT, "data/derived/transport_markings.json")
R_JSON = os.path.join(ROOT, "data/derived/transport_reservations.json")

GATES = {
    "bridges": 2, "walls": 10, "runs": 12, "marks": 323, "skipped": 10,
    "layers": 13, "structure_parts": 43, "marking_parts": 52,
    "delineators": 204, "hazards": 16, "bollards": 8, "lights": 195,
    "signs": 65,
}


def main():
    r = subprocess.run([sys.executable, os.path.join(ROOT, "tools/transport_structures.py")],
                       capture_output=True, text=True, cwd=ROOT)
    print(r.stdout.strip().splitlines()[-1] if r.stdout else "")
    if r.returncode != 0:
        print("SMOKE-FAIL: builder red")
        print(r.stderr[-2000:])
        return 1
    s = json.load(open(S_JSON))
    m = json.load(open(M_JSON))
    rv = json.load(open(R_JSON))
    bad = []
    actual = {
        "bridges": len(s["bridges"]), "walls": len(s["retaining"]["walls"]),
        "runs": len(s["barriers"]["runs"]), "marks": len(m["markings"]),
        "skipped": len(m["skipped"]), "layers": len(rv["layers"]),
        "structure_parts": len(s["parts"]), "marking_parts": len(m["parts"]),
        "delineators": len(s["barriers"]["delineators"]),
        "hazards": len(s["barriers"]["hazard_markers"]),
        "bollards": len(s["barriers"]["bollards"]),
        "lights": len(rv["layers"]["street_light"]),
        "signs": len(rv["layers"]["sign_anchor"]),
    }
    for k, want in GATES.items():
        ok = actual[k] == want
        print("  [%s] %s = %s (want %s)" % ("PASS" if ok else "FAIL", k, actual[k], want))
        if not ok:
            bad.append(k)
    print("checksums: %s %s %s" % (s["checksum"], m["checksum"], rv["checksum"]))
    print("SMOKE-STRUCTURE: %d/%d passed" % (len(GATES) - len(bad), len(GATES)))
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
