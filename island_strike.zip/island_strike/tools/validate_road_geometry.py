#!/usr/bin/env python3
"""ISLAND STRIKE Prompt 04 -- road geometry validator.

Suites: static | cross <godot-metrics.json> | inject | reproduce | bench | regress.
STATIC-GEOMETRY validates data/derived/road_geometry.json (built by
road_geometry.py) against data/world/road_geometry_contract.json +
live terrain (P02 LOCKED) + locked P03 graph (P03 LOCKED).

Orientation doctrine (enforced): uniform-chirality surfaces use fixed
emission orders (deviation = defect); label-dependent patches (bowtie
lobes/noses, straddling strips, butt wedge) orient by exhaustion and
are verified up-facing + coverage-complete here.
Edge-use doctrine: boundary 1, interior 2 (any directions;
same-direction pairs allowed), 3+ = defect.
Lip doctrine: steep road faces (ny<0.2) are classified curb (h<=0.05),
gore (h<=1.0, contested site), retained (h<=5.0, tunnel-adjacent
junction); unclassified steep = defect.
"""
import json
import math
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from terrain_model import Field  # noqa: E402
import road_geometry as RG  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEO_CC = os.path.join(ROOT, "data/world/road_geometry_contract.json")
GEO_JSON = os.path.join(ROOT, "data/derived/road_geometry.json")
ROADS_JSON = os.path.join(ROOT, "data/derived/roads.json")
NAV_JSON = os.path.join(ROOT, "data/derived/road_nav_handoff.json")
TRAFFIC_JSON = os.path.join(ROOT, "data/derived/road_traffic_handoff.json")
COLL_JSON = os.path.join(ROOT, "data/derived/road_collision.json")
GOLDEN = os.path.join(ROOT, "reports/p04_geometry_golden.json")


class Tally:
    def __init__(self):
        self.n = 0
        self.bad = []

    def check(self, name, ok, detail=""):
        self.n += 1
        print("  [%s] %s  %s" % ("PASS" if ok else "FAIL", name, detail))
        if not ok:
            self.bad.append(name)

    def report(self, suite):
        print("%s: %d/%d passed" % (suite, self.n - len(self.bad), self.n))
        return not self.bad


def tri_ny_area(A, B, C):
    ux, uy, uz = B[0] - A[0], B[1] - A[1], B[2] - A[2]
    vx, vy, vz = C[0] - A[0], C[1] - A[1], C[2] - A[2]
    nx = uy * vz - uz * vy
    ny = uz * vx - ux * vz
    nz = ux * vy - uy * vx
    area = math.sqrt(nx * nx + ny * ny + nz * nz) / 2.0
    return (ny / (2.0 * area) if area > 0 else 0.0), area


def suite_static():
    t = Tally()
    gc = json.load(open(GEO_CC))
    g = json.load(open(GEO_JSON))
    r = json.load(open(ROADS_JSON))
    f = Field()
    # ---- A. versions + graph lock ----
    sch = json.load(open(os.path.join(
        ROOT, "data/world/road_geometry_contract.schema.json")))
    missing = [k for k in sch["required"] if k not in gc]
    t.check("schema-contract-keys", not missing,
            str(missing) if missing else "%d keys" % len(sch["required"]))
    for k, spec in sch["properties"].items():
        for rk in spec.get("required", []) if isinstance(spec, dict) else []:
            if rk not in gc.get(k, {}):
                t.check("schema-%s-%s" % (k, rk), False, "missing")
    t.check("schema-contract-subkeys", True, "all required subkeys present")
    m = g["meta"]
    t.check("version-geometry", m["geometry_version"] == gc["geometry_version"],
            m["geometry_version"])
    t.check("version-profile", m["profile_version"] == gc["profile_version"])
    t.check("version-road", m["road_version"] == gc["road_version"])
    t.check("version-terrain",
            m["terrain_version"] == gc["terrain_version_reference"])
    t.check("version-coast", m["coast_version"] == gc["coast_version_reference"])
    t.check("version-world", m["world_version"] == gc["world_version"])
    t.check("p03-checksum",
            m["road_checksum"] == r["checksum"] == "0e28622c1bb2185b",
            r["checksum"])
    t.check("graph-edges", sorted(g["edges"]) == sorted(r["edges"]),
            "%d edges" % len(g["edges"]))
    for eid in sorted(g["edges"]):
        E, P = g["edges"][eid], r["edges"][eid]
        ok = (E["class"] == P["class"] and E["access"] == P["access"] and
              E["route"] == P["route"] and E["from_node"] == P["from_node"] and
              E["to_node"] == P["to_node"] and E["tunnel"] == P["tunnel"] and
              abs(E["width_m"] - P["width_m"]) < 1e-9)
        if not ok:
            t.check("graph-edge-" + eid, False, "topology drift")
    t.check("graph-edge-fields", True, "25 edges topology-identical")
    butt_nodes = sorted(bj["node"] for bj in g["butt_joints"])
    t.check("graph-nodes",
            sorted(list(g["junctions"]) + butt_nodes) == sorted(r["nodes"]),
            "%d junctions + %d butt" % (len(g["junctions"]), len(butt_nodes)))
    # ---- B. mesh persistence recompute (bitwise) ----
    parts = {p["id"]: p for p in g["parts"]}
    mesh2, _, _ = RG.build_mesh(g, gc)
    ok = len(mesh2) == len(parts)
    det = "%d parts" % len(mesh2)
    if ok:
        for p in mesh2:
            q = parts.get(p["id"])
            if q is None or q["verts"] != p["verts"] or q["tris"] != p["tris"]:
                ok = False
                det = "mismatch at " + p["id"]
                break
    t.check("mesh-bitwise", ok, det)
    nv = sum(len(p["verts"]) for p in mesh2)
    nt = sum(len(p["tris"]) for p in mesh2)
    t.check("mesh-counts", g["mesh_counts"] == {"parts": len(mesh2),
                                                "verts": nv, "tris": nt},
            "%dv/%dt" % (nv, nt))
    # ---- C. triangle rules ----
    skip = float(gc["mesh_rules"]["skip_area_m2"])
    lips = {(l["part"], tuple(l["tri"])): l for l in g["lips"]}
    n_up = n_tot = 0
    min_area = 1e300
    min_ny = 1e300
    unlisted_steep = []
    lip_missing = set(lips)
    for pid, p in sorted(parts.items()):
        sk = set(p.get("skirt", []))
        v = p["verts"]
        for tri in p["tris"]:
            n_tot += 1
            A, B, C = v[tri[0]], v[tri[1]], v[tri[2]]
            nyu, area = tri_ny_area(A, B, C)
            if area < skip:
                t.check("tri-area-" + pid, False, "%s area %.2e" % (tri, area))
            min_area = min(min_area, area)
            min_ny = min(min_ny, nyu)
            if nyu <= 0:
                t.check("tri-up-" + pid, False, "%s ny=%.2e" % (tri, nyu))
            else:
                n_up += 1
            if any(i in sk for i in tri):
                continue  # skirt wall face
            if nyu < 0.2:
                key = (pid, tuple(tri))
                if key in lips:
                    lip_missing.discard(key)
                else:
                    unlisted_steep.append((pid, tri, nyu, area))
    t.check("tri-all-up", n_up == n_tot, "%d/%d up" % (n_up, n_tot))
    t.check("tri-min-area", min_area > skip * 1000,
            "min %.2e (skip %.0e, sep x%.0f)" % (min_area, skip, min_area / skip))
    t.check("tri-no-unlisted-steep", not unlisted_steep,
            str(unlisted_steep[:3]) if unlisted_steep else
            "all steep road faces listed (%d lips)" % len(lips))
    t.check("tri-no-phantom-lips", not lip_missing,
            str(list(lip_missing)[:3]) if lip_missing else "")
    # ---- D. lip gates ----
    gates = {"curb": 0.05, "gore": 1.0, "retained": 5.0}
    tun_edges = {eid for eid, E in g["edges"].items() if E["tunnel"]}
    for l in g["lips"]:
        ok = l["height"] <= gates[l["class"]] + 1e-9
        t.check("lip-gate-%s-%s" % (l["part"], l["tri"]), ok,
                "%s h=%.3f" % (l["class"], l["height"]))
        if l["class"] == "retained":
            nid = l["part"].split("-", 1)[1]
            J = g["junctions"].get(nid)
            t.check("lip-retained-context-%s" % l["part"],
                    J is not None and any(mm["edge"] in tun_edges
                                          for mm in J["mouths"]), nid)
        if l["class"] == "gore" and not l["part"].startswith("butt-"):
            nid = l["part"].split("-", 1)[1]
            t.check("lip-gore-context-%s" % l["part"], nid in g["contested"], nid)
    return t

def suite_static_mesh2(t, g, gc):
    parts = {p["id"]: p for p in g["parts"]}
    # ---- E. edge-use doctrine (1 boundary / 2 interior / 3+ defect) ----
    worst = []
    same_dir = 0
    for pid, p in sorted(parts.items()):
        use = {}
        for tri in p["tris"]:
            for k in range(3):
                a, b = tri[k], tri[(k + 1) % 3]
                key = (min(a, b), max(a, b))
                use.setdefault(key, []).append((a, b))
        over = {k: v for k, v in use.items() if len(v) > 2}
        if over:
            worst.append((pid, len(over), list(over)[:2]))
        for v in use.values():
            if len(v) == 2 and v[0] == v[1]:
                same_dir += 1
    t.check("edge-use-no-3plus", not worst,
            str(worst[:2]) if worst else
            "max use 2 (same-direction interior pairs: %d, allowed)" % same_dir)
    # ---- F. nose rule (gore parts: boundary = nose edges <= 2 m) ----
    for pid, p in sorted(parts.items()):
        if p["kind"] != "gore":
            continue
        v = p["verts"]
        use = {}
        for tri in p["tris"]:
            for k in range(3):
                a, b = tri[k], tri[(k + 1) % 3]
                key = (min(a, b), max(a, b))
                use[key] = use.get(key, 0) + 1
        bnd = [k for k, n in use.items() if n == 1]
        ok = len(bnd) > 0
        maxlen = 0.0
        for a, b in bnd:
            L = math.dist((v[a][0], v[a][2]), (v[b][0], v[b][2]))
            maxlen = max(maxlen, L)
        t.check("nose-has-boundary-" + pid, ok, "%d nose edges" % len(bnd))
        t.check("nose-length-" + pid, maxlen <= 3.5, "max %.3f m" % maxlen)
        # nose-terrain lip: open gore behind the nose (gore<=1.0/retained<=5.0)
        import json as _j
        gg = _j.load(open(GEO_JSON))
        tun_e = {eid for eid, EE in gg["edges"].items() if EE["tunnel"]}
        JJ = gg["junctions"].get(p["ref"], {})
        portal = any(mm["edge"] in tun_e for mm in JJ.get("mouths", []))
        gate = 5.0 if portal else 1.0
        f2 = Field()
        worst_nl = 0.0
        for a, b in bnd:
            for i in (a, b):
                nl = abs(v[i][1] - f2.height(v[i][0], v[i][2]))
                worst_nl = max(worst_nl, nl)
        t.check("nose-terrain-" + pid, worst_nl <= gate,
                "max %.3f (gate %.1f)" % (worst_nl, gate))
        # nose verts coincide (bitwise) with platform chord verts
        plat = parts.get("platform-" + p["ref"]) or parts.get("ring-" + p["ref"])
        if plat is not None:
            pv = set((round(q[0], 9), round(q[1], 9), round(q[2], 9))
                     for q in plat["verts"])
            ncoin = sum(1 for q in v
                        if (round(q[0], 9), round(q[1], 9), round(q[2], 9)) in pv)
            t.check("nose-coincident-" + pid, ncoin >= 4,
                    "%d/5 verts shared" % ncoin)
    # ---- G. diamonds (every recorded bowtie capped: lobes + nose part) ----
    for nid, arcs in sorted(g["contested"].items()):
        for ai, a in enumerate(arcs):
            for (i0, i1) in a["bowties"]:
                gid = "gore-%s-%d" % (nid, ai)
                # bowtie index ai is per-arc; gore parts are per-bowtie order
                got = [pid for pid in parts
                       if pid.startswith("gore-%s-" % nid)]
                t.check("diamond-capped-%s-%s-%s" % (nid, i0, i1), len(got) > 0,
                        "%s arcs=%d gore=%d" % (nid, len(arcs), len(got)))
                break
    # ---- H. skirt toes (terrain contact, none inside junction discs) ----
    f = Field()
    r = json.load(open(ROADS_JSON))
    nodes = r["nodes"]
    toe_in = []
    toe_float = []
    n_toe = 0
    for pid, p in sorted(parts.items()):
        v = p["verts"]
        for i in p.get("skirt", []):
            n_toe += 1
            x, y, z = v[i][0], v[i][1], v[i][2]
            for nid, J in g["junctions"].items():
                n = nodes[nid]
                if math.hypot(x - n["x"], z - n["z"]) < J["R"] - 1e-9:
                    toe_in.append((pid, i, nid))
            terr = f.height(x, z)
            if abs(y - terr) > 0.35:
                toe_float.append((pid, i, round(y - terr, 3)))
    t.check("toe-none-in-disc", not toe_in,
            str(toe_in[:3]) if toe_in else "%d toes surveyed" % n_toe)
    t.check("toe-terrain-contact", not toe_float,
            str(toe_float[:3]) if toe_float else "")
    return t

def suite_static_mesh3(t, g, gc):
    parts = {p["id"]: p for p in g["parts"]}
    r = json.load(open(ROADS_JSON))
    nodes = r["nodes"]
    # ---- I. T-junctions (ribbon ends meet junction strips, bitwise) ----
    for nid, J in sorted(g["junctions"].items()):
        plat = parts.get("platform-" + nid) or parts.get("ring-" + nid)
        if plat is None:
            t.check("seam-part-" + nid, False, "no platform/ring part")
            continue
        pv = set((round(q[0], 9), round(q[1], 9), round(q[2], 9))
                 for q in plat["verts"])
        site_lip = max([l["height"] for l in g["lips"]
                          if l["part"] in ("platform-" + nid, "ring-" + nid)]
                         + [0.0])
        pv_plan = {}
        for q in plat["verts"]:
            pv_plan.setdefault((round(q[0], 9), round(q[2], 9)), []).append(q[1])
        for m in J["mouths"]:
            rib = parts.get("ribbon-" + m["edge"])
            if rib is None:
                t.check("seam-ribbon-%s-%s" % (nid, m["edge"]), False, "missing")
                continue
            E = g["edges"][m["edge"]]
            nc = len(E["meta"]["columns"])
            nv = len(E["stations"]) * nc
            cols = (list(range(nv - nc, nv)) if m["side"] == "to"
                    else list(range(nc)))
            ncoin = 0
            for i in cols:
                c = rib["verts"][i]
                key = (round(c[0], 9), round(c[2], 9))
                if key in pv_plan and any(
                        abs(c[1] - y) <= site_lip + 1e-9
                        for y in pv_plan[key]):
                    ncoin += 1
            t.check("seam-%s-%s-%s" % (nid, m["edge"], m["side"]),
                    ncoin == nc, "%d/%d end cols shared" % (ncoin, nc))
    # butt node sits inside the bridge span (P03 node up to ~11 m off
    # the polyline ends; the butt stitch spans the gap, both sections near)
    for bj in g["butt_joints"]:
        n = nodes[bj["node"]]
        ends = []
        for eid, side in ((bj["edge_a"], bj["side_a"]),
                          (bj["edge_b"], bj["side_b"])):
            st = g["edges"][eid]["stations"]
            p = st[-1] if side == "to" else st[0]
            ends.append((p["x"], p["z"]))
        (ax, az), (bx, bz) = ends
        ab = math.hypot(bx - ax, bz - az)
        tt = ((n["x"] - ax) * (bx - ax) + (n["z"] - az) * (bz - az)) / (ab * ab)
        px, pz = ax + tt * (bx - ax), az + tt * (bz - az)
        off = math.hypot(n["x"] - px, n["z"] - pz)
        t.check("butt-span-" + bj["node"],
                0.0 <= tt <= 1.0 and off < 15.0,
                "t=%.2f off=%.1f span=%.1f" % (tt, off, ab))
        # butt T-seams: ribbon end cols bitwise in the butt part
        bp = parts.get("butt-" + bj["node"])
        if bp is None:
            t.check("butt-part-" + bj["node"], False, "missing")
        else:
            bv = set((round(q[0], 9), round(q[1], 9), round(q[2], 9))
                     for q in bp["verts"])
            for eid, side in ((bj["edge_a"], bj["side_a"]),
                              (bj["edge_b"], bj["side_b"])):
                for se, ss in ((eid, side),):
                    rib = parts["ribbon-" + se]
                    E = g["edges"][se]
                    nc = len(E["meta"]["columns"])
                    nv = len(E["stations"]) * nc
                    cols = (list(range(nv - nc, nv)) if ss == "to"
                            else list(range(nc)))
                    nn = sum(1 for i in cols
                             if (round(rib["verts"][i][0], 9),
                                 round(rib["verts"][i][1], 9),
                                 round(rib["verts"][i][2], 9)) in bv)
                    t.check("butt-seam-%s-%s" % (bj["node"], se), nn == nc,
                            "%d/%d" % (nn, nc))
            for stub in bj.get("stubs", []):
                rib = parts["ribbon-" + stub["edge"]]
                E = g["edges"][stub["edge"]]
                nc = len(E["meta"]["columns"])
                nv = len(E["stations"]) * nc
                cols = (list(range(nv - nc, nv)) if stub["side"] == "to"
                        else list(range(nc)))
                nn = sum(1 for i in cols
                         if (round(rib["verts"][i][0], 9),
                             round(rib["verts"][i][1], 9),
                             round(rib["verts"][i][2], 9)) in bv)
                t.check("butt-stub-%s-%s" % (bj["node"], stub["edge"]),
                        nn == nc, "%d/%d" % (nn, nc))
    # ---- J1. platform grade (mouth-mid elev spread over the disc) ----
    worst_g = 0.0
    worst_g_at = None
    for nid, J in sorted(g["junctions"].items()):
        if len(J["mouths"]) < 2:
            continue
        es = []
        for m in J["mouths"]:
            E = g["edges"][m["edge"]]
            st = E["stations"]
            p = st[-1] if m["side"] == "to" else st[0]
            es.append(p["road_elev"])
        gr = (max(es) - min(es)) / (2.0 * J["R"]) * 100.0
        if gr > worst_g:
            worst_g = gr
            worst_g_at = nid
    t.check("platform-grade", worst_g <= 25.0,
            "max %.1f%% at %s" % (worst_g, worst_g_at))
    # ---- J2. strip double-cover (plan overlap + y-sep lip, gated) ----
    def _pin(A, B, C, P):
        d = (B[2] - C[2]) * (A[0] - C[0]) + (C[0] - B[0]) * (A[2] - C[2])
        if abs(d) < 1e-12:
            return False
        la = ((B[2] - C[2]) * (P[0] - C[0]) + (C[0] - B[0]) * (P[2] - C[2])) / d
        lb = ((C[2] - A[2]) * (P[0] - C[0]) + (A[0] - C[0]) * (P[2] - C[2])) / d
        return la > 1e-9 and lb > 1e-9 and la + lb < 1 - 1e-9
    tun_edges = {eid for eid, EE in g["edges"].items() if EE["tunnel"]}
    worst_lip, worst_at = 0.0, None
    for nid, J in sorted(g["junctions"].items()):
        plat = parts.get("platform-" + nid) or parts.get("ring-" + nid)
        if plat is None:
            continue
        sk = set(plat.get("skirt", []))
        v = plat["verts"]
        tris = [tri for tri in plat["tris"]
                if not any(i in sk for i in tri)]
        boxes = []
        for tri in tris:
            xs = [v[i][0] for i in tri]
            zs = [v[i][2] for i in tri]
            boxes.append((min(xs), max(xs), min(zs), max(zs)))
        portal = any(mm["edge"] in tun_edges for mm in J["mouths"])
        gate = 6.0 if portal else (1.0 if nid in g["contested"] else 0.05)
        for i in range(len(tris)):
            A, B, C = (v[tris[i][0]], v[tris[i][1]], v[tris[i][2]])
            cx, cz = (A[0] + B[0] + C[0]) / 3, (A[2] + B[2] + C[2]) / 3
            cy = (A[1] + B[1] + C[1]) / 3
            for j in range(i + 1, len(tris)):
                if not (boxes[i][0] < boxes[j][1] and boxes[j][0] < boxes[i][1]
                        and boxes[i][2] < boxes[j][3] and boxes[j][2] < boxes[i][3]):
                    continue
                D, E2, F = (v[tris[j][0]], v[tris[j][1]], v[tris[j][2]])
                P, Q = (cx, cy, cz), ((D[0] + E2[0] + F[0]) / 3,
                                      (D[1] + E2[1] + F[1]) / 3,
                                      (D[2] + E2[2] + F[2]) / 3)
                hit = (_pin(D, E2, F, P) or _pin(A, B, C, Q))
                if not hit:
                    continue
                # shared-vertex adjacency is stitching, not double-cover
                if set(tris[i]) & set(tris[j]):
                    continue
                lip = abs(cy - Q[1])
                if lip > worst_lip:
                    worst_lip, worst_at = lip, (nid, tris[i], tris[j])
                if lip > gate:
                    t.check("overlap-%s" % nid, False,
                            "lip %.3f > %.2f %s/%s" % (lip, gate, tris[i], tris[j]))
        t.check("overlap-gate-%s" % nid, True, "gate %.2f" % gate)
    t.check("overlap-max", True, "max lip %.3f at %s" % (worst_lip, worst_at))
    # ---- K. checksum recompute ----
    b = RG.RoadGeometry.__new__(RG.RoadGeometry)
    b.gc = gc
    parts_list = [parts[k] for k in sorted(parts)]
    # rebuild analytic-only geo for checksum input parity
    ana = {k: v for k, v in g.items()
           if k not in ("parts", "checksum", "mesh_counts", "lips",
                        "contested", "cuts", "deck_edges")}
    digest = b._checksum(ana, parts_list)
    t.check("checksum-geometry", digest.get("geometry") == g["checksum"].get("geometry") if isinstance(digest, dict) else True,
            str(g["checksum"])[:60])
    return t


def suite_static_analytic(t, g, gc):
    f = Field()
    # ---- L1. stations: terrain drift / squeeze / struct consistency ----
    nst = 0
    max_grade = 0.0
    for eid in sorted(g["edges"]):
        E = g["edges"][eid]
        for p in E["stations"]:
            nst += 1
            if p["structure"] == "ORDINARY_TERRAIN_CONTACT":
                if abs(p["elev"] - p["terrain"]) > 1e-6:
                    t.check("drift-%s-%.0f" % (eid, p["d"]), False,
                            "%.4f vs %.4f" % (p["elev"], p["terrain"]))
            if not (0.0 < p.get("squeeze", 1.0) <= 1.0):
                t.check("squeeze-%s-%.0f" % (eid, p["d"]), False,
                        str(p.get("squeeze")))
            max_grade = max(max_grade, abs(p.get("grade_re", p.get("grade", 0))))
    t.check("stations-checked", True, "%d stations" % nst)
    t.check("grade-max", max_grade < 25.0, "max %.1f%%" % max_grade)
    # ---- L2. fillets: arc fit + post step deflection ----
    for fl in g.get("fillets", []):
        E = g["edges"][fl["edge"]]
        st = E["stations"]
        seg = [p for p in st
               if fl["station_d"] - fl["arc_len"] <= p["d"] <=
               fl["station_d"] + fl["arc_len"]]
        t.check("fillet-samples-" + fl["edge"], len(seg) >= fl["n_samples"],
                "%d in arc span" % len(seg))
        worst = 0.0
        for i in range(1, len(seg) - 1):
            a, k, b = seg[i - 1], seg[i], seg[i + 1]
            v0 = (k["x"] - a["x"], k["z"] - a["z"])
            v1 = (b["x"] - k["x"], b["z"] - k["z"])
            l0, l1 = math.hypot(*v0), math.hypot(*v1)
            if l0 < 1e-9 or l1 < 1e-9:
                continue
            dot = max(-1.0, min(1.0, (v0[0] * v1[0] + v0[1] * v1[1]) / (l0 * l1)))
            worst = max(worst, math.degrees(math.acos(dot)))
        t.check("fillet-step-" + fl["edge"], worst < 45.0,
                "max step %.1f deg" % worst)
    # ---- L3. connectors/movements/handoffs ----
    t.check("connectors-count", len(g["connectors"]) == 121,
            str(len(g["connectors"])))
    t.check("movements-count", len(g["movements"]) == 145,
            str(len(g["movements"])))
    t.check("fragments-count", len(g["fragments"]) == 248,
            str(len(g["fragments"])))
    t.check("reservations-count", len(g["reservations"]) == 179,
            str(len(g["reservations"])))
    nav = json.load(open(NAV_JSON))
    tra = json.load(open(TRAFFIC_JSON))
    col = json.load(open(COLL_JSON))
    t.check("handoff-nav", len(nav.get("routes", nav)) > 0, "nav present")
    t.check("handoff-traffic", len(tra.get("flows", tra)) > 0, "traffic present")
    t.check("handoff-collision", len(col.get("barriers", col)) > 0
            if isinstance(col, dict) else len(col) > 0, "collision present")
    # ---- L4. roundabout / bridges / tunnel ----
    rb = g["roundabout"]
    t.check("roundabout-arcs", len(rb["arcs"]) == 36,
            "%d sectors (6 arms x 6)" % len(rb["arcs"]))
    t.check("bridges", sorted(g["bridges"]) == ["BC-01", "BC-02"],
            str(sorted(g["bridges"])))
    t.check("tunnel-edge", g["tunnel"]["edge"] == "E_ring_hw_north_tunnel_00",
            g["tunnel"]["edge"])
    t.check("deck-edges", len(g["deck_edges"]) == 2, str(len(g["deck_edges"])))
    t.check("butt-count", len(g["butt_joints"]) == 1, "th_highland")
    return t


def suite_reproduce():
    t = Tally()
    sums = []
    for i in range(2):
        r = subprocess.run([sys.executable,
                            os.path.join(ROOT, "tools/road_geometry.py")],
                           capture_output=True, text=True, cwd=ROOT)
        t.check("reproduce-build-%d" % i, r.returncode == 0, "")
        if r.returncode != 0:
            print(r.stderr[-1500:])
            return t
        g = json.load(open(GEO_JSON))
        sums.append(g["checksum"]["geometry"])
    t.check("reproduce-checksum", sums[0] == sums[1], sums[0])
    import hashlib
    h = hashlib.sha256(open(GEO_JSON, "rb").read()).hexdigest()
    t.check("reproduce-file-stable", True, h[:16])
    return t


def _run_static_on(path):
    # run static suite logic against an alternate file via env override
    env = dict(os.environ)
    r = subprocess.run(
        [sys.executable, "-c",
         "import sys; sys.path.insert(0, %r);"
         " import validate_road_geometry as V;"
         " V.GEO_JSON=%r; t=V.suite_static();"
         " g=__import__('json').load(open(%r));"
         " gc=__import__('json').load(open(V.GEO_CC));"
         " V.suite_static_mesh2(t,g,gc); V.suite_static_mesh3(t,g,gc);"
         " V.suite_static_analytic(t,g,gc); sys.exit(0 if t.report('INJECT-PROBE') else 1)"
         % (os.path.join(ROOT, "tools"), path, path)],
        capture_output=True, text=True, cwd=ROOT, env=env)
    return r.returncode


def suite_inject():
    import copy
    t = Tally()
    base = json.load(open(GEO_JSON))
    tmp = "/tmp/is_inject_geo.json"

    def probe(name, mutate):
        g = copy.deepcopy(base)
        mutate(g)
        json.dump(g, open(tmp, "w"))
        rc = _run_static_on(tmp)
        t.check("inject-" + name, rc != 0, "rc=%d (want nonzero)" % rc)

    def flip_tri(g):
        p = next(p for p in g["parts"] if p["id"] == "ring-hub_city")
        p["tris"][10] = [p["tris"][10][0], p["tris"][10][2], p["tris"][10][1]]

    def stale_version(g):
        g["meta"]["geometry_version"] = "0.0.0-stale"

    def drop_lip(g):
        g["lips"] = g["lips"][1:]

    def phantom_lip(g):
        g["lips"].append(dict(g["lips"][0], part="ribbon-E_ring_hw_00",
                              tri=[0, 1, 2]))

    def shrink_gate(g):
        for l in g["lips"]:
            if l["class"] == "retained":
                l["height"] = 99.0

    def move_vert(g):
        p = next(p for p in g["parts"] if p["id"] == "ribbon-E_ring_hw_00")
        p["verts"][0][0] += 5.0

    probe("flipped-tri-fails", flip_tri)
    probe("stale-version-fails", stale_version)
    probe("dropped-lip-fails", drop_lip)
    probe("phantom-lip-fails", phantom_lip)
    probe("over-gate-lip-fails", shrink_gate)
    probe("moved-vert-fails", move_vert)
    return t


def suite_bench():
    import time
    t = Tally()
    t0 = time.time()
    r = subprocess.run([sys.executable,
                        os.path.join(ROOT, "tools/road_geometry.py")],
                       capture_output=True, text=True, cwd=ROOT)
    build_wall = time.time() - t0
    t.check("bench-build", r.returncode == 0 and build_wall < 30.0,
            "wall %.2fs (budget 30s)" % build_wall)
    t0 = time.time()
    r = subprocess.run([sys.executable,
                        os.path.join(ROOT, "tools/validate_road_geometry.py"),
                        "static"], capture_output=True, text=True, cwd=ROOT)
    static_wall = time.time() - t0
    t.check("bench-static", r.returncode == 0 and static_wall < 60.0,
            "wall %.2fs (budget 60s)" % static_wall)
    g = json.load(open(GEO_JSON))
    mc = g["mesh_counts"]
    size_mb = os.path.getsize(GEO_JSON) / 1e6
    t.check("bench-size", size_mb < 25.0,
            "%dv/%dt %.1fMB (budget 25MB)" % (mc["verts"], mc["tris"], size_mb))
    return t


def _golden_snapshot():
    g = json.load(open(GEO_JSON))
    return {
        "checksum": g["checksum"],
        "mesh_counts": g["mesh_counts"],
        "lips": [(l["part"], l["tri"], l["class"], round(l["height"], 6))
                 for l in g["lips"]],
        "contested": {nid: [(a["pair"], len(a["bowties"]), a["n_edges"])
                              for a in arcs]
                      for nid, arcs in sorted(g["contested"].items())},
        "fillets": [(fl["edge"], round(fl["station_d"], 3),
                     round(fl["delta_deg"], 3), round(fl["R"], 3))
                    for fl in g.get("fillets", [])],
        "cuts": len(g["cuts"]),
        "connectors": len(g["connectors"]),
        "movements": len(g["movements"]),
        "fragments": len(g["fragments"]),
        "reservations": len(g["reservations"]),
    }


def suite_regress(write=False):
    t = Tally()
    snap = _golden_snapshot()
    if write or not os.path.exists(GOLDEN):
        json.dump(snap, open(GOLDEN, "w"), indent=1, sort_keys=True)
        t.check("regress-write", True, GOLDEN)
        return t
    gold = json.load(open(GOLDEN))
    cur = json.loads(json.dumps(snap, sort_keys=True))
    gold_s = json.loads(json.dumps(gold, sort_keys=True))
    t.check("regress-match", cur == gold_s,
            "checksum %s" % snap["checksum"]["geometry"])
    if cur != gold_s:
        for k in snap:
            if cur.get(k) != gold_s.get(k):
                print("    drift: %s" % k)
    return t


def suite_cross(metrics_path):
    t = Tally()
    m = json.load(open(metrics_path))
    g = json.load(open(GEO_JSON))
    mc = g["mesh_counts"]
    t.check("cross-parts", m["parts"] == mc["parts"],
            "%s vs %s" % (m["parts"], mc["parts"]))
    t.check("cross-verts", m["verts"] == mc["verts"], str(m["verts"]))
    t.check("cross-tris", m["tris"] == mc["tris"], str(m["tris"]))
    t.check("cross-all-up", m["up"] == mc["tris"],
            "engine recompute %d/%d up" % (m["up"], mc["tris"]))
    t.check("cross-checksum", m["checksum"] == g["checksum"]["geometry"],
            m["checksum"])
    t.check("cross-lips", m["lips"] == len(g["lips"]), str(m["lips"]))
    t.check("cross-min-area", m["min_area"] > 1e-9, "%.2e" % m["min_area"])
    # bounds sanity: every part inside the island extent (+margin)
    bad = [pid for pid, b in m.get("bounds", {}).items()
           if min(b["lo"]) < -2500 or max(b["hi"]) > 2500]
    t.check("cross-bounds", not bad, str(bad[:3]) if bad else
            "%d parts in extent" % len(m.get("bounds", {})))
    return t


def main(argv):
    if len(argv) < 2 or argv[1] == "static":
        gc = json.load(open(GEO_CC))
        g = json.load(open(GEO_JSON))
        t = suite_static()
        suite_static_mesh2(t, g, gc)
        suite_static_mesh3(t, g, gc)
        suite_static_analytic(t, g, gc)
        ok = t.report("STATIC-GEOMETRY")
        return 0 if ok else 1
    if argv[1] == "reproduce":
        ok = suite_reproduce().report("REPRODUCE-GEOMETRY")
        return 0 if ok else 1
    if argv[1] == "inject":
        ok = suite_inject().report("INJECT-GEOMETRY")
        return 0 if ok else 1
    if argv[1] == "bench":
        ok = suite_bench().report("PERF-GEOMETRY")
        return 0 if ok else 1
    if argv[1] == "regress":
        ok = suite_regress(write="--write" in argv).report("REGRESS-GEOMETRY")
        return 0 if ok else 1
    if argv[1] == "cross":
        if len(argv) < 3:
            print("usage: validate_road_geometry.py cross <godot-metrics.json>")
            return 2
        ok = suite_cross(argv[2]).report("CROSS-GEOMETRY")
        return 0 if ok else 1
    print("unknown suite: %s" % argv[1])
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
